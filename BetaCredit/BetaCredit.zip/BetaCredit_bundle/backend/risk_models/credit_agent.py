"""
risk_models.credit_agent
========================

CreditDecisionAgent — the orchestrator that takes a single borrower row
(or a DataFrame of borrowers) and produces a complete credit decision
with PD, LGD, EAD, IFRS 9 stage, four ECL measures, an APPROVE / REVIEW /
DECLINE recommendation, a one-line rationale, and a confidence band.

This agent stitches together the existing per-component suites
(PDModelSuite, LGDModelSuite, EADModelSuite, SICREngine) so a downstream
consumer — a script, an API endpoint, or a Claude Skill — can ask a
single question and get a single answer per loan.

Quick start
-----------
    >>> from risk_models import CreditDecisionAgent
    >>> agent = CreditDecisionAgent()
    >>> decision = agent.decide_one({
    ...     "asset_class": "sme_unsecured",
    ...     "bureau_score": 620,
    ...     "cashflow_coverage": 1.3,
    ...     "ltv": 0.0,
    ...     "loan_amount": 50_000,
    ...     "loan_term_months": 36,
    ...     "default_flag": 0,
    ... })
    >>> print(decision.summary())

Or against the parquet produced by notebook 00:

    >>> import pandas as pd
    >>> df = pd.read_parquet("df_all.parquet")
    >>> result = agent.decide_portfolio(df)
    >>> result.summary_table()
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any

import numpy as np
import pandas as pd

from risk_models.asset_classes import AssetClass, ASSET_CLASS_CONFIG
from risk_models.pd_models  import PDModelSuite, PDScore
from risk_models.lgd_models import LGDModelSuite, LGDEstimate
from risk_models.ead_sicr   import EADModelSuite, SICREngine, EADEstimate, SICRAssessment

__all__ = [
    "CreditDecisionAgent",
    "CreditDecision",
    "PortfolioDecisionResult",
    "DecisionRecommendation",
]

_log = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Decision types
# ─────────────────────────────────────────────────────────────────────────────

class DecisionRecommendation(str, Enum):
    """Top-level decision the agent produces per loan."""
    APPROVE = "APPROVE"        # Low risk, automatic green light
    REVIEW  = "REVIEW"         # Borderline; underwriter should look
    DECLINE = "DECLINE"        # High risk, automatic red light


@dataclass
class CreditDecision:
    """
    The complete credit-decision record for one borrower.

    The four ECL / RWA fields are computed as:
        ecl_12m    = pd_floored × lgd_be × ead         (IFRS 9 12-month)
        ecl_life   = pd_pit_3y  × lgd_be × ead         (IFRS 9 lifetime)
        ecl_stress = pd_pit_3y  × lgd_dt × ead         (downturn lifetime)
        rwa        = capital_pd × lgd_dt × ead × 12.5  (Basel IV)
    """
    borrower_id:        str
    asset_class:        str

    # PD
    pd_pit_1y:          float
    pd_ttc_1y:          float
    pd_pit_3y:          float
    pd_floored:         float
    capital_pd:         float
    risk_band:          str

    # LGD / EAD
    lgd_be:             float
    lgd_dt:             float
    ead:                float

    # IFRS 9
    stage:              str       # 'stage_1' | 'stage_2' | 'stage_3'
    sicr_triggers:      list[str] # e.g. ['rel_pd_125pct_gt_100pct']

    # ECL / RWA
    ecl_12m:            float
    ecl_life:           float
    ecl_stress:         float
    rwa:                float

    # Top-level decision
    recommendation:     DecisionRecommendation
    rationale:          str
    confidence:         float     # 0-1, how sure the agent is

    # Cohort metadata (None if borrower row has no origination_date)
    vintage_quarter:    str | None = None

    # v1.2 LGD decomposition — surfaces why each LGD is what it is
    lgd_source:         str  = "asset_class_default"   # observed / computed_from_components / asset_class_default
    lgd_components:     dict = field(default_factory=dict)

    # Provenance
    inputs:             dict      = field(default_factory=dict)

    def summary(self) -> str:
        """Human-readable one-paragraph summary, suitable for printing in a notebook."""
        lines = [
            f"Borrower {self.borrower_id} · {self.asset_class}",
            f"  Recommendation:  {self.recommendation.value}   "
            f"(confidence {self.confidence:.0%})",
            f"  Rationale:       {self.rationale}",
            f"  Risk band:       {self.risk_band}  "
            f"|  IFRS 9 stage: {self.stage}",
            f"  PD 12m:          {self.pd_pit_1y:6.2%}    "
            f"PD lifetime: {self.pd_pit_3y:6.2%}",
            f"  LGD:             {self.lgd_be:6.2%}    "
            f"(downturn {self.lgd_dt:.2%}, source={self.lgd_source})",
            f"  EAD:             £{self.ead:>10,.0f}",
            f"  ECL 12m:         £{self.ecl_12m:>10,.0f}   "
            f"Lifetime: £{self.ecl_life:,.0f}   Stress: £{self.ecl_stress:,.0f}",
            f"  RWA:             £{self.rwa:>10,.0f}",
        ]
        if self.sicr_triggers:
            lines.append(f"  SICR triggers:   {', '.join(self.sicr_triggers)}")
        return "\n".join(lines)

    def to_dict(self) -> dict:
        """Plain-dict serialisation (enums → strings) for JSON / dataframe use."""
        d = asdict(self)
        d["recommendation"] = self.recommendation.value
        return d


@dataclass
class PortfolioDecisionResult:
    """
    Output of agent.decide_portfolio(df). Holds the per-loan decisions plus
    portfolio-level totals so a consumer can either drill into individual
    cases or quote headline numbers directly.
    """
    decisions:       list[CreditDecision]
    n_loans:         int
    n_approve:       int
    n_review:        int
    n_decline:       int
    total_ead:       float
    total_ecl_12m:   float
    total_ecl_life:  float
    total_ecl_stress:float
    total_rwa:       float
    stage_counts:    dict[str, int]     # {'stage_1': N1, 'stage_2': N2, 'stage_3': N3}
    by_asset_class:  pd.DataFrame       # one row per asset class with subtotals

    def summary_table(self) -> str:
        """Top-of-page summary suitable for a notebook print or a Skill response."""
        lines = [
            "Portfolio Decision Summary",
            "=" * 58,
            f"  Loans scored:       {self.n_loans:>10,}",
            f"  APPROVE:            {self.n_approve:>10,}  "
            f"({self.n_approve/self.n_loans*100:5.1f}%)",
            f"  REVIEW:             {self.n_review:>10,}  "
            f"({self.n_review/self.n_loans*100:5.1f}%)",
            f"  DECLINE:            {self.n_decline:>10,}  "
            f"({self.n_decline/self.n_loans*100:5.1f}%)",
            "",
            f"  Stage 1:            {self.stage_counts.get('stage_1', 0):>10,}",
            f"  Stage 2:            {self.stage_counts.get('stage_2', 0):>10,}",
            f"  Stage 3:            {self.stage_counts.get('stage_3', 0):>10,}",
            "",
            f"  Total EAD:          £{self.total_ead:>13,.0f}",
            f"  Total ECL (12m):    £{self.total_ecl_12m:>13,.0f}",
            f"  Total ECL (life):   £{self.total_ecl_life:>13,.0f}",
            f"  Total ECL (stress): £{self.total_ecl_stress:>13,.0f}",
            f"  Total RWA:          £{self.total_rwa:>13,.0f}",
            "=" * 58,
        ]
        return "\n".join(lines)

    def to_dataframe(self) -> pd.DataFrame:
        """Flatten all decisions into a single DataFrame."""
        return pd.DataFrame([d.to_dict() for d in self.decisions])


# ─────────────────────────────────────────────────────────────────────────────
# Configuration: how to decide
# ─────────────────────────────────────────────────────────────────────────────

# Default thresholds for the APPROVE / REVIEW / DECLINE recommendation.
# These are per-asset-class so that, for instance, a 5% PD is "high" for
# a mortgage but typical for an SME unsecured loan.
#
# Each tuple is (approve_below, decline_above) on pd_pit_1y. Anything
# in between is REVIEW. The recommendation is also overridden to DECLINE
# whenever the loan is already at IFRS 9 Stage 3 (credit-impaired).
_DEFAULT_THRESHOLDS = {
    "sme_unsecured":        (0.030, 0.120),
    "sme_secured":          (0.020, 0.090),
    "consumer_unsecured":   (0.035, 0.140),
    "residential_mortgage": (0.008, 0.040),
    "buy_to_let":           (0.012, 0.060),
    "motor_finance":        (0.025, 0.100),
    "invoice_finance":      (0.020, 0.080),
    "asset_finance":        (0.025, 0.100),
}


# ─────────────────────────────────────────────────────────────────────────────
# The agent itself
# ─────────────────────────────────────────────────────────────────────────────

class CreditDecisionAgent:
    """
    Orchestrates BetaCredit's PD, LGD, EAD, and SICR engines to produce a
    complete decision for one loan or a portfolio.

    Parameters
    ----------
    pd_suite, lgd_suite, ead_suite, sicr_engine
        Optionally inject pre-trained / pre-configured suites. If omitted,
        fresh defaults are constructed on first use.
    thresholds : dict[str, tuple[float, float]] | None
        Per-asset-class (approve_below, decline_above) thresholds on
        12-month PD. Defaults are reasonable UK-lending starting points;
        a real lender should override these from their underwriting policy.
    """

    def __init__(
        self,
        pd_suite:    PDModelSuite  | None = None,
        lgd_suite:   LGDModelSuite | None = None,
        ead_suite:   EADModelSuite | None = None,
        sicr_engine: SICREngine    | None = None,
        thresholds:  dict[str, tuple[float, float]] | None = None,
        pd_model_path: str | None = "pd_models.pkl",
    ) -> None:
        """
        Parameters (in addition to those documented above):
        ----------
        pd_model_path
            Path to a serialised PDModelSuite (produced by notebook 02 via
            `pd_suite.save(...)`). If the file exists and pd_suite was not
            passed explicitly, it is loaded automatically — this is how the
            agent picks up a real-data fit without you having to plumb it
            through. Pass None to disable auto-loading; pass an explicit
            pd_suite to override entirely.
        """
        # If the caller didn't pass an explicit PD suite, try loading one
        # from disk. This is the integration point that makes a retrained
        # model "just work" across the suite.
        if pd_suite is None and pd_model_path is not None:
            from pathlib import Path
            p = Path(pd_model_path)
            if p.exists():
                try:
                    pd_suite = PDModelSuite.load(p)
                    _log.info(
                        "CreditDecisionAgent loaded PD suite from %s "
                        "(source=%s, n_rows=%s)",
                        p, pd_suite.fit_provenance.get("source"),
                        pd_suite.fit_provenance.get("n_rows"),
                    )
                except Exception as e:
                    _log.warning(
                        "CreditDecisionAgent failed to load %s, falling "
                        "back to synthetic PD suite: %s", p, e,
                    )
                    pd_suite = None

        self.pd_suite    = pd_suite    or PDModelSuite()
        self.lgd_suite   = lgd_suite   or LGDModelSuite()
        self.ead_suite   = ead_suite   or EADModelSuite()
        self.sicr_engine = sicr_engine or SICREngine()
        self.thresholds  = thresholds  or _DEFAULT_THRESHOLDS

    @property
    def pd_provenance(self) -> dict:
        """Where the agent's PD model came from (synthetic vs real fit)."""
        return self.pd_suite.fit_provenance if hasattr(self.pd_suite, "fit_provenance") \
            else {"source": "unknown"}

    # ── Single loan ────────────────────────────────────────────────────────
    def decide_one(
        self,
        borrower: dict | pd.Series,
        borrower_id: str | None = None,
    ) -> CreditDecision:
        """
        Produce a full credit decision for a single borrower record.

        Parameters
        ----------
        borrower
            Dict or pandas Series with at least the required canonical
            fields: asset_class, bureau_score, cashflow_coverage, ltv,
            loan_amount, loan_term_months, default_flag.
        borrower_id
            Optional identifier; defaults to "loan_<hash>" derived from
            the input dict so the same loan always gets the same ID.
        """
        # Normalise the input to a plain dict
        if isinstance(borrower, pd.Series):
            row = borrower.to_dict()
        else:
            row = dict(borrower)

        ac_str = self._resolve_asset_class(row.get("asset_class"))
        ac     = AssetClass(ac_str)
        bid    = borrower_id or row.get("borrower_id") or f"loan_{abs(hash(frozenset(str(v) for v in row.values()))) % 10**8:08d}"

        # ── PD: use the model suite but rescale by the borrower's actual
        # bureau_score and cashflow_coverage so different real borrowers
        # in the same asset class receive different PDs. The suite alone
        # generates synthetic features per call; we anchor to the real
        # features by applying a logit adjustment.
        base_pd = self.pd_suite.score(ac, borrower_id=bid)
        adjusted_pd = self._adjust_pd_for_borrower(base_pd, row, ac_str)

        # ── EAD first (needed by LGD decomposition for collateral scaling)
        ead_est = self.ead_suite.estimate(ac)
        # If the row carries its own loan_amount, prefer that for EAD
        # rather than the suite's average (suite produces a typical EAD
        # for the asset class, not this specific facility).
        ead_value = float(row.get("loan_amount", ead_est.ead) or ead_est.ead)

        # ── LGD (v1.2: pass row + ead so per-loan components flow through)
        # When the row has lgd_observed it overrides; when it has any of
        # collateral_value / cure_prob / recovery_costs / time_to_resolution_months
        # they engage the component path; otherwise asset-class defaults apply.
        lgd_est = self.lgd_suite.estimate(ac, row=row, ead=ead_value)

        # ── SICR / IFRS 9 stage
        # pd_orig = pd_ttc_1y as a proxy for origination-time PD
        # pd_curr = pd_pit_1y as the latest point-in-time PD
        # If the row has dpd / forbearance_flag, use them; else assume clean.
        sicr = self.sicr_engine.assess(
            ac,
            pd_orig=adjusted_pd.pd_ttc_1y,
            pd_curr=adjusted_pd.pd_pit_1y,
            flags={
                "days_past_due":    int(row.get("dpd", 0) or 0),
                "forbearance_flag": bool(row.get("forbearance_flag", False)),
            },
        )

        # ── ECL / RWA arithmetic (the four canonical measures)
        ecl_12m    = adjusted_pd.pd_floored * lgd_est.lgd_best_estimate * ead_value
        ecl_life   = adjusted_pd.pd_pit_3y  * lgd_est.lgd_best_estimate * ead_value
        ecl_stress = adjusted_pd.pd_pit_3y  * lgd_est.lgd_downturn      * ead_value
        rwa        = adjusted_pd.capital_pd * lgd_est.lgd_downturn      * ead_value * 12.5

        # ── Recommendation
        recommendation, rationale, confidence = self._recommend(
            adjusted_pd, sicr, ac_str, row,
        )

        # Extract vintage_quarter from the row when present. Accept either
        # an already-derived string ("2023Q3") or an origination_date that
        # we coerce here.
        vintage = row.get("vintage_quarter")
        if not vintage and row.get("origination_date") is not None:
            try:
                vintage = str(pd.Timestamp(row["origination_date"]).to_period("Q"))
            except (ValueError, TypeError):
                vintage = None
        if isinstance(vintage, float) and pd.isna(vintage):
            vintage = None

        return CreditDecision(
            borrower_id     = bid,
            asset_class     = ac_str,
            pd_pit_1y       = adjusted_pd.pd_pit_1y,
            pd_ttc_1y       = adjusted_pd.pd_ttc_1y,
            pd_pit_3y       = adjusted_pd.pd_pit_3y,
            pd_floored      = adjusted_pd.pd_floored,
            capital_pd      = adjusted_pd.capital_pd,
            risk_band       = adjusted_pd.risk_band,
            lgd_be          = lgd_est.lgd_best_estimate,
            lgd_dt          = lgd_est.lgd_downturn,
            ead             = ead_value,
            stage           = sicr.stage,
            sicr_triggers   = list(sicr.triggers_fired) if sicr.triggers_fired else [],
            ecl_12m         = float(ecl_12m),
            ecl_life        = float(ecl_life),
            ecl_stress      = float(ecl_stress),
            rwa             = float(rwa),
            recommendation  = recommendation,
            rationale       = rationale,
            confidence      = confidence,
            vintage_quarter = vintage,
            lgd_source      = lgd_est.source,
            lgd_components  = dict(lgd_est.components) if lgd_est.components else {},
            inputs          = row,
        )

    # ── Portfolio ──────────────────────────────────────────────────────────
    def decide_portfolio(
        self,
        df: pd.DataFrame,
        progress: bool = False,
    ) -> PortfolioDecisionResult:
        """
        Score every loan in a DataFrame (e.g. df_all.parquet from
        notebook 00) and return per-loan + portfolio-level results.
        """
        decisions: list[CreditDecision] = []
        n = len(df)
        for idx, row in df.iterrows():
            bid = f"PORT-{idx:06d}"
            decisions.append(self.decide_one(row, borrower_id=bid))
            if progress and (idx + 1) % max(1, n // 20) == 0:
                pct = (idx + 1) / n * 100
                _log.info("decide_portfolio progress: %.0f%% (%d/%d)", pct, idx + 1, n)

        # ── Aggregate
        recs = [d.recommendation for d in decisions]
        stage_counts: dict[str, int] = {}
        for d in decisions:
            stage_counts[d.stage] = stage_counts.get(d.stage, 0) + 1

        # Asset-class breakdown
        ac_rows = []
        for ac in sorted({d.asset_class for d in decisions}):
            ds = [d for d in decisions if d.asset_class == ac]
            ac_rows.append({
                "asset_class":    ac,
                "n":              len(ds),
                "approve":        sum(1 for x in ds if x.recommendation == DecisionRecommendation.APPROVE),
                "review":         sum(1 for x in ds if x.recommendation == DecisionRecommendation.REVIEW),
                "decline":        sum(1 for x in ds if x.recommendation == DecisionRecommendation.DECLINE),
                "ead":            sum(x.ead         for x in ds),
                "ecl_12m":        sum(x.ecl_12m     for x in ds),
                "ecl_life":       sum(x.ecl_life    for x in ds),
                "ecl_stress":     sum(x.ecl_stress  for x in ds),
                "rwa":            sum(x.rwa         for x in ds),
            })
        by_asset_class = pd.DataFrame(ac_rows)

        return PortfolioDecisionResult(
            decisions        = decisions,
            n_loans          = len(decisions),
            n_approve        = sum(1 for r in recs if r == DecisionRecommendation.APPROVE),
            n_review         = sum(1 for r in recs if r == DecisionRecommendation.REVIEW),
            n_decline        = sum(1 for r in recs if r == DecisionRecommendation.DECLINE),
            total_ead        = sum(d.ead        for d in decisions),
            total_ecl_12m    = sum(d.ecl_12m    for d in decisions),
            total_ecl_life   = sum(d.ecl_life   for d in decisions),
            total_ecl_stress = sum(d.ecl_stress for d in decisions),
            total_rwa        = sum(d.rwa        for d in decisions),
            stage_counts     = stage_counts,
            by_asset_class   = by_asset_class,
        )

    # ── Back-test ──────────────────────────────────────────────────────────
    def backtest(self, df: pd.DataFrame, economics=None):
        """
        Run the agent across a labelled dataframe (must contain default_flag)
        and produce a BackTestResult with confusion matrix, precision/recall,
        AUC, profit at policy, threshold sweep, and cohort breakdowns.

        Parameters
        ----------
        df
            DataFrame conforming to the canonical schema, including
            default_flag. Optional columns vintage_quarter and asset_class
            unlock the cohort breakdowns.
        economics
            BackTestEconomics with the unit profit / loss per outcome.
            Defaults to BackTestEconomics() which is a reasonable UK SME
            starting point.
        """
        from risk_models.backtester import backtest as _backtest
        return _backtest(self, df, economics=economics)

    # ─────────────────────────────────────────────────────────────────────
    # Internals
    # ─────────────────────────────────────────────────────────────────────

    def _resolve_asset_class(self, raw: Any) -> str:
        """Normalise an asset_class field into a canonical string."""
        if isinstance(raw, AssetClass):
            return raw.value
        if isinstance(raw, str) and raw in {ac.value for ac in AssetClass}:
            return raw
        # Light-touch alias handling for the most common typos. For full
        # normalisation, callers should ingest via data_ingestion.ingest()
        # which has the complete alias table.
        if not raw:
            raise ValueError(
                "Borrower row is missing asset_class. Either set it on the "
                "input dict, or run data_ingestion.ingest() first to "
                "produce a canonical df_all."
            )
        key = str(raw).strip().lower().replace("-", "_").replace(" ", "_")
        if key in {ac.value for ac in AssetClass}:
            return key
        raise ValueError(
            f"Unrecognised asset_class {raw!r}. Valid values: "
            f"{[ac.value for ac in AssetClass]}"
        )

    def _adjust_pd_for_borrower(
        self,
        base: PDScore,
        row: dict,
        ac_str: str,
    ) -> PDScore:
        """
        Adjust the suite's synthetic PD by the borrower's *actual* bureau
        score and cashflow coverage so different real borrowers in the
        same asset class receive different PDs.

        The adjustment is a logit shift centred on the asset-class typical
        bureau (~620) and typical CCR (~1.4). A borrower 100 points above
        average gets a PD shift of about -1.3 in log-odds (so a 5% baseline
        PD drops to ~1.4%); a borrower 100 points below average shifts the
        other way.
        """
        cfg = ASSET_CLASS_CONFIG[ac_str]
        bs  = float(row.get("bureau_score", 620) or 620)
        ccr = float(row.get("cashflow_coverage", 1.4) or 1.4)

        # Logit shift: each 100 bureau points = -1.3 log-odds; each
        # 1.0 of CCR above 1.4 = -0.40 log-odds.
        shift = -((bs - 620) / 100.0) * 1.3 - (ccr - 1.4) * 0.40

        # Apply to pd_pit_1y by going to logit, shifting, going back.
        p = float(base.pd_pit_1y)
        logit = np.log(p / (1 - p))
        logit_new = logit + shift
        pd_pit_new = float(1.0 / (1.0 + np.exp(-logit_new)))
        pd_pit_new = float(np.clip(pd_pit_new, cfg.pd_floor, 0.85))

        # Re-derive the other PD measures from pd_pit_new
        ratio = pd_pit_new / max(base.pd_pit_1y, 1e-6)
        pd_ttc_new  = float(np.clip(base.pd_ttc_1y * ratio,  cfg.pd_floor, 0.85))
        pd_pit_3y_new = float(np.clip(1 - (1 - pd_pit_new) ** 3, cfg.pd_floor, 0.99))
        pd_floored  = max(pd_pit_new, cfg.pd_floor)
        capital_pd  = float(np.clip(pd_ttc_new * 1.06, cfg.pd_floor, 0.999))

        # Re-band
        from risk_models.pd_models import _pd_to_band  # local import: private helper
        risk_band = _pd_to_band(pd_pit_new)

        return PDScore(
            pd_pit_1y  = pd_pit_new,
            pd_ttc_1y  = pd_ttc_new,
            pd_pit_3y  = pd_pit_3y_new,
            pd_floored = pd_floored,
            capital_pd = capital_pd,
            risk_band  = risk_band,
        )

    def _recommend(
        self,
        pd_score: PDScore,
        sicr:     SICRAssessment,
        ac_str:   str,
        row:      dict,
    ) -> tuple[DecisionRecommendation, str, float]:
        """
        Apply the decision policy:

          1. Anything at Stage 3 → DECLINE (credit-impaired).
          2. Bureau score < 400 → DECLINE (well below UK bureau floor).
          3. PD above the asset-class decline threshold → DECLINE.
          4. PD below the asset-class approve threshold AND Stage 1 → APPROVE.
          5. Anything else → REVIEW.

        Confidence is a heuristic: distance from the closer of the two
        thresholds on a log-odds scale, capped at 1.
        """
        approve_below, decline_above = self.thresholds.get(ac_str, (0.025, 0.10))
        pd_val = pd_score.pd_pit_1y

        # Rule 1: Stage 3 always DECLINE
        if sicr.stage == "stage_3":
            return (
                DecisionRecommendation.DECLINE,
                "IFRS 9 Stage 3 (credit-impaired): " +
                    ", ".join(sicr.triggers_fired or ["unspecified trigger"]),
                0.98,
            )

        # Rule 2: bureau floor
        bs = float(row.get("bureau_score", 620) or 620)
        if bs < 400:
            return (
                DecisionRecommendation.DECLINE,
                f"Bureau score {int(bs)} below acceptable floor (400).",
                0.95,
            )

        # Rule 3: PD above decline ceiling
        if pd_val > decline_above:
            return (
                DecisionRecommendation.DECLINE,
                f"12-month PD {pd_val:.1%} exceeds asset-class ceiling "
                f"{decline_above:.1%}.",
                _confidence_from_distance(pd_val, decline_above),
            )

        # Rule 4: PD below approve floor AND Stage 1
        if pd_val < approve_below and sicr.stage == "stage_1":
            return (
                DecisionRecommendation.APPROVE,
                f"12-month PD {pd_val:.1%} comfortably below "
                f"{approve_below:.1%}; Stage 1 performing.",
                _confidence_from_distance(approve_below, pd_val),
            )

        # Rule 5: anything else
        if sicr.stage == "stage_2":
            return (
                DecisionRecommendation.REVIEW,
                f"IFRS 9 Stage 2 (SICR triggered: "
                f"{', '.join(sicr.triggers_fired or ['unspecified'])}); "
                f"PD {pd_val:.1%}.",
                0.70,
            )
        return (
            DecisionRecommendation.REVIEW,
            f"PD {pd_val:.1%} in REVIEW band "
            f"({approve_below:.1%} – {decline_above:.1%}).",
            0.55,
        )


def _confidence_from_distance(a: float, b: float) -> float:
    """
    Heuristic confidence: 1 - exp(-2 × |Δlogit|), capped at 0.98.
    Bigger gap between the actual PD and the threshold → higher confidence.
    """
    eps = 1e-6
    la = np.log(a / (1 - a + eps) + eps)
    lb = np.log(b / (1 - b + eps) + eps)
    return float(min(0.98, 1 - np.exp(-2 * abs(la - lb))))

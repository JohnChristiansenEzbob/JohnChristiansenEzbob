"""
risk_models.backtester
======================

BackTestResult — the empirical evaluation of a CreditDecisionAgent's
policy against a labelled dataset (a book of loans with a default_flag).

Where the agent answers the question "what should I do with this loan?",
the back-tester answers the question that always comes next: **"is the
policy any good?"** It compares the agent's APPROVE / REVIEW / DECLINE
recommendations to the realised default outcomes and produces:

- A confusion matrix (recommendation × actual default).
- Precision, recall, FPR, FNR at the APPROVE/DECLINE boundary.
- A profit-at-policy calculation using user-supplied unit economics.
- A threshold sweep showing how each metric would shift if you moved
  the APPROVE/DECLINE thresholds tighter or looser.
- A cohort breakdown by vintage_quarter (when present) so you can see
  whether the policy holds up evenly across origination cohorts.
- A per-asset-class breakdown.

Quick start
-----------
    >>> import pandas as pd
    >>> from risk_models import CreditDecisionAgent
    >>>
    >>> df = pd.read_parquet("df_all.parquet")
    >>> agent = CreditDecisionAgent()
    >>>
    >>> result = agent.backtest(df)
    >>> print(result.summary())
    >>> result.by_threshold       # DataFrame of sweep
    >>> result.by_vintage         # DataFrame of cohort breakdown
    >>> result.by_asset_class     # DataFrame of asset-class breakdown
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import numpy as np
import pandas as pd

if TYPE_CHECKING:
    from risk_models.credit_agent import CreditDecision

__all__ = ["BackTestResult", "BackTestEconomics"]


# ─────────────────────────────────────────────────────────────────────────────
# User-supplied economics for the profit calculation
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class BackTestEconomics:
    """
    Unit economics used in the profit-at-policy calculation. All values are
    in pounds sterling per loan unless stated. Sensible defaults reflect a
    typical UK SME lender; pass your own numbers if you know them.

    The profit model is deliberately simple:
        profit per approved good     = approval_profit
        profit per approved defaulter = -default_loss_per_loan
        profit per declined applicant = 0  (the lost opportunity is *not*
                                            counted as a loss — you didn't
                                            commit capital)
        profit per "REVIEW" case      = review_profit (or 0 by default)

    Override only the values that matter for your scenario; everything
    else falls back to the default.
    """
    approval_profit:      float = 1_200.0   # Mean lifetime margin on a good loan
    default_loss_per_loan: float = 8_500.0  # Mean loss on an approved defaulter
    review_profit:        float = 0.0       # Net effect of putting a case through manual review
    decline_profit:       float = 0.0       # By default declining costs nothing

    def value_per_decision(self, recommendation: str, defaulted: bool) -> float:
        """Compute the profit/loss of a single decision under these economics."""
        if recommendation == "APPROVE":
            return -self.default_loss_per_loan if defaulted else self.approval_profit
        if recommendation == "REVIEW":
            # Approximation: a review case behaves like a 50/50 between
            # approve and decline — half become approvals (and might
            # default), half become declines (and earn 0).
            if defaulted:
                return -self.default_loss_per_loan * 0.5
            return self.approval_profit * 0.5 + self.review_profit
        if recommendation == "DECLINE":
            return self.decline_profit
        return 0.0


# ─────────────────────────────────────────────────────────────────────────────
# Result container
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class BackTestResult:
    """
    The complete output of agent.backtest(df). All numeric fields are
    populated; the DataFrames (by_threshold, by_vintage, by_asset_class)
    are populated when their respective inputs exist.
    """
    # Headline counts
    n_loans:           int
    n_actual_defaults: int
    actual_default_rate: float

    # Confusion matrix  (3 recs × 2 outcomes)
    cm: dict   # {'APPROVE': {'good': N, 'default': N}, 'REVIEW': {...}, 'DECLINE': {...}}

    # APPROVE/DECLINE-treated-as-binary metrics
    precision_decline: float   # of DECLINEs, what share were actual defaults
    recall_decline:    float   # of actual defaults, what share got DECLINEd
    precision_approve: float   # of APPROVEs, what share were goods (non-default)
    recall_approve:    float   # of actual goods, what share got APPROVEd
    fpr_decline:       float   # false-positive rate of DECLINE policy
    fnr_decline:       float   # false-negative rate of DECLINE policy

    # PD-based AUC / Gini using the raw pd_pit_1y of every loan
    auc:               float
    gini:              float

    # Profit
    total_profit:      float
    avg_profit_per_loan: float
    economics_used:    BackTestEconomics

    # Threshold sweep
    by_threshold:      pd.DataFrame

    # Cohort and asset class breakdowns
    by_vintage:        pd.DataFrame | None = None
    by_asset_class:    pd.DataFrame | None = None

    # Provenance
    pd_provenance:     dict = field(default_factory=dict)

    # ── Output helpers ─────────────────────────────────────────────────────
    def summary(self) -> str:
        """Headline summary suitable for printing in a notebook."""
        # Format the confusion matrix nicely
        rows = []
        for rec in ("APPROVE", "REVIEW", "DECLINE"):
            good = self.cm[rec]["good"]
            bad  = self.cm[rec]["default"]
            tot  = good + bad
            dr   = bad / tot * 100 if tot else 0.0
            rows.append(f"  {rec:<10s} good={good:>6,}  default={bad:>5,}  "
                        f"total={tot:>6,}  dr={dr:5.2f}%")

        # Quality warnings — surface obvious calibration problems up top
        warnings = self.warnings()
        warn_block = ["", "⚠  Quality warnings:"] + [f"   - {w}" for w in warnings] if warnings else []

        lines = [
            "BackTest Result",
            "=" * 60,
            f"  Loans:                  {self.n_loans:>10,}",
            f"  Actual defaulters:      {self.n_actual_defaults:>10,}  "
            f"({self.actual_default_rate*100:5.2f}%)",
            f"  PD model source:        {self.pd_provenance.get('source', 'unknown')}",
            *warn_block,
            "",
            "Confusion matrix (recommendation × actual outcome):",
            *rows,
            "",
            f"  AUC:                    {self.auc:.4f}",
            f"  Gini:                   {self.gini:.4f}",
            "",
            "DECLINE policy as a binary classifier of defaulters:",
            f"  Precision:              {self.precision_decline:.2%}",
            f"  Recall:                 {self.recall_decline:.2%}",
            f"  False-positive rate:    {self.fpr_decline:.2%}",
            f"  False-negative rate:    {self.fnr_decline:.2%}",
            "",
            f"  Total portfolio profit: £{self.total_profit:>13,.0f}",
            f"  Avg profit per loan:    £{self.avg_profit_per_loan:>13,.2f}",
            "=" * 60,
        ]
        return "\n".join(lines)

    def warnings(self) -> list[str]:
        """Return human-readable warnings about the back-test quality."""
        out = []
        # AUC too low to take recommendations seriously
        if not np.isnan(self.auc) and self.auc < 0.55:
            out.append(
                f"AUC {self.auc:.3f} is barely above random — the PD model "
                f"is not discriminating defaulters from goods. Inspect "
                f"feature distributions and default-flag polarity."
            )
        # Overfit fit (perfect in-sample AUC) — fit_provenance carries CV AUC
        cv_auc = self.pd_provenance.get("cv_auc")
        in_auc = self.pd_provenance.get("in_sample_auc")
        if in_auc is not None and cv_auc is not None and not (np.isnan(in_auc) or np.isnan(cv_auc)):
            if in_auc - cv_auc > 0.2:
                out.append(
                    f"Saved PD model shows strong overfit (in-sample AUC "
                    f"{in_auc:.3f} vs 5-fold CV AUC {cv_auc:.3f}). Reduce "
                    f"n_estimators or regularise before quoting figures."
                )
        # Default rate looks inverted
        if 0.4 < self.actual_default_rate < 0.6:
            out.append(
                f"Default rate {self.actual_default_rate:.1%} is suspiciously "
                f"close to 50% — possible default_flag polarity error."
            )
        if self.actual_default_rate > 0.6:
            out.append(
                f"Default rate {self.actual_default_rate:.1%} is implausibly "
                f"high — almost certainly a default_flag polarity error "
                f"(1=good, 0=bad). Flip the column before re-running."
            )
        # No DECLINE decisions at all
        n_decl = self.cm["DECLINE"]["good"] + self.cm["DECLINE"]["default"]
        if n_decl == 0:
            out.append(
                "Policy never DECLINES — thresholds may be too loose. "
                "Examine the threshold sweep (.by_threshold) for tighter "
                "options."
            )
        return out


# ─────────────────────────────────────────────────────────────────────────────
# Implementation — invoked as agent.backtest(df) (see credit_agent for the
# binding). Kept as a free function so it's easy to test in isolation.
# ─────────────────────────────────────────────────────────────────────────────

def _confusion_matrix(decisions: list, defaulted: np.ndarray) -> dict:
    cm = {
        "APPROVE": {"good": 0, "default": 0},
        "REVIEW":  {"good": 0, "default": 0},
        "DECLINE": {"good": 0, "default": 0},
    }
    for d, def_flag in zip(decisions, defaulted):
        rec = d.recommendation.value if hasattr(d.recommendation, "value") else d.recommendation
        bucket = "default" if def_flag else "good"
        cm[rec][bucket] += 1
    return cm


def _auc_gini(pd_pit_1y: np.ndarray, default_flag: np.ndarray) -> tuple[float, float]:
    """AUC of pd_pit_1y as a default classifier; Gini = 2*AUC - 1."""
    from sklearn.metrics import roc_auc_score
    try:
        auc = float(roc_auc_score(default_flag, pd_pit_1y))
    except ValueError:
        # All one class
        auc = float("nan")
    gini = 2 * auc - 1 if not np.isnan(auc) else float("nan")
    return auc, gini


def _threshold_sweep(
    decisions: list,
    pd_pit_1y: np.ndarray,
    default_flag: np.ndarray,
    eco: BackTestEconomics,
    grid_pct: tuple[float, ...] = (-50, -25, -10, 0, +10, +25, +50),
) -> pd.DataFrame:
    """
    Sweep the DECLINE threshold up and down (relative %, applied to each
    loan's actual asset-class threshold) and recompute approval rate,
    default capture, and profit at each point. Helps the user see what
    happens if they tighten or loosen their policy.
    """
    # Pre-compute each loan's decline-threshold-PD from the actual decisions
    # by reverse-engineering: for each row we need the asset-class ceiling.
    # The agent's CreditDecision doesn't carry the threshold, so we pull it
    # from a freshly-built agent's `thresholds` dict.
    from risk_models.credit_agent import CreditDecisionAgent
    a = CreditDecisionAgent()
    asset_classes = [d.asset_class for d in decisions]
    base_ceilings = np.array([a.thresholds.get(ac, (0.03, 0.12))[1]
                              for ac in asset_classes])

    rows = []
    for pct in grid_pct:
        # Each loan's ceiling shifted by pct
        ceilings = base_ceilings * (1 + pct / 100)
        declined_mask = pd_pit_1y > ceilings
        approved_mask = ~declined_mask & (default_flag.shape[0] > 0)  # naive: not declined → not necessarily approved

        # Simplified profit calc at this shifted threshold:
        # treat everyone below ceiling as APPROVE
        profit = np.where(
            declined_mask,                                       # declined
            eco.decline_profit,
            np.where(default_flag.astype(bool),                  # approved & defaulted
                     -eco.default_loss_per_loan,
                     eco.approval_profit),                       # approved & good
        ).sum()

        n_decl = int(declined_mask.sum())
        n_appr = int((~declined_mask).sum())
        defaults_in_appr = int(((~declined_mask) & default_flag.astype(bool)).sum())
        defaults_caught  = int((declined_mask & default_flag.astype(bool)).sum())
        total_defaults   = int(default_flag.astype(bool).sum())

        rows.append({
            "shift_pct":         pct,
            "declined":          n_decl,
            "approved":          n_appr,
            "default_capture":   defaults_caught / total_defaults if total_defaults else 0,
            "defaults_approved": defaults_in_appr,
            "profit":            float(profit),
        })

    return pd.DataFrame(rows)


def _cohort_breakdown(decisions: list, default_flag: np.ndarray,
                      grouping: list) -> pd.DataFrame | None:
    """
    Group decisions by `grouping` (a list of strings, one per decision)
    and compute the headline metrics per group. Returns None if every
    grouping value is None.
    """
    if all(g is None for g in grouping):
        return None

    rows = []
    groups = sorted({g for g in grouping if g is not None})
    for g in groups:
        idx = [i for i, x in enumerate(grouping) if x == g]
        ds  = [decisions[i] for i in idx]
        dfl = default_flag[idx]
        if len(ds) == 0:
            continue

        recs = [d.recommendation.value if hasattr(d.recommendation, "value")
                else d.recommendation for d in ds]
        n_app = recs.count("APPROVE")
        n_rev = recs.count("REVIEW")
        n_dec = recs.count("DECLINE")

        # PD distribution
        pds = np.array([d.pd_pit_1y for d in ds])

        rows.append({
            "group":         g,
            "n":             len(ds),
            "default_rate":  float(dfl.mean()) if len(dfl) else 0.0,
            "approve":       n_app,
            "review":        n_rev,
            "decline":       n_dec,
            "approve_rate":  n_app / len(ds),
            "decline_rate":  n_dec / len(ds),
            "mean_pd":       float(pds.mean()),
        })

    return pd.DataFrame(rows)


def backtest(
    agent,
    df: pd.DataFrame,
    economics: BackTestEconomics | None = None,
    decisions: list | None = None,
) -> BackTestResult:
    """
    Run a back-test of `agent`'s policy against the labelled DataFrame `df`.

    Parameters
    ----------
    agent
        A CreditDecisionAgent (or compatible object). Required attribute:
        decide_portfolio(df). Used only if `decisions` is not supplied.
    df
        A DataFrame conforming to the BetaCredit canonical schema with at
        least asset_class, pd inputs, and default_flag. vintage_quarter
        and asset_class are optional but enable the cohort breakdowns.
    economics
        Unit economics for the profit calculation. Defaults to BackTestEconomics().
    decisions
        Optional — if the caller has already scored the book once, pass the
        list of CreditDecision objects here to avoid re-scoring.

    Returns
    -------
    BackTestResult
    """
    eco = economics or BackTestEconomics()

    if decisions is None:
        port = agent.decide_portfolio(df)
        decisions = port.decisions

    default_flag = df["default_flag"].astype(int).values
    pd_pit_1y    = np.array([d.pd_pit_1y for d in decisions])

    # Confusion matrix and binary metrics
    cm = _confusion_matrix(decisions, default_flag)

    n_loans = len(decisions)
    n_defaults = int(default_flag.sum())
    actual_dr = n_defaults / max(n_loans, 1)

    # DECLINE policy as a binary classifier
    declined_mask = np.array([
        (d.recommendation.value if hasattr(d.recommendation, "value")
         else d.recommendation) == "DECLINE"
        for d in decisions
    ])
    approved_mask = np.array([
        (d.recommendation.value if hasattr(d.recommendation, "value")
         else d.recommendation) == "APPROVE"
        for d in decisions
    ])
    dflag_bool = default_flag.astype(bool)

    tp = int(((declined_mask) & (dflag_bool)).sum())
    fp = int(((declined_mask) & (~dflag_bool)).sum())
    fn = int((~(declined_mask) & (dflag_bool)).sum())
    tn = int((~(declined_mask) & ~(dflag_bool)).sum())

    precision_decline = tp / (tp + fp) if (tp + fp) else 0.0
    recall_decline    = tp / (tp + fn) if (tp + fn) else 0.0
    fpr_decline       = fp / (fp + tn) if (fp + tn) else 0.0
    fnr_decline       = fn / (fn + tp) if (fn + tp) else 0.0

    tp_a = int(((approved_mask) & (~dflag_bool)).sum())
    fp_a = int(((approved_mask) & (dflag_bool)).sum())
    fn_a = int((~(approved_mask) & ~(dflag_bool)).sum())
    precision_approve = tp_a / (tp_a + fp_a) if (tp_a + fp_a) else 0.0
    recall_approve    = tp_a / (tp_a + fn_a) if (tp_a + fn_a) else 0.0

    # AUC / Gini on raw PD
    auc, gini = _auc_gini(pd_pit_1y, default_flag)

    # Profit
    profits = np.array([
        eco.value_per_decision(
            d.recommendation.value if hasattr(d.recommendation, "value")
            else d.recommendation,
            bool(default_flag[i]),
        )
        for i, d in enumerate(decisions)
    ])
    total_profit = float(profits.sum())
    avg_profit = float(profits.mean())

    # Threshold sweep
    by_threshold = _threshold_sweep(decisions, pd_pit_1y, default_flag, eco)

    # Cohort breakdowns
    vintages = [d.vintage_quarter for d in decisions]
    by_vintage = _cohort_breakdown(decisions, default_flag, vintages)

    asset_classes = [d.asset_class for d in decisions]
    by_asset_class = _cohort_breakdown(decisions, default_flag, asset_classes)

    pd_prov = getattr(agent, "pd_provenance", {"source": "unknown"})

    return BackTestResult(
        n_loans           = n_loans,
        n_actual_defaults = n_defaults,
        actual_default_rate = actual_dr,
        cm                = cm,
        precision_decline = precision_decline,
        recall_decline    = recall_decline,
        precision_approve = precision_approve,
        recall_approve    = recall_approve,
        fpr_decline       = fpr_decline,
        fnr_decline       = fnr_decline,
        auc               = auc,
        gini              = gini,
        total_profit      = total_profit,
        avg_profit_per_loan = avg_profit,
        economics_used    = eco,
        by_threshold      = by_threshold,
        by_vintage        = by_vintage,
        by_asset_class    = by_asset_class,
        pd_provenance     = pd_prov,
    )

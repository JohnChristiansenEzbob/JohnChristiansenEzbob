---
name: de-identity-orchestration-agent
description: |
  Verify the identity of a single natural-person principal — typically via document verification, biometric liveness, and database cross-checks (electoral roll, credit header). Returns a verification verdict plus a confidence score. Invoked by multi-principal-fan-out-orchestrator for each director / PSC.
---

# Identity Orchestration Agent

Foundational per-principal check. Get identity wrong and the whole AML/KYC chain is compromised.

## Input contract

```yaml
identity_request:
  principal_id: string
  case_id: string
  name: string
  prior_names: [string]                     # nullable
  dob: date
  current_residential_address: string
  prior_addresses_3y: [string]              # nullable
  nationality: string
  document_evidence:                        # provided by applicant at intake
    - doc_type: enum                        # passport | driving_licence | brp | residence_permit
      doc_number: string
      expiry: date
      front_image_pointer: string
      back_image_pointer: string            # nullable for passports
  biometric_evidence: string                # selfie image pointer
  consent_token: string                     # bureau header consent
```

## Output contract

```yaml
identity_verification:
  principal_id: string
  identity_verified: boolean
  confidence: float                         # 0.0 - 1.0
  document_check:
    doc_type: enum
    authenticity_score: float
    tampering_signals: [string]
  biometric_check:
    liveness_passed: boolean
    facial_match_score: float
  database_check:
    electoral_roll_match: boolean
    credit_header_match: boolean
    name_match: boolean
    address_match: boolean
    dob_match: boolean
  outcome: enum                             # verified | refer | hard_fail
  reason_codes: [string]
```

## Decision logic

```
Document check: authenticity + tampering signals.
Biometric check: liveness + facial match to document photo.
Database check: cross-reference against electoral roll and credit header.

if document_check.authenticity_score < 0.5 OR len(tampering_signals) > 0:
  outcome = hard_fail
elif biometric_check.liveness_passed == false:
  outcome = hard_fail
elif biometric_check.facial_match_score < 0.7:
  outcome = refer
elif database_check.name_match AND database_check.address_match AND database_check.dob_match:
  outcome = verified
  confidence = composite_score(all_checks)
else:
  outcome = refer
```

## Worked example (Brandenburg Engineering GmbH case)

Input:
```yaml
identity_request:
  principal_id: DIR-001
  case_id: "BRA-2026-04-001"
  name: "Lachlan MacKenzie"
  dob: "1981-03-22"
  current_residential_address: "12 Strathblane Road, Milngavie, Berlin, G62 8DJ"
  nationality: "British"
  document_evidence:
    - doc_type: passport
      doc_number: "[redacted]"
      expiry: "2028-06-14"
      front_image_pointer: "doc_evidence://DIR-001/passport/front.jpg"
  biometric_evidence: "biometric_evidence://DIR-001/selfie.jpg"
  consent_token: "TKN-bureau-con-2026-04-12-DIR-001"
```

Output:
```yaml
identity_verification:
  principal_id: DIR-001
  identity_verified: true
  confidence: 0.97
  document_check:
    doc_type: passport
    authenticity_score: 0.98
    tampering_signals: []
  biometric_check:
    liveness_passed: true
    facial_match_score: 0.94
  database_check:
    electoral_roll_match: true
    credit_header_match: true
    name_match: true
    address_match: true
    dob_match: true
  outcome: verified
  reason_codes: ["UK_IDENTITY_VERIFIED_HIGH_CONFIDENCE"]
```

Strong identity verification: authentic passport, high biometric match, all database checks corroborate. Composite confidence 0.97. Sarah Chen (DIR-002) returns similar shape with confidence 0.98.

## Bright lines

- Document tampering signals present → hard_fail; case held
- Liveness check failed (static image, replay) → hard_fail
- Name/DOB on document does not match application → hard_fail

## Operational rules

- Image evidence retained per DPA 2018 for as long as relationship plus 6 years
- Failed verifications are auditable — must record reason, not just outcome
- Where applicant has changed name (marriage etc.), verify both names

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Document image quality too poor | Refer; request reupload |
| Database lookups all return no match | Refer; could be valid (new resident) but needs human |
| Address declared mismatches all databases | Refer to fraud agent |


## Germany-specific operational notes

This agent operates within the German lending framework — BaFin supervisory perimeter (with Bundesbank joint prudential and ECB SSM for significant institutions), BGB §§ 491-505e for consumer credit, KWG (Kreditwesengesetz) for banking, GwG for AML.

- **SCHUFA monopoly:** SCHUFA holds the effective monopoly on consumer credit data. BDSG §29 consent (Einwilligung) is mandatory before any SCHUFA query — operational rigour matters; querying without consent is a data protection breach with material fines.
- **Notar requirement:** German property transfers require notarial certification (Notar). This is structural — mortgage origination must accommodate notarial step and cannot bypass it.
- **Cooperative + savings dominance:** Sparkassen and Volksbanken/Raiffeisenbanken collectively dominate German consumer + SME credit. Hausbank (house bank) culture means existing relationships are sticky.
- **Long-fixed-rate culture:** German mortgages commonly fixed for 10-30 years; affordability stress testing must reflect this product structure, not UK SVR conventions.
- **Transparenzregister:** UBO register (5AMLD-compliant). Threshold 25%+. Public access restricted post-CJEU ruling; financial institutions retain access via legitimate interest.
- **Cross-reference:** `country-de-lending-policy-agent` provides full DE jurisdictional context.

## Statutory hooks

- Germany GwG (customer due diligence — identity verification)
- Transparenzregistergesetz + GwG (director identity verification)
- Germany GDPR (biometric data is special category — explicit consent + minimisation)

---
name: es-bureau-orchestration-agent
description: |
  Orchestrate commercial credit bureau pulls (Informa D&B España + Axesor, Equifax Commercial, CreditSafe, optionally Dun & Bradstreet). Aggregate into a composite credit picture. Handles bureau-specific scoring quirks and returns a consolidated view consumable by downstream affordability and PD agents.
---

# Bureau Orchestration Agent

Authoritative credit picture from the bureaux. Each bureau has its own model and scoring; the orchestrator presents them as one consistent set of facts.

## Input contract

```yaml
bureau_request:
  case_id: string
  company_number: string
  consent_token: string                     # bureau_commercial
  bureaux_requested: [enum]                 # subset of {experian, equifax, creditsafe, dnb}
```

## Output contract

```yaml
bureau_composite:
  case_id: string
  company_number: string
  experian:
    delphi_score: integer                   # 0-100
    band: enum                              # 1=high risk, 6=very low risk (or similar)
    age_at_companies_house: integer
  equifax:
    score: string                           # alphabetic A/B/C/D...
    arrears_indicator: boolean
  creditsafe:
    score: integer                          # 0-100
    international_score: integer
  dnb:                                      # nullable; not always pulled
    paydex: integer
    failure_score: integer
  consolidated:
    composite_rating: enum                  # solid | adequate | weak
    cumulative_ccj_count_company: integer
    current_charges_outstanding: integer
    current_arrears_with_any_lender: boolean
    discrepancies_across_bureaux: [string]
  reason_codes: [string]
```

## Decision logic

```
Parallel pulls of all bureaux_requested.
For each bureau response:
  - record raw score + band
  - normalise key facts (CCJs, charges, arrears)
Cross-check key facts across bureaux:
  - if bureaux disagree on CCJ count: flag discrepancy
  - if one bureau reports arrears the others don't: flag discrepancy

Composite rating:
  - solid: all bureaux above their respective "low risk" thresholds
  - adequate: at least 2 of 3 above thresholds
  - weak: majority below thresholds OR any bureau reports arrears
```

## Worked example (Ibero Engineering S.L. case)

Input:
```yaml
bureau_request:
  case_id: "IBE-2026-04-001"
  company_number: "B-12345678"
  consent_token: "TKN-bureau-com-2026-04-12-001"
  bureaux_requested: [experian, equifax, creditsafe]
```

Output:
```yaml
bureau_composite:
  case_id: "IBE-2026-04-001"
  company_number: "B-12345678"
  experian:
    delphi_score: 78
    band: 4                                # low-medium risk
    age_at_companies_house: 102
  equifax:
    score: "B+"
    arrears_indicator: false
  creditsafe:
    score: 72
    international_score: 70
  consolidated:
    composite_rating: solid
    cumulative_ccj_count_company: 0
    current_charges_outstanding: 1
    current_arrears_with_any_lender: false
    discrepancies_across_bureaux: []
  reason_codes: ["UK_BUREAU_COMPOSITE_SOLID_NO_DISCREPANCIES"]
```

All three bureaux agree on the substantive facts (no CCJs, 1 outstanding charge, no current arrears). Scores cluster in the solid mid-tier (Delphi 78, Equifax B+, CreditSafe 72). Composite rating: solid.

## Bright lines

- Bureau flags 'do not lend' marker (rare; reserved for confirmed serious adverse) → BLOCK
- Active arrears with any reported lender → AUTOMATIC REFER

## Operational rules

- Discrepancies across bureaux are NOT automatically resolved — they're flagged for review
- Different bureau scales are preserved in raw; only the composite is normalised
- Bureau costs: aim for 2 bureaux minimum, 3 for cases >€100k
- Bureau data is point-in-time — re-pull if case takes >30 days

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| One bureau unavailable | Proceed with other two; flag completeness < ideal |
| All bureaux unavailable | Refer; cannot make data-driven decision |
| Bureaux disagree materially on key facts | Refer for manual reconciliation |


## Spain-specific operational notes

This agent operates within the Spanish lending framework — Banco de España + CNMV joint regulatory perimeter, Ley 10/2014 for banking supervision, LCC (Ley 16/2011) for consumer credit, LRCCI (Ley 5/2019) for mortgage credit.

- **CIRBE €9k threshold:** Banco de España central credit register. Commercial risks >€9,000 mandatory contribution. Small SME facilities frequently below threshold — limited CIRBE visibility for genuine SME risk.
- **ASNEF / BADEXCUG strict access:** Spanish consumer bureau access has the strictest legal review requirement in EU. Operational onboarding must include legal basis attestation. ASNEF for negative; BADEXCUG for comprehensive — separate access agreements required.
- **LRCCI notarial requirement (AGNCN):** Mortgage origination requires AGNCN (Acta de Información Notarial Previa) — notarial pre-contractual information act. Cannot bypass; significant operational integration with notary network.
- **Tarjeta revolving usury (2020 Supreme Court):** Revolving credit cards subject to enhanced disclosure post-2020 Supreme Court rulings on usury. APR materially above market average is voidable.
- **Bizum ubiquity:** Mobile P2P payment platform with near-universal Spanish adoption; PSD2 integration via participating banks.
- **NIE administrative complexity:** Foreign residents require NIE (Número de Identidad de Extranjero) — multiple issuing authorities, common source of onboarding friction.
- **Cross-reference:** `country-es-lending-policy-agent` provides full ES jurisdictional context.

## Statutory hooks

- Ley 16/2011 (LCC) (where applicable — sole traders, small partnerships)
- Spain GDPR / DPA 2018
- CNMV + BdE LCC + BdE supervision

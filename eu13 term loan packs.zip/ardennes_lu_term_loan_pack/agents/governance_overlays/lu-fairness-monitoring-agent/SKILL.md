---
name: lu-fairness-monitoring-agent
description: |
  Monitor decision outcomes for fairness across protected attribute proxies (region, deprivation index, SIC code where it correlates with protected attributes). Returns demographic parity statistics, drift indicators, and any breach signals. Operates per-case (current decision vs portfolio baseline) and aggregate (rolling portfolio statistics).
---

# Fairness Monitoring Agent

Continuous fairness oversight. EU AI Act + CSSF CSSF customer protection framework + (where applicable) Equality Act 2010 require demonstrable fairness in automated credit decisioning.

## Input contract

```yaml
fairness_check_request:
  case_id: string
  decision_outcome: enum                    # accept | refer | decline
  applicant_attributes_proxy:
    region: string
    deprivation_quintile: integer           # IMD 1-5
    sic_code: string
  portfolio_baseline_ref: string            # reference to current baseline snapshot
```

## Output contract

```yaml
fairness_check_result:
  case_id: string
  this_case_in_distribution: boolean
  demographic_parity_delta: float           # vs baseline
  drift_indicators:
    region_drift: boolean
    deprivation_drift: boolean
    sic_drift: boolean
  within_tolerance: boolean
  alert_required: boolean
  audit_ledger_entry_id: string
  reason_codes: [string]
```

## Decision logic

```
Compare this case's outcome distribution against portfolio baseline.
Compute demographic parity delta on each protected attribute proxy.

Tolerance thresholds (configurable):
  - region parity delta <= 0.05 (5%)
  - deprivation parity delta <= 0.05
  - sic parity delta <= 0.05

if any delta > tolerance: drift_indicator = true

Rolling alerts:
  - Sustained drift >4 weeks → alert + reportable under AI Directive 2024
  - Single case in extreme outlier → flag for manual review
```

## Worked example (Ardennes Engineering S.à r.l. case)

Input:
```yaml
fairness_check_request:
  case_id: "ARD-2026-04-001"
  decision_outcome: accept
  applicant_attributes_proxy:
    region: "GB-SCT"
    deprivation_quintile: 4                # mid-upper (Milngavie postcode)
    sic_code: "71121"
  portfolio_baseline_ref: "fairness_baseline_2026Q1"
```

Output:
```yaml
fairness_check_result:
  case_id: "ARD-2026-04-001"
  this_case_in_distribution: true
  demographic_parity_delta: 0.03
  drift_indicators:
    region_drift: false
    deprivation_drift: false
    sic_drift: false
  within_tolerance: true
  alert_required: false
  audit_ledger_entry_id: "FM-2026-04-12-HE-001"
  reason_codes: ["UK_FAIRNESS_WITHIN_TOLERANCE"]
```

This single case is within distribution and consistent with baseline. No drift signals. No alert required. Audit ledger updated.

## Bright lines

- Sustained breach >4 weeks → MUST notify CSSF + reportable under (where applicable) AI Algorithmic Directive

## Operational rules

- Protected attribute proxies, not protected attributes themselves (cannot collect race/ethnicity for credit)
- Baseline refreshed quarterly
- Per-case alerts are advisory; portfolio alerts are mandatory action

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Baseline data stale | Use cautiously; flag refresh required |
| Outlier case but no clear protected attribute correlation | Flag for human review |


## Luxembourg-specific operational notes

This agent operates within the Luxembourgish lending framework — CSSF as unified supervisor (banking, investment funds, payment services, insurance via CAA), with ECB SSM for significant institutions. Loi du 5 avril 1993 is the foundational banking law.

- **EU financial centre context:** Luxembourg's banking sector is heavily skewed toward private banking, fund administration, and cross-border services. Domestic consumer lending is a smaller proportion of activity than peer EU jurisdictions.
- **Trilingual jurisdiction:** French is primary for legal documents; German and Luxembourgish (Lëtzebuergesch) also constitutional. Customer-facing materials commonly trilingual.
- **CSSF supervisory style:** Investment fund and private banking focus means CSSF supervisory rhythm and reporting differs from peer prudential supervisors. Banking supervision sits within the unified CSSF.
- **Limited domestic credit visibility:** No central consumer credit register equivalent to FR FICP or BE CKP; lender visibility relies on bureau-by-bureau queries and Open Banking.
- **Cross-border banking:** Many lending applications involve cross-border structures (Belgian, German, French residents working in Luxembourg). KYB chains often complex.
- **Cross-reference:** `country-lu-lending-policy-agent` for full LU jurisdictional context (currently a stub in the Country Policy Pack).

## Statutory hooks

- Equality Act 2010 (indirect discrimination via correlated attributes)
- CSSF CSSF customer protection framework
- EU AI Act (high-risk classification — credit scoring) where applicable
- CSSF model risk supervision + ECB SREP

---
name: dk-consumer-protection-outcomes-agent
description: |
  Cross-cutting Finanstilsynet customer protection framework checks across the four outcomes: products + services, price + value, consumer understanding, consumer support. Runs continuously and writes a Finanstilsynet customer protection framework audit trail to the case ledger. For business lending, the Duty applies to micro-enterprises (turnover <€2m + <10 employees).
---

# Finanstilsynet customer protection framework Outcomes Agent

Continuous Finanstilsynet customer protection framework oversight. Captures the audit trail Finanstilsynet inspections will ask for.

## Input contract

```yaml
duty_check_request:
  case_id: string
  case_state_snapshot: object               # current case state at this check
  trigger_event: enum                       # phase_completion | manual | scheduled
```

## Output contract

```yaml
duty_check_result:
  case_id: string
  outcomes_checked:
    products_and_services: enum             # pass | fail | not_applicable
    price_and_value: enum
    consumer_understanding: enum
    consumer_support: enum
  fair_value_check_passed: boolean
  understanding_check_passed: boolean
  audit_ledger_entry_id: string
  reason_codes: [string]
```

## Decision logic

```
For each outcome, check against rules:

products_and_services:
  - Product matches needs (cross-ref needs-discovery + purpose-validation)
  - No prohibited customer-product combinations

price_and_value:
  - Final rate within fair value band
  - Total cost transparent (incl. broker commission)
  - No hidden fees

consumer_understanding:
  - Key facts disclosed (rate, term, total cost, security implications)
  - Conditions clearly stated
  - Decline reasoning available (right to explanation)

consumer_support:
  - Channel-appropriate support available
  - Vulnerable customer flagged → enhanced support route

if all 4 outcomes pass → pass
else → fail with specific outcome flagged
```

## Worked example (Viking Engineering A/S case)

Input:
```yaml
duty_check_request:
  case_id: "VIK-2026-04-001"
  case_state_snapshot: {... full case state at decision time ...}
  trigger_event: phase_completion
```

Output:
```yaml
duty_check_result:
  case_id: "VIK-2026-04-001"
  outcomes_checked:
    products_and_services: pass             # term loan fits stated purpose
    price_and_value: pass                   # 8.4% within fair value band for B+ grade
    consumer_understanding: pass            # conditions clearly stated, decline reasons would be available
    consumer_support: pass                  # broker channel + lender support team available
  fair_value_check_passed: true
  understanding_check_passed: true
  audit_ledger_entry_id: "CD-2026-04-12-HE-001"
  reason_codes: ["UK_CONSUMER_DUTY_ALL_OUTCOMES_PASS"]
```

All four Finanstilsynet customer protection framework outcomes pass for Viking Engineering A/S. Note: Highland is a limited company with turnover ~DKK 850k and 6 employees — technically not a 'consumer' (>turnover threshold). The lender still applies Duty-equivalent standards as a matter of policy.

## Bright lines

- Fair value failure → escalate to product team; cannot proceed at quoted price
- Material information not disclosed pre-contract → cannot proceed

## Operational rules

- Duty applies to micro-enterprises in business lending (Finanstilsynet scope)
- Lender policy may extend Duty-equivalent standards to all business customers
- Audit trail is mandatory for Finanstilsynet inspection

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Case state snapshot incomplete | Defer check; re-run when complete |
| Fair value benchmark unavailable | Conservative interpretation; refer to product team |


## Denmark-specific operational notes

This agent operates within the Danish lending framework — Finanstilsynet as unified financial supervisor, Lov om finansiel virksomhed (LOF) for banking, Kreditaftaleloven for consumer credit, Hvidvaskloven for AML.

- **Realkreditloven mortgage bond system:** Denmark's distinctive mortgage credit institution (realkreditinstitut) model issues Pfandbrief-equivalent bonds 1:1 backed by individual mortgages. Operationally different from UK SVR-based mortgage origination — fixed-rate, callable-by-borrower options dominate.
- **Outside Eurozone:** Currency is DKK, pegged to EUR via ERM II at ~7.46 DKK/EUR. Cross-border lending requires FX consideration but pegged stability reduces hedging requirement.
- **MitID universal:** Replaced NemID. Used for all online financial onboarding. Strong customer authentication is operationally seamless.
- **CPR number:** 10-digit national identifier with date of birth + gender encoded. Restricted use for identification by financial institutions.
- **No central credit register:** Bureaus are private (Experian DK, Bisnode DK, RKI for negative consumer). Multi-bureau best practice; no equivalent of UK Highland CCR.
- **e-Boks:** Digital postbox used for most government and financial communications; assume customer reads e-Boks rather than email.
- **Cross-reference:** `country-dk-lending-policy-agent` for full DK jurisdictional context (currently a stub in the Country Policy Pack).

## Statutory hooks

- Finanstilsynet Finanstilsynet customer protection framework (PS22/9)
- Finanstilsynet retningslinjer + LOF Finanstilsynet customer outcomes (the Duty)
- Finanstilsynet Finalised Guidance FG22/5

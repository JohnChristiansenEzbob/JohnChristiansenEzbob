"""
risk_models.beta_loader
=======================

Beta upgrade: data ingestion is now first-class.

Every modelling notebook (02–07) calls one of the ``load_for_*`` helpers in
this module. The helpers auto-detect ``df_all.parquet`` on disk (produced by
notebook 00's ingestion pipeline) and reshape it into whatever the calling
notebook needs. If no ingested file is found, they fall back to the original
synthetic data so the notebook still runs out-of-the-box for demos.

Public entry points
-------------------
    load_for_pd_models()        → notebook 02 expects: borrower DataFrame + FEATURES list
    load_for_lgd_ead()          → notebook 03 expects: asset-class mix dict
    load_for_sicr()             → notebook 04 expects: arrays (pd_orig, pd_curr, dpd, forb, ac_draw)
    load_for_fairness()         → notebook 05 expects: borrower DataFrame with protected attributes
    load_for_rl_outcomes()      → notebook 06 expects: list[OutcomeEvent]
    load_for_portfolio_ecl()    → notebook 07 expects: asset-class draws + count

Each returns a dataclass result with ``.is_real`` set to ``True`` when the
ingested book was used and ``False`` for the synthetic fallback. Notebooks
print a short banner to make the source transparent.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

DEFAULT_PARQUET = "df_all.parquet"


# ─────────────────────────────────────────────────────────────────────────────
# Detection + load
# ─────────────────────────────────────────────────────────────────────────────

def _find_parquet(path: str | None = None) -> Path | None:
    """Return the path to the ingested parquet if present, else None."""
    candidate = Path(path) if path else Path(DEFAULT_PARQUET)
    if candidate.exists():
        return candidate
    # Also check parent dir (notebooks may be run from anywhere)
    parent_candidate = Path("..") / candidate.name
    if parent_candidate.exists():
        return parent_candidate
    return None


def _load_df_all(path: str | None = None) -> pd.DataFrame | None:
    """Load ``df_all.parquet`` if it exists; else return None."""
    p = _find_parquet(path)
    if p is None:
        return None
    return pd.read_parquet(p)


def _banner(is_real: bool, n: int, source: str) -> str:
    if is_real:
        return (
            f"[Beta] Using INGESTED data from {source}: {n:,} borrowers. "
            f"To revert to synthetic data, delete df_all.parquet."
        )
    return (
        f"[Beta] No df_all.parquet found — using SYNTHETIC data ({n:,} borrowers). "
        f"Run notebook 00 to ingest a real book."
    )


# ─────────────────────────────────────────────────────────────────────────────
# Result wrappers
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class LoaderResult:
    """Generic container — concrete fields depend on the loader."""
    data: Any
    is_real: bool
    source: str
    n_rows: int
    banner: str = ""

    def __post_init__(self) -> None:
        if not self.banner:
            self.banner = _banner(self.is_real, self.n_rows, self.source)


# ─────────────────────────────────────────────────────────────────────────────
# Notebook 02 — PD models with SHAP / LIME
# ─────────────────────────────────────────────────────────────────────────────

# Notebook 02 uses these short feature names. Map canonical → 02's names.
_NB02_FEATURE_MAP = {
    "bureau_score":                 "bureau_score",
    "cashflow_coverage":            "cashflow_coverage",
    "ltv":                          "ltv",
    "gnn_connected_party_risk":     "gnn_risk",
    "open_banking_income_stability":"ob_income_stability",
    "num_prior_defaults":           "num_prior_defaults",
    "months_since_adverse":         "months_since_adverse",
    "utilisation_rate":             "utilisation_rate",
    "loan_amount":                  "loan_amount_log",   # log-transformed
    "loan_term_months":             "loan_term_months",
    "age_years":                    "age_years",
    "months_banking_relationship":  "months_banking",
    "num_active_credit_lines":      "num_credit_lines",
    "hmrc_revenue_match_ratio":     "hmrc_revenue_match",
    "time_in_business_months":      "time_in_business_months",
    # 'open_banking_vol_stability' is NOT in canonical schema — derive from ob_income_stability
}

NB02_FEATURES = [
    "bureau_score", "cashflow_coverage", "ltv", "gnn_risk", "ob_income_stability",
    "num_prior_defaults", "months_since_adverse", "utilisation_rate",
    "loan_amount_log", "loan_term_months", "age_years", "months_banking",
    "num_credit_lines", "hmrc_revenue_match", "time_in_business_months",
    "open_banking_vol_stability",
]


def _make_synthetic_nb02(n: int = 12_000, seed: int = 2026) -> pd.DataFrame:
    """Replicate notebook 02's original make_dataset() exactly."""
    rng = np.random.default_rng(seed)
    np.random.seed(seed)
    d = {
        "bureau_score":               np.clip(np.random.normal(620, 80, n), 300, 999),
        "cashflow_coverage":          np.clip(np.random.normal(1.4, 0.55, n), 0.1, 5.0),
        "ltv":                        np.clip(np.random.normal(0.68, 0.16, n), 0.05, 1.20),
        "gnn_risk":                   np.clip(np.random.beta(1.2, 8, n), 0, 1),
        "ob_income_stability":        np.clip(np.random.normal(0.72, 0.18, n), 0, 1),
        "num_prior_defaults":         np.random.choice([0, 1, 2, 3], n, p=[0.72, 0.17, 0.07, 0.04]),
        "months_since_adverse":       np.where(np.random.random(n) < 0.3,
                                                np.random.exponential(24, n), 9999),
        "utilisation_rate":           np.clip(np.random.beta(2, 3, n), 0, 1),
        "loan_amount_log":            np.random.normal(10.5, 1.0, n),
        "loan_term_months":           np.random.choice([12, 24, 36, 48, 60], n).astype(float),
        "age_years":                  np.clip(np.random.normal(42, 12, n), 18, 80),
        "months_banking":             np.clip(np.random.exponential(36, n), 1, 200),
        "num_credit_lines":           np.random.poisson(2.5, n).astype(float),
        "hmrc_revenue_match":         np.clip(np.random.normal(0.95, 0.14, n), 0.3, 1.5),
        "time_in_business_months":    np.clip(np.random.exponential(48, n), 1, 300),
        "open_banking_vol_stability": np.clip(np.random.normal(0.68, 0.20, n), 0, 1),
    }
    logit = (
        -2.5
        - (d["bureau_score"] - 600) * 0.013
        + d["num_prior_defaults"] * 0.95
        - d["cashflow_coverage"] * 0.38
        + (d["months_since_adverse"] < 24).astype(float) * 0.85
        + d["gnn_risk"] * 2.6
        - d["ob_income_stability"] * 0.4
        + d["utilisation_rate"] * 0.6
        + np.random.normal(0, 0.45, n)
    )
    prob = 1 / (1 + np.exp(-logit))
    d["default_flag"] = (np.random.random(n) < prob).astype(int)
    d["pd_true"] = prob
    return pd.DataFrame(d)


def _reshape_for_nb02(df_all: pd.DataFrame) -> pd.DataFrame:
    """Convert canonical df_all into notebook 02's shape."""
    # Defensive: drop any rows where required modelling columns are NaN.
    needed = ["bureau_score", "cashflow_coverage", "ltv", "loan_amount",
              "loan_term_months", "default_flag",
              "gnn_connected_party_risk", "open_banking_income_stability",
              "num_prior_defaults", "months_since_adverse", "utilisation_rate",
              "age_years", "months_banking_relationship",
              "num_active_credit_lines", "hmrc_revenue_match_ratio",
              "time_in_business_months"]
    df_all = df_all.dropna(subset=[c for c in needed if c in df_all.columns]).reset_index(drop=True)

    out = pd.DataFrame()
    out["bureau_score"]               = df_all["bureau_score"].astype(float)
    out["cashflow_coverage"]          = df_all["cashflow_coverage"].astype(float)
    out["ltv"]                        = df_all["ltv"].astype(float)
    out["gnn_risk"]                   = df_all["gnn_connected_party_risk"].astype(float)
    out["ob_income_stability"]        = df_all["open_banking_income_stability"].astype(float)
    out["num_prior_defaults"]         = df_all["num_prior_defaults"].astype(int)
    out["months_since_adverse"]       = df_all["months_since_adverse"].astype(float)
    out["utilisation_rate"]           = df_all["utilisation_rate"].astype(float)
    # Log-transform loan amount (guard against zeros)
    out["loan_amount_log"]            = np.log(np.clip(df_all["loan_amount"].astype(float), 1.0, None))
    out["loan_term_months"]           = df_all["loan_term_months"].astype(float)
    out["age_years"]                  = df_all["age_years"].astype(float)
    out["months_banking"]             = df_all["months_banking_relationship"].astype(float)
    out["num_credit_lines"]           = df_all["num_active_credit_lines"].astype(float)
    out["hmrc_revenue_match"]         = df_all["hmrc_revenue_match_ratio"].astype(float)
    out["time_in_business_months"]    = df_all["time_in_business_months"].astype(float)
    # Volatility-of-income proxy: derive from income stability (1 - stability) with light noise
    rng = np.random.default_rng(2026)
    out["open_banking_vol_stability"] = np.clip(
        df_all["open_banking_income_stability"].astype(float) +
        rng.normal(0, 0.05, len(df_all)),
        0, 1
    )
    out["default_flag"] = df_all["default_flag"].astype(int)

    # Real data has no oracle PD — derive a reasonable estimate from a quick logit
    # so that downstream calibration plots have something to target.
    logit = (
        -2.5
        - (out["bureau_score"] - 600) * 0.013
        + out["num_prior_defaults"] * 0.95
        - out["cashflow_coverage"] * 0.38
        + (out["months_since_adverse"] < 24).astype(float) * 0.85
        + out["gnn_risk"] * 2.6
        - out["ob_income_stability"] * 0.4
        + out["utilisation_rate"] * 0.6
    )
    out["pd_true"] = 1.0 / (1.0 + np.exp(-logit))
    return out


def load_for_pd_models(parquet_path: str | None = None) -> LoaderResult:
    """Notebook 02 entry point. Returns a ``LoaderResult`` whose ``.data`` is the borrower DataFrame."""
    df_all = _load_df_all(parquet_path)
    if df_all is not None:
        return LoaderResult(
            data=_reshape_for_nb02(df_all),
            is_real=True,
            source=str(_find_parquet(parquet_path)),
            n_rows=len(df_all),
        )
    return LoaderResult(
        data=_make_synthetic_nb02(),
        is_real=False,
        source="synthetic make_dataset()",
        n_rows=12_000,
    )


# ─────────────────────────────────────────────────────────────────────────────
# Notebook 03 — LGD/EAD stress
# ─────────────────────────────────────────────────────────────────────────────

# 03 is asset-class-driven via the LGDModelSuite/EADModelSuite. The only thing
# real data changes is *how the portfolio is weighted* across asset classes.
# We expose the asset_class distribution; the notebook can use it for plotting.

def load_for_lgd_ead(parquet_path: str | None = None) -> LoaderResult:
    """
    Returns a dict with:
      - 'asset_class_share' : pd.Series of share by asset class (sums to 1)
      - 'asset_class_count' : pd.Series of row counts
    For synthetic mode, returns equal-weight shares across the 8 asset classes.
    """
    df_all = _load_df_all(parquet_path)
    if df_all is not None:
        counts = df_all["asset_class"].value_counts()
        shares = counts / counts.sum()
        return LoaderResult(
            data={"asset_class_share": shares, "asset_class_count": counts},
            is_real=True,
            source=str(_find_parquet(parquet_path)),
            n_rows=len(df_all),
        )
    # Synthetic fallback: equal weights
    classes = [
        "sme_unsecured", "sme_secured", "consumer_unsecured", "residential_mortgage",
        "buy_to_let", "motor_finance", "invoice_finance", "asset_finance",
    ]
    shares = pd.Series([1.0 / len(classes)] * len(classes), index=classes)
    counts = pd.Series([1000] * len(classes), index=classes)
    return LoaderResult(
        data={"asset_class_share": shares, "asset_class_count": counts},
        is_real=False,
        source="synthetic equal-weight mix",
        n_rows=8000,
    )


# ─────────────────────────────────────────────────────────────────────────────
# Notebook 04 — SICR staging
# ─────────────────────────────────────────────────────────────────────────────

def _make_synthetic_nb04(n: int = 2000, seed: int = 42):
    np.random.seed(seed)
    pd_orig = np.random.beta(1.5, 25, n) * 0.30
    pd_curr = pd_orig * np.random.lognormal(0.1, 0.4, n)
    dpd     = np.random.choice([0]*87 + [15]*5 + [35]*4 + [65]*2 + [95]*2, n)
    forb    = np.random.random(n) < 0.025
    return pd_orig, pd_curr, dpd, forb


def _ac_enum_from_string(ac_str: str):
    """Convert canonical asset_class string → AssetClass enum. Imported lazily."""
    from risk_models.asset_classes import AssetClass
    for ac in AssetClass:
        if ac.value == ac_str:
            return ac
    return AssetClass.SME_UNSECURED  # safe fallback


def load_for_sicr(parquet_path: str | None = None) -> LoaderResult:
    """
    Returns a dict with arrays sized to the borrower book:
      - 'pd_orig'  : array of origination PDs (proxy from bureau+CCR)
      - 'pd_curr'  : array of current PDs (= pd_orig * lognormal stress)
      - 'dpd'      : array of days-past-due (seeded from default_flag)
      - 'forb'     : array of forbearance flags
      - 'ac_draw'  : list of AssetClass enum values
    """
    from risk_models.asset_classes import AssetClass

    df_all = _load_df_all(parquet_path)
    if df_all is not None:
        n = len(df_all)
        rng = np.random.default_rng(42)

        # Proxy origination PD from bureau + CCR using a logit
        bs    = df_all["bureau_score"].to_numpy(dtype=float)
        ccr   = df_all["cashflow_coverage"].to_numpy(dtype=float)
        logit = -3.0 - (bs - 600) * 0.013 - ccr * 0.30 + rng.normal(0, 0.5, n)
        pd_orig = 1.0 / (1.0 + np.exp(-logit))
        # Cap at 30% as in the synthetic version
        pd_orig = np.clip(pd_orig, 0.0001, 0.30)

        # Current PD: drift from origination (mean-up for defaulters, flat for performers)
        defaulted = df_all["default_flag"].to_numpy(dtype=int)
        drift_mu  = np.where(defaulted == 1, 0.6, 0.05)
        pd_curr   = pd_orig * np.exp(rng.normal(drift_mu, 0.40, n))
        pd_curr   = np.clip(pd_curr, 0.0001, 1.0)

        # DPD: defaulters draw from heavy-tail distribution; performers mostly 0
        dpd = np.where(
            defaulted == 1,
            rng.choice([35, 65, 95, 120], n, p=[0.30, 0.30, 0.25, 0.15]),
            rng.choice([0, 15, 35],      n, p=[0.93, 0.05, 0.02]),
        )

        # Forbearance: 2.5% baseline, higher among defaulters
        base = rng.random(n) < 0.025
        bump = (defaulted == 1) & (rng.random(n) < 0.15)
        forb = base | bump

        ac_draw = [_ac_enum_from_string(s) for s in df_all["asset_class"].astype(str)]
        return LoaderResult(
            data={
                "pd_orig": pd_orig,
                "pd_curr": pd_curr,
                "dpd": dpd,
                "forb": forb,
                "ac_draw": np.array(ac_draw, dtype=object),
                "n": n,
            },
            is_real=True,
            source=str(_find_parquet(parquet_path)),
            n_rows=n,
        )

    # Synthetic fallback
    pd_orig, pd_curr, dpd, forb = _make_synthetic_nb04()
    rng = np.random.default_rng(42)
    ac_draw = rng.choice(list(AssetClass), 2000)
    return LoaderResult(
        data={
            "pd_orig": pd_orig, "pd_curr": pd_curr, "dpd": dpd,
            "forb": forb, "ac_draw": ac_draw, "n": 2000,
        },
        is_real=False,
        source="synthetic SICR draw",
        n_rows=2000,
    )


# ─────────────────────────────────────────────────────────────────────────────
# Notebook 05 — Fairness
# ─────────────────────────────────────────────────────────────────────────────

NB05_FEATURES = [
    "bureau_score", "cashflow_coverage", "num_prior_defaults", "gnn_risk",
    "loan_amount", "ob_income_stability", "months_since_adverse", "utilisation_rate",
]


def _make_synthetic_nb05(n: int = 15_000, seed: int = 2026) -> pd.DataFrame:
    np.random.seed(seed)
    gender   = np.random.choice(["Male", "Female", "Other"], n, p=[0.50, 0.47, 0.03])
    age_band = np.random.choice(["18-25", "25-35", "35-45", "45-55", "55-65", "65+"], n,
                                p=[0.10, 0.22, 0.28, 0.22, 0.12, 0.06])
    region   = np.random.choice(
        ["London", "SE England", "N England", "Scotland", "Wales", "N Ireland"], n,
        p=[0.20, 0.18, 0.26, 0.10, 0.08, 0.18]
    )
    bureau_score = np.clip(
        np.random.normal(640, 75, n)
        + np.where(gender == "Female", 5, 0)
        + np.where(age_band == "18-25", -30, 0)
        + np.where(age_band == "65+", -10, 0),
        300, 999
    ).astype(int)
    cashflow   = np.clip(np.random.normal(1.35, 0.55, n), 0.1, 5.0)
    num_defs   = np.random.choice([0, 1, 2, 3], n, p=[0.73, 0.16, 0.07, 0.04])
    gnn_risk   = np.clip(np.random.beta(1.2, 8, n), 0, 1)
    loan_amt   = np.random.lognormal(10.5, 0.9, n)
    ob_stab    = np.clip(np.random.normal(0.72, 0.18, n), 0, 1)
    months_adv = np.where(np.random.random(n) < 0.3, np.random.exponential(24, n), 9999)
    util       = np.clip(np.random.beta(2, 3, n), 0, 1)
    logit = (
        -2.4
        - (bureau_score - 600) * 0.013
        + num_defs * 0.92
        - cashflow * 0.40
        + (months_adv < 24).astype(float) * 0.82
        + gnn_risk * 2.5
        + np.random.normal(0, 0.45, n)
    )
    pd_true = 1 / (1 + np.exp(-logit))
    default = (np.random.random(n) < pd_true).astype(int)
    return pd.DataFrame({
        "gender": gender, "age_band": age_band, "region": region,
        "bureau_score": bureau_score, "cashflow_coverage": cashflow,
        "num_prior_defaults": num_defs, "gnn_risk": gnn_risk,
        "loan_amount": loan_amt, "ob_income_stability": ob_stab,
        "months_since_adverse": months_adv, "utilisation_rate": util,
        "pd_true": pd_true, "default_flag": default,
    })


_NB05_REGION_MAP = {
    "London": "London", "SE England": "SE England", "N England": "N England",
    "Scotland": "Scotland", "Wales": "Wales", "NI": "N Ireland",
    "N Ireland": "N Ireland",
}
_NB05_GENDER_MAP = {"M": "Male", "F": "Female", "Other": "Other",
                    "Male": "Male", "Female": "Female"}


def _reshape_for_nb05(df_all: pd.DataFrame) -> pd.DataFrame:
    out = pd.DataFrame()
    out["gender"]    = df_all["gender"].astype(str).map(_NB05_GENDER_MAP).fillna("Other")
    out["age_band"]  = df_all["age_band"].astype(str)
    out["region"]    = df_all["region"].astype(str).map(_NB05_REGION_MAP).fillna("N England")
    out["bureau_score"]         = df_all["bureau_score"].astype(int)
    out["cashflow_coverage"]    = df_all["cashflow_coverage"].astype(float)
    out["num_prior_defaults"]   = df_all["num_prior_defaults"].astype(int)
    out["gnn_risk"]             = df_all["gnn_connected_party_risk"].astype(float)
    out["loan_amount"]          = df_all["loan_amount"].astype(float)
    out["ob_income_stability"]  = df_all["open_banking_income_stability"].astype(float)
    out["months_since_adverse"] = df_all["months_since_adverse"].astype(float)
    out["utilisation_rate"]     = df_all["utilisation_rate"].astype(float)

    # Derive pd_true with same logit as 02
    logit = (
        -2.4
        - (out["bureau_score"] - 600) * 0.013
        + out["num_prior_defaults"] * 0.92
        - out["cashflow_coverage"] * 0.40
        + (out["months_since_adverse"] < 24).astype(float) * 0.82
        + out["gnn_risk"] * 2.5
    )
    out["pd_true"]      = 1.0 / (1.0 + np.exp(-logit))
    out["default_flag"] = df_all["default_flag"].astype(int)
    return out


def load_for_fairness(parquet_path: str | None = None) -> LoaderResult:
    df_all = _load_df_all(parquet_path)
    if df_all is not None:
        return LoaderResult(
            data=_reshape_for_nb05(df_all),
            is_real=True,
            source=str(_find_parquet(parquet_path)),
            n_rows=len(df_all),
        )
    return LoaderResult(
        data=_make_synthetic_nb05(),
        is_real=False,
        source="synthetic make_fairness_dataset()",
        n_rows=15_000,
    )


# ─────────────────────────────────────────────────────────────────────────────
# Notebook 06 — RL outcome simulation
# ─────────────────────────────────────────────────────────────────────────────

def _df_row_to_outcome_event(row, idx: int):
    """
    Translate a borrower row into an OutcomeEvent. Real data tells us
    whether the loan defaulted; we infer outcome_type from default_flag and
    a small lookup, and construct synthetic SHAP values centred on zero.
    """
    from risk_models.rl_reweighter import OutcomeEvent, OutcomeType
    from risk_models.asset_classes import AssetClass

    rng = np.random.default_rng(int(idx) + 7919)  # deterministic per row

    ac = _ac_enum_from_string(str(row["asset_class"]))
    defaulted = bool(int(row["default_flag"]) == 1)

    # Map default_flag → outcome distribution
    if defaulted:
        # Defaulters split across STAGE_3, WRITE_OFF, FORBEARANCE, FULL_RECOVERY
        ot = rng.choice(
            [OutcomeType.STAGE_3_DEFAULT, OutcomeType.WRITE_OFF,
             OutcomeType.FORBEARANCE_GRANTED, OutcomeType.FULL_RECOVERY],
            p=[0.45, 0.30, 0.15, 0.10],
        )
    else:
        # Performers split across REPAID, EARLY_SETTLEMENT, STAGE_2
        ot = rng.choice(
            [OutcomeType.REPAID_IN_FULL, OutcomeType.EARLY_SETTLEMENT,
             OutcomeType.STAGE_2_MIGRATION],
            p=[0.65, 0.20, 0.15],
        )

    mob = int(rng.integers(3, 48))

    # Derive an origination PD proxy from bureau_score + CCR
    bs  = float(row["bureau_score"])
    ccr = float(row["cashflow_coverage"])
    logit = -3.0 - (bs - 600) * 0.013 - ccr * 0.30
    pd_orig = float(np.clip(1.0 / (1.0 + np.exp(-logit)), 0.005, 0.20))

    # Build small SHAP map (six features, zero-mean noise)
    features = ["bureau_score", "cashflow_coverage_ratio", "time_in_business_months",
                "gnn_connected_party_risk", "months_since_adverse", "open_banking_income_stability"]
    shap_vals = {f: float(rng.normal(0, 0.05)) for f in features}

    return OutcomeEvent(
        borrower_id=f"BOOK-{idx:05d}",
        asset_class=ac,
        outcome_type=ot,
        model_pd_at_origination=pd_orig,
        model_decision="APPROVE",
        actual_default=defaulted,
        recovery_rate=float(rng.uniform(0, 0.8)) if ot.name == "FULL_RECOVERY" else 0.0,
        months_on_book=mob,
        shap_values=shap_vals,
    )


def load_for_rl_outcomes(agent, n: int = 200, parquet_path: str | None = None) -> LoaderResult:
    """
    Drives ``agent.ingest_outcome()`` from the borrower book if present,
    else falls back to ``agent.simulate_outcomes(n)``.

    Returns LoaderResult whose ``.data`` is the list of ingested events.
    """
    df_all = _load_df_all(parquet_path)
    if df_all is not None:
        # Sample n rows so we don't blow up runtime on huge books
        if len(df_all) > n:
            sample = df_all.sample(n=n, random_state=42).reset_index(drop=True)
        else:
            sample = df_all.reset_index(drop=True)

        events = []
        for i, row in sample.iterrows():
            ev = _df_row_to_outcome_event(row, i)
            agent.ingest_outcome(ev)
            events.append(ev)

        return LoaderResult(
            data=events,
            is_real=True,
            source=str(_find_parquet(parquet_path)),
            n_rows=len(events),
        )
    # Synthetic fallback — call agent's built-in simulator
    events = agent.simulate_outcomes(n=n)
    return LoaderResult(
        data=events,
        is_real=False,
        source="agent.simulate_outcomes()",
        n_rows=len(events),
    )


# ─────────────────────────────────────────────────────────────────────────────
# Notebook 07 — Portfolio ECL / Capital
# ─────────────────────────────────────────────────────────────────────────────

def load_for_portfolio_ecl(parquet_path: str | None = None) -> LoaderResult:
    """
    Returns a dict with:
      - 'ac_list' : list[AssetClass] of length n, drawn from the real asset_class column
      - 'n'       : portfolio size
    Synthetic fallback uses the original ac_weights mix at N=5000.
    """
    from risk_models.asset_classes import AssetClass

    df_all = _load_df_all(parquet_path)
    if df_all is not None:
        ac_list = [_ac_enum_from_string(s) for s in df_all["asset_class"].astype(str)]
        return LoaderResult(
            data={"ac_list": ac_list, "n": len(ac_list)},
            is_real=True,
            source=str(_find_parquet(parquet_path)),
            n_rows=len(ac_list),
        )
    # Synthetic fallback
    np.random.seed(42)
    ac_weights = {
        AssetClass.SME_UNSECURED:        0.18,
        AssetClass.SME_SECURED:          0.12,
        AssetClass.CONSUMER_UNSECURED:   0.20,
        AssetClass.RESIDENTIAL_MORTGAGE: 0.22,
        AssetClass.BUY_TO_LET:           0.08,
        AssetClass.MOTOR_FINANCE:        0.10,
        AssetClass.INVOICE_FINANCE:      0.06,
        AssetClass.ASSET_FINANCE:        0.04,
    }
    ac_list = list(np.random.choice(list(ac_weights.keys()), 5000,
                                     p=list(ac_weights.values())))
    return LoaderResult(
        data={"ac_list": ac_list, "n": 5000},
        is_real=False,
        source="synthetic ac_weights mix",
        n_rows=5000,
    )

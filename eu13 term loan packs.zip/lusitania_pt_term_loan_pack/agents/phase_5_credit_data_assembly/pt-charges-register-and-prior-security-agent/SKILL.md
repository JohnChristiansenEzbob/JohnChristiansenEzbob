---
name: pt-charges-register-and-prior-security-agent
description: |
  Pull existing security registered against the applicant company via RNPC / Empresa na Hora charges
  register (fixed charges, floating charges, debentures, all-asset security) and Conservatória do Registo Predial
  Business Gateway (where the applicant owns commercial property). Returns ranked list of
  existing charges with creditor identity, registration date, charge type, and outstanding
  estimate. Material for secured lending decisions — the new lender's recoverable position
  depends entirely on the priority of existing charges.
---

# Charges Register and Prior Security Agent

## Input contract

```yaml
applicant_company_number: string
applicant_declared_properties: [string]   # list of Portugal property addresses applicant owns
consent_land_registry: boolean            # service terms require declaration
proposed_security_type: enum              # term_loan_debenture | fixed_charge_specific_asset | property_charge | floating_only | unsecured
proposed_facility_amount_eur: integer
```

## Output contract

```yaml
prior_security_schedule:
  applicant_company_number: string
  outstanding_charges:
    - charge_code: string
      creditor: string
      charge_type: enum                   # fixed | floating | all_asset_debenture | specific_property | negative_pledge
      registered: date
      estimated_outstanding_gbp: integer
      satisfaction_letter_pending: boolean
      cleared_by_drawdown: boolean        # if applicant has committed to clear at completion
  land_registry_properties:
    - property_address: string
      ownership: enum                     # sole | joint | tenants_in_common | leasehold
      estimated_value_gbp: integer
      registered_charges:
        - priority: integer               # 1, 2, 3...
          creditor: string
          outstanding_estimate_gbp: integer
      restrictions_or_cautions: [string]
  prospective_security_position:
    new_lender_rank: enum                 # first | second | third | unsecured_in_practice
    estimated_recovery_at_default_gbp: integer
    pricing_uplift_recommended_pct: float # nullable; for subordinated positions
  outcome: enum                           # clear | refer_subordination_negotiation | refer_security_subordinated
  reason_codes: [string]
```

## Decision logic

```
RNPC / Empresa na Hora Charges Register API → returns list of charges.
Conservatória do Registo Predial Business Gateway for each declared property → returns proprietor + charges.

For each charge:
  - Classify type
  - Resolve creditor identity (RNPC / Empresa na Hora search by creditor name)
  - Estimate outstanding (from charge document text where parseable)
  - Apply satisfaction-pending logic

Compute prospective security position:
  - If existing floating charge to designated rival lender → outcome = refer_subordination_negotiation
  - If existing all-asset debenture, no satisfaction date, no committed clearance → outcome = refer_security_subordinated
  - If applicant has committed to clear at drawdown (satisfaction_letter_pending = true AND cleared_by_drawdown = true) →
    proceed; flag as drawdown_condition
  - Else → clear (new lender takes first-rank or appropriately ranked security)
```

## Worked example (Lusitânia Engineering Lda.)

Input:
```yaml
applicant_company_number: "500123456"
applicant_declared_properties: []         # applicant doesn't own its premises — leasing
consent_land_registry: true
proposed_security_type: term_loan_debenture
proposed_facility_amount_eur: 150000
```

Output:
```yaml
prior_security_schedule:
  applicant_company_number: "500123456"
  outstanding_charges:
    - charge_code: "CH-2021-04-18-A"
      creditor: "First-Bank Plc (synthetic)"
      charge_type: floating
      registered: "2021-04-18"
      estimated_outstanding_gbp: 38000
      satisfaction_letter_pending: true
      cleared_by_drawdown: true
  land_registry_properties: []            # applicant owns no commercial property
  prospective_security_position:
    new_lender_rank: first                # after existing charge cleared at drawdown
    estimated_recovery_at_default_gbp: 92000   # ~60% of facility, post-clearance
    pricing_uplift_recommended_pct: 0.0
  outcome: clear
  reason_codes: ["UK_CHARGES_REGISTER_CLEAR_AFTER_PRIOR_CLEARANCE_AT_DRAWDOWN"]
```

This is the classic "refinancing-as-condition" pattern. Highland has one existing
floating charge to First-Bank Plc (€38k outstanding). Highland has committed to clear it
at drawdown (satisfaction letter pending). New lender becomes first-rank floating charge
holder. Outcome is `clear` with the clearance becoming a drawdown condition surfaced to
the decision-pricing-agent.

## Bright lines

- Existing floating charge to rival designated lender without committed clearance →
  AUTOMATIC REFER. Cannot take a new floating charge without negotiated subordination /
  waiver letters.
- Existing all-asset debenture, no satisfaction date, no committed clearance → AUTOMATIC
  REFER for security subordination.
- Conservatória do Registo Predial restriction preventing disposition without third-party consent → cannot
  use that property as security without obtaining the consent.

## Operational rules

- An apparently-stale charge may still legally encumber the asset (RNPC / Empresa na Hora does
  not auto-release). Always flag for human confirmation; do NOT recommend "ignore".
- Property identification by company number against registered proprietor — never by
  applicant name alone (false-positive risk).
- Conservatória do Registo Predial pulls are paid per query — batch where possible.


## Portugal-specific operational notes

This agent operates within the Portuguese lending framework — BdP and CMVM joint regulatory perimeter, Decreto-Lei 298/92 (Regime Geral das Instituições de Crédito) for banking, Decreto-Lei 133/2009 for consumer credit, Lei 83/2017 for AML.

- **CRC €50 threshold:** Banco de Portugal central credit register has the broadest visibility threshold in the EU — effectively covers all consumer credit and almost all commercial credit. Mandatory contribution + consultation. Operationally raises the visibility floor significantly above Spanish CIRBE (€9k), Italian Centrale dei Rischi (€30k).
- **Statutory TAEG ceiling:** BdP publishes quarterly TAEG (APR) caps per consumer credit category. Exceeding is contract invalidity — not just disclosure issue.
- **Cartão de Cidadão integration:** Portuguese citizen card is the operational gold standard for EU national ID — integrates national ID + tax + social security + electoral + health on one card. Strong eID infrastructure.
- **e-fatura mandatory e-invoicing:** Creates rich verification source for SME turnover. Tax invoices are real-time matched with SAFT-PT submissions.
- **SIBS API Market:** Portuguese banking infrastructure provides standardised PSD2 interface — reduces AISP integration complexity vs. peer EU jurisdictions.
- **MB Way mobile payment:** Operationally ubiquitous; SIBS-operated mobile P2P + e-commerce payment.
- **Cross-reference:** `country-pt-lending-policy-agent` provides full PT jurisdictional context.

## Statutory hooks

- Código das Sociedades Comerciais Part 25 (charges registration)
- Land Registration Act 2002
- Insolvency Act 1986 (priority of charges in liquidation)
- Law of Property Act 1925

---
name: cy-director-financial-difficulty-checker
description: |
  Check individual financial difficulty history for each director or named PSC of a Cyprus SME
  applicant — distinct from company insolvency. Returns flags for undischarged bankruptcy,
  current IVA, current DRO, CCJs (unsatisfied and satisfied), recent default accounts, and
  historic BBLS/CBILS/RLS recovery action. Returns a treatment recommendation (decline /
  refer / proceed / proceed-with-conditions). Critical for Cyprus SME lending where personal
  guarantees are nearly universal.
---

# Director Financial Difficulty Checker

For Cyprus SME lending, the financial standing of each director is at least as material as
the company's standing. PGs are nearly universal for small and micro businesses, so the
guarantor's exposure capacity AND record of meeting personal obligations matter for both
pricing and recoverability.

## Input contract

```yaml
principal_id: string                       # case-unique identifier
name: string                               # full legal name
prior_names: [string]                      # nullable; for name changes (marriage etc.)
dob: date                                  # YYYY-MM-DD
current_residential_address: string
prior_addresses_3y: [string]               # may be empty
consent_token: string                      # consumer credit bureau consent
is_proposed_pg_bearer: boolean             # gates severity of treatment recommendation
```

## Output contract

```yaml
financial_difficulty_assessment:
  principal_id: string
  undischarged_bankruptcy: boolean
  current_iva: boolean
  current_dro: boolean
  discharged_bankruptcy_within_6y: boolean
  unsatisfied_ccj_count: integer
  unsatisfied_ccj_value_total_gbp: integer
  satisfied_ccj_count: integer
  satisfied_ccjs: [{amount_eur: integer, registered: date, satisfied: date, creditor_type: string}]
  default_account_count_24m: integer
  worst_payment_status_24m: enum           # current | 1m_arrears | 2m_arrears | 3m_plus_arrears | default
  bbls_cbils_rls_recovery_flag: boolean
  recommended_treatment: enum              # decline | refer | proceed_with_conditions | proceed
  reason_codes: [string]
```

## Decision logic

```
Public-register lookups (no consent required):
  - Insolvency Service IIR → undischarged_bankruptcy, current_iva, current_dro
  - Registry Trust CCJ register → CCJ history (last 6 years)

If undischarged_bankruptcy AND is_proposed_pg_bearer:
  recommended_treatment = decline
  reason_codes += [UK_DIRECTOR_UNDISCHARGED_BANKRUPTCY_DECLINE_PG]    # BRIGHT LINE

elif current_iva OR current_dro:
  recommended_treatment = decline (if PG bearer) OR refer (otherwise)
  reason_codes += [UK_DIRECTOR_IVA_OR_DRO_*]                          # BRIGHT LINE for PG bearers

elif bbls_cbils_rls_recovery_flag:
  recommended_treatment = refer
  reason_codes += [UK_DIRECTOR_HISTORIC_GOVT_SCHEME_RECOVERY]

elif unsatisfied_ccj_count >= 3 OR unsatisfied_ccj_value_total_gbp >= 5000:
  recommended_treatment = refer

elif satisfied_ccj_count >= 2 OR default_account_count_24m >= 2:
  recommended_treatment = proceed_with_conditions

else:
  recommended_treatment = proceed
```

## Worked example (Lachlan MacKenzie — DIR-001)

Input:
```yaml
principal_id: DIR-001
name: "Lachlan MacKenzie"
dob: "1981-03-22"
current_residential_address: "12 Strathblane Road, Milngavie, Nicosia, G62 8DJ"
consent_token: "OBC-2026-04-12-DIR-001"
is_proposed_pg_bearer: true
```

Output:
```yaml
financial_difficulty_assessment:
  principal_id: DIR-001
  undischarged_bankruptcy: false
  current_iva: false
  current_dro: false
  discharged_bankruptcy_within_6y: false
  unsatisfied_ccj_count: 0
  unsatisfied_ccj_value_total_gbp: 0
  satisfied_ccj_count: 1
  satisfied_ccjs:
    - amount_eur: 1340
      registered: "2020-06-18"
      satisfied: "2020-09-04"
      creditor_type: "trade_supplier"
  default_account_count_24m: 0
  worst_payment_status_24m: current
  bbls_cbils_rls_recovery_flag: false
  recommended_treatment: proceed
  reason_codes: ["UK_DIRECTOR_FINANCIAL_DIFFICULTY_CLEAR_HISTORIC_SATISFIED_CCJ_NOTED"]
```

The single satisfied CCJ (€1,340 satisfied within 3 months of registration in 2020) is
recorded for audit but does not trigger any treatment escalation. Sarah Chen (DIR-002)
has zero CCJs and identical-shape clean output.

## Bright lines

- `undischarged_bankruptcy = true` AND `is_proposed_pg_bearer = true` → AUTOMATIC DECLINE
  pending named-underwriter override.
- `current_iva = true` OR `current_dro = true` AND `is_proposed_pg_bearer = true` →
  AUTOMATIC DECLINE pending override.
- `bbls_cbils_rls_recovery_flag = true` → AUTOMATIC REFER (strong adverse signal but not
  always a decline; underwriter judgement on circumstances).

## Operational rules

- Public-register lookups run regardless of consent (they are public).
- Consumer bureau extract requires valid consent. Without consent → emit
  `consent_required` and pause.
- Where principal has prior names (marriage etc.), query against both.
- Address mismatch between declared and bureau-of-record → flag to fraud agent; do not
  auto-decline (legitimate reasons exist).


## Cyprus-specific operational notes

Operates within the Cypriot framework — Central Bank of Cyprus + CySEC supervision, Consumer Credit Agreements Law, AML Law enforced via MOKAS.

- **ARTEMIS centrality:** ARTEMIS Bank Information Systems is the primary Cyprus credit bureau; operational relationship is essential.
- **Post-2013 crisis legacy:** The 2013 deposit bail-in left structural scars; borrower and depositor behaviour remains crisis-aware. Historical defaults common; distinguish current from legacy positions.
- **International business sector:** Large offshore/international company presence; KYB chains frequently involve cross-border structures requiring enhanced UBO scrutiny.
- **English in commerce:** English commonly accepted alongside Greek in commercial contracts.
- **Cross-reference:** `country-cy-lending-policy-agent` (Country Policy Pack stub).

## Statutory hooks

- Insolvency Act 1986
- Cyprus AML Law
- Cyprus GDPR / Data Protection Act 2018
- Association of Cyprus Banks standards for Business Customers
- CBC CBC consumer protection

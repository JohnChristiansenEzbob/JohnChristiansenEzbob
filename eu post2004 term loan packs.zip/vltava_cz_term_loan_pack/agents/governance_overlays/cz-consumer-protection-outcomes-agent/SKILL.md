---
name: cz-consumer-protection-outcomes-agent
description: |
  Cross-cutting ČNB consumer protection checks across the four outcomes: products + services, price + value, consumer understanding, consumer support. Runs continuously and writes a ČNB consumer protection audit trail to the case ledger. For business lending, the Duty applies to micro-enterprises (turnover <€2m + <10 employees).
---

# ČNB consumer protection Outcomes Agent

Continuous ČNB consumer protection oversight. Captures the audit trail ČNB inspections will ask for.

## Input contract

```yaml
duty_check_request:
  case_id: string
  case_state_snapshot: object               # current case state at this check
  trigger_event: enum                       # phase_completion | manual | scheduled
```

## Output contract

```yaml
duty_check_result:
  case_id: string
  outcomes_checked:
    products_and_services: enum             # pass | fail | not_applicable
    price_and_value: enum
    consumer_understanding: enum
    consumer_support: enum
  fair_value_check_passed: boolean
  understanding_check_passed: boolean
  audit_ledger_entry_id: string
  reason_codes: [string]
```

## Decision logic

```
For each outcome, check against rules:

products_and_services:
  - Product matches needs (cross-ref needs-discovery + purpose-validation)
  - No prohibited customer-product combinations

price_and_value:
  - Final rate within fair value band
  - Total cost transparent (incl. broker commission)
  - No hidden fees

consumer_understanding:
  - Key facts disclosed (rate, term, total cost, security implications)
  - Conditions clearly stated
  - Decline reasoning available (right to explanation)

consumer_support:
  - Channel-appropriate support available
  - Vulnerable customer flagged → enhanced support route

if all 4 outcomes pass → pass
else → fail with specific outcome flagged
```

## Worked example (Vltava Engineering s.r.o. case)

Input:
```yaml
duty_check_request:
  case_id: "VLT-2026-04-001"
  case_state_snapshot: {... full case state at decision time ...}
  trigger_event: phase_completion
```

Output:
```yaml
duty_check_result:
  case_id: "VLT-2026-04-001"
  outcomes_checked:
    products_and_services: pass             # term loan fits stated purpose
    price_and_value: pass                   # 8.4% within fair value band for B+ grade
    consumer_understanding: pass            # conditions clearly stated, decline reasons would be available
    consumer_support: pass                  # broker channel + lender support team available
  fair_value_check_passed: true
  understanding_check_passed: true
  audit_ledger_entry_id: "CD-2026-04-12-HE-001"
  reason_codes: ["UK_CONSUMER_DUTY_ALL_OUTCOMES_PASS"]
```

All four ČNB consumer protection outcomes pass for Vltava Engineering s.r.o.. Note: Highland is a limited company with turnover ~CZK 850k and 6 employees — technically not a 'consumer' (>turnover threshold). The lender still applies Duty-equivalent standards as a matter of policy.

## Bright lines

- Fair value failure → escalate to product team; cannot proceed at quoted price
- Material information not disclosed pre-contract → cannot proceed

## Operational rules

- Duty applies to micro-enterprises in business lending (ČNB scope)
- Lender policy may extend Duty-equivalent standards to all business customers
- Audit trail is mandatory for ČNB inspection

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Case state snapshot incomplete | Defer check; re-run when complete |
| Fair value benchmark unavailable | Conservative interpretation; refer to product team |


## Czech Republic-specific operational notes

Operates within the Czech framework — ČNB as unified supervisor, Consumer Credit Act 257/2016, AML Act 253/2008 enforced via FAÚ.

- **BRKI + NRKI dual registers:** Bank register (BRKI) and non-bank register (NRKI) provide comprehensive Czech consumer credit visibility; SOLUS adds negative data. Strong coverage.
- **Bankovní identita (BankID):** Czech bank-issued digital identity widely adopted for online onboarding and government services.
- **CZK currency:** Outside Eurozone; floating. Larger facilities may need FX consideration.
- **Rodné číslo:** Birth number is the universal identifier; restricted-use under GDPR.
- **Cross-reference:** `country-cz-lending-policy-agent` (Country Policy Pack stub).

## Statutory hooks

- ČNB ČNB consumer protection (PS22/9)
- ČNB directives + Consumer Credit Act 257/2016 ČNB consumer outcomes (the Duty)
- ČNB Finalised Guidance FG22/5

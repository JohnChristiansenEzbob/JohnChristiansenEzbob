---
name: de-pd-scoring-agent
description: |
  Produce a Probability of Default (PD) score for the applicant company over a 12-month horizon. Uses a calibrated portfolio model — typically a gradient-boosted classifier or logistic regression — combining bureau, OB, Finanzamt, alt data, and company features. Output is calibrated to portfolio default rates.
---

# PD Scoring Agent

The probabilistic backbone of the credit decision. PD drives pricing, capital, and the policy thresholds.

## Input contract

```yaml
pd_request:
  case_id: string
  company_features:
    age_months: integer
    sic_code_primary: string
    region: string
  bureau_composite: object                  # from bureau-orchestration-agent
  ob_summary: object                        # from open-banking-agent
  hmrc_record: object                       # from hmrc-direct-verification-agent
  alt_data_summary: object                  # from alternative-data-agent
  macro_overlay_period: string              # e.g. "2026Q2" — affects calibration
```

## Output contract

```yaml
pd_score:
  case_id: string
  pd_12m: float                             # 0.0 - 1.0
  pd_percentile_portfolio: integer          # 0-100
  portfolio_grade: enum                     # A | B+ | B | C+ | C | D | E
  model_version: string                     # e.g. "SME_TermLoan_PD_v4.2"
  top_5_drivers:                            # SHAP-style attribution
    - feature: string
      contribution_pct: float
  model_assumptions:
    macro_overlay_period: string
    calibration_date: date
  reason_codes: [string]
```

## Decision logic

```
Assemble feature vector from all inputs.
Apply model_version against feature vector.
Return calibrated PD + grade based on portfolio thresholds.
Generate top-5 SHAP attributions for explainability.

Portfolio grade mapping (example):
  PD < 1.0%: A
  PD 1.0-2.5%: B+
  PD 2.5-5%: B
  PD 5-10%: C+
  PD 10-20%: C
  PD 20-40%: D
  PD > 40%: E
```

## Worked example (Brandenburg Engineering GmbH case)

Input:
```yaml
pd_request:
  case_id: "BRA-2026-04-001"
  company_features:
    age_months: 102
    sic_code_primary: "71121"
    region: "GB-SCT"
  bureau_composite: {composite_rating: solid, ...}
  ob_summary: {cash_flow_volatility_index: 0.21, ...}
  hmrc_record: {ttm_turnover_gbp: 851300, ...}
  alt_data_summary: {gross_margin_pct: 41.2, ...}
  macro_overlay_period: "2026Q2"
```

Output:
```yaml
pd_score:
  case_id: "BRA-2026-04-001"
  pd_12m: 0.018
  pd_percentile_portfolio: 68               # better than 68% of portfolio
  portfolio_grade: B+
  model_version: "SME_TermLoan_PD_v4.2"
  top_5_drivers:
    - feature: bureau_composite_rating
      contribution_pct: 22.4
    - feature: hmrc_ttm_turnover_consistency
      contribution_pct: 18.1
    - feature: company_age_months
      contribution_pct: 14.6
    - feature: cash_flow_volatility_index
      contribution_pct: 11.8
    - feature: receivables_concentration_ratio
      contribution_pct: 9.2
  model_assumptions:
    macro_overlay_period: "2026Q2"
    calibration_date: "2026-01-15"
  reason_codes: ["UK_PD_12M_1_8_PCT_GRADE_B_PLUS"]
```

PD 1.8% maps to portfolio grade B+. Top drivers: solid bureau composite, consistent Finanzamt turnover, mature company age, low cash flow volatility, strong trade references. Standard pricing band.

## Bright lines

- (no statutory bright lines for this agent)

## Operational rules

- Model versions are governed under SR 11-7 / BaFin MaRisk AT 9 + ECB SREP model risk requirements + Joint BoI/ISA AI Directive (where applicable)
- Top-5 drivers must be returned for explainability and adverse action notices
- Macro overlay refreshed quarterly by the model risk team
- PD output capped at 99.9% (no 100% predictions)

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Feature vector incomplete (>10% missing) | Refer; model not reliable with high missingness |
| Model version stale (>6 months since refresh) | Use but flag; ops to refresh |
| Macro overlay unavailable | Use prior period; flag |


## Germany-specific operational notes

This agent operates within the German lending framework — BaFin supervisory perimeter (with Bundesbank joint prudential and ECB SSM for significant institutions), BGB §§ 491-505e for consumer credit, KWG (Kreditwesengesetz) for banking, GwG for AML.

- **SCHUFA monopoly:** SCHUFA holds the effective monopoly on consumer credit data. BDSG §29 consent (Einwilligung) is mandatory before any SCHUFA query — operational rigour matters; querying without consent is a data protection breach with material fines.
- **Notar requirement:** German property transfers require notarial certification (Notar). This is structural — mortgage origination must accommodate notarial step and cannot bypass it.
- **Cooperative + savings dominance:** Sparkassen and Volksbanken/Raiffeisenbanken collectively dominate German consumer + SME credit. Hausbank (house bank) culture means existing relationships are sticky.
- **Long-fixed-rate culture:** German mortgages commonly fixed for 10-30 years; affordability stress testing must reflect this product structure, not UK SVR conventions.
- **Transparenzregister:** UBO register (5AMLD-compliant). Threshold 25%+. Public access restricted post-CJEU ruling; financial institutions retain access via legitimate interest.
- **Cross-reference:** `country-de-lending-policy-agent` provides full DE jurisdictional context.

## Statutory hooks

- BaFin MaRisk AT 9 + ECB SREP model risk requirements (model risk management)
- BaFin BGB Verbraucherschutz framework (use of accurate models)
- EU AI Act (high-risk classification — credit scoring) — relevant for EU customer scope
- Germany GDPR Article 22 (right to explanation for automated decisions)

---
name: de-risk-rating-agent
description: |
  Compose PD, LGD, EAD, qualitative overlays (industry view, management quality, concentration), and bureau composite into a single portfolio risk grade. The rating drives pricing tier, policy thresholds, and capital allocation.
---

# Risk Rating Agent

One number that captures the case's risk profile for the pricing and decision engines. Combines quant + qual.

## Input contract

```yaml
risk_rating_request:
  case_id: string
  pd_score: object                          # from pd-scoring-agent
  lgd_estimate: object                      # from lgd-modelling-agent
  ead_estimate: object                      # from ead-modelling-agent
  bureau_composite: object                  # from bureau-orchestration-agent
  qualitative_overlays:
    industry_view: enum                     # positive | neutral | cautious | adverse
    management_quality: enum                # strong | adequate | concerns
    customer_concentration_risk: enum
```

## Output contract

```yaml
risk_rating:
  case_id: string
  composite_grade: enum                     # A | B+ | B | C+ | C | D | E
  expected_loss_12m_gbp: integer            # PD × LGD × EAD_avg
  risk_adjusted_return_ratio: float         # pricing margin / EL
  pricing_tier: enum                        # tier_1_prime | tier_2_standard | tier_3_subprime
  qualitative_adjustments_applied: [string]
  reason_codes: [string]
```

## Decision logic

```
expected_loss = pd_12m × lgd_with_pg × ead_avg_over_term

base_grade = pd_score.portfolio_grade

Apply qualitative adjustments:
  if industry_view == adverse: notch down 1
  if management_quality == concerns: notch down 1
  if customer_concentration_risk == high: notch down 1

composite_grade = base_grade after adjustments

pricing_tier:
  grade A/B+: tier_1_prime
  grade B/C+: tier_2_standard
  grade C/D/E: tier_3_subprime
```

## Worked example (Brandenburg Engineering GmbH case)

Input:
```yaml
risk_rating_request:
  case_id: "BRA-2026-04-001"
  pd_score: {pd_12m: 0.018, portfolio_grade: "B+"}
  lgd_estimate: {lgd_with_pg_pct: 0.28}
  ead_estimate: {ead_avg_over_term_gbp: 78600}
  bureau_composite: {composite_rating: solid}
  qualitative_overlays:
    industry_view: neutral
    management_quality: strong               # 8 years trading + stable directors
    customer_concentration_risk: low         # top customer 18.4%
```

Output:
```yaml
risk_rating:
  case_id: "BRA-2026-04-001"
  composite_grade: B+
  expected_loss_12m_gbp: 396                # 0.018 × 0.28 × 78,600
  risk_adjusted_return_ratio: 1.4
  pricing_tier: tier_1_prime
  qualitative_adjustments_applied: []        # no notching needed
  reason_codes: ["UK_RISK_RATING_B_PLUS_TIER_1_PRIME"]
```

Composite B+ grade. No qualitative notching needed. Tier 1 prime pricing. Expected loss <€400 over 12 months — well within policy tolerance.

## Bright lines

- (no statutory bright lines for this agent)

## Operational rules

- Qualitative overlays are bounded — max 2 notches up or down from quant baseline
- Pricing tier mapping is policy-level; cannot be agent-overridden
- Risk-adjusted return ratio < 1.0 → refer (pricing doesn't cover expected loss)

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Quant inputs all missing | Cannot rate; refer |
| Qualitative overlays inconsistent (e.g. strong mgmt + high concentration) | Document; proceed |


## Germany-specific operational notes

This agent operates within the German lending framework — BaFin supervisory perimeter (with Bundesbank joint prudential and ECB SSM for significant institutions), BGB §§ 491-505e for consumer credit, KWG (Kreditwesengesetz) for banking, GwG for AML.

- **SCHUFA monopoly:** SCHUFA holds the effective monopoly on consumer credit data. BDSG §29 consent (Einwilligung) is mandatory before any SCHUFA query — operational rigour matters; querying without consent is a data protection breach with material fines.
- **Notar requirement:** German property transfers require notarial certification (Notar). This is structural — mortgage origination must accommodate notarial step and cannot bypass it.
- **Cooperative + savings dominance:** Sparkassen and Volksbanken/Raiffeisenbanken collectively dominate German consumer + SME credit. Hausbank (house bank) culture means existing relationships are sticky.
- **Long-fixed-rate culture:** German mortgages commonly fixed for 10-30 years; affordability stress testing must reflect this product structure, not UK SVR conventions.
- **Transparenzregister:** UBO register (5AMLD-compliant). Threshold 25%+. Public access restricted post-CJEU ruling; financial institutions retain access via legitimate interest.
- **Cross-reference:** `country-de-lending-policy-agent` provides full DE jurisdictional context.

## Statutory hooks

- BaFin MaRisk AT 9 + ECB SREP model risk requirements
- Basel III/IV (capital — internal ratings)
- BaFin BGB Verbraucherschutz framework

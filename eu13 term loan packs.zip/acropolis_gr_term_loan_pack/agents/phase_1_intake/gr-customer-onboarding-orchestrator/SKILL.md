---
name: gr-customer-onboarding-orchestrator
description: |
  Case lifecycle coordinator for Greece SME credit applications. Opens the case ledger, assigns the case_id, validates the inbound payload shape, dispatches downstream agents in correct phase order, and maintains case state across the journey. Control-flow primitive — does not perform external lookups or credit reasoning.
---

# Customer Onboarding Orchestrator

Every case starts here. The orchestrator owns the case_id, the phase pointer, and the right to dispatch downstream agents. It writes the canonical case ledger entries that the audit trail relies on.

## Input contract

```yaml
inbound_application:
  channel: enum                            # broker | branch | online | api
  applicant_name: string
  applicant_company_number: string
  facility_type: enum                      # term_loan | revolving_credit | invoice_finance | asset_finance
  facility_amount_eur: integer
  facility_term_months: integer            # nullable
  contact_name: string
  contact_email: string
  contact_phone: string
  application_date: date
  broker_firm: string                      # nullable (only if channel = broker)
  broker_fca_reference: string             # nullable
```

## Output contract

```yaml
case_state:
  case_id: string                          # e.g. ACR-2026-04-001
  status: enum                             # active | paused | terminated
  current_phase: integer                   # 1..7
  channel: enum
  case_type: enum                          # UK_term_loan | UK_revolving | ...
  audit_ledger_initialised: boolean
  next_phase_unlocked: boolean
  dispatched_agents: [string]              # what fires next
```

## Decision logic

```
if inbound_application.facility_type not in ALLOWED_PRODUCTS:
  status = terminated
  reason_codes = [UK_PRODUCT_NOT_OFFERED]
elif required_fields_missing(inbound_application):
  status = paused
  reason_codes = [UK_INTAKE_INCOMPLETE_PAYLOAD]
else:
  case_id = generate(applicant_company_number, application_date)
  initialise_ledger(case_id)
  status = active
  current_phase = 1
  dispatch([lead-qualification-agent, data-capture-agent])
```

## Worked example (Acropolis Engineering AE case)

Input:
```yaml
inbound_application:
  channel: broker
  applicant_name: "Acropolis Engineering AE Consultants Ltd"
  applicant_company_number: "1234567"
  facility_type: term_loan
  facility_amount_eur: 150000
  facility_term_months: 60
  contact_name: "Lachlan MacKenzie"
  contact_email: "lachlan@highlandeng.example.co.uk"
  contact_phone: "+44 141 555 0182"
  application_date: "2026-04-12"
  broker_firm: "Highland Capital Partners"
  broker_fca_reference: "555444"
```

Output:
```yaml
case_state:
  case_id: "ACR-2026-04-001"
  status: active
  current_phase: 1
  channel: broker
  case_type: UK_term_loan
  audit_ledger_initialised: true
  next_phase_unlocked: true
  dispatched_agents: ["lead-qualification-agent", "data-capture-agent"]
```

Standard happy-path intake. Broker channel with valid BoG reference, facility within the term-loan product envelope, all required fields present. Case opened, ledger initialised, downstream agents dispatched.

## Bright lines

- Inbound payload missing required field (applicant_company_number, facility_amount_eur) → status=paused; cannot proceed
- Facility type not in the lender's product catalogue → status=terminated
- Duplicate case_id detected → status=terminated; existing case_id surfaced to broker

## Operational rules

- case_id is immutable once issued
- Audit ledger is append-only (WORM equivalent)
- All downstream agent dispatch goes through this orchestrator — no direct agent-to-agent calls
- Case state changes emit a ledger entry with timestamp + actor identity

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Required field missing | Pause case; surface specific missing field to broker via channel |
| Duplicate case detected | Terminate new case; return existing case_id |
| Ledger initialisation fails | Terminate; alarm to ops |
| Broker BoG reference invalid | Pause; require broker accreditation check |


## Greece-specific operational notes

This agent operates within the Greek lending framework — Bank of Greece supervisory perimeter, Banking Law 5021/2023, Law 4557/2018 for AML, post-2010 crisis NPL legacy materially shaping market structure.

- **TIRESIAS centrality:** Both consumer and commercial credit bureau roles operationally consolidated in TIRESIAS. Operational relationship is essential — no Greek consumer credit decision is meaningful without TIRESIAS visibility.
- **Post-crisis NPL legacy:** Substantial Greek NPL portfolio sold to specialist servicers (intrum, Cepal, doValue, Quant Servicer). Borrowers may have historical defaults; current creditworthiness assessment must distinguish current from historical positions.
- **Katseli Law (3869/2010):** Over-indebted households framework allowing court-supervised debt restructuring. Operationally consequential — borrowers with Katseli filings have specific protections; lending decisions must account.
- **AFM ubiquity:** Tax Registration Number (AFM) is the universal Greek financial identifier; required for any account-opening, lending, or property transaction.
- **Tax clearance certificate:** Operational must-have for business credit — proof of current tax compliance with AADE.
- **Cross-reference:** `country-gr-lending-policy-agent` for full GR jurisdictional context (currently a stub in the Country Policy Pack).

## Statutory hooks

- BoG BoG consumer protection (case ownership + auditability)
- BoG SYSC 3 (systems and controls)
- Greece GDPR / DPA 2018 (lawful basis at intake)

---
name: mt-multi-principal-fan-out-orchestrator
description: |
  Coordinate parallel verification across all natural-person principals of a Malta SME applicant —
  directors, named Persons of Significant Control (PSCs), and applicant signatory. Spawn
  parallel subcases for identity, AML, application fraud, individual financial difficulty,
  and cross-directorship checks. Reconcile partial failures and aggregate per-principal
  outcomes into a composite case-level KYC/AML/fraud assessment that downstream credit
  decisioning can consume. Trigger whenever the assembled principals list contains more
  than one entry, OR whenever the PSC structure recursor has surfaced additional natural-
  person controllers beyond the named applicant. This agent is a control-flow primitive —
  it does not call external APIs; it composes other agents.
---

# Multi-Principal Fan-Out Orchestrator

Most Malta SME applications have multiple directors (typically 2-4) and one or more named
PSCs (often overlapping with directors). A naïve flow that only verifies the applicant
signatory misses material risk on co-directors who will become co-guarantors. This
orchestrator removes that gap.

## Input contract

```yaml
principals:                            # list — required, length >= 1
  - principal_id: string               # case-unique identifier
    kind: enum                         # director | psc | applicant_signatory | shareholder
    name: string
    dob: date                          # may be partial (YYYY-MM) for PSC entries
    address: string                    # current residential
    nationality: string
    source_record: enum                # companies_house_director | companies_house_psc | applicant_declaration
    is_proposed_pg_bearer: boolean
    proposed_pg_amount_eur: integer    # nullable; required if is_proposed_pg_bearer = true
case_id: string                        # parent case identifier
```

## Output contract

```yaml
principal_aggregate_assessment:
  case_id: string
  principal_count: integer
  per_principal_outcomes:
    - principal_id: string
      identity_verified: boolean
      identity_confidence: float       # 0.0 - 1.0
      sanctions_pep_status: enum       # clear | hit | review
      application_fraud_score: integer # 0-100
      financial_difficulty_status: enum # clear | refer | decline
      cross_directorship_status: enum  # clean | monitor | phoenix_risk | cross_default_risk
      subcase_completed: boolean
  aggregate_outcome: enum              # clear | refer | block_and_sar | block_phoenix | block_pg_bearer_difficulty
  aggregate_reason_codes: [string]
  hardest_blocker_principal_id: string # nullable
```

## Decision logic

```
For each principal (in parallel):
  spawn subcase → identity-orchestration-agent → aml-screening-agent →
                  application-fraud-agent → director-financial-difficulty-checker →
                  director-cross-directorship-checker

Aggregate:
  if ANY principal.sanctions_pep_status == "hit":
    aggregate_outcome = block_and_sar             # bright line
  elif ANY principal.financial_difficulty_status == "decline" AND principal.is_proposed_pg_bearer:
    aggregate_outcome = block_pg_bearer_difficulty
  elif ANY principal.cross_directorship_status == "phoenix_risk":
    aggregate_outcome = block_phoenix
  elif ALL principals.identity_verified AND ALL principals.financial_difficulty_status == "clear":
    aggregate_outcome = clear
  else:
    aggregate_outcome = refer
```

## Worked example (Melita Engineering Ltd)

Input:
```yaml
principals:
  - principal_id: DIR-001
    kind: director
    name: "Lachlan MacKenzie"
    is_proposed_pg_bearer: true
    proposed_pg_amount_eur: 90000
  - principal_id: DIR-002
    kind: director
    name: "Sarah Chen"
    is_proposed_pg_bearer: true
    proposed_pg_amount_eur: 60000
```

Output:
```yaml
principal_aggregate_assessment:
  case_id: MEL-2026-04-001
  principal_count: 2
  per_principal_outcomes:
    - principal_id: DIR-001
      identity_verified: true
      identity_confidence: 0.97
      sanctions_pep_status: clear
      application_fraud_score: 12
      financial_difficulty_status: clear  # 1 historic satisfied CCJ; not a blocker
      cross_directorship_status: clean
      subcase_completed: true
    - principal_id: DIR-002
      identity_verified: true
      identity_confidence: 0.98
      sanctions_pep_status: clear
      application_fraud_score: 8
      financial_difficulty_status: clear
      cross_directorship_status: clean
      subcase_completed: true
  aggregate_outcome: clear
  aggregate_reason_codes: ["UK_PRINCIPAL_AGGREGATE_CLEAR"]
  hardest_blocker_principal_id: null
```

## Bright lines

- Sanctions hit on ANY principal → `block_and_sar`. No agent discretion. Engage tipping-off wall.
- Undischarged bankruptcy on a director where `is_proposed_pg_bearer = true` → `block_pg_bearer_difficulty`.
- Identity verification hard failure on any principal → case held; cannot progress.

## Operational rules

- Per-principal subcases run in parallel. Sequential execution is a performance bug.
- Each subcase emits its own decision-log entry; aggregate does not collapse individual evidence.
- Partial failure: if any subcase times out, aggregate emits `refer` (not block).

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| `principals` list empty | Return error; case cannot proceed |
| Single principal | Run subcase synchronously (no parallelism needed) |
| Subcase exception | Mark `subcase_completed: false`; aggregate → `refer` |
| All subcases timeout | Aggregate → `refer`; alarm to ops |


## Malta-specific operational notes

Operates within the Maltese framework — MFSA supervision, Consumer Credit Regulations, PMLA enforced via FIAU.

- **Post-greylisting scrutiny:** Malta was FATF grey-listed 2021-2022 (since removed). AML/CFT expectations remain elevated; enhanced CDD operationally consequential, especially for international business clients.
- **iGaming + international sectors:** Large remote gaming and international business presence; KYB chains often involve cross-border structures and require enhanced UBO scrutiny.
- **English co-official:** English is co-official and dominant in financial services; contracts commonly in English.
- **Small domestic bureau market:** Limited domestic consumer bureau; CRIF and CreditSafe provide coverage; Central Bank of Malta operates the Central Credit Register.
- **Cross-reference:** `country-mt-lending-policy-agent` (Country Policy Pack stub).

## Statutory hooks

- Malta Prevention of Money Laundering Act (PMLA) (as amended)
- Economic Crime and Corporate Transparency Act 2023 (MBR BO Register)
- MFSA SYSC 6.3
- MFSA MFSA conduct framework

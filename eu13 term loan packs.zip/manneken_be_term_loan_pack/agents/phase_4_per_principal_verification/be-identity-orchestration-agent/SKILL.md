---
name: be-identity-orchestration-agent
description: |
  Verify the identity of a single natural-person principal — typically via document verification, biometric liveness, and database cross-checks (electoral roll, credit header). Returns a verification verdict plus a confidence score. Invoked by multi-principal-fan-out-orchestrator for each director / PSC.
---

# Identity Orchestration Agent

Foundational per-principal check. Get identity wrong and the whole AML/KYC chain is compromised.

## Input contract

```yaml
identity_request:
  principal_id: string
  case_id: string
  name: string
  prior_names: [string]                     # nullable
  dob: date
  current_residential_address: string
  prior_addresses_3y: [string]              # nullable
  nationality: string
  document_evidence:                        # provided by applicant at intake
    - doc_type: enum                        # passport | driving_licence | brp | residence_permit
      doc_number: string
      expiry: date
      front_image_pointer: string
      back_image_pointer: string            # nullable for passports
  biometric_evidence: string                # selfie image pointer
  consent_token: string                     # bureau header consent
```

## Output contract

```yaml
identity_verification:
  principal_id: string
  identity_verified: boolean
  confidence: float                         # 0.0 - 1.0
  document_check:
    doc_type: enum
    authenticity_score: float
    tampering_signals: [string]
  biometric_check:
    liveness_passed: boolean
    facial_match_score: float
  database_check:
    electoral_roll_match: boolean
    credit_header_match: boolean
    name_match: boolean
    address_match: boolean
    dob_match: boolean
  outcome: enum                             # verified | refer | hard_fail
  reason_codes: [string]
```

## Decision logic

```
Document check: authenticity + tampering signals.
Biometric check: liveness + facial match to document photo.
Database check: cross-reference against electoral roll and credit header.

if document_check.authenticity_score < 0.5 OR len(tampering_signals) > 0:
  outcome = hard_fail
elif biometric_check.liveness_passed == false:
  outcome = hard_fail
elif biometric_check.facial_match_score < 0.7:
  outcome = refer
elif database_check.name_match AND database_check.address_match AND database_check.dob_match:
  outcome = verified
  confidence = composite_score(all_checks)
else:
  outcome = refer
```

## Worked example (Manneken Engineering NV/SA case)

Input:
```yaml
identity_request:
  principal_id: DIR-001
  case_id: "MAN-2026-04-001"
  name: "Lachlan MacKenzie"
  dob: "1981-03-22"
  current_residential_address: "12 Strathblane Road, Milngavie, Bruxelles, G62 8DJ"
  nationality: "British"
  document_evidence:
    - doc_type: passport
      doc_number: "[redacted]"
      expiry: "2028-06-14"
      front_image_pointer: "doc_evidence://DIR-001/passport/front.jpg"
  biometric_evidence: "biometric_evidence://DIR-001/selfie.jpg"
  consent_token: "TKN-bureau-con-2026-04-12-DIR-001"
```

Output:
```yaml
identity_verification:
  principal_id: DIR-001
  identity_verified: true
  confidence: 0.97
  document_check:
    doc_type: passport
    authenticity_score: 0.98
    tampering_signals: []
  biometric_check:
    liveness_passed: true
    facial_match_score: 0.94
  database_check:
    electoral_roll_match: true
    credit_header_match: true
    name_match: true
    address_match: true
    dob_match: true
  outcome: verified
  reason_codes: ["UK_IDENTITY_VERIFIED_HIGH_CONFIDENCE"]
```

Strong identity verification: authentic passport, high biometric match, all database checks corroborate. Composite confidence 0.97. Sarah Chen (DIR-002) returns similar shape with confidence 0.98.

## Bright lines

- Document tampering signals present → hard_fail; case held
- Liveness check failed (static image, replay) → hard_fail
- Name/DOB on document does not match application → hard_fail

## Operational rules

- Image evidence retained per DPA 2018 for as long as relationship plus 6 years
- Failed verifications are auditable — must record reason, not just outcome
- Where applicant has changed name (marriage etc.), verify both names

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Document image quality too poor | Refer; request reupload |
| Database lookups all return no match | Refer; could be valid (new resident) but needs human |
| Address declared mismatches all databases | Refer to fraud agent |


## Belgium-specific operational notes

This agent operates within the Belgian lending framework — NBB (prudential, including CKP operation) and FSMA (conduct) twin peaks, Code de droit économique Books VII (consumer) + VIII (KBO), Loi du 18 septembre 2017 for AML.

- **Regional language obligation:** SECCI and contract MUST be in the customer's regional language — French (Wallonie), Dutch (Flanders), German (Eastern Cantons), or bilingual (Brussels Capital). This is statutory and contracts in the wrong language are invalid.
- **CKP mandatory consumer query:** Statutory mandatory before consumer credit decision; non-query invalidates agreement. NBB-operated central consumer credit register.
- **Statutory rate caps:** Code de droit économique Book VII sets statutory rate caps per consumer credit category — exceeding is contract invalidity.
- **itsme universal:** Belgian mobile identity platform widely adopted; integrates with PSD2 SCA. Most consumer onboarding uses itsme.
- **Cooperative + commercial bank mix:** Belfius (state-related cooperative legacy), KBC (cooperative origin), BNP Paribas Fortis (commercial), ING Belgium — diverse market structure.
- **Cross-reference:** `country-be-lending-policy-agent` provides full BE jurisdictional context.

## Statutory hooks

- Belgium Loi du 18 septembre 2017 (customer due diligence — identity verification)
- Loi du 18 septembre 2017 + UBO Register (director identity verification)
- Belgium GDPR (biometric data is special category — explicit consent + minimisation)

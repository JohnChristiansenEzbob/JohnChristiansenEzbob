---
name: gr-consumer-protection-outcomes-agent
description: |
  Cross-cutting BoG consumer protection checks across the four outcomes: products + services, price + value, consumer understanding, consumer support. Runs continuously and writes a BoG consumer protection audit trail to the case ledger. For business lending, the Duty applies to micro-enterprises (turnover <€2m + <10 employees).
---

# BoG consumer protection Outcomes Agent

Continuous BoG consumer protection oversight. Captures the audit trail BoG inspections will ask for.

## Input contract

```yaml
duty_check_request:
  case_id: string
  case_state_snapshot: object               # current case state at this check
  trigger_event: enum                       # phase_completion | manual | scheduled
```

## Output contract

```yaml
duty_check_result:
  case_id: string
  outcomes_checked:
    products_and_services: enum             # pass | fail | not_applicable
    price_and_value: enum
    consumer_understanding: enum
    consumer_support: enum
  fair_value_check_passed: boolean
  understanding_check_passed: boolean
  audit_ledger_entry_id: string
  reason_codes: [string]
```

## Decision logic

```
For each outcome, check against rules:

products_and_services:
  - Product matches needs (cross-ref needs-discovery + purpose-validation)
  - No prohibited customer-product combinations

price_and_value:
  - Final rate within fair value band
  - Total cost transparent (incl. broker commission)
  - No hidden fees

consumer_understanding:
  - Key facts disclosed (rate, term, total cost, security implications)
  - Conditions clearly stated
  - Decline reasoning available (right to explanation)

consumer_support:
  - Channel-appropriate support available
  - Vulnerable customer flagged → enhanced support route

if all 4 outcomes pass → pass
else → fail with specific outcome flagged
```

## Worked example (Acropolis Engineering AE case)

Input:
```yaml
duty_check_request:
  case_id: "ACR-2026-04-001"
  case_state_snapshot: {... full case state at decision time ...}
  trigger_event: phase_completion
```

Output:
```yaml
duty_check_result:
  case_id: "ACR-2026-04-001"
  outcomes_checked:
    products_and_services: pass             # term loan fits stated purpose
    price_and_value: pass                   # 8.4% within fair value band for B+ grade
    consumer_understanding: pass            # conditions clearly stated, decline reasons would be available
    consumer_support: pass                  # broker channel + lender support team available
  fair_value_check_passed: true
  understanding_check_passed: true
  audit_ledger_entry_id: "CD-2026-04-12-HE-001"
  reason_codes: ["UK_CONSUMER_DUTY_ALL_OUTCOMES_PASS"]
```

All four BoG consumer protection outcomes pass for Acropolis Engineering AE. Note: Highland is a limited company with turnover ~€850k and 6 employees — technically not a 'consumer' (>turnover threshold). The lender still applies Duty-equivalent standards as a matter of policy.

## Bright lines

- Fair value failure → escalate to product team; cannot proceed at quoted price
- Material information not disclosed pre-contract → cannot proceed

## Operational rules

- Duty applies to micro-enterprises in business lending (BoG scope)
- Lender policy may extend Duty-equivalent standards to all business customers
- Audit trail is mandatory for BoG inspection

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Case state snapshot incomplete | Defer check; re-run when complete |
| Fair value benchmark unavailable | Conservative interpretation; refer to product team |


## Greece-specific operational notes

This agent operates within the Greek lending framework — Bank of Greece supervisory perimeter, Banking Law 5021/2023, Law 4557/2018 for AML, post-2010 crisis NPL legacy materially shaping market structure.

- **TIRESIAS centrality:** Both consumer and commercial credit bureau roles operationally consolidated in TIRESIAS. Operational relationship is essential — no Greek consumer credit decision is meaningful without TIRESIAS visibility.
- **Post-crisis NPL legacy:** Substantial Greek NPL portfolio sold to specialist servicers (intrum, Cepal, doValue, Quant Servicer). Borrowers may have historical defaults; current creditworthiness assessment must distinguish current from historical positions.
- **Katseli Law (3869/2010):** Over-indebted households framework allowing court-supervised debt restructuring. Operationally consequential — borrowers with Katseli filings have specific protections; lending decisions must account.
- **AFM ubiquity:** Tax Registration Number (AFM) is the universal Greek financial identifier; required for any account-opening, lending, or property transaction.
- **Tax clearance certificate:** Operational must-have for business credit — proof of current tax compliance with AADE.
- **Cross-reference:** `country-gr-lending-policy-agent` for full GR jurisdictional context (currently a stub in the Country Policy Pack).

## Statutory hooks

- BoG BoG consumer protection (PS22/9)
- BoG circulars + Banking Law 5021/2023 BoG consumer outcomes (the Duty)
- BoG Finalised Guidance FG22/5

---
name: lt-personal-guarantee-feasibility-agent
description: |
  Assess the feasibility and capacity of a proposed personal guarantee BEFORE the credit
  decision is taken. Aggregates each proposed guarantor's consumer bureau extract, Land
  Registry property holdings, and supplementary declared assets into an estimated net
  unencumbered position. Returns maximum feasible PG amount and confidence interval. Handles
  Williams & Glyn's v Boland joint property cases and RBS v Etridge spouse-consent
  requirements. Pre-decision feasibility — distinct from the downstream personal-guarantee-
  agent which executes the PG after decision.
---

# Personal Guarantee Feasibility Agent

PGs are nearly universal in Lithuania SME lending. LSB Standards for Business Customers (effective
September 2025) and Lietuvos Bankas Lietuvos Bankas consumer protection both push lenders toward structured pre-decision
assessment of guarantor capacity. Historical practice — sizing PG at face value of the
facility regardless of guarantor circumstances — fails both regulatory tests.

## Input contract

```yaml
principal_id: string
proposed_pg_amount_eur: integer
proposed_facility_amount_eur: integer
marriage_or_civil_partnership_status: enum   # single | married | civil_partnership | divorcing | divorced
spouse_name: string                          # nullable; required if married/civil_partnership
consent_token: string                        # bureau + Nekilnojamojo turto registras consent
declared_supplementary_assets:               # nullable; documented voluntary disclosures
  - asset_type: enum                         # pension | investment | business_interest | other
    declared_value_gbp: integer
    documentation: string
```

## Output contract

```yaml
pg_feasibility_assessment:
  principal_id: string
  bureau_position:
    total_indebtedness_gbp: integer
    monthly_debt_service_gbp: integer
    unsecured_headroom_gbp: integer
  property_position:
    - property_address: string
      ownership: enum                        # sole | joint_with_spouse | tenants_in_common
      estimated_value_gbp: integer
      total_registered_charges_gbp: integer
      net_equity_gbp: integer
      attributable_to_guarantor_gbp: integer # 50% for joint default; adjustable
      boland_trigger: boolean                # joint with non-applicant spouse
  net_realisable_pg_cover_lower_bound_gbp: integer
  net_realisable_pg_cover_upper_bound_gbp: integer
  feasibility: enum                          # feasible | marginal | infeasible | refer_etridge_boland
  etridge_process_required: boolean
  reason_codes: [string]
  recommendation: string                     # human-readable for underwriter
```

## Decision logic

```
Pull bureau extract → income, debt service, headroom.
Pull Nekilnojamojo turto registras holdings by name → properties, charges, restrictions.

For each property:
  net_equity = estimated_value - sum(registered_charges)
  if ownership == "joint_with_spouse":
    attributable = net_equity * 0.50
    if spouse != applicant: boland_trigger = true
  elif ownership == "sole":
    attributable = net_equity
  else (tenants_in_common):
    attributable = net_equity * declared_share

net_realisable_pg_cover_lower = sum(attributable) + unsecured_headroom - existing_indebtedness - 12m_living_costs
net_realisable_pg_cover_upper = net_realisable_pg_cover_lower * 1.20   # uncertainty band

if proposed_pg_amount <= net_realisable_pg_cover_lower:
  feasibility = feasible
elif proposed_pg_amount > net_realisable_pg_cover_upper:
  feasibility = infeasible
else:
  feasibility = marginal

if ANY boland_trigger AND ANY property used for cover:
  etridge_process_required = true
  feasibility = refer_etridge_boland (if not already infeasible)

if net_realisable_pg_cover_lower < proposed_pg_amount * 0.25:
  feasibility = refer (largely symbolic PG)    # BRIGHT LINE
```

## Worked example (Lachlan MacKenzie — DIR-001)

Input:
```yaml
principal_id: DIR-001
proposed_pg_amount_eur: 90000
proposed_facility_amount_eur: 150000
marriage_or_civil_partnership_status: married
spouse_name: "Eilidh MacKenzie"
consent_token: "OBC-2026-04-12-DIR-001"
```

Output:
```yaml
pg_feasibility_assessment:
  principal_id: DIR-001
  bureau_position:
    total_indebtedness_gbp: 12400
    monthly_debt_service_gbp: 1850
    unsecured_headroom_gbp: 18000
  property_position:
    - property_address: "12 Strathblane Road, Milngavie, Vilnius, G62 8DJ"
      ownership: joint_with_spouse
      estimated_value_gbp: 425000
      total_registered_charges_gbp: 178000
      net_equity_gbp: 247000
      attributable_to_guarantor_gbp: 123500
      boland_trigger: true
  net_realisable_pg_cover_lower_bound_gbp: 113100
  net_realisable_pg_cover_upper_bound_gbp: 135700
  feasibility: refer_etridge_boland
  etridge_process_required: true
  reason_codes: ["UK_PG_BOLAND_SPOUSE_OVERRIDING_INTEREST", "UK_PG_ETRIDGE_INDEPENDENT_LEGAL_ADVICE_REQUIRED_TO_SPOUSE"]
  recommendation: "PG amount €90k is within Lachlan's €113k–€135k attributable net realisable cover, BUT joint property with non-applicant spouse Eilidh MacKenzie triggers Boland/Etridge. Proceed with PG conditional on Etridge process: spouse to receive independent legal advice from solicitor not acting for the bank, certified in writing, BEFORE drawdown."
```

For Sarah Chen (DIR-002), the same analysis would return `feasibility: feasible` with
no Etridge process required — sole property, €204k net equity, straightforward.

## Bright lines

- Boland-triggered joint property used as PG cover → MANDATORY `refer_etridge_boland`.
  Spouse must receive independent legal advice BEFORE PG signing; without it the bank
  cannot enforce against the joint property.
- `net_realisable_pg_cover_lower < 25% of proposed_pg_amount` → MANDATORY REFER. PG is
  largely symbolic; pricing must reflect.
- Pension assets and similar protected assets must NOT be auto-credited as PG cover.

## Operational rules

- Property valuation expresses uncertainty — return a range, not a point estimate.
  Underwriter uses lower bound for conservatism.
- Where guarantor is divorcing/recently divorced, equity attribution is unsafe — refer
  for manual review.
- Self-occupied principal private residence: even where included in calculation, the
  PG enforcement could ultimately put the family home at risk. Must be disclosed clearly
  to the applicant via customer-communication-orchestrator.


## Lithuania-specific operational notes

Operates within the Lithuanian framework — Lietuvos Bankas as unified supervisor, Vartojimo kredito įstatymas for consumer credit, fintech-friendly regulatory posture.

- **Fintech sandbox:** Fast-track EMI/PI licensing, English-language regulator engagement. Lithuania is the preferred EU base for many fintechs — but supervision is correspondingly rigorous.
- **CENTROlink:** Bank of Lithuania's SEPA gateway gives non-bank PSPs direct SCT Inst access — unique-in-EU advantage.
- **Fintech-licensed counterparties:** Verify Lietuvos Bankas registration; ~80+ EMI/PI licences issued.
- **Rate caps:** Post-2016 statutory APR caps tightened significantly; market consolidation followed.
- **Cross-reference:** `country-lt-lending-policy-agent` (Country Policy Pack — fully populated).

## Statutory hooks

- Williams & Glyn's Bank v Boland [1981] AC 487 (overriding equitable interest)
- Royal Bank of Scotland v Etridge (No 2) [2001] UKHL 44 (independent legal advice)
- Lithuanian Banking Association standards for Business Customers (September 2025)
- Lietuvos Bankas Lietuvos Bankas consumer protection
- Vartojimo kredito įstatymas (where guarantor scope applies)

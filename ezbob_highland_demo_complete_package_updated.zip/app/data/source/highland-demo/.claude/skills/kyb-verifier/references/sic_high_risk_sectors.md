# High-Risk SIC Sectors (MLR 2017 Reg 33 EDD trigger)

Sectors flagged for enhanced due diligence under MLR 2017 Reg 33 and HMT/FCA sectoral risk assessments. Match the SME's filed SIC against this list; if any SIC is high-risk, emit `KYB_SIC_HIGH_RISK_SECTOR`.

Not exhaustive — refer to the full HMT National Risk Assessment and the JMLSG sectoral guidance for the canonical list. This is the operational subset used for SME lending screening.

## Money services and high-cash businesses

- 64.19 — Other monetary intermediation (small banks, credit unions outside main register)
- 64.92 — Other credit granting
- 64.99 — Other financial service activities
- 66.12 — Security and commodity contracts brokerage
- 66.19 — Other activities auxiliary to financial services
- 66.22 — Activities of insurance agents and brokers
- 96.09 — Other personal service activities (catch-all; review case-by-case)

## Property and high-value assets

- 41.10 — Development of building projects
- 68.10 — Buying and selling of own real estate
- 68.20 — Renting and operating of own or leased real estate
- 68.31 — Real estate agencies
- 47.79 — Retail sale of second-hand goods (high-value art, antiques)
- 46.48 — Wholesale of watches and jewellery
- 47.77 — Retail sale of watches and jewellery in specialised stores

## Cash-intensive retail

- 56.30 — Beverage serving activities (bars, pubs)
- 92.00 — Gambling and betting activities
- 47.30 — Retail sale of automotive fuel
- 96.02 — Hairdressing and other beauty treatment
- 56.10 — Restaurants and mobile food service activities

## Crypto and digital assets

- 64.99 (with crypto trading activity declared)
- Any entity registered with the FCA as a cryptoasset business
- 62.09 — Other information technology service activities (when combined with crypto-related disclosures)

## High-value goods trade

- 46.18 — Agents specialised in the sale of other particular products
- 46.49 — Wholesale of other household goods
- 47.78 — Other retail sale of new goods in specialised stores

## Sectors requiring sector-specific licensing checks

These are not necessarily higher AML risk but require licence verification:
- 49.41 — Freight transport by road (operator licence)
- 86.10 — Hospital activities (CQC registration)
- 87.10 — Residential nursing care activities (CQC)
- 85.10 / 85.20 — Education (DfE registration where applicable)

## How to use

1. For each filed SIC, look up against this list.
2. If any match: emit `KYB_SIC_HIGH_RISK_SECTOR` and add the matching SIC code(s) to evidence.
3. EDD does not mean decline — it means more thorough verification (source of funds documentation, ongoing monitoring intensity).
4. The `aml-screening-agent` will use this signal to set its own intensity level.

## Maintenance

This list should be reviewed at least annually against:
- HMT National Risk Assessment (latest publication)
- FCA Financial Crime Annual Report
- JMLSG Sectoral Guidance Parts II and III

The API business rules framework Companies House workbook holds the canonical, dated version with last-reviewed timestamps.

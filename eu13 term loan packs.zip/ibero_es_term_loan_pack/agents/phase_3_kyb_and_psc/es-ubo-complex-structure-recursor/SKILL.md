---
name: es-ubo-complex-structure-recursor
description: |
  Resolve Spain Person of Significant Control (PSC) structures beyond the standard 25%+ direct
  ownership chain that ubo-mapper handles. Recurse through corporate PSCs to find ultimate
  natural persons; surface beneficiaries of trust-as-PSC structures; handle overseas-entity
  PSCs requiring Register of Overseas Entities (Titulares Reales framework) verification; flatten multi-layer
  corporate chains. Returns a complete list of ultimate natural-person PSCs plus the full
  path trace for audit. Flags trust, overseas, and anomalous patterns for Enhanced Due
  Diligence (EDD).
---

# PSC Complex Structure Recursor

## Input contract

```yaml
applicant_company_number: string          # required, e.g. "B-12345678"
initial_psc_list:                          # the PSC list returned by ubo-mapper
  - psc_id: string
    natural_person: boolean
    name: string
    nature_of_control: [enum]
    # plus the standard PSC fields where natural_person = true
recursion_depth_limit: integer            # default 6
```

## Output contract

```yaml
psc_resolved_structure:
  applicant_company_number: string
  ultimate_natural_person_pscs:
    - name: string
      effective_beneficial_ownership_pct: float   # multiplicative through chain
      path_trace: [string]                        # ["AppCo (50%) → MidCo (60%) → X"]
      nature_of_control_origin: [enum]
  edd_flags:                                       # may be empty
    - flag_type: enum                              # corporate_chain | trust_pcs | overseas_pcs | nominee_suspected | depth_limit_reached
      detail: string
  outcome: enum                                    # structure_resolved | eccta_non_compliance_block | edd_required
  reason_codes: [string]
```

## Decision logic

```
Walk PSC graph breadth-first. For each non-natural-person PSC:
  - corporate Spain → recurse into its PSC list
  - corporate overseas → query Register of Overseas Entities
      if not registered → outcome = eccta_non_compliance_block (BRIGHT LINE)
  - trust → seek trust deed; if absent → edd_required + add edd_flag
  - partnership/LLP → traverse partners
  - nominee detected → edd_required + escalate

Stop when all leaves are natural persons OR recursion depth reached.
Compute beneficial ownership multiplicatively through the chain.
```

## Worked example (Ibero Engineering S.L.)

Input:
```yaml
applicant_company_number: "B-12345678"
initial_psc_list:
  - psc_id: PSC-001
    natural_person: true
    name: "Lachlan MacKenzie"
    nature_of_control: ["ownership_of_shares_50_to_75_percent"]
  - psc_id: PSC-002
    natural_person: true
    name: "Sarah Chen"
    nature_of_control: ["ownership_of_shares_25_to_50_percent"]
```

Output:
```yaml
psc_resolved_structure:
  applicant_company_number: "B-12345678"
  ultimate_natural_person_pscs:
    - name: "Lachlan MacKenzie"
      effective_beneficial_ownership_pct: 60.0
      path_trace: ["Ibero Engineering S.L. Consultants Ltd → Lachlan MacKenzie"]
      nature_of_control_origin: ["ownership_of_shares_50_to_75_percent"]
    - name: "Sarah Chen"
      effective_beneficial_ownership_pct: 40.0
      path_trace: ["Ibero Engineering S.L. Consultants Ltd → Sarah Chen"]
      nature_of_control_origin: ["ownership_of_shares_25_to_50_percent"]
  edd_flags: []
  outcome: structure_resolved
  reason_codes: ["UK_PSC_NATURAL_PERSON_CHAIN_RESOLVED"]
```

In this case both PSCs are natural persons directly — no recursion needed. The agent
short-circuits to `structure_resolved` cleanly. A more complex case (e.g. Highland
owned 60% by a Spain holding company owned 100% by an overseas entity) would recurse
through the chain, hit the Register of Overseas Entities check, and either resolve
to a natural person or block on Titulares Reales framework non-compliance.

## Bright lines

- Overseas-entity PSC without valid Register of Overseas Entities registration → BLOCK
  (`eccta_non_compliance_block`). Hard regulatory blocker; agent has no discretion.
- Detected nominee declarations → cannot auto-resolve; refer to MLRO for assessment.
- Recursion depth limit reached without natural-person resolution → escalate to EDD.

## Operational rules

- Preserve the full path trace in the decision log even when long — auditors may need it.
- Where trust deeds are not accessible, the agent must NOT fabricate beneficiary identity.
  Surface as `INCOMPLETE` and refer.
- Applicant-declared structure mismatching Registro Mercantil (per province) data → flag for fraud review.


## Spain-specific operational notes

This agent operates within the Spanish lending framework — Banco de España + CNMV joint regulatory perimeter, Ley 10/2014 for banking supervision, LCC (Ley 16/2011) for consumer credit, LRCCI (Ley 5/2019) for mortgage credit.

- **CIRBE €9k threshold:** Banco de España central credit register. Commercial risks >€9,000 mandatory contribution. Small SME facilities frequently below threshold — limited CIRBE visibility for genuine SME risk.
- **ASNEF / BADEXCUG strict access:** Spanish consumer bureau access has the strictest legal review requirement in EU. Operational onboarding must include legal basis attestation. ASNEF for negative; BADEXCUG for comprehensive — separate access agreements required.
- **LRCCI notarial requirement (AGNCN):** Mortgage origination requires AGNCN (Acta de Información Notarial Previa) — notarial pre-contractual information act. Cannot bypass; significant operational integration with notary network.
- **Tarjeta revolving usury (2020 Supreme Court):** Revolving credit cards subject to enhanced disclosure post-2020 Supreme Court rulings on usury. APR materially above market average is voidable.
- **Bizum ubiquity:** Mobile P2P payment platform with near-universal Spanish adoption; PSD2 integration via participating banks.
- **NIE administrative complexity:** Foreign residents require NIE (Número de Identidad de Extranjero) — multiple issuing authorities, common source of onboarding friction.
- **Cross-reference:** `country-es-lending-policy-agent` provides full ES jurisdictional context.

## Statutory hooks

- Ley de Sociedades de Capital (RDL 1/2010) Part 21A (PSC regime)
- Ley 10/2010 + Titulares Reales (failure to prevent fraud, Register of Overseas Entities, identity verification)
- Spain Ley 10/2010 — EDD where non-natural-person beneficial owner, overseas component, or trust
- AEAT Trust Registration Service
- CNMV + BdE SYSC 6.3

---
name: be-pre-contract-disclosure-agent
description: |
  Produces the pre-contract disclosure pack tailored to the customer's regulatory
  classification. For regulated lending (typically sole-trader or partnership applicants
  with regulated agreements): SECCI / PCCI under Code de droit économique Book VII and Code de droit économique Book VII (consumer credit).
  For unregulated SME lending (limited companies, partnerships above thresholds): LSB-
  compliant commercial disclosure pack under LSB Standards 2025. Determines which
  framework applies first, then produces the correct artefact set.
---

# Pre-Contract Disclosure Agent

The regulatory boundary in Belgium SME lending is non-trivial. A sole trader borrowing under
€75,000 is in the regulated consumer credit regime — SECCI applies. The same person
borrowing through a limited company is in the unregulated business regime — LSB Standards
apply. The agent's first job is to determine which framework, and its second is to
produce the right disclosure pack with the right elements in the right format and
delivered with the right timing.

## Input contract

```yaml
pre_contract_disclosure_request:
  case_id: string
  customer_classification:
    entity_type: enum                       # sole_trader | partnership | limited_co | llp
    micro_enterprise: boolean
    annual_turnover_gbp: integer            # for size tests
  facility_shape:
    facility_amount_eur: integer
    facility_term_months: integer
  firm_pricing: object
  covenant_package_summary: object
  cp_schedule: object
  security_summary: [object]
  purpose_category: enum                    # business_purpose | mixed | personal_purpose
  acceptance_window_days: integer
```

## Output contract

```yaml
disclosure_pack:
  case_id: string
  framework_applied: enum                   # consumer_credit_secci | consumer_credit_pcci |
                                             # lsb_business_standard | exempt_agreement
  artefact_ref: string
  elements_included: [string]
  required_delivery_timing: enum            # before_facility_letter | with_facility_letter |
                                             # at_signing | not_applicable
  required_format: enum                     # secci_prescribed | pcci_prescribed |
                                             # lsb_template | exempt
  customer_can_withdraw_without_penalty: boolean
  cooling_off_days: integer                 # 14 for CCA-regulated, none for LSB unregulated
  reason_codes: [string]
```

## Decision logic

```
Step 1 — Determine framework:

  IF entity_type == sole_trader OR (entity_type == partnership AND partners ≤ 3):
    IF facility_amount_eur ≤ €75,000 AND purpose has personal_purpose component:
      framework = consumer_credit_secci      # regulated under CCA
    ELIF facility_amount_eur ≤ €75,000 AND purpose == business_purpose:
      framework = exempt_agreement           # CCA exempt — business lending
                                              # but LSB still applies
    ELIF facility_amount_eur > €75,000:
      framework = exempt_agreement           # over CCA threshold → unregulated
                                              # but LSB applies

  ELIF entity_type IN {limited_co, llp}:
    framework = lsb_business_standard       # always unregulated; LSB only

  ELIF entity_type == partnership AND partners > 3:
    framework = lsb_business_standard       # large partnership; CCA does not apply

Step 2 — Compose elements:

  For consumer_credit_secci (SECCI):
    Prescribed form under Code de droit économique Book VII (consumer credit) App 1.2
    Sections in fixed order:
      - Type of credit
      - Total amount of credit
      - Duration
      - Total amount payable
      - Withdrawal right (14-day cooling off)
      - Cost of credit (APR breakdown)
      - Right to early repayment
      - Consequences of missed payments
      - Default information
    Cooling off: 14 days from later of agreement signing or copy receipt

  For consumer_credit_pcci (PCCI):
    Used for overdrafts (not relevant for term loans typically) — emit if applicable

  For lsb_business_standard:
    LSB Standards 2025 commercial disclosure:
      - Summary of key terms
      - Fees breakdown
      - Security requirements (plain English)
      - Covenant summary (plain English)
      - Validity period of the offer
      - Complaints process
      - Ombudsfin eligibility (if micro-enterprise)
      - Right to seek independent legal/accountancy advice
    No cooling-off period — but borrower retains right to decline before acceptance
    Customer can withdraw without penalty before signing (commercial practice, not statutory)

  For exempt_agreement (CCA-exempt business lending below threshold):
    LSB applies even though CCA does not
    Same elements as lsb_business_standard but with explicit "this agreement is exempt
    from the Consumer Credit Act" disclosure
```

## Worked example (Manneken Engineering NV/SA)

Input:
```yaml
pre_contract_disclosure_request:
  case_id: "MAN-2026-04-001"
  customer_classification:
    entity_type: limited_co
    micro_enterprise: true
    annual_turnover_gbp: 851300
  facility_shape:
    facility_amount_eur: 150000
    facility_term_months: 60
  firm_pricing:
    firm_rate_pct: 8.4
    firm_arrangement_fee_pct: 1.0
  covenant_package_summary: {summary: "B+ covenant package, annual reporting, DSCR 1.25x"}
  cp_schedule: {summary: "5 conditions precedent"}
  security_summary:
    - type: all_asset_debenture
    - type: fixed_charge_equipment
    - type: personal_guarantee
      count: 2
  purpose_category: business_purpose
  acceptance_window_days: 30
```

Output:
```yaml
disclosure_pack:
  case_id: "MAN-2026-04-001"
  framework_applied: lsb_business_standard
  artefact_ref: "offer/MAN-2026-04-001/lsb_business_disclosure_v1.pdf"
  elements_included:
    - summary_of_key_terms
    - fees_breakdown
    - security_requirements_plain_english
    - covenant_summary_plain_english
    - offer_validity_period
    - complaints_process
    - fos_eligibility_micro_enterprise
    - right_to_independent_advice
    - cca_exempt_disclosure                  # because facility > €25k AND business purpose
  required_delivery_timing: with_facility_letter
  required_format: lsb_template
  customer_can_withdraw_without_penalty: true   # before signing (commercial practice)
  cooling_off_days: 0                            # no statutory cooling-off for LSB unregulated
  reason_codes: ["UK_DISCLOSURE_LSB_LIMITED_CO_UNREGULATED_FACILITY_OVER_THRESHOLD"]
```

Highland is a limited company borrowing for business purposes → LSB framework, not CCA.
Specifically because it's over €25k AND business purpose AND limited company, there's no
ambiguity. The disclosure pack is delivered alongside the facility letter and includes
the standard LSB elements plus an explicit "this is exempt from the CCA" notice that
prevents the customer from later claiming consumer-credit protections.

## Bright lines

- Entity type cannot be determined → escalate; cannot select framework
- Sole trader with mixed purpose (business + personal use) → refer; framework selection requires legal review
- SECCI required but missing prescribed elements → refuse to issue
- LSB pack issued AFTER facility letter (wrong timing) → refuse; LSB requires with-or-before
- Cooling-off period stated incorrectly (e.g. claiming 14 days for LSB-only customer) → refuse

## Operational rules

- Framework determination is deterministic; the agent does not "judge" cases — the rules are policy
- If framework is genuinely ambiguous (e.g. sole-trader applying for limited-co finance to be set up post-drawdown), escalate to legal — do not guess
- For regulated SECCI, the prescribed form is exactly that — prescribed. Custom wording is a regulatory breach.
- For LSB, plain English is mandated; Flesch reading ease ≥ 60 (same threshold as facility letter)
- The disclosure pack is a distinct artefact from the facility letter — never merged into one document

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Mixed personal/business purpose for sole trader | Escalate to legal; ambiguous framework |
| Partnership with unknown partner count | Refer to data-capture-agent |
| Customer requests to "opt out" of disclosure | Refuse the opt-out (cannot waive regulatory disclosure); document the request |
| Disclosure framework requires data not in input | Refer upstream |


## Belgium-specific operational notes

This agent operates within the Belgian lending framework — NBB (prudential, including CKP operation) and FSMA (conduct) twin peaks, Code de droit économique Books VII (consumer) + VIII (KBO), Loi du 18 septembre 2017 for AML.

- **Regional language obligation:** SECCI and contract MUST be in the customer's regional language — French (Wallonie), Dutch (Flanders), German (Eastern Cantons), or bilingual (Brussels Capital). This is statutory and contracts in the wrong language are invalid.
- **CKP mandatory consumer query:** Statutory mandatory before consumer credit decision; non-query invalidates agreement. NBB-operated central consumer credit register.
- **Statutory rate caps:** Code de droit économique Book VII sets statutory rate caps per consumer credit category — exceeding is contract invalidity.
- **itsme universal:** Belgian mobile identity platform widely adopted; integrates with PSD2 SCA. Most consumer onboarding uses itsme.
- **Cooperative + commercial bank mix:** Belfius (state-related cooperative legacy), KBC (cooperative origin), BNP Paribas Fortis (commercial), ING Belgium — diverse market structure.
- **Cross-reference:** `country-be-lending-policy-agent` provides full BE jurisdictional context.

## Statutory hooks

- Code de droit économique Book VII
- Code de droit économique Book VII (consumer credit) App 1.2 (SECCI prescribed form)
- Code de droit économique Book VII (consumer credit) 4 (pre-contractual information)
- LSB Standards 2025 (Lending Practice for Business Customers)
- Ombudsfin eligibility (micro-enterprise definition from EU 2003/361/EC retained)
- Consumer Credit (Exempt Agreements) Order 2007 (€25k threshold for business lending exemption)

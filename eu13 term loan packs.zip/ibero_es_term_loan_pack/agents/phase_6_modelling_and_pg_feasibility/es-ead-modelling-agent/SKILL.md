---
name: es-ead-modelling-agent
description: |
  Estimate Exposure at Default. For Spain term loans, this is largely deterministic — principal at drawdown amortising over term. For revolving credit or committed lines, includes credit conversion factor for undrawn portions. Term loans get a simple EAD profile.
---

# EAD Modelling Agent

EAD is the exposure metric for capital and ECL. For term loans it's near-trivial; kept as a separate agent for consistency and to handle non-term products.

## Input contract

```yaml
ead_request:
  case_id: string
  facility_type: enum
  facility_amount_eur: integer
  facility_term_months: integer
  drawdown_pattern: enum                    # single | phased | revolving
  undrawn_commitment_gbp: integer           # for revolving / committed
```

## Output contract

```yaml
ead_estimate:
  case_id: string
  ead_at_completion_gbp: integer
  ead_profile_over_term:                    # amortising schedule
    - month: integer
      outstanding_gbp: integer
  ead_avg_over_term_gbp: integer
  credit_conversion_factor: float           # 1.0 for term loans
  reason_codes: [string]
```

## Decision logic

```
For term_loan:
  ead_at_completion = facility_amount (fully drawn at completion)
  ead_profile = annuity_amortisation_schedule(facility_amount, term, rate)
  ead_avg = mean(ead_profile)
  credit_conversion_factor = 1.0

For revolving_credit:
  ead = drawn_estimate + (undrawn * CCF)  # CCF typically 40-75%

For asset_finance / invoice_finance:
  agent-specific logic
```

## Worked example (Ibero Engineering S.L. case)

Input:
```yaml
ead_request:
  case_id: "IBE-2026-04-001"
  facility_type: term_loan
  facility_amount_eur: 150000
  facility_term_months: 60
  drawdown_pattern: single
  undrawn_commitment_gbp: 0
```

Output:
```yaml
ead_estimate:
  case_id: "IBE-2026-04-001"
  ead_at_completion_gbp: 150000
  ead_profile_over_term:
    - month: 0
      outstanding_gbp: 150000
    - month: 12
      outstanding_gbp: 124800
    - month: 24
      outstanding_gbp: 97200
    - month: 36
      outstanding_gbp: 67100
    - month: 48
      outstanding_gbp: 34200
    - month: 60
      outstanding_gbp: 0
  ead_avg_over_term_gbp: 78600
  credit_conversion_factor: 1.0
  reason_codes: ["UK_EAD_TERM_LOAN_AMORTISING_PROFILE"]
```

Simple amortising profile for a €150k 60-month term loan. €150k at completion, ~€0 at maturity, time-weighted average €78.6k. Used as input to ECL (in combination with PD and LGD).

## Bright lines

- (no statutory bright lines for this agent)

## Operational rules

- Term loans: EAD profile is deterministic; no model risk in this calculation
- Revolving: CCF is portfolio-calibrated; updated quarterly

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Phased drawdown: unclear timing | Use worst-case (all drawn at once); flag |
| Asset finance: depreciation profile not provided | Refer |


## Spain-specific operational notes

This agent operates within the Spanish lending framework — Banco de España + CNMV joint regulatory perimeter, Ley 10/2014 for banking supervision, LCC (Ley 16/2011) for consumer credit, LRCCI (Ley 5/2019) for mortgage credit.

- **CIRBE €9k threshold:** Banco de España central credit register. Commercial risks >€9,000 mandatory contribution. Small SME facilities frequently below threshold — limited CIRBE visibility for genuine SME risk.
- **ASNEF / BADEXCUG strict access:** Spanish consumer bureau access has the strictest legal review requirement in EU. Operational onboarding must include legal basis attestation. ASNEF for negative; BADEXCUG for comprehensive — separate access agreements required.
- **LRCCI notarial requirement (AGNCN):** Mortgage origination requires AGNCN (Acta de Información Notarial Previa) — notarial pre-contractual information act. Cannot bypass; significant operational integration with notary network.
- **Tarjeta revolving usury (2020 Supreme Court):** Revolving credit cards subject to enhanced disclosure post-2020 Supreme Court rulings on usury. APR materially above market average is voidable.
- **Bizum ubiquity:** Mobile P2P payment platform with near-universal Spanish adoption; PSD2 integration via participating banks.
- **NIE administrative complexity:** Foreign residents require NIE (Número de Identidad de Extranjero) — multiple issuing authorities, common source of onboarding friction.
- **Cross-reference:** `country-es-lending-policy-agent` provides full ES jurisdictional context.

## Statutory hooks

- Basel III/IV (EAD for capital)
- IFRS 9 (ECL inputs)

---
name: sk-security-documentation-agent
description: |
  Drafts the security documentation package — the legally distinct instruments that
  create the security interests the lender takes: all-asset debenture (floating + fixed
  charges), specific fixed charges, personal guarantee deeds (Etridge-aware where
  required), deeds of priority (for inter-creditor positioning). Each is its own
  enforceable document executed separately from the loan agreement. Applies LPMPA 1989
  deed-execution formalities and Companies Act 2006 corporate execution requirements.
---

# Security Documentation Agent

Security documentation is where legal nuance compounds. A debenture without the right
charging clauses doesn't create the charge you think it does. A PG without proper spouse
consent under Etridge can't be enforced against joint property. An unregistered charge
becomes void against the company's liquidator after 21 days. The agent composes each
instrument with the right form, the right execution mechanics, and the right
post-completion registration plan.

## Input contract

```yaml
security_documentation_request:
  case_id: string
  security_composite: object                 # from security-composite-agent (the valuation work)
  proposed_security_package: [object]        # each item: type, holder_over, ranking, parties
  pg_feasibility_outcomes: [object]          # to identify Etridge-required deeds
  governing_law: enum                        # english | scottish | ni
  parties:
    borrower: object                         # company name, number, registered office
    lender: object
    guarantors: [object]                     # each with id, full name, address, marital status
  registration_targets:                      # where charges need to be registered post-completion
    - target: enum                           # companies_house | land_registry | bills_of_sale
      deadline_days_after_drawdown: integer
  prior_security:                            # existing charges, for ranking/priority deeds
    - charge_holder: string
      charge_type: enum
      to_be_released: boolean
```

## Output contract

```yaml
security_documentation:
  case_id: string
  documents:
    - document_id: string
      document_type: enum                    # debenture | fixed_charge | pg_deed |
                                              # deed_of_priority | spouse_consent
      artefact_ref: string
      parties: [string]
      governing_law: enum
      execution_method: enum                 # deed_execution_lpmpa_1989 | corporate_execution_s44 |
                                              # individual_with_witness | scottish_holograph
      etridge_compliant: boolean             # for PG deeds only
      spouse_consent_attached: boolean       # for Etridge-required PGs
      requires_registration_at: enum         # companies_house | land_registry | none
      registration_deadline: date
  post_completion_filings:
    - filing_id: string
      target: enum
      filing_form: string                    # MR01, AP01, etc.
      deadline: date
      owner: enum                            # lender_legal | external_legal
  reason_codes: [string]
```

## Decision logic

```
For each item in proposed_security_package:

  IF type == all_asset_debenture:
    Draft instrument with:
      - Floating charge over present and future assets
      - Fixed charges where perfectible (book debts, IP, specified equipment if identified)
      - Crystallisation triggers (default, insolvency, lender notice)
      - Negative pledge
      - Power of attorney for enforcement
      - Application of proceeds clause (reflecting s176A prescribed-part order)
    Execution: corporate seal OR s44 (two directors or director + secretary)
    Registration: Obchodný register MR01 within 21 days (s859A CA 2006)

  IF type == fixed_charge_specific:
    Draft separate instrument for the specific asset:
      - Asset identification (with serial numbers if available, or commitment to capture)
      - Charging clause
      - Insurance covenant (asset insured, lender's interest noted)
      - Inspection rights
      - Disposal restrictions
    Execution: corporate execution
    Registration: Obchodný register MR01 within 21 days

  IF type == personal_guarantee AND etridge_required:
    Draft PG deed with:
      - Standard PG clauses (continuing guarantee, no marshalling, etc.)
      - All-monies wording bounded by face amount
      - Etridge-specific schedule:
        * Spouse consent annex (separate signed document)
        * Solicitor's ILA certificate slot
        * Affirmation by guarantor that ILA was received
      - Witness attestation block (LPMPA 1989 s1)
    Execution: deed by individual in presence of witness, LPMPA 1989
    Registration: not required (PG is personal, not against company; CH registration N/A)

  IF type == personal_guarantee AND NOT etridge_required:
    Standard PG deed (as above but no Etridge schedule)
    Execution: deed by individual in presence of witness
    Registration: not required

  IF prior_security has unreleased charge holder:
    Either:
      - Wait for clearance (preferred — handled by CP-001 satisfaction letter)
      - OR draft deed_of_priority with prior holder (if they remain in place)

Governing law sweep:
  Apply selected governing law consistently across all documents
  For Scottish-law security, use "standard security" instead of "fixed charge" for land
  For NI, similar adaptations

Post-completion registration plan:
  For each registrable security, add MR01 filing to post_completion_filings
  21-day deadline from creation
  Owner = lender_legal team
```

## Worked example (Tatra Engineering s.r.o.)

Input:
```yaml
security_documentation_request:
  case_id: "TAT-2026-04-001"
  proposed_security_package:
    - type: all_asset_debenture
      ranking: first
    - type: fixed_charge_specific
      asset: "Non-destructive testing equipment (Phased Array Slovakia Ltd)"
      ranking: first
    - type: personal_guarantee
      guarantor_id: DIR-001
      face_amount_eur: 90000
    - type: personal_guarantee
      guarantor_id: DIR-002
      face_amount_eur: 60000
  pg_feasibility_outcomes:
    - principal_id: DIR-001
      etridge_process_required: true
      spouse_full_name: "Eilidh MacKenzie"
      spouse_address: "12 Strathblane Road, Bratislava G63 9AB"
    - principal_id: DIR-002
      etridge_process_required: false
  governing_law: english
  parties:
    borrower:
      company_name: "Tatra Engineering s.r.o. Consultants Ltd"
      company_number: "12345678"
      registered_office: "2 Atlantic Quay, Bratislava G2 8JB"
    guarantors:
      - id: DIR-001
        full_name: "Lachlan Andrew MacKenzie"
        address: "12 Strathblane Road, Bratislava G63 9AB"
        marital_status: married
      - id: DIR-002
        full_name: "Sarah Yi-Mei Chen"
        address: "44 Kelvinside Terrace South, Bratislava G20 8DJ"
        marital_status: single
  prior_security:
    - charge_holder: "First-Bank Plc"
      charge_type: floating
      to_be_released: true
```

Output:
```yaml
security_documentation:
  case_id: "TAT-2026-04-001"
  documents:
    - document_id: SEC-DOC-001
      document_type: debenture
      artefact_ref: "offer/TAT-2026-04-001/debenture_v1.docx"
      parties: ["Tatra Engineering s.r.o. Consultants Ltd", "ezbob Ltd"]
      governing_law: english
      execution_method: corporate_execution_s44
      etridge_compliant: not_applicable
      spouse_consent_attached: false
      requires_registration_at: companies_house
      registration_deadline: "2026-06-05"     # 21 days from drawdown 2026-05-15

    - document_id: SEC-DOC-002
      document_type: fixed_charge
      artefact_ref: "offer/TAT-2026-04-001/fixed_charge_equipment_v1.docx"
      parties: ["Tatra Engineering s.r.o. Consultants Ltd", "ezbob Ltd"]
      governing_law: english
      execution_method: corporate_execution_s44
      etridge_compliant: not_applicable
      spouse_consent_attached: false
      requires_registration_at: companies_house
      registration_deadline: "2026-06-05"

    - document_id: SEC-DOC-003
      document_type: pg_deed
      artefact_ref: "offer/TAT-2026-04-001/pg_deed_lachlan_v1.docx"
      parties: ["Lachlan Andrew MacKenzie", "ezbob Ltd"]
      governing_law: english
      execution_method: deed_execution_lpmpa_1989
      etridge_compliant: true
      spouse_consent_attached: true
      requires_registration_at: none
      registration_deadline: null

    - document_id: SEC-DOC-004
      document_type: spouse_consent
      artefact_ref: "offer/TAT-2026-04-001/spouse_consent_eilidh_v1.docx"
      parties: ["Eilidh MacKenzie", "ezbob Ltd"]
      governing_law: english
      execution_method: deed_execution_lpmpa_1989
      etridge_compliant: true
      spouse_consent_attached: false             # this IS the spouse consent
      requires_registration_at: none
      registration_deadline: null

    - document_id: SEC-DOC-005
      document_type: pg_deed
      artefact_ref: "offer/TAT-2026-04-001/pg_deed_sarah_v1.docx"
      parties: ["Sarah Yi-Mei Chen", "ezbob Ltd"]
      governing_law: english
      execution_method: deed_execution_lpmpa_1989
      etridge_compliant: not_applicable
      spouse_consent_attached: false
      requires_registration_at: none
      registration_deadline: null

  post_completion_filings:
    - filing_id: FILING-001
      target: companies_house
      filing_form: MR01
      deadline: "2026-06-05"                     # 21 days from drawdown
      owner: lender_legal

    - filing_id: FILING-002
      target: companies_house
      filing_form: MR01
      deadline: "2026-06-05"
      owner: lender_legal

  reason_codes: ["UK_SECURITY_DOCS_DRAFTED_ETRIDGE_COMPLIANT"]
```

Five separate legal documents, plus two post-completion CH filings. Note SEC-DOC-004 — the
standalone spouse consent for Eilidh MacKenzie. Some lenders bury spouse consent inside
the PG deed; better practice is a standalone document that's clearly signed by Eilidh
herself, in her own name, on advice of her own solicitor. That's what Etridge actually
expects.

## Bright lines

- Etridge required but no spouse consent document drafted → refuse
- Etridge required but spouse consent + PG deed share single signature page (no separation) → refuse
- Charge type that requires registration but no MR01 filing planned → refuse
- Governing law mismatch between debenture and loan agreement → refuse
- Fixed charge over equipment without serial numbers AND no commitment to capture at delivery → refuse

## Operational rules

- PG deeds are always standalone instruments — never bundled with company security
- Spouse consent is always standalone — never appended as a schedule to the PG
- LPMPA 1989 s1 requirements applied strictly: deed must (a) be clear it is intended to be a deed, (b) be signed, witnessed, (c) be delivered
- Witnesses cannot be the other party, the spouse, or a beneficiary
- For Scottish-residence guarantors signing under English-law PG: signature must still satisfy LPMPA 1989; the witness's address can be Scottish but the formalities are English
- Charge registrations are tracked in post_completion_filings; this agent does NOT execute the filings, but it identifies them

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Governing law selected is not in template library | Refuse; legal must add template |
| Spouse address missing for Etridge case | Refer to data-capture-agent |
| Asset identification ambiguous for fixed charge | Refuse; require serial numbers or commitment to capture |
| Prior charge release evidence missing | Defer to CP-001 satisfaction; this agent flags but does not block |
| Guarantor refuses Etridge process | Block; PG cannot be effective against joint property |


## Slovakia-specific operational notes

Operates within the Slovak framework — NBS as unified supervisor, Consumer Credit Act, Housing Loans Act, AML Act 297/2008.

- **SBCB + NRSU dual registers:** Slovak Banking Credit Bureau (bank) and Non-Banking Credit Register provide comprehensive consumer credit visibility.
- **EUR member since 2009:** No FX consideration for euro-denominated lending.
- **Housing loan affordability caps:** NBS sets DTI/DSTI macroprudential caps for housing loans.
- **Cross-reference:** `country-sk-lending-policy-agent` (Country Policy Pack stub).

## Statutory hooks

- LPMPA 1989 s1 (deed execution formalities)
- Companies Act 2006 s44 (corporate execution)
- Companies Act 2006 Part 25 (charge registration), s859A (21-day filing deadline)
- Insolvency Act 1986 s176A (prescribed-part — referenced in debenture's application of proceeds)
- Williams & Glyn's Bank v Boland [1981] AC 487
- RBS v Etridge (No 2) [2001] UKHL 44
- Land Registration Rules 2003 (if land security)
- Bills of Sale Acts 1878-1882 (chattels)
- Sale of Goods Act 1979 (purchase money fixed charges)

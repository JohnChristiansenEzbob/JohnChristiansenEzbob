---
name: se-data-capture-agent
description: |
  Structured information capture from any origination channel. Normalises the raw broker / online / API payload into the canonical case object schema. Validates required fields, normalises currency and dates, flags missing data for follow-up.
---

# Data Capture Agent

Turn the raw inbound payload into a clean, structured case object that all downstream agents can consume reliably.

## Input contract

```yaml
raw_application_payload:
  source_channel: enum
  source_payload_raw: object                # arbitrary shape from broker/online form
  payload_schema_version: string
```

## Output contract

```yaml
case_object:
  case_id: string
  applicant:
    company_number: string
    name: string
    registered_office: string
    sic_codes: [string]
  facility:
    type: enum
    amount_sek: integer
    term_months: integer
    purpose_raw: string
  contact:
    primary_name: string
    primary_email: string
    primary_phone: string
    role: string
  channel: enum
  broker:                                   # nullable
    firm: string
    fca_reference: string
  validation_warnings: [string]
  field_count_populated: integer
```

## Decision logic

```
parse(raw_application_payload) against schema version.
For each field:
  - validate format (e.g. company_number = 8 digits, email regex, phone E.164)
  - normalise (currency to integer SEK, dates to ISO 8601)
  - if invalid: append to validation_warnings

If any required field missing or invalid: emit case_object with warnings populated.
Downstream orchestrator decides whether to pause or proceed.
```

## Worked example (Norrland Engineering AB case)

Input:
```yaml
raw_application_payload:
  source_channel: broker
  source_payload_raw:
    company_no: "556677-8899"
    co_name: "Norrland Engineering AB Consultants Ltd"
    facility: "term loan"
    amount: "150,000.00"
    term_yrs: 5
    contact: "Lachlan MacKenzie"
    contact_email: "lachlan@highlandeng.example.co.uk"
    contact_phone: "0141 555 0182"
  payload_schema_version: "broker_v3.2"
```

Output:
```yaml
case_object:
  case_id: "NOR-2026-04-001"
  applicant:
    company_number: "556677-8899"
    name: "Norrland Engineering AB Consultants Ltd"
    registered_office: "Kungsgatan 30, 111 35 Stockholm"
    sic_codes: ["71121"]
  facility:
    type: term_loan
    amount_sek: 150000
    term_months: 60                         # normalised from 5 yrs
    purpose_raw: "Premises fit-out + testing equipment"
  contact:
    primary_name: "Lachlan MacKenzie"
    primary_email: "lachlan@highlandeng.example.co.uk"
    primary_phone: "+441415550182"          # normalised to E.164
    role: "Managing Director"
  channel: broker
  broker:
    firm: "Highland Capital Partners"
    fca_reference: "555444"
  validation_warnings: []
  field_count_populated: 47
```

Broker payload normalised — amount string '150,000.00' becomes integer 150000, term '5 yrs' becomes 60 months, phone normalised to E.164. No validation warnings.

## Bright lines

- (no statutory bright lines for this agent)

## Operational rules

- Field normalisation is deterministic — same input always produces same output
- Currency normalised to integer SEK (no fractional pence at this stage)
- Dates normalised to ISO 8601
- Phone numbers normalised to E.164
- Validation warnings are non-blocking — downstream agents see them and decide

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Payload schema version unknown | Refer to ops; cannot parse safely |
| Required field present but unparseable | Warning logged; field left null; case proceeds |
| Optional field unparseable | Warning logged; field left null; case proceeds |


## Sweden-specific operational notes

This agent operates within the Swedish lending framework — Finansinspektionen (FI) as unified supervisor, Banking and Financing Business Act (2004:297), Konsumentkreditlag (2010:1846) for consumer credit, Lag 2017:630 for AML.

- **BankID universal:** Operationally critical. Every Swedish consumer financial interaction uses BankID for SCA. Without BankID integration, customer onboarding friction is material.
- **Swish dominance:** Swedish bank-cooperative mobile payment platform; near-universal adoption for P2P + retail payments. Significant cash displacement in Sweden.
- **UC AB near-monopoly:** Upplysningscentralen (UC AB) holds dominant position for consumer credit data. Operational relationship is essential — analogous to SCHUFA in Germany.
- **Outside Eurozone:** SEK is free-floating. Larger lending facilities may need FX hedging consideration.
- **Macroprudential amortisation requirements:** FI sets statutory amortisation requirements (amorteringskrav) for high-LTV mortgages — operationally significant for mortgage product structure.
- **High household debt:** Sweden has historically high household debt-to-income; FI macroprudential focus is operationally consequential.
- **Personnummer privacy:** Restricted-use identifier; over-collection is privacy breach.
- **Cross-reference:** `country-se-lending-policy-agent` for full SE jurisdictional context (currently a stub in the Country Policy Pack).

## Statutory hooks

- Sweden GDPR (data minimisation — capture only what's needed)
- FI (Finansinspektionen) FI customer protection (clear capture of customer's stated needs)

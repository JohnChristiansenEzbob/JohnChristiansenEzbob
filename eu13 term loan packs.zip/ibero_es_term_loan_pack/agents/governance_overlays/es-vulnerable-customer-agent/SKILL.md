---
name: es-vulnerable-customer-agent
description: |
  Detect indicators of customer vulnerability — financial, health, life events, capability — and flag for enhanced support. For SME lending the principals can be vulnerable even where the company is not. Sole traders are particularly in scope.
---

# Vulnerable Customer Agent

Vulnerability is a LCC + BdE supervision cross-cutting requirement. Many vulnerability signals are subtle; this agent looks across all signals consistently.

## Input contract

```yaml
vulnerability_check_request:
  case_id: string
  applicant_legal_form: enum                # limited_company | partnership | sole_trader
  principal_signals_per_director:
    - principal_id: string
      bureau_signals: [string]              # recent defaults, multiple credit applications, etc.
      application_signals: [string]         # life-event indicators in application text
      stated_vulnerabilities: [string]      # explicitly declared
```

## Output contract

```yaml
vulnerability_assessment:
  case_id: string
  vulnerability_flags:
    - principal_id: string
      flag_type: enum                       # financial | health | life_event | capability | digital_capability
      severity: enum                        # low | medium | high
      source: enum                          # bureau | application | declared | inferred
      treatment_marker: enum                # enhanced_support | clear_communication | extended_timeframe
  enhanced_support_required: boolean
  audit_ledger_entry_id: string
  reason_codes: [string]
```

## Decision logic

```
For each principal:
  Check bureau signals (recent defaults, multiple applications, etc.)
  Check application signals (life events in stated purpose, contact patterns)
  Check declared vulnerabilities

Sole traders + micro-businesses: principals' personal vulnerability is materially relevant.

If any flag at medium/high severity: enhanced_support_required = true.
```

## Worked example (Ibero Engineering S.L. case)

Input:
```yaml
vulnerability_check_request:
  case_id: "IBE-2026-04-001"
  applicant_legal_form: limited_company
  principal_signals_per_director:
    - principal_id: DIR-001
      bureau_signals: []
      application_signals: []
      stated_vulnerabilities: []
    - principal_id: DIR-002
      bureau_signals: []
      application_signals: []
      stated_vulnerabilities: []
```

Output:
```yaml
vulnerability_assessment:
  case_id: "IBE-2026-04-001"
  vulnerability_flags: []
  enhanced_support_required: false
  audit_ledger_entry_id: "VC-2026-04-12-HE-001"
  reason_codes: ["UK_VULNERABILITY_NO_FLAGS_STANDARD_HANDLING"]
```

No vulnerability flags for Highland's directors. Standard handling. Both directors are stable, well-established, no adverse signals.

## Bright lines

- (no statutory bright lines for this agent)

## Operational rules

- Vulnerability is a sensitive attribute — handle in line with DPA 2018 + CNMV + BdE guidance
- Treatment markers are advisory to channel staff, not blocking
- Declared vulnerabilities are first-class — never override applicant's own statement

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Vulnerability signal but principal disputes | Record dispute; treat per applicant's preference |


## Spain-specific operational notes

This agent operates within the Spanish lending framework — Banco de España + CNMV joint regulatory perimeter, Ley 10/2014 for banking supervision, LCC (Ley 16/2011) for consumer credit, LRCCI (Ley 5/2019) for mortgage credit.

- **CIRBE €9k threshold:** Banco de España central credit register. Commercial risks >€9,000 mandatory contribution. Small SME facilities frequently below threshold — limited CIRBE visibility for genuine SME risk.
- **ASNEF / BADEXCUG strict access:** Spanish consumer bureau access has the strictest legal review requirement in EU. Operational onboarding must include legal basis attestation. ASNEF for negative; BADEXCUG for comprehensive — separate access agreements required.
- **LRCCI notarial requirement (AGNCN):** Mortgage origination requires AGNCN (Acta de Información Notarial Previa) — notarial pre-contractual information act. Cannot bypass; significant operational integration with notary network.
- **Tarjeta revolving usury (2020 Supreme Court):** Revolving credit cards subject to enhanced disclosure post-2020 Supreme Court rulings on usury. APR materially above market average is voidable.
- **Bizum ubiquity:** Mobile P2P payment platform with near-universal Spanish adoption; PSD2 integration via participating banks.
- **NIE administrative complexity:** Foreign residents require NIE (Número de Identidad de Extranjero) — multiple issuing authorities, common source of onboarding friction.
- **Cross-reference:** `country-es-lending-policy-agent` provides full ES jurisdictional context.

## Statutory hooks

- CNMV + BdE FG21/1 (Vulnerable Customers)
- CNMV + BdE LCC + BdE supervision
- Equality Act 2010 (disability)
- Spain GDPR (special category data — health)

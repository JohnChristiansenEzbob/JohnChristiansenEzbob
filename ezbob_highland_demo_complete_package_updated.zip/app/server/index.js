import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '..');
const app = express();
const data = JSON.parse(fs.readFileSync(path.join(root, 'data', 'demo-data.json'), 'utf8'));

app.use(express.json({ limit: '1mb' }));
app.use(express.static(root));

function normaliseCompanyNumber(value = '') {
  return String(value).trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
}

function assertCompanyNumber(companyNumber) {
  if (!/^[A-Z0-9]{2,8}$/.test(companyNumber)) {
    const err = new Error('Invalid Companies House company number format');
    err.status = 400;
    throw err;
  }
}

function demoCompanyProfile(companyNumber) {
  return {
    mode: 'replay',
    source: 'demo-companies-house-profile',
    companyNumber,
    note: 'Replay response. Configure COMPANIES_HOUSE_API_KEY or CH_API_KEY and pass mode=live to call Companies House.',
    request: {
      method: data.companiesHouse.api_call.method,
      url: data.companiesHouse.api_call.url_template.replace('{companyNumber}', companyNumber),
      auth: 'server-side Basic auth header redacted'
    },
    httpStatus: 200,
    profile: data.companiesHouse.demo_response,
    mappedFields: data.companiesHouse.mapped_fields,
    payloadHash: crypto.createHash('sha256').update(JSON.stringify(data.companiesHouse.demo_response)).digest('hex')
  };
}

async function fetchCompaniesHouseProfile(companyNumber) {
  const apiKey = process.env.COMPANIES_HOUSE_API_KEY || process.env.CH_API_KEY;
  if (!apiKey) return demoCompanyProfile(companyNumber);

  const url = `https://api.company-information.service.gov.uk/company/${encodeURIComponent(companyNumber)}`;
  const auth = Buffer.from(`${apiKey}:`).toString('base64');
  const response = await fetch(url, {
    method: 'GET',
    headers: {
      Authorization: `Basic ${auth}`,
      Accept: 'application/json'
    }
  });

  const text = await response.text();
  let payload;
  try {
    payload = text ? JSON.parse(text) : {};
  } catch {
    payload = { raw: text };
  }

  if (!response.ok) {
    const err = new Error(`Companies House request failed with HTTP ${response.status}`);
    err.status = response.status;
    err.payload = payload;
    throw err;
  }

  return {
    mode: 'live',
    source: 'companies-house-public-data-api',
    companyNumber,
    request: {
      method: 'GET',
      url,
      auth: 'server-side Basic auth header redacted'
    },
    httpStatus: response.status,
    etag: response.headers.get('etag'),
    profile: payload,
    mappedFields: data.companiesHouse.mapped_fields,
    payloadHash: crypto.createHash('sha256').update(JSON.stringify(payload)).digest('hex')
  };
}

app.get('/api/case', (_req, res) => res.json(data.caseSummary));
app.get('/api/ui-seed', (_req, res) => res.json(data.uiSeed));

app.post('/api/company-profile', async (req, res) => {
  try {
    const companyNumber = normaliseCompanyNumber(
      req.body?.companyNumber || req.body?.company_registration_number || data.uiSeed.company_registration_number
    );
    assertCompanyNumber(companyNumber);
    const wantsLive = String(req.body?.mode || req.query.mode || 'replay').toLowerCase() === 'live';
    const result = wantsLive ? await fetchCompaniesHouseProfile(companyNumber) : demoCompanyProfile(companyNumber);
    res.json(result);
  } catch (err) {
    res.status(err.status || 500).json({
      error: err.message || 'Companies House lookup failed',
      source: 'companies-house-adapter',
      payload: err.payload || null
    });
  }
});

app.post('/api/start-application', async (req, res) => {
  try {
    const uiSeed = {
      ...data.uiSeed,
      ...req.body,
      applicant: { ...data.uiSeed.applicant, ...(req.body?.applicant || {}) }
    };
    const companyNumber = normaliseCompanyNumber(uiSeed.company_registration_number);
    assertCompanyNumber(companyNumber);
    const companyProfile = await (String(req.body?.mode || 'replay').toLowerCase() === 'live'
      ? fetchCompaniesHouseProfile(companyNumber)
      : Promise.resolve(demoCompanyProfile(companyNumber)));

    res.json({
      case_id: data.caseSummary.case_id,
      status: 'seeded',
      uiSeed,
      companyProfile,
      next: {
        orchestrator: 'customer-onboarding-orchestrator',
        phase: 'phase1',
        mode: 'synthetic-replay-from-this-point-to-offer'
      },
      events: data.steps.map(s => ({ step: s.step, phaseId: s.phaseId, title: s.title, highlightSkills: s.highlightSkills }))
    });
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message || 'Application seed failed' });
  }
});

app.get('/api/demo-run', (req, res) => {
  const mode = req.query.mode || 'replay';
  res.json({
    mode,
    source: mode === 'live' ? 'live-adapter-boundary' : 'deterministic-replay',
    note: mode === 'live'
      ? 'Adapter endpoint is ready for Companies House and future agent/service integration. It returns replay data unless COMPANIES_HOUSE_API_KEY or CH_API_KEY is configured.'
      : 'Replay uses the attached synthetic Highland Engineering case, markdown skill contracts, UI seed and demo Companies House profile.',
    uiSeed: data.uiSeed,
    companiesHouse: {
      endpoint: '/api/company-profile',
      externalEndpoint: data.companiesHouse.api_call.url_template,
      auth: 'server-side Basic auth; key never reaches browser'
    },
    events: data.steps.map(s => ({ step: s.step, phaseId: s.phaseId, title: s.title, highlightSkills: s.highlightSkills }))
  });
});

app.post('/api/run-phase/:phaseId', (req, res) => {
  const phase = data.phases.find(p => p.id === req.params.phaseId);
  if (!phase) return res.status(404).json({ error: 'Unknown phase' });
  res.json({ phase, status: 'complete', mode: req.body?.mode || 'replay', ledgerFile: phase.output, skills: phase.skills });
});

const port = process.env.PORT || 4173;
app.listen(port, () => console.log('ezbob demo server running on http://localhost:' + port + '/standalone-demo.html'));

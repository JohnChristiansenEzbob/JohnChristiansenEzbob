---
name: dk-lgd-modelling-agent
description: |
  Estimate Loss Given Default — the percentage of exposure expected to be lost if the borrower defaults. Combines security position (from charges-register), personal guarantee feasibility (from pg-feasibility), and recovery model assumptions to produce a forward-looking LGD.
---

# LGD Modelling Agent

LGD drives both expected credit loss (IFRS 9) and risk-based pricing. Get LGD wrong and pricing is wrong.

## Input contract

```yaml
lgd_request:
  case_id: string
  facility_amount_dkk: integer
  proposed_security_type: enum
  charges_register_outcome: object          # from charges-register-and-prior-security-agent
  pg_feasibility_outcomes: [object]         # per-guarantor; from personal-guarantee-feasibility-agent
  industry: string                          # SIC code; influences recovery on liquidation
```

## Output contract

```yaml
lgd_estimate:
  case_id: string
  lgd_baseline_pct: float                   # before PG enforcement
  lgd_with_pg_pct: float                    # after PG realisation
  recovery_components:
    floating_charge_realisation_gbp: integer
    pg_realisation_attributable_gbp: integer
    industry_recovery_assumption_pct: float
  model_version: string
  reason_codes: [string]
```

## Decision logic

```
expected_facility_at_default = facility_amount * EAD_factor  # from ead-modelling-agent
expected_recovery_from_floating = (floating_charge_position_value * industry_recovery_factor)
expected_recovery_from_pg = sum(pg_feasibility.net_realisable_pg_cover_lower)

if NO PG:
  lgd_with_pg = lgd_baseline
else:
  lgd_with_pg = max(0, (EAD - expected_recovery_from_floating - expected_recovery_from_pg) / EAD)
```

## Worked example (Viking Engineering A/S case)

Input:
```yaml
lgd_request:
  case_id: "VIK-2026-04-001"
  facility_amount_dkk: 150000
  proposed_security_type: term_loan_debenture
  charges_register_outcome:
    new_lender_rank: first
    estimated_recovery_at_default_gbp: 92000
  pg_feasibility_outcomes:
    - principal_id: DIR-001
      net_realisable_pg_cover_lower_bound_gbp: 113100
    - principal_id: DIR-002
      net_realisable_pg_cover_lower_bound_gbp: 158000
  industry: "71121"
```

Output:
```yaml
lgd_estimate:
  case_id: "VIK-2026-04-001"
  lgd_baseline_pct: 0.38
  lgd_with_pg_pct: 0.28
  recovery_components:
    floating_charge_realisation_gbp: 92000
    pg_realisation_attributable_gbp: 90000   # capped at PG amount per principal
    industry_recovery_assumption_pct: 0.61
  model_version: "SME_LGD_v2.1"
  reason_codes: ["UK_LGD_28_PCT_WITH_PGS_IN_PLACE"]
```

Baseline LGD 38% — after first-rank floating charge realisation. PGs from both directors take LGD down to 28%. Substantial recovery uplift from PGs, which justifies the PG requirement.

## Bright lines

- (no statutory bright lines for this agent)

## Operational rules

- PG realisation is capped at the PG face value per principal
- Industry recovery assumptions refreshed annually based on portfolio actuals
- Boland-triggered PG cover: discount to lower bound × 0.6 (Etridge process risk)
- Cross-validate against historical portfolio LGDs in same SIC band

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| No PG and no security | LGD baseline at industry mean — typically high (>60%) |
| Recovery assumptions inconsistent with industry data | Refer model risk for review |


## Denmark-specific operational notes

This agent operates within the Danish lending framework — Finanstilsynet as unified financial supervisor, Lov om finansiel virksomhed (LOF) for banking, Kreditaftaleloven for consumer credit, Hvidvaskloven for AML.

- **Realkreditloven mortgage bond system:** Denmark's distinctive mortgage credit institution (realkreditinstitut) model issues Pfandbrief-equivalent bonds 1:1 backed by individual mortgages. Operationally different from UK SVR-based mortgage origination — fixed-rate, callable-by-borrower options dominate.
- **Outside Eurozone:** Currency is DKK, pegged to EUR via ERM II at ~7.46 DKK/EUR. Cross-border lending requires FX consideration but pegged stability reduces hedging requirement.
- **MitID universal:** Replaced NemID. Used for all online financial onboarding. Strong customer authentication is operationally seamless.
- **CPR number:** 10-digit national identifier with date of birth + gender encoded. Restricted use for identification by financial institutions.
- **No central credit register:** Bureaus are private (Experian DK, Bisnode DK, RKI for negative consumer). Multi-bureau best practice; no equivalent of UK Highland CCR.
- **e-Boks:** Digital postbox used for most government and financial communications; assume customer reads e-Boks rather than email.
- **Cross-reference:** `country-dk-lending-policy-agent` for full DK jurisdictional context (currently a stub in the Country Policy Pack).

## Statutory hooks

- Finanstilsynet model risk supervision (model risk management)
- IFRS 9 (ECL calculation)
- Basel III/IV (capital — internal models where applicable)

export const demoData = {
  "brand": {
    "name": "ezbob",
    "product": "SME Credit Decision Command Centre"
  },
  "caseSummary": {
    "case_id": "HE-2026-04-001",
    "borrower": "Highland Engineering Consultants Ltd",
    "company_number": "10428671",
    "channel": "broker",
    "broker": "Highland Capital Partners (FCA reg 555444)",
    "facility_amount_gbp": 150000,
    "facility_term_months": 60,
    "purpose": "Premises fit-out at new Glasgow office (60%) and specialised non-destructive testing equipment (40%) to support new infrastructure-sector clients.",
    "directors": [
      "Lachlan MacKenzie",
      "Sarah Chen"
    ],
    "expected_decision": {
      "outcome": "accept_with_conditions",
      "approved_amount_gbp": 150000,
      "approved_term_months": 60,
      "indicative_rate_pct": 8.4,
      "conditions": [
        "Existing floating charge to First-Bank Plc to be released at drawdown (satisfaction letter from First-Bank Plc required)",
        "Personal guarantee from Lachlan MacKenzie £90,000 — Etridge process required (independent legal advice to spouse re joint property)",
        "Personal guarantee from Sarah Chen £60,000 — standard process (sole property)",
        "Equipment to be specified by drawdown for inclusion in security schedule"
      ],
      "reason_codes": [
        "UK_CREDIT_DECISION_ACCEPT_WITHIN_POLICY",
        "UK_PG_ETRIDGE_BOLAND_PROCESS_REQUIRED_DIR_001",
        "UK_EXISTING_FLOATING_CHARGE_TO_BE_RELEASED_AT_DRAWDOWN"
      ]
    }
  },
  "metrics": {
    "Facility": "£150,000",
    "Term": "60 months",
    "Indicative / final rate": "8.4%",
    "Effective APR": "9.5%",
    "DSCR": "2.02x",
    "PD 12m": "1.8%",
    "LGD": "28%",
    "Risk grade": "B+",
    "Avg EAD": "£78.6k",
    "Outcome": "Accept with conditions"
  },
  "conditions": [
    "Existing floating charge to First-Bank Plc to be released at drawdown (satisfaction letter from First-Bank Plc required)",
    "Personal guarantee from Lachlan MacKenzie £90,000 — Etridge process required (independent legal advice to spouse re joint property)",
    "Personal guarantee from Sarah Chen £60,000 — standard process (sole property)",
    "Equipment to be specified by drawdown for inclusion in security schedule"
  ],
  "reasonCodes": [
    "UK_CREDIT_DECISION_ACCEPT_WITHIN_POLICY",
    "UK_PG_ETRIDGE_BOLAND_PROCESS_REQUIRED_DIR_001",
    "UK_EXISTING_FLOATING_CHARGE_TO_BE_RELEASED_AT_DRAWDOWN"
  ],
  "phases": [
    {
      "id": "front",
      "number": 0,
      "name": "Front-end intake",
      "subagent": "React operations UI",
      "output": "ui_seed_payload.json + companies_house_profile.json",
      "skills": [],
      "summary": "One-page UI captures four seed fields, then the Node adapter enriches the company profile through Companies House before replay data continues the lending journey."
    },
    {
      "id": "phase1",
      "number": 1,
      "name": "Intake",
      "subagent": "intake-coordinator",
      "output": "phase_1_intake.json",
      "skills": [
        "customer-onboarding-orchestrator",
        "data-capture-agent",
        "lead-qualification-agent"
      ],
      "summary": "Open the ledger, normalise the application and run policy-fit pre-screening."
    },
    {
      "id": "phase2",
      "number": 2,
      "name": "Consent + Purpose",
      "subagent": "consent-purpose-coordinator",
      "output": "phase_2_consent_purpose.json",
      "skills": [
        "consent-management-agent",
        "needs-discovery-agent",
        "purpose-validation-agent"
      ],
      "summary": "Capture scoped consents and validate the declared borrowing purpose."
    },
    {
      "id": "phase3",
      "number": 3,
      "name": "KYB + PSC",
      "subagent": "kyb-psc-coordinator",
      "output": "phase_3_kyb_psc.json",
      "skills": [
        "kyb-verifier",
        "ubo-mapper",
        "psc-complex-structure-recursor"
      ],
      "summary": "Use the Companies House profile as KYB evidence, then resolve PSC / beneficial ownership structure."
    },
    {
      "id": "phase4",
      "number": 4,
      "name": "Per-principal verification",
      "subagent": "principal-verifier × 2 parallel lanes",
      "output": "phase_4_per_principal.json",
      "skills": [
        "multi-principal-fan-out-orchestrator",
        "identity-orchestration-agent",
        "aml-screening-agent",
        "application-fraud-agent",
        "director-financial-difficulty-checker",
        "director-cross-directorship-checker"
      ],
      "summary": "Run identity, AML, fraud, financial difficulty and cross-directorship checks per principal."
    },
    {
      "id": "phase5",
      "number": 5,
      "name": "Credit data assembly",
      "subagent": "credit-data-assembler",
      "output": "phase_5_credit_data.json",
      "skills": [
        "bureau-orchestration-agent",
        "open-banking-agent",
        "hmrc-direct-verification-agent",
        "alternative-data-agent",
        "charges-register-and-prior-security-agent"
      ],
      "summary": "Assemble bureau, Open Banking, HMRC, alternative data and charges register information."
    },
    {
      "id": "phase6",
      "number": 6,
      "name": "Modelling + security",
      "subagent": "risk-modeller",
      "output": "phase_6_modelling.json",
      "skills": [
        "affordability-agent",
        "pd-scoring-agent",
        "floating-charge-valuation-agent",
        "fixed-charge-valuation-agent",
        "personal-guarantee-feasibility-agent",
        "security-composite-agent",
        "lgd-modelling-agent",
        "ead-modelling-agent",
        "risk-rating-agent"
      ],
      "summary": "Run affordability, PD, security valuation, PG feasibility, LGD, EAD and risk rating."
    },
    {
      "id": "phase7",
      "number": 7,
      "name": "Decision + pricing",
      "subagent": "decision-maker",
      "output": "phase_7_decision.json",
      "skills": [
        "decision-pricing-agent",
        "sme-pricing-strategy-agent"
      ],
      "summary": "Synthesize upstream evidence into decision, pricing and drawdown conditions."
    },
    {
      "id": "gov",
      "number": 8,
      "name": "Governance overlays",
      "subagent": "governance-auditor",
      "output": "governance_overlays.json",
      "skills": [
        "consumer-duty-outcomes-agent",
        "fairness-monitoring-agent",
        "vulnerable-customer-agent",
        "model-inventory-agent",
        "adverse-action-agent"
      ],
      "summary": "Attach Consumer Duty, fairness, vulnerability, model inventory and adverse-action governance overlays."
    }
  ],
  "skills": [
    {
      "id": "customer-onboarding-orchestrator",
      "folder": "customer-onboarding-orchestrator",
      "name": "customer-onboarding-orchestrator",
      "displayName": "Customer Onboarding Orchestrator",
      "description": "Case lifecycle coordinator for UK SME credit applications. Opens the case ledger, assigns the case_id, validates the inbound payload shape, dispatches downstream agents in correct phase order, and maintains case state across the journey. Control-flow primitive — does not perform external lookups or credit reasoning.",
      "logic": "if inbound_application.facility_type not in ALLOWED_PRODUCTS: status = terminated reason_codes = [UK_PRODUCT_NOT_OFFERED] elif required_fields_missing(inbound_application): status = paused reason_codes = [UK_INTAKE_INCOMPLETE_PAYLOAD] else: case_id = generate(applicant_company_number, application_date) initialise_ledger(case_id) status = active current_phase = 1 dispatch([lead-qualification-agent, data-capture-agent])",
      "brightLines": [
        "Inbound payload missing required field (applicant_company_number, facility_amount_gbp) → status=paused; cannot proceed",
        "Facility type not in the lender's product catalogue → status=terminated",
        "Duplicate case_id detected → status=terminated; existing case_id surfaced to broker"
      ],
      "operationalRules": [
        "case_id is immutable once issued",
        "Audit ledger is append-only (WORM equivalent)",
        "All downstream agent dispatch goes through this orchestrator — no direct agent-to-agent calls",
        "Case state changes emit a ledger entry with timestamp + actor identity"
      ],
      "statutoryHooks": [
        "FCA Consumer Duty (case ownership + auditability)",
        "FCA SYSC 3 (systems and controls)",
        "UK GDPR / DPA 2018 (lawful basis at intake)"
      ],
      "workedExample": "case_state:\n  case_id: \"HE-2026-04-001\"\n  status: active\n  current_phase: 1\n  channel: broker\n  case_type: UK_term_loan\n  audit_ledger_initialised: true\n  next_phase_unlocked: true\n  dispatched_agents: [\"lead-qualification-agent\", \"data-capture-agent\"]",
      "phaseId": "phase1",
      "phaseName": "Intake",
      "subagent": "intake-coordinator",
      "keyOutput": "Case ledger opened as HE-2026-04-001; broker channel accepted; audit ledger initialised; next phase unlocked.",
      "caseStatus": "active"
    },
    {
      "id": "data-capture-agent",
      "folder": "data-capture-agent",
      "name": "data-capture-agent",
      "displayName": "Data Capture Agent",
      "description": "Structured information capture from any origination channel. Normalises the raw broker / online / API payload into the canonical case object schema. Validates required fields, normalises currency and dates, flags missing data for follow-up.",
      "logic": "parse(raw_application_payload) against schema version. For each field: - validate format (e.g. company_number = 8 digits, email regex, phone E.164) - normalise (currency to integer GBP, dates to ISO 8601) - if invalid: append to validation_warnings If any required field missing or invalid: emit case_object with warnings populated. Downstream orchestrator decides whether to pause or proceed.",
      "brightLines": [
        "(no statutory bright lines for this agent)"
      ],
      "operationalRules": [
        "Field normalisation is deterministic — same input always produces same output",
        "Currency normalised to integer GBP (no fractional pence at this stage)",
        "Dates normalised to ISO 8601",
        "Phone numbers normalised to E.164",
        "Validation warnings are non-blocking — downstream agents see them and decide"
      ],
      "statutoryHooks": [
        "UK GDPR (data minimisation — capture only what's needed)",
        "FCA Consumer Duty (clear capture of customer's stated needs)"
      ],
      "workedExample": "case_object:\n  case_id: \"HE-2026-04-001\"\n  applicant:\n    company_number: \"10428671\"\n    name: \"Highland Engineering Consultants Ltd\"\n    registered_office: \"Suite 4, 2 Atlantic Quay, Glasgow, G2 8GA\"\n    sic_codes: [\"71121\"]\n  facility:\n    type: term_loan\n    amount_gbp: 150000\n    term_months: 60                         # normalised from 5 yrs\n    purpose_raw: \"Premises fit-out + testing equipment\"\n  contact:\n    primary_name: \"Lachlan MacKenzie\"\n    primary_email: \"lachlan@highlandeng.example.co.uk\"\n    primary_phone: \"+441415550182\"          # normalised to E.164\n    role: \"Managing Director\"\n  channel: broker\n  broker:\n    firm: \"Highland Capital Partners\"\n    fca_reference: \"555444\"\n  validation_warnings: []\n  field_count_populated: 47",
      "phaseId": "phase1",
      "phaseName": "Intake",
      "subagent": "intake-coordinator",
      "keyOutput": "Raw broker payload normalised into canonical case object: company, facility, contact, purpose, broker, consent-ready data fields.",
      "caseStatus": "active"
    },
    {
      "id": "lead-qualification-agent",
      "folder": "lead-qualification-agent",
      "name": "lead-qualification-agent",
      "displayName": "Lead Qualification Agent",
      "description": "Policy-fit pre-screen for UK SME credit applications. Tests the inbound case against the lender's credit policy envelope — product range, amount band, prohibited sectors, geographic restrictions, broker accreditation status. Returns qualification outcome before any external data is pulled.",
      "logic": "if facility_amount_gbp not in product.amount_band: outcome = decline_policy reason_codes += [UK_LEAD_AMOUNT_OUTSIDE_BAND] if facility_term_months not in product.term_band: outcome = decline_policy reason_codes += [UK_LEAD_TERM_OUTSIDE_BAND] if primary_sic_code in PROHIBITED_SECTORS: outcome = decline_policy reason_codes += [UK_LEAD_PROHIBITED_SECTOR] if channel == \"broker\": if broker_fca_reference not in ACCREDITED_BROKERS: outcome = refer reason_codes += [UK_LEAD_BROKER_NOT_ACCREDITED] if geographic_region not in COVERED_REGIONS: outcome = decline_policy reason_codes += [UK_LEAD_REGION_NOT_COVERED] if outcome == None: outcome = pass product_match = match_product_variant(facility_type, amount, term)",
      "brightLines": [
        "Prohibited sectors (e.g. crypto exchanges, gambling, adult content) — automatic decline_policy",
        "Sanctioned regions / jurisdictions — automatic decline_policy",
        "Non-accredited broker — automatic refer (cannot auto-approve via unaccredited channel)"
      ],
      "operationalRules": [
        "Policy data (prohibited sectors, accredited brokers, regions) is versioned and loaded from a controlled config",
        "Pre-screen is cheap and synchronous — must complete within 200ms",
        "Policy changes require named credit-policy committee sign-off; the agent does not have discretion to override"
      ],
      "statutoryHooks": [
        "FCA Consumer Duty (clear product-customer fit at first touch)",
        "Financial Promotions regime (lender must only offer products it advertises)"
      ],
      "workedExample": "qualification_outcome:\n  case_id: \"HE-2026-04-001\"\n  outcome: pass\n  product_match: \"UK_term_loan_v3\"\n  fail_reasons: []\n  reason_codes: [\"UK_LEAD_QUALIFICATION_PASS\"]",
      "phaseId": "phase1",
      "phaseName": "Intake",
      "subagent": "intake-coordinator",
      "keyOutput": "Policy-fit pass for UK term loan v3: £150,000 / 60 months / eligible engineering consultancy / accredited broker.",
      "caseStatus": "active"
    },
    {
      "id": "consent-management-agent",
      "folder": "consent-management-agent",
      "name": "consent-management-agent",
      "displayName": "Consent Management Agent",
      "description": "Capture, validate, and issue scoped consent tokens for all downstream data pulls — commercial bureau, consumer bureau (per director), Open Banking, HMRC MTD APIs, Land Registry. Records consent provenance and provides a revocation handle.",
      "logic": "For each scope_requested: Find matching consent_capture_evidence entry. Validate evidence (signature, timestamp recency, IP if online). If valid: Issue scoped token with appropriate expiry (24h to 90 days depending on scope). Append to tokens list. Else: Append to scopes_refused. if all requested scopes granted: outcome = complete elif some granted: outcome = partial else: outcome = consent_required",
      "brightLines": [
        "Consent without evidence (no signed form, no e-sign hash) — cannot issue token; refused",
        "Consent older than scope-specific staleness threshold — refused; require refresh"
      ],
      "operationalRules": [
        "Tokens are scope-specific — never issue a single token covering multiple scopes",
        "Revocation handles are issued at token issuance; revocation propagates within 60 seconds",
        "Consent evidence is retained for 6 years post-relationship (DPA 2018 + FCA record-keeping)",
        "IP-based fraud signals (unusual location, VPN exit nodes) flagged but not blocking"
      ],
      "statutoryHooks": [
        "UK GDPR Article 6 (lawful basis) + Article 7 (consent conditions)",
        "Data Protection Act 2018",
        "PSD2 / Open Banking RTS (consent requirements for account access)",
        "Finance Act 2017 (HMRC MTD consent scope)"
      ],
      "workedExample": "consent_token_bundle:\n  case_id: \"HE-2026-04-001\"\n  tokens:\n    - scope: bureau_commercial\n      token_id: \"TKN-bureau-com-2026-04-12-001\"\n      issued_at: \"2026-04-12T09:14:30Z\"\n      expires_at: \"2026-07-11T09:14:30Z\"\n      revocation_handle: \"REV-001\"\n    # (similar entries for other 6 tokens)\n  scopes_granted: [bureau_commercial, bureau_consumer_per_director, open_banking,\n                   hmrc_mtd_vat, hmrc_mtd_paye, hmrc_mtd_ct, land_registry_named_directors]\n  scopes_refused: []\n  outcome: complete",
      "phaseId": "phase2",
      "phaseName": "Consent + Purpose",
      "subagent": "consent-purpose-coordinator",
      "keyOutput": "Scoped consent bundle issued for commercial bureau, consumer bureau, Open Banking, HMRC VAT/PAYE/CT, and Land Registry.",
      "caseStatus": "active"
    },
    {
      "id": "needs-discovery-agent",
      "folder": "needs-discovery-agent",
      "name": "needs-discovery-agent",
      "displayName": "Needs Discovery Agent",
      "description": "Capture the structured needs profile — facility type, amount, term, drawdown pattern, urgency, dependencies. The 'what does the customer actually want' agent. Distinct from data-capture which normalises shape; needs-discovery captures intent.",
      "logic": "Compare declared shape against product fit heuristics: - Term loan + drawdown=revolving → mismatch (suggest revolving credit) - Term loan + amount < £25k → mismatch (suggest unsecured personal loan or revolving) - Term loan + term > 84 months → mismatch (refer to commercial mortgage) If fit ≥ adequate: pass needs_profile through. If mismatch: emit alternative_recommended and refer to broker for re-shape.",
      "brightLines": [
        "(no statutory bright lines for this agent)"
      ],
      "operationalRules": [
        "If applicant has considered asset finance for the equipment portion, surface that as an alternative even if the term loan fits — Consumer Duty fair-value check",
        "Urgency <14d may push the case to expedited review queue but does not skip any agent"
      ],
      "statutoryHooks": [
        "FCA Consumer Duty (products + services outcome — well-fitted product)"
      ],
      "workedExample": "needs_profile:\n  case_id: \"HE-2026-04-001\"\n  facility_shape:\n    type: term_loan\n    amount_gbp: 150000\n    term_months: 60\n    drawdown: single\n  fit_assessment: well_fitted\n  alternative_recommended: null\n  urgency: routine\n  dependencies: [\"equipment_delivery\", \"lease_completion\"]\n  reason_codes: [\"UK_NEEDS_WELL_FITTED_TERM_LOAN\"]",
      "phaseId": "phase2",
      "phaseName": "Consent + Purpose",
      "subagent": "consent-purpose-coordinator",
      "keyOutput": "Needs profile confirms capital expenditure term loan is well fitted; dependencies are equipment delivery and lease completion.",
      "caseStatus": "active"
    },
    {
      "id": "purpose-validation-agent",
      "folder": "purpose-validation-agent",
      "name": "purpose-validation-agent",
      "displayName": "Purpose Validation Agent",
      "description": "Validate the declared purpose against the lender's acceptable-use policy. Detect purpose drift patterns (e.g. 'working capital' that is really debt consolidation). Classify purpose against the canonical purpose taxonomy used by downstream pricing and capital calculations.",
      "logic": "Classify declared_purpose_text against purpose taxonomy. Check for drift patterns: - \"working capital\" + amount > £100k + term > 36m → suspect debt consolidation - \"equipment\" + no supplier named → refer - \"premises\" + no lease or property address → refer - any text containing \"consolidate\" + declared as something else → drift_pattern_detected If purpose ∈ PROHIBITED_PURPOSES (e.g. crypto investment, gambling): decline_policy If drift_pattern_detected: refer for human classification Else: pass with classified category",
      "brightLines": [
        "Prohibited purposes (crypto investment, gambling, weapons, regulated activities customer is not authorised for) → decline_policy",
        "Drift to debt consolidation under a different declared purpose → refer (intentional misrepresentation possible)"
      ],
      "operationalRules": [
        "Evidence (invoices, quotes, lease docs) materially reduces drift risk",
        "Broker-tagged category is a hint, not authoritative — the agent re-classifies independently",
        "Capture of evidence pointers in case ledger for audit"
      ],
      "statutoryHooks": [
        "FCA Consumer Duty (purpose-aware product fit)",
        "UK MLR 2017 (purpose understanding as part of CDD)",
        "ECCTA 2023 (purpose drift can be a fraud signal)"
      ],
      "workedExample": "purpose_validation:\n  case_id: \"HE-2026-04-001\"\n  purpose_category: capex_premises_and_equipment\n  purpose_check: pass\n  drift_pattern_detected: false\n  drift_explanation: null\n  reason_codes: [\"UK_PURPOSE_CAPEX_VALIDATED_WITH_EVIDENCE\"]",
      "phaseId": "phase2",
      "phaseName": "Consent + Purpose",
      "subagent": "consent-purpose-coordinator",
      "keyOutput": "Purpose validated as capex for premises and equipment. No prohibited use or purpose drift detected.",
      "caseStatus": "active"
    },
    {
      "id": "kyb-verifier",
      "folder": "kyb-verifier",
      "name": "kyb-verifier",
      "displayName": "Kyb Verifier",
      "description": "Verify the applicant company at Companies House — active status, registered office currency, accounts filing currency, no strike-off proposed. Establishes the foundational fact that the company is a real, currently-trading legal entity.",
      "logic": "Companies House API call by company_number. if status in [dissolved, liquidation]: outcome = block_dissolved_or_strike_off elif status == proposed_for_strike_off: outcome = block_dissolved_or_strike_off # BRIGHT LINE elif status == not_found: outcome = block_dissolved_or_strike_off reason_codes += [UK_COMPANIES_HOUSE_NOT_FOUND] elif accounts_filing_status == overdue: outcome = refer_filings_overdue # not a hard block but material else: outcome = verified",
      "brightLines": [
        "Company dissolved or in liquidation → BLOCK; no facility can be advanced",
        "Company proposed for strike-off → BLOCK pending applicant explanation",
        "Company not found at Companies House → BLOCK; suspect fraud"
      ],
      "operationalRules": [
        "Companies House data is authoritative for legal status",
        "Registered office must match the applicant-declared trading address sufficiently (or have valid explanation)",
        "Accounts overdue is a material refer signal but not always a decline (recent incorporation, ongoing extension request)"
      ],
      "statutoryHooks": [
        "Companies Act 2006",
        "ECCTA 2023 (Companies House register integrity)",
        "UK MLR 2017"
      ],
      "workedExample": "kyb_result:\n  case_id: \"HE-2026-04-001\"\n  company_number: \"10428671\"\n  status: active\n  incorporation_date: \"2017-09-14\"\n  age_months: 102\n  registered_office: \"Suite 4, 2 Atlantic Quay, Glasgow, G2 8GA\"\n  registered_office_verified: true\n  sic_codes: [\"71121\"]\n  accounts_filing_status: up_to_date\n  last_accounts_made_up_to: \"2025-09-30\"\n  next_accounts_due: \"2026-06-30\"\n  confirmation_statement_status: up_to_date\n  outcome: verified\n  reason_codes: [\"UK_KYB_ACTIVE_CURRENT_FILINGS\"]",
      "phaseId": "phase3",
      "phaseName": "KYB + PSC",
      "subagent": "kyb-psc-coordinator",
      "keyOutput": "Companies House-style KYB returns active company, 102 months trading, current accounts and confirmation statement.",
      "caseStatus": "active"
    },
    {
      "id": "ubo-mapper",
      "folder": "ubo-mapper",
      "name": "ubo-mapper",
      "displayName": "Ubo Mapper",
      "description": "Map the standard 25%+ Person of Significant Control (PSC) chain via the Companies House PSC register. Identifies whether further recursion is needed (corporate PSC, trust-as-PSC, overseas entity) and hands off to psc-complex-structure-recursor if so.",
      "logic": "Pull PSC register from Companies House. For each PSC entry: classify as natural_person or non_natural_person. if any non_natural_person_pscs > 0: requires_recursion = true outcome = recursion_required # hand off to psc-complex-structure-recursor else: requires_recursion = false outcome = mapped",
      "brightLines": [
        "PSC register marked 'super-secure' (extremely rare; person at risk) — handle via senior compliance, do not bypass",
        "PSC register empty for an active company — flag for EDD (companies must declare PSCs)"
      ],
      "operationalRules": [
        "If any non-natural-person PSC present, automatic handoff to psc-complex-structure-recursor",
        "Nature-of-control codes are taxonomic; preserve original codes alongside categorisation"
      ],
      "statutoryHooks": [
        "Companies Act 2006 Part 21A (PSC regime)",
        "ECCTA 2023",
        "UK MLR 2017"
      ],
      "workedExample": "ubo_mapping:\n  case_id: \"HE-2026-04-001\"\n  company_number: \"10428671\"\n  psc_list:\n    - psc_id: PSC-001\n      natural_person: true\n      name: \"Lachlan MacKenzie\"\n      nature_of_control: [\"ownership_of_shares_50_to_75_percent\", \"voting_rights_50_to_75_percent\"]\n      ownership_band: \"50-75\"\n      notified_on: \"2017-09-14\"\n      country_of_residence: \"Scotland, United Kingdom\"\n    - psc_id: PSC-002\n      natural_person: true\n      name: \"Sarah Chen\"\n      nature_of_control: [\"ownership_of_shares_25_to_50_percent\", \"voting_rights_25_to_50_percent\"]\n      ownership_band: \"25-50\"\n      notified_on: \"2020-04-01\"\n      country_of_residence: \"Scotland, United Kingdom\"\n  psc_count: 2\n  natural_person_pscs: 2\n  non_natural_person_pscs: 0\n  requires_recursion: false\n  outcome: mapped\n  reason_codes: [\"UK_UBO_MAPPED_DIRECT_NATURAL_PERSONS\"]",
      "phaseId": "phase3",
      "phaseName": "KYB + PSC",
      "subagent": "kyb-psc-coordinator",
      "keyOutput": "PSC chain mapped directly to two natural persons: Lachlan MacKenzie and Sarah Chen. No complex structure recursion needed.",
      "caseStatus": "active"
    },
    {
      "id": "psc-complex-structure-recursor",
      "folder": "psc-complex-structure-recursor",
      "name": "psc-complex-structure-recursor",
      "displayName": "Psc Complex Structure Recursor",
      "description": "Resolve UK Person of Significant Control (PSC) structures beyond the standard 25%+ direct ownership chain that ubo-mapper handles. Recurse through corporate PSCs to find ultimate natural persons; surface beneficiaries of trust-as-PSC structures; handle overseas-entity PSCs requiring Register of Overseas Entities (ECCTA) verification; flatten multi-layer corporate chains. Returns a complete list of ultimate natural-person PSCs plus the full path trace for audit. Flags trust, overseas, and anomalous patterns for Enhanced Due Diligence (EDD).",
      "logic": "Walk PSC graph breadth-first. For each non-natural-person PSC: - corporate UK → recurse into its PSC list - corporate overseas → query Register of Overseas Entities if not registered → outcome = eccta_non_compliance_block (BRIGHT LINE) - trust → seek trust deed; if absent → edd_required + add edd_flag - partnership/LLP → traverse partners - nominee detected → edd_required + escalate Stop when all leaves are natural persons OR recursion depth reached. Compute beneficial ownership multiplicatively through the chain.",
      "brightLines": [
        "Overseas-entity PSC without valid Register of Overseas Entities registration → BLOCK",
        "(`eccta_non_compliance_block`). Hard regulatory blocker; agent has no discretion.",
        "Detected nominee declarations → cannot auto-resolve; refer to MLRO for assessment.",
        "Recursion depth limit reached without natural-person resolution → escalate to EDD."
      ],
      "operationalRules": [
        "Preserve the full path trace in the decision log even when long — auditors may need it.",
        "Where trust deeds are not accessible, the agent must NOT fabricate beneficiary identity.",
        "Surface as `INCOMPLETE` and refer.",
        "Applicant-declared structure mismatching Companies House data → flag for fraud review."
      ],
      "statutoryHooks": [
        "Companies Act 2006 Part 21A (PSC regime)",
        "ECCTA 2023 (failure to prevent fraud, Register of Overseas Entities, identity verification)",
        "UK MLR 2017 — EDD where non-natural-person beneficial owner, overseas component, or trust",
        "HMRC Trust Registration Service",
        "FCA SYSC 6.3"
      ],
      "workedExample": "psc_resolved_structure:\n  applicant_company_number: \"10428671\"\n  ultimate_natural_person_pscs:\n    - name: \"Lachlan MacKenzie\"\n      effective_beneficial_ownership_pct: 60.0\n      path_trace: [\"Highland Engineering Consultants Ltd → Lachlan MacKenzie\"]\n      nature_of_control_origin: [\"ownership_of_shares_50_to_75_percent\"]\n    - name: \"Sarah Chen\"\n      effective_beneficial_ownership_pct: 40.0\n      path_trace: [\"Highland Engineering Consultants Ltd → Sarah Chen\"]\n      nature_of_control_origin: [\"ownership_of_shares_25_to_50_percent\"]\n  edd_flags: []\n  outcome: structure_resolved\n  reason_codes: [\"UK_PSC_NATURAL_PERSON_CHAIN_RESOLVED\"]",
      "phaseId": "phase3",
      "phaseName": "KYB + PSC",
      "subagent": "kyb-psc-coordinator",
      "keyOutput": "Conditional control shown for completeness. Highland has no corporate, trust, or overseas PSC, so recursion is bypassed.",
      "caseStatus": "conditional"
    },
    {
      "id": "multi-principal-fan-out-orchestrator",
      "folder": "multi-principal-fan-out-orchestrator",
      "name": "multi-principal-fan-out-orchestrator",
      "displayName": "Multi Principal Fan Out Orchestrator",
      "description": "Coordinate parallel verification across all natural-person principals of a UK SME applicant — directors, named Persons of Significant Control (PSCs), and applicant signatory. Spawn parallel subcases for identity, AML, application fraud, individual financial difficulty, and cross-directorship checks. Reconcile partial failures and aggregate per-principal outcomes into a composite case-level KYC/AML/fraud assessment that downstream credit decisioning can consume. Trigger whenever the assembled principals list contains more than one entry, OR whenever the PSC structure recursor has surfaced additional natural- person controllers beyond the named applicant. This agent is a control-flow primitive — it does not call external APIs; it composes other agents.",
      "logic": "For each principal (in parallel): spawn subcase → identity-orchestration-agent → aml-screening-agent → application-fraud-agent → director-financial-difficulty-checker → director-cross-directorship-checker Aggregate: if ANY principal.sanctions_pep_status == \"hit\": aggregate_outcome = block_and_sar # bright line elif ANY principal.financial_difficulty_status == \"decline\" AND principal.is_proposed_pg_bearer: aggregate_outcome = block_pg_bearer_difficulty elif ANY principal.cross_directorship_status == \"phoenix_risk\": aggregate_outcome = block_phoenix elif ALL principals.identity_verified AND ALL principals.financial_difficulty_status == \"clear\": aggregate_outcome = clear else: aggregate_outcome = refer",
      "brightLines": [
        "Sanctions hit on ANY principal → `block_and_sar`. No agent discretion. Engage tipping-off wall.",
        "Undischarged bankruptcy on a director where `is_proposed_pg_bearer = true` → `block_pg_bearer_difficulty`.",
        "Identity verification hard failure on any principal → case held; cannot progress."
      ],
      "operationalRules": [
        "Per-principal subcases run in parallel. Sequential execution is a performance bug.",
        "Each subcase emits its own decision-log entry; aggregate does not collapse individual evidence.",
        "Partial failure: if any subcase times out, aggregate emits `refer` (not block)."
      ],
      "statutoryHooks": [
        "UK Money Laundering Regulations 2017 (as amended)",
        "Economic Crime and Corporate Transparency Act 2023 (ECCTA)",
        "FCA SYSC 6.3",
        "FCA Consumer Duty"
      ],
      "workedExample": "principal_aggregate_assessment:\n  case_id: HE-2026-04-001\n  principal_count: 2\n  per_principal_outcomes:\n    - principal_id: DIR-001\n      identity_verified: true\n      identity_confidence: 0.97\n      sanctions_pep_status: clear\n      application_fraud_score: 12\n      financial_difficulty_status: clear  # 1 historic satisfied CCJ; not a blocker\n      cross_directorship_status: clean\n      subcase_completed: true\n    - principal_id: DIR-002\n      identity_verified: true\n      identity_confidence: 0.98\n      sanctions_pep_status: clear\n      application_fraud_score: 8\n      financial_difficulty_status: clear\n      cross_directorship_status: clean\n      subcase_completed: true\n  aggregate_outcome: clear\n  aggregate_reason_codes: [\"UK_PRINCIPAL_AGGREGATE_CLEAR\"]\n  hardest_blocker_principal_id: null",
      "phaseId": "phase4",
      "phaseName": "Per-principal verification",
      "subagent": "principal-verifier × 2 parallel lanes",
      "keyOutput": "Parent orchestration fans out two principal verification lanes in parallel and aggregates results into phase_4_per_principal.json.",
      "caseStatus": "orchestration logic"
    },
    {
      "id": "identity-orchestration-agent",
      "folder": "identity-orchestration-agent",
      "name": "identity-orchestration-agent",
      "displayName": "Identity Orchestration Agent",
      "description": "Verify the identity of a single natural-person principal — typically via document verification, biometric liveness, and database cross-checks (electoral roll, credit header). Returns a verification verdict plus a confidence score. Invoked by multi-principal-fan-out-orchestrator for each director / PSC.",
      "logic": "Document check: authenticity + tampering signals. Biometric check: liveness + facial match to document photo. Database check: cross-reference against electoral roll and credit header. if document_check.authenticity_score < 0.5 OR len(tampering_signals) > 0: outcome = hard_fail elif biometric_check.liveness_passed == false: outcome = hard_fail elif biometric_check.facial_match_score < 0.7: outcome = refer elif database_check.name_match AND database_check.address_match AND database_check.dob_match: outcome = verified confidence = composite_score(all_checks) else: outcome = refer",
      "brightLines": [
        "Document tampering signals present → hard_fail; case held",
        "Liveness check failed (static image, replay) → hard_fail",
        "Name/DOB on document does not match application → hard_fail"
      ],
      "operationalRules": [
        "Image evidence retained per DPA 2018 for as long as relationship plus 6 years",
        "Failed verifications are auditable — must record reason, not just outcome",
        "Where applicant has changed name (marriage etc.), verify both names"
      ],
      "statutoryHooks": [
        "UK MLR 2017 (customer due diligence — identity verification)",
        "ECCTA 2023 (director identity verification)",
        "UK GDPR (biometric data is special category — explicit consent + minimisation)"
      ],
      "workedExample": "identity_verification:\n  principal_id: DIR-001\n  identity_verified: true\n  confidence: 0.97\n  document_check:\n    doc_type: passport\n    authenticity_score: 0.98\n    tampering_signals: []\n  biometric_check:\n    liveness_passed: true\n    facial_match_score: 0.94\n  database_check:\n    electoral_roll_match: true\n    credit_header_match: true\n    name_match: true\n    address_match: true\n    dob_match: true\n  outcome: verified\n  reason_codes: [\"UK_IDENTITY_VERIFIED_HIGH_CONFIDENCE\"]",
      "phaseId": "phase4",
      "phaseName": "Per-principal verification",
      "subagent": "principal-verifier × 2 parallel lanes",
      "keyOutput": "DIR-001 verified at 0.97 confidence; DIR-002 verified at 0.98 confidence using document, biometric, and database checks.",
      "caseStatus": "active"
    },
    {
      "id": "aml-screening-agent",
      "folder": "aml-screening-agent",
      "name": "aml-screening-agent",
      "displayName": "Aml Screening Agent",
      "description": "Screen a single natural-person principal against sanctions lists (OFSI consolidated list, UN, EU, US OFAC where applicable), Politically Exposed Persons (PEPs) registers, and adverse media. Returns clear / hit / review verdict.",
      "logic": "Screen name (+ prior names) + DOB against: - OFSI consolidated list (UK) - UN sanctions list - EU sanctions list - OFAC SDN list (where principal's nationality / residence in scope) - PEPs register (typically World-Check or similar) - Adverse media (last 5 years) if ANY sanctions list returns a confirmed hit: composite_status = hit # BRIGHT LINE elif PEPs status in [foreign_pep, family_close_associate]: composite_status = review # mandatory EDD elif adverse_media_check.status == material: composite_status = review else: composite_status = clear",
      "brightLines": [
        "OFSI consolidated list hit → BLOCK (mandatory under UK financial sanctions regime)",
        "UN / EU / OFAC hit (within applicable jurisdictional scope) → BLOCK",
        "Tipping-off rule: customer-facing communication must not reveal the underlying reason"
      ],
      "operationalRules": [
        "Fuzzy matching with name variations + transliteration handled by the screening engine",
        "Confirmed hits require MLRO sign-off before any case action",
        "False positives recorded with disposition for future model tuning",
        "PEPs status is not a decline trigger per se but mandates enhanced due diligence (EDD)"
      ],
      "statutoryHooks": [
        "UK Money Laundering Regulations 2017",
        "UK Sanctions and Anti-Money Laundering Act 2018",
        "Financial Sanctions Notice (OFSI)",
        "FCA SYSC 6.3",
        "Proceeds of Crime Act 2002 (POCA) — tipping-off and SAR obligations"
      ],
      "workedExample": "aml_result:\n  principal_id: DIR-001\n  sanctions_check:\n    ofsi: clear\n    un: clear\n    eu: clear\n    ofac: clear\n  peps_check:\n    status: clear\n    pep_country: null\n  adverse_media_check:\n    status: clear\n    sources: []\n  composite_status: clear\n  reason_codes: [\"UK_AML_CLEAR_ALL_LISTS\"]",
      "phaseId": "phase4",
      "phaseName": "Per-principal verification",
      "subagent": "principal-verifier × 2 parallel lanes",
      "keyOutput": "Sanctions, PEP and adverse media screening clear for both principals.",
      "caseStatus": "active"
    },
    {
      "id": "application-fraud-agent",
      "folder": "application-fraud-agent",
      "name": "application-fraud-agent",
      "displayName": "Application Fraud Agent",
      "description": "Detect application-stage fraud indicators per principal — synthetic identity patterns, document tampering signals, velocity rules (repeated applications), CIFAS Protective Registration / National Fraud Database hits, device fingerprinting signals. Returns a fraud score (0-100) with classification.",
      "logic": "Lookup CIFAS National Fraud Database (consent-gated). Apply velocity rules (same identity in N applications in past M days). Device fingerprint analysis (known fraud-associated devices, automation). Synthetic identity detection (DOB-name combinations, address-credit history mismatches). Compute composite fraud_score. if cifas_markers include \"fraud\" (Category 6) marker: outcome = block_high_risk_fraud # BRIGHT LINE; CIFAS fraud marker is decline elif fraud_score >= 70: outcome = block_high_risk_fraud elif fraud_score >= 40: outcome = refer else: outcome = proceed",
      "brightLines": [
        "CIFAS Category 6 fraud marker → AUTO-DECLINE; cannot override without explicit dispensation",
        "Confirmed synthetic identity (fabricated person) → AUTO-DECLINE + SAR"
      ],
      "operationalRules": [
        "CIFAS lookup requires explicit consent; absence of consent → cannot perform that check (not blocking by itself)",
        "Velocity rules windowed (e.g. >3 applications in 30 days flags)",
        "Device fingerprints retained in fraud history for pattern detection"
      ],
      "statutoryHooks": [
        "Fraud Act 2006",
        "ECCTA 2023 (failure to prevent fraud — must have reasonable procedures)",
        "UK MLR 2017 (transaction monitoring + identity)",
        "CIFAS Code of Practice"
      ],
      "workedExample": "fraud_assessment:\n  principal_id: DIR-001\n  fraud_score: 12\n  classification: low\n  signals:\n    cifas_markers: []\n    velocity_signals: []\n    device_signals: []\n    synthetic_identity_signals: []\n  outcome: proceed\n  reason_codes: [\"UK_APPLICATION_FRAUD_LOW_RISK\"]",
      "phaseId": "phase4",
      "phaseName": "Per-principal verification",
      "subagent": "principal-verifier × 2 parallel lanes",
      "keyOutput": "Low fraud scores: Lachlan 12/100, Sarah 8/100. No CIFAS, velocity, device or synthetic identity red flags.",
      "caseStatus": "active"
    },
    {
      "id": "director-financial-difficulty-checker",
      "folder": "director-financial-difficulty-checker",
      "name": "director-financial-difficulty-checker",
      "displayName": "Director Financial Difficulty Checker",
      "description": "Check individual financial difficulty history for each director or named PSC of a UK SME applicant — distinct from company insolvency. Returns flags for undischarged bankruptcy, current IVA, current DRO, CCJs (unsatisfied and satisfied), recent default accounts, and historic BBLS/CBILS/RLS recovery action. Returns a treatment recommendation (decline / refer / proceed / proceed-with-conditions). Critical for UK SME lending where personal guarantees are nearly universal.",
      "logic": "Public-register lookups (no consent required): - Insolvency Service IIR → undischarged_bankruptcy, current_iva, current_dro - Registry Trust CCJ register → CCJ history (last 6 years) If undischarged_bankruptcy AND is_proposed_pg_bearer: recommended_treatment = decline reason_codes += [UK_DIRECTOR_UNDISCHARGED_BANKRUPTCY_DECLINE_PG] # BRIGHT LINE elif current_iva OR current_dro: recommended_treatment = decline (if PG bearer) OR refer (otherwise) reason_codes += [UK_DIRECTOR_IVA_OR_DRO_*] # BRIGHT LINE for PG bearers elif bbls_cbils_rls_recovery_flag: recommended_treatment = refer reason_codes += [UK_DIRECTOR_HISTORIC_GOVT_SCHEME_RECOVERY] elif unsatisfied_ccj_count >= 3 OR unsatisfied_ccj_value_total_gbp >= 5000: recommended_treatment = refer elif satisfied_ccj_count >= 2 OR default_account_count_24m >= 2: recommended_treatment = proceed_with_conditions else: recommended_treatment = proceed",
      "brightLines": [
        "`undischarged_bankruptcy = true` AND `is_proposed_pg_bearer = true` → AUTOMATIC DECLINE",
        "pending named-underwriter override.",
        "`current_iva = true` OR `current_dro = true` AND `is_proposed_pg_bearer = true` →",
        "AUTOMATIC DECLINE pending override.",
        "`bbls_cbils_rls_recovery_flag = true` → AUTOMATIC REFER (strong adverse signal but not"
      ],
      "operationalRules": [
        "Public-register lookups run regardless of consent (they are public).",
        "Consumer bureau extract requires valid consent. Without consent → emit",
        "`consent_required` and pause.",
        "Where principal has prior names (marriage etc.), query against both.",
        "Address mismatch between declared and bureau-of-record → flag to fraud agent; do not"
      ],
      "statutoryHooks": [
        "Insolvency Act 1986",
        "UK MLR 2017",
        "UK GDPR / Data Protection Act 2018",
        "LSB Standards of Lending Practice for Business Customers",
        "FCA Consumer Duty"
      ],
      "workedExample": "financial_difficulty_assessment:\n  principal_id: DIR-001\n  undischarged_bankruptcy: false\n  current_iva: false\n  current_dro: false\n  discharged_bankruptcy_within_6y: false\n  unsatisfied_ccj_count: 0\n  unsatisfied_ccj_value_total_gbp: 0\n  satisfied_ccj_count: 1\n  satisfied_ccjs:\n    - amount_gbp: 1340\n      registered: \"2020-06-18\"\n      satisfied: \"2020-09-04\"\n      creditor_type: \"trade_supplier\"\n  default_account_count_24m: 0\n  worst_payment_status_24m: current\n  bbls_cbils_rls_recovery_flag: false\n  recommended_treatment: proceed\n  reason_codes: [\"UK_DIRECTOR_FINANCIAL_DIFFICULTY_CLEAR_HISTORIC_SATISFIED_CCJ_NOTED\"]",
      "phaseId": "phase4",
      "phaseName": "Per-principal verification",
      "subagent": "principal-verifier × 2 parallel lanes",
      "keyOutput": "No current insolvency, IVA, DRO or unsatisfied CCJs. Lachlan has one historic satisfied CCJ, not a blocker.",
      "caseStatus": "active"
    },
    {
      "id": "director-cross-directorship-checker",
      "folder": "director-cross-directorship-checker",
      "name": "director-cross-directorship-checker",
      "displayName": "Director Cross Directorship Checker",
      "description": "Trace each director's other directorships across UK active and dissolved companies via Companies House director search. Identify cross-default risk (linked companies in arrears with this lender), phoenix-director patterns (serial company failures with same director), and concentration patterns (portfolio director vs synthetic-entity fraud). Returns classification per director: clean | monitor | phoenix_risk | cross_default_risk.",
      "logic": "Companies House director search by name + DOB month/year. For each directorship: fetch company status + incorporation/dissolution dates. Compute pattern metrics. if dissolved_with_insolvency_count_7y >= 2 OR same_trade_after_dissolution: classification = phoenix_risk # BRIGHT LINE — refer to underwriter elif strike_off_count_7y >= 3: classification = phoenix_risk elif cross_default_active_arrears_lender_portfolio: classification = cross_default_risk # BRIGHT LINE — decline pending override elif active_directorships >= 5 AND diverse_sic_code_count >= 4: classification = portfolio_director # Not negative; understand pattern elif active_directorships >= 2: classification = monitor else: classification = clean",
      "brightLines": [
        "`classification = phoenix_risk` → AUTOMATIC REFER. Phoenix patterns are a leading UK",
        "SME fraud signal; cannot auto-approve.",
        "`classification = cross_default_risk` (active arrears in lender's own portfolio) →",
        "AUTOMATIC DECLINE pending underwriter override."
      ],
      "operationalRules": [
        "Director name matching is fuzzy. Under-include rather than over-include where ambiguous",
        "(false positives are worse than false negatives in director matching).",
        "Multiple directorships in genuinely different groups ≠ phoenix; require explicit",
        "dissolution-with-insolvency pattern.",
        "Audit log must include the full directorship list (company numbers), not just the"
      ],
      "statutoryHooks": [
        "Companies Act 2006",
        "Insolvency Act 1986",
        "Company Directors Disqualification Act 1986",
        "UK MLR 2017",
        "ECCTA 2023 (failure to prevent fraud)"
      ],
      "workedExample": "cross_directorship_assessment:\n  principal_id: DIR-001\n  total_lifetime_directorships: 1\n  active_directorships: 1\n  dissolved_with_insolvency_count_7y: 0\n  strike_off_count_7y: 0\n  same_trade_after_dissolution: false\n  cross_default_active_arrears_lender_portfolio: false\n  diverse_sic_code_count: 1\n  classification: clean\n  reason_codes: [\"UK_DIRECTOR_CROSS_DIRECTORSHIP_CLEAN\"]",
      "phaseId": "phase4",
      "phaseName": "Per-principal verification",
      "subagent": "principal-verifier × 2 parallel lanes",
      "keyOutput": "No phoenix pattern or dissolved-company concern. Sarah has one dormant family company; classification remains clean.",
      "caseStatus": "active"
    },
    {
      "id": "bureau-orchestration-agent",
      "folder": "bureau-orchestration-agent",
      "name": "bureau-orchestration-agent",
      "displayName": "Bureau Orchestration Agent",
      "description": "Orchestrate commercial credit bureau pulls (Experian Commercial Delphi, Equifax Commercial, CreditSafe, optionally Dun & Bradstreet). Aggregate into a composite credit picture. Handles bureau-specific scoring quirks and returns a consolidated view consumable by downstream affordability and PD agents.",
      "logic": "Parallel pulls of all bureaux_requested. For each bureau response: - record raw score + band - normalise key facts (CCJs, charges, arrears) Cross-check key facts across bureaux: - if bureaux disagree on CCJ count: flag discrepancy - if one bureau reports arrears the others don't: flag discrepancy Composite rating: - solid: all bureaux above their respective \"low risk\" thresholds - adequate: at least 2 of 3 above thresholds - weak: majority below thresholds OR any bureau reports arrears",
      "brightLines": [
        "Bureau flags 'do not lend' marker (rare; reserved for confirmed serious adverse) → BLOCK",
        "Active arrears with any reported lender → AUTOMATIC REFER"
      ],
      "operationalRules": [
        "Discrepancies across bureaux are NOT automatically resolved — they're flagged for review",
        "Different bureau scales are preserved in raw; only the composite is normalised",
        "Bureau costs: aim for 2 bureaux minimum, 3 for cases >£100k",
        "Bureau data is point-in-time — re-pull if case takes >30 days"
      ],
      "statutoryHooks": [
        "Consumer Credit Act 1974 (where applicable — sole traders, small partnerships)",
        "UK GDPR / DPA 2018",
        "FCA Consumer Duty"
      ],
      "workedExample": "bureau_composite:\n  case_id: \"HE-2026-04-001\"\n  company_number: \"10428671\"\n  experian:\n    delphi_score: 78\n    band: 4                                # low-medium risk\n    age_at_companies_house: 102\n  equifax:\n    score: \"B+\"\n    arrears_indicator: false\n  creditsafe:\n    score: 72\n    international_score: 70\n  consolidated:\n    composite_rating: solid\n    cumulative_ccj_count_company: 0\n    current_charges_outstanding: 1\n    current_arrears_with_any_lender: false\n    discrepancies_across_bureaux: []\n  reason_codes: [\"UK_BUREAU_COMPOSITE_SOLID_NO_DISCREPANCIES\"]",
      "phaseId": "phase5",
      "phaseName": "Credit data assembly",
      "subagent": "credit-data-assembler",
      "keyOutput": "Commercial bureaux consolidate to a solid SME picture: Experian Delphi 78, Equifax B+, CreditSafe 72.",
      "caseStatus": "active"
    },
    {
      "id": "open-banking-agent",
      "folder": "open-banking-agent",
      "name": "open-banking-agent",
      "displayName": "Open Banking Agent",
      "description": "Pull and analyse the applicant's bank transaction history via Open Banking AISP providers (TrueLayer, Plaid, Yapily, Tink). Returns categorised cash flow, turnover, balance trajectory, returned payments, gambling transactions, customer concentration, and volatility indicators.",
      "logic": "Pull last N months of transactions via AISP. Categorise transactions (income / expense / transfer / gambling / cash / etc.). Compute aggregates and behavioural signals. Flags for downstream: - returned_payments_12m >= 3 → adverse signal - gambling_transactions_12m > 12 or gambling_amount > 10% of credits → adverse signal - top_customer_pct > 30% → concentration risk flag - cash_flow_volatility_index > 0.6 → high volatility flag",
      "brightLines": [
        "(no statutory bright lines for this agent)"
      ],
      "operationalRules": [
        "Re-pull required if consent older than 90 days at decision time",
        "Categorisation uses lender's canonical taxonomy — AISP raw categories normalised",
        "Multiple bank accounts: aggregate but flag if applicant has hidden any"
      ],
      "statutoryHooks": [
        "PSD2 (Open Banking RTS)",
        "UK GDPR / DPA 2018",
        "FCA PERG 2.6 (AISP regulatory scope)"
      ],
      "workedExample": "ob_summary:\n  case_id: \"HE-2026-04-001\"\n  account:\n    bank_name: \"Synthetic-Bank UK\"\n    account_age_months: 96\n  flows:\n    trailing_12m_credits_gbp: 847200\n    trailing_12m_debits_gbp: 798450\n    net_12m_gbp: 48750\n  balance:\n    average_monthly_closing_balance_gbp: 38400\n    minimum_balance_12m_gbp: 12800\n    largest_overdraft_excursion_12m_gbp: 0\n  behaviour:\n    returned_payments_12m: 1\n    gambling_transactions_12m: 0\n    gambling_amount_12m_gbp: 0\n    cash_deposits_12m_gbp: 2400\n    salary_or_drawings_pattern: regular\n  customer_concentration:\n    top_customer_pct: 18.4\n    top_3_customer_pct: 42.1\n  cash_flow_volatility_index: 0.21\n  reason_codes: [\"UK_OB_STABLE_CASH_FLOW_LOW_VOLATILITY\"]",
      "phaseId": "phase5",
      "phaseName": "Credit data assembly",
      "subagent": "credit-data-assembler",
      "keyOutput": "Open Banking shows £847k trailing credits, £38.4k average monthly balance, low volatility, one returned payment, no overdraft excursion.",
      "caseStatus": "active"
    },
    {
      "id": "hmrc-direct-verification-agent",
      "folder": "hmrc-direct-verification-agent",
      "name": "hmrc-direct-verification-agent",
      "displayName": "Hmrc Direct Verification Agent",
      "description": "Pull HMRC-held data directly via the Making Tax Digital APIs to verify SME turnover (VAT), employee count and payroll (PAYE RTI), and profitability + accrued tax (Corporation Tax CT600). For sole trader / partnership applicants, route to Self Assessment instead. HMRC data is the most authoritative recent financial snapshot for UK SMEs — materially fresher than 9-12 month-old filed accounts available on Companies House. Manages the OAuth 2.0 flow with scoped consent.",
      "logic": "Validate consent_token: scope coverage + expiry. If expiring within 5 min, refresh. For each requested dataset: Submit OAuth-bearer call with scope. On 401/403 with scope mismatch → emit consent_required. VAT processing: Extract last 8 quarters of returns (sales + purchases + net VAT). Compute TTM turnover, growth, volatility. If obligations overdue → outcome = refer_hmrc_arrears (BRIGHT LINE) PAYE processing: Extract last 12 months RTI submissions. If paye_arrears AND paye_arrears_months > 3 → outcome = decline_paye_arrears (BRIGHT LINE) CT processing: Extract last 2 CT600s. Capture profit + accrued + payment status. Cross-check: if abs(vat_ttm_turnover - applicant_declared_turnover) / applicant_declared_turnover > 0.30: emit application_fraud_escalation flag for downstream fraud agent.",
      "brightLines": [
        "`vat_obligations_overdue = true` → AUTOMATIC REFER. HMRC arrears = priority debt + leading default predictor.",
        "`paye_arrears = true` AND `paye_arrears_months > 3` → AUTOMATIC DECLINE pending underwriter override.",
        "Turnover declared vs HMRC mismatch > 30% → escalate to application-fraud-agent."
      ],
      "operationalRules": [
        "Consent scope is strict. Do NOT request scopes beyond what consent_token grants.",
        "All HMRC data is highly sensitive. Decision log records metadata (which datasets accessed)",
        "only — raw values go to case record with tighter retention.",
        "For partnership / sole trader, route to Self Assessment API; for limited company use the",
        "VAT + PAYE + CT trio."
      ],
      "statutoryHooks": [
        "Finance Act 2017 (Making Tax Digital)",
        "UK GDPR / Data Protection Act 2018",
        "Finance Act 2008 Schedule 36 (information powers)",
        "Common Law of Confidence (HMRC confidentiality regime)"
      ],
      "workedExample": "hmrc_verification_record:\n  applicant_company_number: \"10428671\"\n  vat:\n    queried: true\n    obligations_overdue: false\n    last_8_quarters_returns_filed: true\n    ttm_turnover_gbp: 851300\n    qoq_volatility_pct: 8.4\n    growth_yoy_pct: 11.2\n  paye:\n    queried: true\n    employee_count_current: 6\n    monthly_gross_payroll_gbp: 28150\n    paye_arrears: false\n    paye_arrears_months: 0\n  corporation_tax:\n    queried: true\n    last_filed_period: \"2024-09-30\"\n    profit_before_tax_gbp: 112400\n    ct_accrued_gbp: 28100\n    ct_paid: true\n  outcome: verified\n  reason_codes: [\"UK_HMRC_DATA_RETRIEVED_CLEAN\"]",
      "phaseId": "phase5",
      "phaseName": "Credit data assembly",
      "subagent": "credit-data-assembler",
      "keyOutput": "HMRC-style data verifies VAT turnover £851.3k, 11.2% YoY growth, 6 employees, PAYE clean, corporation tax paid.",
      "caseStatus": "active"
    },
    {
      "id": "alternative-data-agent",
      "folder": "alternative-data-agent",
      "name": "alternative-data-agent",
      "displayName": "Alternative Data Agent",
      "description": "Pull supplementary financial data from accounting platforms (Xero, QuickBooks, Sage) and trade-data providers. Returns recent management accounts, gross margin, overdue payables/receivables, and any other structured operational data the applicant has chosen to share.",
      "logic": "For each connected platform: - pull last 12 months of P&L - pull aged debtors + creditors - pull inventory if applicable Reconcile against bureau + OB: - revenue_ttm vs OB credits — should be close (within 15%) - if material divergence → flag for downstream cross-check",
      "brightLines": [
        "(no statutory bright lines for this agent)"
      ],
      "operationalRules": [
        "Cross-reference revenue against HMRC VAT (where available) and OB credits — 15%+ delta is investigative",
        "Service businesses: gross margin proxied; inventory will be null",
        "Multiple platforms connected: aggregate consistently or flag discrepancy"
      ],
      "statutoryHooks": [
        "UK GDPR / DPA 2018",
        "FCA Consumer Duty (use of accurate, recent data)"
      ],
      "workedExample": "alt_data_summary:\n  case_id: \"HE-2026-04-001\"\n  platforms_used: [xero]\n  revenue_ttm_gbp: 854100\n  gross_margin_pct: 41.2\n  operating_profit_ttm_gbp: 118400\n  overdue_payables_gbp: 4200\n  overdue_receivables_gbp: 11800\n  days_sales_outstanding: 38\n  inventory_value_gbp: null\n  ttm_end_period: \"2026-03-31\"\n  reason_codes: [\"UK_ALT_DATA_XERO_CURRENT_PERIOD_RETRIEVED\"]",
      "phaseId": "phase5",
      "phaseName": "Credit data assembly",
      "subagent": "credit-data-assembler",
      "keyOutput": "Xero-style management data corroborates the case: £854.1k revenue, 41.2% gross margin, low overdue payables.",
      "caseStatus": "active"
    },
    {
      "id": "charges-register-and-prior-security-agent",
      "folder": "charges-register-and-prior-security-agent",
      "name": "charges-register-and-prior-security-agent",
      "displayName": "Charges Register And Prior Security Agent",
      "description": "Pull existing security registered against the applicant company via Companies House charges register (fixed charges, floating charges, debentures, all-asset security) and Land Registry Business Gateway (where the applicant owns commercial property). Returns ranked list of existing charges with creditor identity, registration date, charge type, and outstanding estimate. Material for secured lending decisions — the new lender's recoverable position depends entirely on the priority of existing charges.",
      "logic": "Companies House Charges Register API → returns list of charges. Land Registry Business Gateway for each declared property → returns proprietor + charges. For each charge: - Classify type - Resolve creditor identity (Companies House search by creditor name) - Estimate outstanding (from charge document text where parseable) - Apply satisfaction-pending logic Compute prospective security position: - If existing floating charge to designated rival lender → outcome = refer_subordination_negotiation - If existing all-asset debenture, no satisfaction date, no committed clearance → outcome = refer_security_subordinated - If applicant has committed to clear at drawdown (satisfaction_letter_pending = true AND cleared_by_drawdown = true) → proceed; flag as drawdown_condition - Else → clear (new lender takes first-rank or appropriately ranked security)",
      "brightLines": [
        "Existing floating charge to rival designated lender without committed clearance →",
        "AUTOMATIC REFER. Cannot take a new floating charge without negotiated subordination /",
        "waiver letters.",
        "Existing all-asset debenture, no satisfaction date, no committed clearance → AUTOMATIC",
        "REFER for security subordination."
      ],
      "operationalRules": [
        "An apparently-stale charge may still legally encumber the asset (Companies House does",
        "not auto-release). Always flag for human confirmation; do NOT recommend \"ignore\".",
        "Property identification by company number against registered proprietor — never by",
        "applicant name alone (false-positive risk).",
        "Land Registry pulls are paid per query — batch where possible."
      ],
      "statutoryHooks": [
        "Companies Act 2006 Part 25 (charges registration)",
        "Land Registration Act 2002",
        "Insolvency Act 1986 (priority of charges in liquidation)",
        "Law of Property Act 1925"
      ],
      "workedExample": "prior_security_schedule:\n  applicant_company_number: \"10428671\"\n  outstanding_charges:\n    - charge_code: \"CH-2021-04-18-A\"\n      creditor: \"First-Bank Plc (synthetic)\"\n      charge_type: floating\n      registered: \"2021-04-18\"\n      estimated_outstanding_gbp: 38000\n      satisfaction_letter_pending: true\n      cleared_by_drawdown: true\n  land_registry_properties: []            # applicant owns no commercial property\n  prospective_security_position:\n    new_lender_rank: first                # after existing charge cleared at drawdown\n    estimated_recovery_at_default_gbp: 92000   # ~60% of facility, post-clearance\n    pricing_uplift_recommended_pct: 0.0\n  outcome: clear\n  reason_codes: [\"UK_CHARGES_REGISTER_CLEAR_AFTER_PRIOR_CLEARANCE_AT_DRAWDOWN\"]",
      "phaseId": "phase5",
      "phaseName": "Credit data assembly",
      "subagent": "credit-data-assembler",
      "keyOutput": "Existing First-Bank floating charge of £38k identified; to be cleared at drawdown with satisfaction letter required.",
      "caseStatus": "active"
    },
    {
      "id": "affordability-agent",
      "folder": "affordability-agent",
      "name": "affordability-agent",
      "displayName": "Affordability Agent",
      "description": "Compute FCA-compliant affordability: monthly repayment burden against free cash flow, debt service coverage ratio (DSCR), surplus income after commitments. For term loans, uses TTM cash flow from HMRC + OB + alt data as the base. Returns a compliant / non-compliant verdict with the calculation evidence.",
      "logic": "monthly_repayment = annuity(facility_amount, term, indicative_rate) ttm_operating_cash_flow = best estimate from HMRC profit + OB net + alt data operating profit ttm_free_cash_flow = ttm_operating_cash_flow - ttm_existing_debt_service dscr = ttm_free_cash_flow / (12 * monthly_repayment) stress_rate = indicative_rate + 2.0% stress_monthly = annuity(facility_amount, term, stress_rate) stress_dscr = ttm_free_cash_flow / (12 * stress_monthly) if dscr >= 1.25 AND stress_dscr >= 1.10: outcome = affordable; fca_compliant = true elif dscr >= 1.10 AND stress_dscr >= 1.00: outcome = marginal; fca_compliant = true else: outcome = unaffordable; fca_compliant = false",
      "brightLines": [
        "dscr < 1.0 stressed → AUTOMATIC DECLINE (cannot demonstrate affordability under stress)",
        "Free cash flow negative or zero → AUTOMATIC DECLINE",
        "FCA-compliant calculation methodology must be documented in audit log"
      ],
      "operationalRules": [
        "Use the LOWER of HMRC profit + OB cash flow + alt data — conservatism",
        "Stress test at +200bps minimum (some lenders use +300bps for term > 60m)",
        "If facility has phased drawdown, model based on full-drawn position"
      ],
      "statutoryHooks": [
        "FCA CONC 5.2A (responsible lending — consumer credit)",
        "FCA Consumer Duty",
        "LSB Standards of Lending Practice for Business Customers"
      ],
      "workedExample": "affordability_assessment:\n  case_id: \"HE-2026-04-001\"\n  monthly_repayment_gbp: 3070\n  ttm_revenue_gbp: 851300\n  ttm_operating_cash_flow_gbp: 92700\n  ttm_existing_debt_service_gbp: 13200\n  ttm_free_cash_flow_gbp: 74400              # net of existing facility being cleared at drawdown\n  dscr: 2.02\n  surplus_after_repayment_gbp_per_month: 3130\n  fca_compliant: true\n  outcome: affordable\n  stress_test_passed: true\n  reason_codes: [\"UK_AFFORDABILITY_AFFORDABLE_DSCR_2_02\"]",
      "phaseId": "phase6",
      "phaseName": "Modelling + security",
      "subagent": "risk-modeller",
      "keyOutput": "Affordability passes: monthly repayment about £3,070; free cash flow £74.4k; DSCR 2.02x; stress test passes.",
      "caseStatus": "active"
    },
    {
      "id": "pd-scoring-agent",
      "folder": "pd-scoring-agent",
      "name": "pd-scoring-agent",
      "displayName": "Pd Scoring Agent",
      "description": "Produce a Probability of Default (PD) score for the applicant company over a 12-month horizon. Uses a calibrated portfolio model — typically a gradient-boosted classifier or logistic regression — combining bureau, OB, HMRC, alt data, and company features. Output is calibrated to portfolio default rates.",
      "logic": "Assemble feature vector from all inputs. Apply model_version against feature vector. Return calibrated PD + grade based on portfolio thresholds. Generate top-5 SHAP attributions for explainability. Portfolio grade mapping (example): PD < 1.0%: A PD 1.0-2.5%: B+ PD 2.5-5%: B PD 5-10%: C+ PD 10-20%: C PD 20-40%: D PD > 40%: E",
      "brightLines": [
        "(no statutory bright lines for this agent)"
      ],
      "operationalRules": [
        "Model versions are governed under SR 11-7 / PRA SS1/23 + Joint BoI/ISA AI Directive (where applicable)",
        "Top-5 drivers must be returned for explainability and adverse action notices",
        "Macro overlay refreshed quarterly by the model risk team",
        "PD output capped at 99.9% (no 100% predictions)"
      ],
      "statutoryHooks": [
        "PRA SS1/23 (model risk management)",
        "FCA Consumer Duty (use of accurate models)",
        "EU AI Act (high-risk classification — credit scoring) — relevant for EU customer scope",
        "UK GDPR Article 22 (right to explanation for automated decisions)"
      ],
      "workedExample": "pd_score:\n  case_id: \"HE-2026-04-001\"\n  pd_12m: 0.018\n  pd_percentile_portfolio: 68               # better than 68% of portfolio\n  portfolio_grade: B+\n  model_version: \"SME_TermLoan_PD_v4.2\"\n  top_5_drivers:\n    - feature: bureau_composite_rating\n      contribution_pct: 22.4\n    - feature: hmrc_ttm_turnover_consistency\n      contribution_pct: 18.1\n    - feature: company_age_months\n      contribution_pct: 14.6\n    - feature: cash_flow_volatility_index\n      contribution_pct: 11.8\n    - feature: receivables_concentration_ratio\n      contribution_pct: 9.2\n  model_assumptions:\n    macro_overlay_period: \"2026Q2\"\n    calibration_date: \"2026-01-15\"\n  reason_codes: [\"UK_PD_12M_1_8_PCT_GRADE_B_PLUS\"]",
      "phaseId": "phase6",
      "phaseName": "Modelling + security",
      "subagent": "risk-modeller",
      "keyOutput": "12-month PD estimated at 1.8%, portfolio grade B+, with consistent bureau/HMRC/OB evidence.",
      "caseStatus": "active"
    },
    {
      "id": "floating-charge-valuation-agent",
      "folder": "floating-charge-valuation-agent",
      "name": "floating-charge-valuation-agent",
      "displayName": "Floating Charge Valuation Agent",
      "description": "Value a proposed floating charge over the applicant company's asset base. Takes the company's working assets (inventory, receivables, plant & machinery, intangibles, cash) and applies liquidation-scenario haircuts to produce a realistic recoverable estimate for the lender at the prospective security rank. Distinct from charges-register-and- prior-security-agent which discovers EXISTING charges; this agent values the NEW floating charge the lender is taking.",
      "logic": "For each asset class, apply liquidation haircut: cash: realisable = book × 0.95 (minor reconciliation losses) receivables: realisable = book × (1 - aged_60_plus_pct) × 0.65 (collection in liquidation is hard; aged debt rarely recovers) inventory: realisable = book × inventory_haircut[type] raw_materials: 0.30 | wip: 0.15 | finished_goods: 0.45 not_applicable (services): 0 plant: realisable = nbv × age_haircut(age_years) age 0-2y: 0.55 | 2-5y: 0.40 | 5-10y: 0.25 | >10y: 0.15 intangibles: realisable = book × 0.05 (goodwill rarely transfers) inv_property: realisable = book × 0.85 (RICS forced sale ~85%) Sum gross_realisable. realisation_costs = max(£15,000, gross_realisable × 0.10) (liquidator + legal + sale) Prescribed part carve-out (Enterprise Act 2002 / s176A IA 1986): if net floating > £10,000: prescribed_part = min(£800,000, 50% of first £10k + 20% of next £2,990,000) set aside for unsecured creditors if prospective_rank == \"first\": net_realisable = gross_realisable - realisation_costs - prescribed_part elif prospective_rank == \"second\": net_realisable = max(0, gross_realisable - ",
      "brightLines": [
        "Prospective rank ≠ first AND no committed clearance of prior charge → realisable = 0; security is symbolic",
        "Goodwill / brand IP claimed at book — apply 95% haircut by default unless RICS valuation in evidence",
        "Inventory in regulated / perishable categories (food, pharma, fashion) — apply additional 30% haircut"
      ],
      "operationalRules": [
        "Liquidation haircuts are policy-controlled and refreshed annually from portfolio actuals",
        "Prescribed-part calculation MUST be included; otherwise the lender systematically over-counts",
        "For services businesses (zero inventory), the floating charge value sits in receivables + plant — communicate this transparently",
        "Cross-check with charges-register-and-prior-security-agent for existing rank; recovery on subordinated positions is materially lower"
      ],
      "statutoryHooks": [
        "Companies Act 2006 Part 25 (registration of charges)",
        "Insolvency Act 1986 s176A (prescribed-part carve-out)",
        "Enterprise Act 2002 (prescribed-part introduction)",
        "Law of Property Act 1925",
        "PRA SS1/23 (model use governance for LGD inputs)"
      ],
      "workedExample": "floating_charge_valuation:\n  case_id: \"HE-2026-04-001\"\n  asset_realisations:\n    cash_realisable_gbp: 36500                    # 38400 × 0.95\n    receivables_realisable_gbp: 53200             # 88900 × 0.92 × 0.65\n    inventory_realisable_gbp: 0\n    plant_realisable_gbp: 33000                   # 60000 × 0.55 (new equipment)\n    intangibles_realisable_gbp: 600\n    investment_property_realisable_gbp: 0\n  gross_realisable_gbp: 123300\n  realisation_costs_gbp: 15000                    # minimum\n  prescribed_part_carve_out_gbp: 27660            # ~22% effective on net\n  net_realisable_floating_gbp: 80640\n  recovery_ratio_to_facility: 0.54                # vs £150k facility\n  reason_codes: [\"UK_FLOATING_CHARGE_FIRST_RANK_AFTER_PRIOR_CLEARANCE\"]",
      "phaseId": "phase6",
      "phaseName": "Modelling + security",
      "subagent": "risk-modeller",
      "keyOutput": "Floating charge asset base valued after haircuts and s176A-style prescribed-part carve-out; net contribution feeds security composite.",
      "caseStatus": "active"
    },
    {
      "id": "fixed-charge-valuation-agent",
      "folder": "fixed-charge-valuation-agent",
      "name": "fixed-charge-valuation-agent",
      "displayName": "Fixed Charge Valuation Agent",
      "description": "Value proposed fixed charges over specific assets — commercial property (RICS Red Book methodology), chattels and equipment (secondary-market valuation), vehicles, and specific receivables (e.g. blocks assignment in invoice finance). Returns a forced-sale net realisable value per asset plus time-to-realise and enforcement cost estimate. Distinct from floating-charge-valuation-agent which addresses the whole asset base; this agent values each fixed asset specifically.",
      "logic": "For each proposed fixed charge: COMMERCIAL PROPERTY: Required: RICS Red Book valuation OR HMLR index-adjusted purchase price Open market value = best evidence Forced sale value = OMV × 0.80 (RICS typical forced-sale discount) Enforcement costs = max(£8,000, forced_sale × 0.06) Time to realise: 9-15 months CHATTEL / EQUIPMENT: Required: supplier quote (new) OR secondary-market listing (used) Open market value: if new: declared_value × 0.95 (immediate depreciation on first use) if used: secondary_market_value Apply depreciation curve based on age: 0-1y: 0.70 | 1-3y: 0.50 | 3-5y: 0.35 | 5-10y: 0.20 | >10y: 0.10 Forced sale = open_market × 0.75 (chattel auction realises 70-80%) Enforcement costs = max(£3,000, forced_sale × 0.10) Time to realise: 2-4 months VEHICLES: HPI / DVLA + secondary market check Forced sale = trade value (not retail) Enforcement costs = max(£500, forced_sale × 0.05) Time to realise: 1 month RESIDENTIAL PROPERTY (where charged as security, rare for SME term loan): RICS valuation required Forced sale = OMV × 0.85 Enforcement costs = max(£10,000, forced_sale × 0.07) T",
      "brightLines": [
        "Commercial property charge without RICS valuation — REFUSE valuation; require RICS Red Book before any reliance on the asset",
        "Chattel charge over assets that move or that the customer can dispose of without notice (vehicles in particular) — require additional registration / asset tracking; otherwise discount by 50%",
        "Specific receivables assignment with no verified debtor or no debtor consent — treat as floating, not fixed"
      ],
      "operationalRules": [
        "RICS valuations have a 12-week shelf life; older valuations require revalidation",
        "Equipment age determined as at the date of perfection of the charge, not at application",
        "Forced-sale discounts policy-controlled; refreshed annually from realised outcomes",
        "The agent does NOT commission RICS valuations — it works from supplied evidence; if absent, refers to the underwriter"
      ],
      "statutoryHooks": [
        "Companies Act 2006 Part 25",
        "Law of Property Act 1925",
        "Bills of Sale Acts 1878-1882 (chattel mortgages — rarely used for businesses but relevant)",
        "RICS Red Book (valuation standards)",
        "Consumer Credit Act 1974 (where applicable to chattel security on sole-trader applicants)"
      ],
      "workedExample": "fixed_charge_valuation:\n  case_id: \"HE-2026-04-001\"\n  per_asset_valuations:\n    - asset_id: FX-001\n      asset_class: chattel_equipment\n      valuation_method: chattel_secondary_market\n      open_market_value_gbp: 57000               # 60000 × 0.95 (immediate-use haircut)\n      forced_sale_value_gbp: 42750               # 57000 × 0.75 chattel auction\n      enforcement_costs_gbp: 4275                # 10% of forced sale\n      net_realisable_gbp: 38475\n      time_to_realise_months: 3\n      rank_adjustment_applied: 1.0               # first rank, no adjustment\n  total_net_realisable_fixed_gbp: 38475\n  reason_codes: [\"UK_FIXED_CHARGE_CHATTEL_NEW_EQUIPMENT_FIRST_RANK\"]",
      "phaseId": "phase6",
      "phaseName": "Modelling + security",
      "subagent": "risk-modeller",
      "keyOutput": "Specialist equipment valued: £60k declared value, £38.5k net realisable forced-sale estimate.",
      "caseStatus": "active"
    },
    {
      "id": "personal-guarantee-feasibility-agent",
      "folder": "personal-guarantee-feasibility-agent",
      "name": "personal-guarantee-feasibility-agent",
      "displayName": "Personal Guarantee Feasibility Agent",
      "description": "Assess the feasibility and capacity of a proposed personal guarantee BEFORE the credit decision is taken. Aggregates each proposed guarantor's consumer bureau extract, Land Registry property holdings, and supplementary declared assets into an estimated net unencumbered position. Returns maximum feasible PG amount and confidence interval. Handles Williams & Glyn's v Boland joint property cases and RBS v Etridge spouse-consent requirements. Pre-decision feasibility — distinct from the downstream personal-guarantee- agent which executes the PG after decision.",
      "logic": "Pull bureau extract → income, debt service, headroom. Pull Land Registry holdings by name → properties, charges, restrictions. For each property: net_equity = estimated_value - sum(registered_charges) if ownership == \"joint_with_spouse\": attributable = net_equity * 0.50 if spouse != applicant: boland_trigger = true elif ownership == \"sole\": attributable = net_equity else (tenants_in_common): attributable = net_equity * declared_share net_realisable_pg_cover_lower = sum(attributable) + unsecured_headroom - existing_indebtedness - 12m_living_costs net_realisable_pg_cover_upper = net_realisable_pg_cover_lower * 1.20 # uncertainty band if proposed_pg_amount <= net_realisable_pg_cover_lower: feasibility = feasible elif proposed_pg_amount > net_realisable_pg_cover_upper: feasibility = infeasible else: feasibility = marginal if ANY boland_trigger AND ANY property used for cover: etridge_process_required = true feasibility = refer_etridge_boland (if not already infeasible) if net_realisable_pg_cover_lower < proposed_pg_amount * 0.25: feasibility = refer (largely symbolic PG) # BRIGHT LINE",
      "brightLines": [
        "Boland-triggered joint property used as PG cover → MANDATORY `refer_etridge_boland`.",
        "Spouse must receive independent legal advice BEFORE PG signing; without it the bank",
        "cannot enforce against the joint property.",
        "`net_realisable_pg_cover_lower < 25% of proposed_pg_amount` → MANDATORY REFER. PG is",
        "largely symbolic; pricing must reflect."
      ],
      "operationalRules": [
        "Property valuation expresses uncertainty — return a range, not a point estimate.",
        "Underwriter uses lower bound for conservatism.",
        "Where guarantor is divorcing/recently divorced, equity attribution is unsafe — refer",
        "for manual review.",
        "Self-occupied principal private residence: even where included in calculation, the"
      ],
      "statutoryHooks": [
        "Williams & Glyn's Bank v Boland [1981] AC 487 (overriding equitable interest)",
        "Royal Bank of Scotland v Etridge (No 2) [2001] UKHL 44 (independent legal advice)",
        "LSB Standards of Lending Practice for Business Customers (September 2025)",
        "FCA Consumer Duty",
        "Consumer Credit Act 1974 (where guarantor scope applies)"
      ],
      "workedExample": "pg_feasibility_assessment:\n  principal_id: DIR-001\n  bureau_position:\n    total_indebtedness_gbp: 12400\n    monthly_debt_service_gbp: 1850\n    unsecured_headroom_gbp: 18000\n  property_position:\n    - property_address: \"12 Strathblane Road, Milngavie, Glasgow, G62 8DJ\"\n      ownership: joint_with_spouse\n      estimated_value_gbp: 425000\n      total_registered_charges_gbp: 178000\n      net_equity_gbp: 247000\n      attributable_to_guarantor_gbp: 123500\n      boland_trigger: true\n  net_realisable_pg_cover_lower_bound_gbp: 113100\n  net_realisable_pg_cover_upper_bound_gbp: 135700\n  feasibility: refer_etridge_boland\n  etridge_process_required: true\n  reason_codes: [\"UK_PG_BOLAND_SPOUSE_OVERRIDING_INTEREST\", \"UK_PG_ETRIDGE_INDEPENDENT_LEGAL_ADVICE_REQUIRED_TO_SPOUSE\"]\n  recommendation: \"PG amount £90k is within Lachlan's £113k–£135k attributable net realisable cover, BUT joint property with non-applicant spouse Eilidh MacKenzie triggers Boland/Etridge. Proceed with PG conditional on Etridge process: spouse to receive independent legal advice from solicitor not acting for the bank, certified in writing, BEFORE drawdown.\"",
      "phaseId": "phase6",
      "phaseName": "Modelling + security",
      "subagent": "risk-modeller",
      "keyOutput": "PG capacity passes but DIR-001 property is jointly held with spouse, triggering Etridge/Boland condition before PG signing.",
      "caseStatus": "active"
    },
    {
      "id": "security-composite-agent",
      "folder": "security-composite-agent",
      "name": "security-composite-agent",
      "displayName": "Security Composite Agent",
      "description": "Compose per-security valuations into a single net recoverable position for the proposed facility. Takes outputs from floating-charge-valuation-agent, fixed-charge-valuation- agent, and personal-guarantee-feasibility-agent; applies enforcement-sequencing logic (fixed first, then PG, then floating); deducts prescribed-part carve-out only once; produces the composite recoverable value that lgd-modelling-agent consumes.",
      "logic": "Build recovery waterfall in enforcement order: 1. FIXED CHARGES (rank within asset, fastest realisation): For each per_asset_valuation in fixed_charge_valuation: add to waterfall with time_to_realise from agent cumulative_recovery += net_realisable_gbp 2. PERSONAL GUARANTEES (commenced in parallel with fixed but slower): For each guarantor in pg_feasibility_outcomes: pg_realisable = min(proposed_pg_amount_gbp, net_realisable_pg_cover_lower_bound_gbp) if etridge_process_required AND not_completed: pg_realisable *= 0.6 (Etridge non-compliance enforcement risk) add to waterfall cumulative_recovery += pg_realisable 3. FLOATING CHARGE (last in sequence, longest to realise): net_realisable_floating already reflects prescribed-part carve-out But adjust for overlap with fixed: If fixed charge over plant included in floating asset base, deduct plant from floating to avoid double-count. add to waterfall Compute expected_total_recovery as the sum, capped at EAD. Probability-weighted scenarios (conservative default): recovery_scenario_pessimistic: total × 0.70 recovery_scenario_central: total × ",
      "brightLines": [
        "Total expected recovery < 25% of EAD → flag for underwriter; security materially insufficient",
        "Composition warnings empty when overlap obvious (plant in both fixed and floating) → bug; refuse output and refer",
        "PGs counted without confirming legal feasibility (Boland/Etridge process status) → refer"
      ],
      "operationalRules": [
        "Enforcement sequencing follows UK standard waterfall (fixed → preferential → prescribed-part to unsecured → floating to charge-holder)",
        "Overlapping security MUST be deducted to avoid double-count (plant under both fixed and floating, receivables charged separately AND part of floating, etc.)",
        "Probability weights (pessimistic/central/optimistic) are policy-controlled",
        "The agent does NOT decide whether security is sufficient — that's a credit policy judgement made by decision-pricing-agent"
      ],
      "statutoryHooks": [
        "Insolvency Act 1986 (waterfall + s176A prescribed part)",
        "Enterprise Act 2002",
        "Companies Act 2006 Part 25",
        "PRA SS1/23 (LGD model inputs)",
        "IFRS 9 (recovery modelling)"
      ],
      "workedExample": "security_composite:\n  case_id: \"HE-2026-04-001\"\n  recovery_waterfall:\n    - rank: 1\n      source: fixed_charge\n      asset_or_principal_id: FX-001-equipment\n      gross_recoverable_gbp: 38475\n      cumulative_recovery_gbp: 38475\n      time_to_realise_months: 3\n    - rank: 2\n      source: personal_guarantee\n      asset_or_principal_id: DIR-002\n      gross_recoverable_gbp: 60000                 # capped at PG amount, sole property — full\n      cumulative_recovery_gbp: 98475\n      time_to_realise_months: 8\n    - rank: 3\n      source: personal_guarantee\n      asset_or_principal_id: DIR-001\n      gross_recoverable_gbp: 90000                 # Etridge completed at drawdown → full\n      cumulative_recovery_gbp: 188475\n      time_to_realise_months: 8\n    - rank: 4\n      source: floating_charge\n      asset_or_principal_id: all-asset-debenture\n      gross_recoverable_gbp: 47640                 # 80640 - 33000 plant (already counted in fixed)\n      cumulative_recovery_gbp: 236115\n      time_to_realise_months: 12\n  expected_total_recovery_gbp: 78600               # capped at EAD £78.6k\n  expected_recovery_pct_of_facility: 0.524\n  expected_recovery_pct_of_ead_avg: 1.00           # fully covered at EAD-avg\n  weighted_time_to_realise_months: 7.5\n  uncovered_exposure_gbp: 0\n  composition_warnings:\n    - \"Plant value £33k deducted from floating charge to avoid double-count with fixed charge ove",
      "phaseId": "phase6",
      "phaseName": "Modelling + security",
      "subagent": "risk-modeller",
      "keyOutput": "Recovery waterfall composes fixed charge, PGs and floating charge while avoiding double-counting the equipment.",
      "caseStatus": "active"
    },
    {
      "id": "lgd-modelling-agent",
      "folder": "lgd-modelling-agent",
      "name": "lgd-modelling-agent",
      "displayName": "Lgd Modelling Agent",
      "description": "Estimate Loss Given Default — the percentage of exposure expected to be lost if the borrower defaults. Combines security position (from charges-register), personal guarantee feasibility (from pg-feasibility), and recovery model assumptions to produce a forward-looking LGD.",
      "logic": "expected_facility_at_default = facility_amount * EAD_factor # from ead-modelling-agent expected_recovery_from_floating = (floating_charge_position_value * industry_recovery_factor) expected_recovery_from_pg = sum(pg_feasibility.net_realisable_pg_cover_lower) if NO PG: lgd_with_pg = lgd_baseline else: lgd_with_pg = max(0, (EAD - expected_recovery_from_floating - expected_recovery_from_pg) / EAD)",
      "brightLines": [
        "(no statutory bright lines for this agent)"
      ],
      "operationalRules": [
        "PG realisation is capped at the PG face value per principal",
        "Industry recovery assumptions refreshed annually based on portfolio actuals",
        "Boland-triggered PG cover: discount to lower bound × 0.6 (Etridge process risk)",
        "Cross-validate against historical portfolio LGDs in same SIC band"
      ],
      "statutoryHooks": [
        "PRA SS1/23 (model risk management)",
        "IFRS 9 (ECL calculation)",
        "Basel III/IV (capital — internal models where applicable)"
      ],
      "workedExample": "lgd_estimate:\n  case_id: \"HE-2026-04-001\"\n  lgd_baseline_pct: 0.38\n  lgd_with_pg_pct: 0.28\n  recovery_components:\n    floating_charge_realisation_gbp: 92000\n    pg_realisation_attributable_gbp: 90000   # capped at PG amount per principal\n    industry_recovery_assumption_pct: 0.61\n  model_version: \"SME_LGD_v2.1\"\n  reason_codes: [\"UK_LGD_28_PCT_WITH_PGS_IN_PLACE\"]",
      "phaseId": "phase6",
      "phaseName": "Modelling + security",
      "subagent": "risk-modeller",
      "keyOutput": "LGD estimated at 28% with personal guarantees and security package in place.",
      "caseStatus": "active"
    },
    {
      "id": "ead-modelling-agent",
      "folder": "ead-modelling-agent",
      "name": "ead-modelling-agent",
      "displayName": "Ead Modelling Agent",
      "description": "Estimate Exposure at Default. For UK term loans, this is largely deterministic — principal at drawdown amortising over term. For revolving credit or committed lines, includes credit conversion factor for undrawn portions. Term loans get a simple EAD profile.",
      "logic": "For term_loan: ead_at_completion = facility_amount (fully drawn at completion) ead_profile = annuity_amortisation_schedule(facility_amount, term, rate) ead_avg = mean(ead_profile) credit_conversion_factor = 1.0 For revolving_credit: ead = drawn_estimate + (undrawn * CCF) # CCF typically 40-75% For asset_finance / invoice_finance: agent-specific logic",
      "brightLines": [
        "(no statutory bright lines for this agent)"
      ],
      "operationalRules": [
        "Term loans: EAD profile is deterministic; no model risk in this calculation",
        "Revolving: CCF is portfolio-calibrated; updated quarterly"
      ],
      "statutoryHooks": [
        "Basel III/IV (EAD for capital)",
        "IFRS 9 (ECL inputs)"
      ],
      "workedExample": "ead_estimate:\n  case_id: \"HE-2026-04-001\"\n  ead_at_completion_gbp: 150000\n  ead_profile_over_term:\n    - month: 0\n      outstanding_gbp: 150000\n    - month: 12\n      outstanding_gbp: 124800\n    - month: 24\n      outstanding_gbp: 97200\n    - month: 36\n      outstanding_gbp: 67100\n    - month: 48\n      outstanding_gbp: 34200\n    - month: 60\n      outstanding_gbp: 0\n  ead_avg_over_term_gbp: 78600\n  credit_conversion_factor: 1.0\n  reason_codes: [\"UK_EAD_TERM_LOAN_AMORTISING_PROFILE\"]",
      "phaseId": "phase6",
      "phaseName": "Modelling + security",
      "subagent": "risk-modeller",
      "keyOutput": "Term-loan EAD profile amortises from £150k to zero over 60 months; average exposure £78.6k.",
      "caseStatus": "active"
    },
    {
      "id": "risk-rating-agent",
      "folder": "risk-rating-agent",
      "name": "risk-rating-agent",
      "displayName": "Risk Rating Agent",
      "description": "Compose PD, LGD, EAD, qualitative overlays (industry view, management quality, concentration), and bureau composite into a single portfolio risk grade. The rating drives pricing tier, policy thresholds, and capital allocation.",
      "logic": "expected_loss = pd_12m × lgd_with_pg × ead_avg_over_term base_grade = pd_score.portfolio_grade Apply qualitative adjustments: if industry_view == adverse: notch down 1 if management_quality == concerns: notch down 1 if customer_concentration_risk == high: notch down 1 composite_grade = base_grade after adjustments pricing_tier: grade A/B+: tier_1_prime grade B/C+: tier_2_standard grade C/D/E: tier_3_subprime",
      "brightLines": [
        "(no statutory bright lines for this agent)"
      ],
      "operationalRules": [
        "Qualitative overlays are bounded — max 2 notches up or down from quant baseline",
        "Pricing tier mapping is policy-level; cannot be agent-overridden",
        "Risk-adjusted return ratio < 1.0 → refer (pricing doesn't cover expected loss)"
      ],
      "statutoryHooks": [
        "PRA SS1/23",
        "Basel III/IV (capital — internal ratings)",
        "FCA Consumer Duty"
      ],
      "workedExample": "risk_rating:\n  case_id: \"HE-2026-04-001\"\n  composite_grade: B+\n  expected_loss_12m_gbp: 396                # 0.018 × 0.28 × 78,600\n  risk_adjusted_return_ratio: 1.4\n  pricing_tier: tier_1_prime\n  qualitative_adjustments_applied: []        # no notching needed\n  reason_codes: [\"UK_RISK_RATING_B_PLUS_TIER_1_PRIME\"]",
      "phaseId": "phase6",
      "phaseName": "Modelling + security",
      "subagent": "risk-modeller",
      "keyOutput": "Composite grade B+ / tier_1_prime; expected loss about £396; no qualitative notching required.",
      "caseStatus": "active"
    },
    {
      "id": "decision-pricing-agent",
      "folder": "decision-pricing-agent",
      "name": "decision-pricing-agent",
      "displayName": "Decision Pricing Agent",
      "description": "The credit decision engine. Synthesises every upstream output into an accept / refer / decline outcome with base pricing. Captures conditions raised upstream (existing charge clearance, Etridge process, equipment specification) as drawdown conditions. Generates the reason-code set for adverse-action handling if applicable.",
      "logic": "Check for any hard blockers in upstream output: - principal_aggregate.aggregate_outcome in [block_and_sar, block_pg_bearer_difficulty, block_phoenix] → decline - kyb_result.outcome == block_dissolved_or_strike_off → decline - psc_resolved_structure.outcome == eccta_non_compliance_block → decline - hmrc.outcome == decline_paye_arrears → decline - affordability.fca_compliant == false → decline Check for refer signals (cumulative): - principal_aggregate.aggregate_outcome == refer → refer - hmrc.outcome == refer_hmrc_arrears → refer - charges_register.outcome contains refer_subordination → refer if no committed clearance - bureau.composite_rating == weak → refer - risk_rating.pricing_tier == tier_3_subprime → refer (typical policy) If no blockers and no refers: outcome = accept_with_conditions (if any conditions raised) OR accept approved_amount = facility_amount approved_term = facility_term indicative_rate = base_rate(risk_rating.composite_grade) + small_adjustments Collect all conditions from upstream: - existing_floating_charge to clear → charges-register raised it - Etridge process ",
      "brightLines": [
        "Any upstream block_ outcome → AUTOMATIC DECLINE",
        "FCA-non-compliant affordability → AUTOMATIC DECLINE",
        "Reason codes are the authoritative basis for adverse-action notices",
        "Approved amount cannot exceed requested amount (cannot 'top up' against customer's interest)"
      ],
      "operationalRules": [
        "Indicative rate is base + small adjustments; sme-pricing-strategy-agent finalises pricing within commercial guardrails",
        "Conditions are immutable once decision rendered (changes require new decision cycle)",
        "Reason codes are taxonomic — drawn from a controlled vocabulary, not freeform",
        "Decline path triggers adverse-action-agent for customer notice + Bank Referral Scheme dispatch"
      ],
      "statutoryHooks": [
        "FCA Consumer Duty (4 outcomes)",
        "LSB Standards of Lending Practice for Business Customers",
        "Consumer Credit Act 1974 (where applicable — sole traders, small partnerships)",
        "UK GDPR Article 22 (automated decision-making)",
        "PRA SS1/23 (model use governance)"
      ],
      "workedExample": "credit_decision:\n  case_id: \"HE-2026-04-001\"\n  outcome: accept_with_conditions\n  approved_amount_gbp: 150000\n  approved_term_months: 60\n  indicative_rate_pct: 8.4\n  conditions:\n    - condition_id: COND-001\n      condition_text: \"Existing floating charge to First-Bank Plc (£38,000) to be released at drawdown; satisfaction letter from First-Bank Plc required.\"\n      origin_agent: charges-register-and-prior-security-agent\n      timing: at_drawdown\n    - condition_id: COND-002\n      condition_text: \"Personal guarantee from Lachlan MacKenzie (£90,000): Etridge process required — independent legal advice to spouse Eilidh MacKenzie from a solicitor not acting for the bank, certified in writing, BEFORE PG signing.\"\n      origin_agent: personal-guarantee-feasibility-agent\n      timing: pre_drawdown\n    - condition_id: COND-003\n      condition_text: \"Personal guarantee from Sarah Chen (£60,000): standard process — sole property, no Etridge requirement.\"\n      origin_agent: personal-guarantee-feasibility-agent\n      timing: pre_drawdown\n    - condition_id: COND-004\n      condition_text: \"Equipment specification (Phased Array UK Ltd quote) to be finalised before drawdown for inclusion in security schedule.\"\n      origin_agent: purpose-validation-agent\n      timing: pre_drawdown\n  reason_codes:\n    - UK_CREDIT_DECISION_ACCEPT_WITHIN_POLICY\n    - UK_PG_ETRIDGE_BOLAND_PROCESS_REQUIRED_DIR_001",
      "phaseId": "phase7",
      "phaseName": "Decision + pricing",
      "subagent": "decision-maker",
      "keyOutput": "Decision engine returns accept_with_conditions for £150k / 60 months / 8.4% indicative rate and four drawdown conditions.",
      "caseStatus": "active"
    },
    {
      "id": "sme-pricing-strategy-agent",
      "folder": "sme-pricing-strategy-agent",
      "name": "sme-pricing-strategy-agent",
      "displayName": "Sme Pricing Strategy Agent",
      "description": "Apply risk-based pricing within commercial guardrails. Takes the decision-pricing-agent's indicative rate as base and applies pricing strategy overlays: competitive positioning, broker compensation, floor/ceiling checks, fair-value verification under Consumer Duty.",
      "logic": "final_rate = indicative_rate Apply competitive adjustment: if market_position_target == match: final_rate = peer_avg_rate elif above: final_rate = max(indicative_rate, peer_avg_rate + 0.5) elif below: final_rate = min(indicative_rate, peer_avg_rate - 0.25) Floor: final_rate >= product_floor (cost of funds + margin minimum) Ceiling: final_rate <= grade_ceiling (consumer duty fair value) Arrangement fee per product policy (typically 0.5-2.0%). Broker commission per accreditation tier. Effective APR computed (BoE methodology). Fair value check: - APR vs peer benchmark - Total cost over term vs facility amount - Customer Duty 'price + value' outcome",
      "brightLines": [
        "Rate < product floor → AUTOMATIC REFER; unviable",
        "Rate > grade ceiling → fair value challenge under Consumer Duty",
        "Broker commission > 3% → escalate (commission disclosure)"
      ],
      "operationalRules": [
        "Final pricing is committee-approved policy not agent-discretionary above 0.5% deviation from indicative",
        "Broker channel pricing accounts for commission as part of customer-borne cost (transparency)",
        "Pricing reviewed monthly against market benchmark"
      ],
      "statutoryHooks": [
        "FCA Consumer Duty (price + value outcome)",
        "Financial Promotions regime (representative APR disclosure)",
        "Broker commission disclosure (LSB Standards)"
      ],
      "workedExample": "pricing_outcome:\n  case_id: \"HE-2026-04-001\"\n  final_rate_pct: 8.4\n  arrangement_fee_pct: 1.0\n  broker_commission_pct: 1.5\n  effective_apr_pct: 9.5\n  within_commercial_band: true\n  fair_value_check_passed: true\n  adjustments_applied: []\n  reason_codes: [\"UK_PRICING_TIER_1_PRIME_COMPETITIVE_MATCH\"]",
      "phaseId": "phase7",
      "phaseName": "Decision + pricing",
      "subagent": "decision-maker",
      "keyOutput": "Final rate remains 8.4%; arrangement fee 1.0%; broker commission 1.5%; effective APR 9.5%; fair-value check passes.",
      "caseStatus": "active"
    },
    {
      "id": "consumer-duty-outcomes-agent",
      "folder": "consumer-duty-outcomes-agent",
      "name": "consumer-duty-outcomes-agent",
      "displayName": "Consumer Duty Outcomes Agent",
      "description": "Cross-cutting Consumer Duty checks across the four outcomes: products + services, price + value, consumer understanding, consumer support. Runs continuously and writes a Consumer Duty audit trail to the case ledger. For business lending, the Duty applies to micro-enterprises (turnover <€2m + <10 employees).",
      "logic": "For each outcome, check against rules: products_and_services: - Product matches needs (cross-ref needs-discovery + purpose-validation) - No prohibited customer-product combinations price_and_value: - Final rate within fair value band - Total cost transparent (incl. broker commission) - No hidden fees consumer_understanding: - Key facts disclosed (rate, term, total cost, security implications) - Conditions clearly stated - Decline reasoning available (right to explanation) consumer_support: - Channel-appropriate support available - Vulnerable customer flagged → enhanced support route if all 4 outcomes pass → pass else → fail with specific outcome flagged",
      "brightLines": [
        "Fair value failure → escalate to product team; cannot proceed at quoted price",
        "Material information not disclosed pre-contract → cannot proceed"
      ],
      "operationalRules": [
        "Duty applies to micro-enterprises in business lending (FCA scope)",
        "Lender policy may extend Duty-equivalent standards to all business customers",
        "Audit trail is mandatory for FCA inspection"
      ],
      "statutoryHooks": [
        "FCA Consumer Duty (PS22/9)",
        "FCA Handbook PRIN 12 (the Duty)",
        "FCA Finalised Guidance FG22/5"
      ],
      "workedExample": "duty_check_result:\n  case_id: \"HE-2026-04-001\"\n  outcomes_checked:\n    products_and_services: pass             # term loan fits stated purpose\n    price_and_value: pass                   # 8.4% within fair value band for B+ grade\n    consumer_understanding: pass            # conditions clearly stated, decline reasons would be available\n    consumer_support: pass                  # broker channel + lender support team available\n  fair_value_check_passed: true\n  understanding_check_passed: true\n  audit_ledger_entry_id: \"CD-2026-04-12-HE-001\"\n  reason_codes: [\"UK_CONSUMER_DUTY_ALL_OUTCOMES_PASS\"]",
      "phaseId": "gov",
      "phaseName": "Governance overlays",
      "subagent": "governance-auditor",
      "keyOutput": "Products and services, price and value, understanding and support outcomes pass for the micro-enterprise case.",
      "caseStatus": "active"
    },
    {
      "id": "fairness-monitoring-agent",
      "folder": "fairness-monitoring-agent",
      "name": "fairness-monitoring-agent",
      "displayName": "Fairness Monitoring Agent",
      "description": "Monitor decision outcomes for fairness across protected attribute proxies (region, deprivation index, SIC code where it correlates with protected attributes). Returns demographic parity statistics, drift indicators, and any breach signals. Operates per-case (current decision vs portfolio baseline) and aggregate (rolling portfolio statistics).",
      "logic": "Compare this case's outcome distribution against portfolio baseline. Compute demographic parity delta on each protected attribute proxy. Tolerance thresholds (configurable): - region parity delta <= 0.05 (5%) - deprivation parity delta <= 0.05 - sic parity delta <= 0.05 if any delta > tolerance: drift_indicator = true Rolling alerts: - Sustained drift >4 weeks → alert + reportable under AI Directive 2024 - Single case in extreme outlier → flag for manual review",
      "brightLines": [
        "Sustained breach >4 weeks → MUST notify FCA + reportable under (where applicable) AI Algorithmic Directive"
      ],
      "operationalRules": [
        "Protected attribute proxies, not protected attributes themselves (cannot collect race/ethnicity for credit)",
        "Baseline refreshed quarterly",
        "Per-case alerts are advisory; portfolio alerts are mandatory action"
      ],
      "statutoryHooks": [
        "Equality Act 2010 (indirect discrimination via correlated attributes)",
        "FCA Consumer Duty",
        "EU AI Act (high-risk classification — credit scoring) where applicable",
        "PRA SS1/23"
      ],
      "workedExample": "fairness_check_result:\n  case_id: \"HE-2026-04-001\"\n  this_case_in_distribution: true\n  demographic_parity_delta: 0.03\n  drift_indicators:\n    region_drift: false\n    deprivation_drift: false\n    sic_drift: false\n  within_tolerance: true\n  alert_required: false\n  audit_ledger_entry_id: \"FM-2026-04-12-HE-001\"\n  reason_codes: [\"UK_FAIRNESS_WITHIN_TOLERANCE\"]",
      "phaseId": "gov",
      "phaseName": "Governance overlays",
      "subagent": "governance-auditor",
      "keyOutput": "Case sits within portfolio baseline tolerance; no region, deprivation or SIC drift alert required.",
      "caseStatus": "active"
    },
    {
      "id": "vulnerable-customer-agent",
      "folder": "vulnerable-customer-agent",
      "name": "vulnerable-customer-agent",
      "displayName": "Vulnerable Customer Agent",
      "description": "Detect indicators of customer vulnerability — financial, health, life events, capability — and flag for enhanced support. For SME lending the principals can be vulnerable even where the company is not. Sole traders are particularly in scope.",
      "logic": "For each principal: Check bureau signals (recent defaults, multiple applications, etc.) Check application signals (life events in stated purpose, contact patterns) Check declared vulnerabilities Sole traders + micro-businesses: principals' personal vulnerability is materially relevant. If any flag at medium/high severity: enhanced_support_required = true.",
      "brightLines": [
        "(no statutory bright lines for this agent)"
      ],
      "operationalRules": [
        "Vulnerability is a sensitive attribute — handle in line with DPA 2018 + FCA guidance",
        "Treatment markers are advisory to channel staff, not blocking",
        "Declared vulnerabilities are first-class — never override applicant's own statement"
      ],
      "statutoryHooks": [
        "FCA FG21/1 (Vulnerable Customers)",
        "FCA Consumer Duty",
        "Equality Act 2010 (disability)",
        "UK GDPR (special category data — health)"
      ],
      "workedExample": "vulnerability_assessment:\n  case_id: \"HE-2026-04-001\"\n  vulnerability_flags: []\n  enhanced_support_required: false\n  audit_ledger_entry_id: \"VC-2026-04-12-HE-001\"\n  reason_codes: [\"UK_VULNERABILITY_NO_FLAGS_STANDARD_HANDLING\"]",
      "phaseId": "gov",
      "phaseName": "Governance overlays",
      "subagent": "governance-auditor",
      "keyOutput": "No vulnerability indicators detected for either principal; standard handling is appropriate.",
      "caseStatus": "active"
    },
    {
      "id": "model-inventory-agent",
      "folder": "model-inventory-agent",
      "name": "model-inventory-agent",
      "displayName": "Model Inventory Agent",
      "description": "Register every model invocation in the case — version, calibration date, input features, output, confidence. Satisfies PRA SS1/23 model use governance and (where applicable) the Joint BoI/ISA AI Algorithmic Directive for high-impact use cases. Writes to the case audit trail.",
      "logic": "Record metadata for every model invocation: - PD scoring model - LGD model - Identity verification model (biometric) - Application fraud model - Fairness monitoring baseline - AML screening engine Classify against SS1/23: - Models with material customer impact → high_impact - Models supporting decisioning → medium_impact - Operational models → low_impact Append to case-level model inventory. At decision rendering, the inventory is attached to the case as audit evidence.",
      "brightLines": [
        "(no statutory bright lines for this agent)"
      ],
      "operationalRules": [
        "Every model invocation is recorded — no silent inference",
        "Model versions are immutable once deployed; updates trigger new inventory entries",
        "Inventory survives the case (retained 7-25 years depending on facility class)",
        "Joint BoI/ISA AI Algorithmic Directive material change triggers re-registration"
      ],
      "statutoryHooks": [
        "PRA SS1/23 (Model Risk Management)",
        "Joint BoI/ISA AI Algorithmic Directive 2024 (where applicable)",
        "EU AI Act (high-risk model inventory)",
        "FCA Consumer Duty (explainable models)"
      ],
      "workedExample": "model_inventory_entry:\n  case_id: \"HE-2026-04-001\"\n  inventory_record_id: \"MI-2026-04-12-HE-001-006\"\n  model_id: SME_TermLoan_PD\n  model_version: v4.2\n  governance_classification: high_impact\n  ss1_23_classification: ai_use_case\n  audit_ledger_entry_id: \"MI-LEDGER-001\"\n  reason_codes: [\"UK_MODEL_INVENTORIED_HIGH_IMPACT_AI_USE_CASE\"]",
      "phaseId": "gov",
      "phaseName": "Governance overlays",
      "subagent": "governance-auditor",
      "keyOutput": "Model inventory entry records PD, LGD, EAD, affordability, risk-rating and pricing model usage for audit.",
      "caseStatus": "active"
    },
    {
      "id": "adverse-action-agent",
      "folder": "adverse-action-agent",
      "name": "adverse-action-agent",
      "displayName": "Adverse Action Agent",
      "description": "Generate decline / refer reason codes in both regulatory taxonomy and customer-facing language. Triggered when decision-pricing-agent renders a decline or refer outcome. Ensures the right-to-explanation under UK GDPR Article 22 is fulfilled and the LSB-compliant decline notice is prepared.",
      "logic": "For each regulatory reason_code: Look up canonical customer-facing translation. Compose decline letter: - Outcome statement (clear, plain English) - Reasons (top 3-5, prioritised by materiality) - Right to explanation + request channel - Appeal route - Bank Referral Scheme notice if applicable - Vulnerability-aware language adjustments Set bank_referral_scheme_eligibility based on lender designation + outcome.",
      "brightLines": [
        "Tipping-off cases: decline letter must NOT reveal underlying suspicion",
        "Customer-facing reasons cannot be more specific than regulatory codes allow"
      ],
      "operationalRules": [
        "Plain English required (Flesch Reading Ease >= 60)",
        "Reasons prioritised by materiality, not first-discovered",
        "Vulnerability-aware language for flagged principals",
        "Appeal route must be a real working channel, not a black hole"
      ],
      "statutoryHooks": [
        "UK GDPR Article 22 (right to explanation for automated decisions)",
        "FCA Consumer Duty (consumer understanding outcome)",
        "LSB Standards of Lending Practice for Business Customers",
        "SBEE Act 2015 (Bank Referral Scheme on decline)"
      ],
      "workedExample": "(not triggered for Highland — accept outcome.\nExample shape for a hypothetical decline:\n\nadverse_action_output:\n  case_id: \"HE-2026-04-001\"\n  customer_facing_decline_letter_text: \"...\"\n  reason_codes_customer:\n    - \"Your business's recent trading performance does not currently meet our affordability requirements.\"\n    - \"There is an existing charge on the company that would need to be released before we could provide new funding.\"\n  right_to_explanation_text: \"...\"\n  appeal_route_text: \"...\"\n  bank_referral_scheme_eligibility: true)",
      "phaseId": "gov",
      "phaseName": "Governance overlays",
      "subagent": "governance-auditor",
      "keyOutput": "Conditional branch shown for governance completeness. Not triggered because Highland is accepted with conditions.",
      "caseStatus": "conditional"
    }
  ],
  "steps": [
    {
      "title": "ezbob SME Credit Decision Command Centre",
      "caption": "Updated internal demo: a lender operations UI captures a tiny set of applicant fields, calls Companies House for the company profile, then lets the synthetic Highland Engineering journey continue through offer.",
      "phaseId": "front",
      "highlightSkills": [],
      "mode": "REPLAY + LIVE CONNECTOR",
      "body": "Synthetic case: Highland Engineering Consultants Ltd requests a £150,000, 60-month UK SME term loan. The new front-end seed is deliberately small: company number plus primary applicant identity details.",
      "view": "hero",
      "metricFocus": "",
      "duration": 5.0,
      "step": 0
    },
    {
      "title": "Two execution modes",
      "caption": "Replay mode is deterministic and video-safe. Live mode now includes a Companies House connector boundary that can pull public company profile data when an API key is configured.",
      "phaseId": "front",
      "highlightSkills": [],
      "mode": "REPLAY + LIVE",
      "body": "Replay uses attached YAML/markdown and a mocked Companies House response. Live mode routes through the Node API adapter; API credentials stay server-side.",
      "view": "architecture",
      "metricFocus": "",
      "duration": 5.0,
      "step": 1
    },
    {
      "title": "One-page UI seed data",
      "caption": "This screen uses only the data entered in the UI: company registration number, applicant name, applicant residential address and applicant date of birth. The rest of the case remains synthetic replay data for now.",
      "phaseId": "front",
      "highlightSkills": [],
      "mode": "UI SEED",
      "body": "The one-page intake form does not load the full profile file. It creates a small seed payload used to start the case and call Companies House.",
      "view": "uiSeed",
      "metricFocus": "",
      "duration": 5.0,
      "step": 2
    },
    {
      "title": "Companies House profile lookup",
      "caption": "The Node adapter calls Companies House using GET /company/{companyNumber}. In this recording the response is replayed; in live mode the same endpoint pulls public company data with server-side Basic authentication.",
      "phaseId": "front",
      "highlightSkills": [],
      "mode": "LIVE CONNECTOR + REPLAY FALLBACK",
      "body": "The company number from the UI becomes the path parameter. The returned company profile populates legal name, status, registered office, jurisdiction, SIC codes and links for officers, PSCs and charges.",
      "view": "companiesHouse",
      "metricFocus": "",
      "duration": 6.0,
      "step": 3
    },
    {
      "title": "Mapped workflow hand-off",
      "caption": "The UI seed and Companies House profile become ledger artefacts. After that point, the remaining credit journey runs exactly as before until offer.",
      "phaseId": "front",
      "highlightSkills": [],
      "mode": "REPLAY",
      "body": "UI seed payload plus Companies House profile are written before intake. Facility data, financial data, security values, bureau outputs and final offer are still the synthetic Highland profile.",
      "view": "workflowHandoff",
      "metricFocus": "",
      "duration": 5.0,
      "step": 4
    },
    {
      "step": 5,
      "title": "Workflow map: UI → orchestration → skills → ledger",
      "caption": "The app maps the front-end seed, Companies House enrichment, backend orchestration and all specialist skills that write structured JSON to the case ledger.",
      "phaseId": "front",
      "highlightSkills": [],
      "mode": "REPLAY",
      "body": "The ledger pattern is deliberately boring and reliable: UI seed and Companies House profile first, then each phase produces a named JSON artifact for audit and replay.",
      "view": "architecture",
      "metricFocus": "",
      "duration": 4.5
    },
    {
      "step": 6,
      "title": "Phase 1 — Intake",
      "caption": "intake-coordinator takes control. Open the ledger, normalise the application and run policy-fit pre-screening.",
      "phaseId": "phase1",
      "highlightSkills": [],
      "mode": "REPLAY",
      "body": "Output target: phase_1_intake.json | Skills in scope: 3",
      "view": "phaseIntro",
      "metricFocus": "",
      "duration": 3.5
    },
    {
      "step": 7,
      "title": "Customer Onboarding Orchestrator",
      "caption": "customer-onboarding-orchestrator runs under intake-coordinator. Case ledger opened as HE-2026-04-001; broker channel accepted; audit ledger initialised; next phase unlocked.",
      "phaseId": "phase1",
      "highlightSkills": [
        "customer-onboarding-orchestrator"
      ],
      "mode": "REPLAY",
      "body": "Case ledger opened as HE-2026-04-001; broker channel accepted; audit ledger initialised; next phase unlocked.",
      "view": "skill",
      "metricFocus": "customer-onboarding-orchestrator",
      "duration": 3.2
    },
    {
      "step": 8,
      "title": "Data Capture Agent",
      "caption": "data-capture-agent runs under intake-coordinator. Raw broker payload normalised into canonical case object: company, facility, contact, purpose, broker, consent-ready data fields.",
      "phaseId": "phase1",
      "highlightSkills": [
        "data-capture-agent"
      ],
      "mode": "REPLAY",
      "body": "Raw broker payload normalised into canonical case object: company, facility, contact, purpose, broker, consent-ready data fields.",
      "view": "skill",
      "metricFocus": "data-capture-agent",
      "duration": 3.2
    },
    {
      "step": 9,
      "title": "Lead Qualification Agent",
      "caption": "lead-qualification-agent runs under intake-coordinator. Policy-fit pass for UK term loan v3: £150,000 / 60 months / eligible engineering consultancy / accredited broker.",
      "phaseId": "phase1",
      "highlightSkills": [
        "lead-qualification-agent"
      ],
      "mode": "REPLAY",
      "body": "Policy-fit pass for UK term loan v3: £150,000 / 60 months / eligible engineering consultancy / accredited broker.",
      "view": "skill",
      "metricFocus": "lead-qualification-agent",
      "duration": 3.2
    },
    {
      "step": 10,
      "title": "Phase 2 — Consent + Purpose",
      "caption": "consent-purpose-coordinator takes control. Capture scoped consents and validate the declared borrowing purpose.",
      "phaseId": "phase2",
      "highlightSkills": [],
      "mode": "REPLAY",
      "body": "Output target: phase_2_consent_purpose.json | Skills in scope: 3",
      "view": "phaseIntro",
      "metricFocus": "",
      "duration": 3.5
    },
    {
      "step": 11,
      "title": "Consent Management Agent",
      "caption": "consent-management-agent runs under consent-purpose-coordinator. Scoped consent bundle issued for commercial bureau, consumer bureau, Open Banking, HMRC VAT/PAYE/CT, and Land Registry.",
      "phaseId": "phase2",
      "highlightSkills": [
        "consent-management-agent"
      ],
      "mode": "REPLAY",
      "body": "Scoped consent bundle issued for commercial bureau, consumer bureau, Open Banking, HMRC VAT/PAYE/CT, and Land Registry.",
      "view": "skill",
      "metricFocus": "consent-management-agent",
      "duration": 3.2
    },
    {
      "step": 12,
      "title": "Needs Discovery Agent",
      "caption": "needs-discovery-agent runs under consent-purpose-coordinator. Needs profile confirms capital expenditure term loan is well fitted; dependencies are equipment delivery and lease completion.",
      "phaseId": "phase2",
      "highlightSkills": [
        "needs-discovery-agent"
      ],
      "mode": "REPLAY",
      "body": "Needs profile confirms capital expenditure term loan is well fitted; dependencies are equipment delivery and lease completion.",
      "view": "skill",
      "metricFocus": "needs-discovery-agent",
      "duration": 3.2
    },
    {
      "step": 13,
      "title": "Purpose Validation Agent",
      "caption": "purpose-validation-agent runs under consent-purpose-coordinator. Purpose validated as capex for premises and equipment. No prohibited use or purpose drift detected.",
      "phaseId": "phase2",
      "highlightSkills": [
        "purpose-validation-agent"
      ],
      "mode": "REPLAY",
      "body": "Purpose validated as capex for premises and equipment. No prohibited use or purpose drift detected.",
      "view": "skill",
      "metricFocus": "purpose-validation-agent",
      "duration": 3.2
    },
    {
      "step": 14,
      "title": "Phase 3 — KYB + PSC",
      "caption": "kyb-psc-coordinator takes control. Verify the company and resolve PSC / beneficial ownership structure.",
      "phaseId": "phase3",
      "highlightSkills": [],
      "mode": "REPLAY",
      "body": "Output target: phase_3_kyb_psc.json | Skills in scope: 3",
      "view": "phaseIntro",
      "metricFocus": "",
      "duration": 3.5
    },
    {
      "step": 15,
      "title": "Kyb Verifier",
      "caption": "kyb-verifier runs under kyb-psc-coordinator. Companies House-style KYB returns active company, 102 months trading, current accounts and confirmation statement.",
      "phaseId": "phase3",
      "highlightSkills": [
        "kyb-verifier"
      ],
      "mode": "REPLAY",
      "body": "Companies House-style KYB returns active company, 102 months trading, current accounts and confirmation statement.",
      "view": "skill",
      "metricFocus": "kyb-verifier",
      "duration": 3.2
    },
    {
      "step": 16,
      "title": "Ubo Mapper",
      "caption": "ubo-mapper runs under kyb-psc-coordinator. PSC chain mapped directly to two natural persons: Lachlan MacKenzie and Sarah Chen. No complex structure recursion needed.",
      "phaseId": "phase3",
      "highlightSkills": [
        "ubo-mapper"
      ],
      "mode": "REPLAY",
      "body": "PSC chain mapped directly to two natural persons: Lachlan MacKenzie and Sarah Chen. No complex structure recursion needed.",
      "view": "skill",
      "metricFocus": "ubo-mapper",
      "duration": 3.2
    },
    {
      "step": 17,
      "title": "Psc Complex Structure Recursor",
      "caption": "psc-complex-structure-recursor runs under kyb-psc-coordinator. This conditional branch is shown but skipped for Highland because the PSCs are direct natural persons. Conditional control shown for completeness. Highland has no corporate, trust, or overseas PSC, so recursion is bypassed.",
      "phaseId": "phase3",
      "highlightSkills": [
        "psc-complex-structure-recursor"
      ],
      "mode": "REPLAY",
      "body": "Conditional control shown for completeness. Highland has no corporate, trust, or overseas PSC, so recursion is bypassed.",
      "view": "skill",
      "metricFocus": "psc-complex-structure-recursor",
      "duration": 3.2
    },
    {
      "step": 18,
      "title": "Phase 4 — Per-principal verification",
      "caption": "principal-verifier × 2 parallel lanes takes control. Run identity, AML, fraud, financial difficulty and cross-directorship checks per principal.",
      "phaseId": "phase4",
      "highlightSkills": [],
      "mode": "REPLAY",
      "body": "Output target: phase_4_per_principal.json | Skills in scope: 6",
      "view": "phaseIntro",
      "metricFocus": "",
      "duration": 3.5
    },
    {
      "step": 19,
      "title": "Multi Principal Fan Out Orchestrator",
      "caption": "multi-principal-fan-out-orchestrator runs under principal-verifier × 2 parallel lanes. This is parent orchestration logic: it launches the two principal lanes concurrently and reconciles their outputs. Parent orchestration fans out two principal verification lanes in parallel and aggregates results into phase_4_per_principal.json.",
      "phaseId": "phase4",
      "highlightSkills": [
        "multi-principal-fan-out-orchestrator"
      ],
      "mode": "REPLAY",
      "body": "Parent orchestration fans out two principal verification lanes in parallel and aggregates results into phase_4_per_principal.json.",
      "view": "skill",
      "metricFocus": "multi-principal-fan-out-orchestrator",
      "duration": 3.2
    },
    {
      "step": 20,
      "title": "Identity Orchestration Agent",
      "caption": "identity-orchestration-agent runs under principal-verifier × 2 parallel lanes. DIR-001 verified at 0.97 confidence; DIR-002 verified at 0.98 confidence using document, biometric, and database checks.",
      "phaseId": "phase4",
      "highlightSkills": [
        "identity-orchestration-agent"
      ],
      "mode": "REPLAY",
      "body": "DIR-001 verified at 0.97 confidence; DIR-002 verified at 0.98 confidence using document, biometric, and database checks.",
      "view": "skill",
      "metricFocus": "identity-orchestration-agent",
      "duration": 3.2
    },
    {
      "step": 21,
      "title": "Aml Screening Agent",
      "caption": "aml-screening-agent runs under principal-verifier × 2 parallel lanes. Sanctions, PEP and adverse media screening clear for both principals.",
      "phaseId": "phase4",
      "highlightSkills": [
        "aml-screening-agent"
      ],
      "mode": "REPLAY",
      "body": "Sanctions, PEP and adverse media screening clear for both principals.",
      "view": "skill",
      "metricFocus": "aml-screening-agent",
      "duration": 3.2
    },
    {
      "step": 22,
      "title": "Application Fraud Agent",
      "caption": "application-fraud-agent runs under principal-verifier × 2 parallel lanes. Low fraud scores: Lachlan 12/100, Sarah 8/100. No CIFAS, velocity, device or synthetic identity red flags.",
      "phaseId": "phase4",
      "highlightSkills": [
        "application-fraud-agent"
      ],
      "mode": "REPLAY",
      "body": "Low fraud scores: Lachlan 12/100, Sarah 8/100. No CIFAS, velocity, device or synthetic identity red flags.",
      "view": "skill",
      "metricFocus": "application-fraud-agent",
      "duration": 3.2
    },
    {
      "step": 23,
      "title": "Director Financial Difficulty Checker",
      "caption": "director-financial-difficulty-checker runs under principal-verifier × 2 parallel lanes. No current insolvency, IVA, DRO or unsatisfied CCJs. Lachlan has one historic satisfied CCJ, not a blocker.",
      "phaseId": "phase4",
      "highlightSkills": [
        "director-financial-difficulty-checker"
      ],
      "mode": "REPLAY",
      "body": "No current insolvency, IVA, DRO or unsatisfied CCJs. Lachlan has one historic satisfied CCJ, not a blocker.",
      "view": "skill",
      "metricFocus": "director-financial-difficulty-checker",
      "duration": 3.2
    },
    {
      "step": 24,
      "title": "Director Cross Directorship Checker",
      "caption": "director-cross-directorship-checker runs under principal-verifier × 2 parallel lanes. No phoenix pattern or dissolved-company concern. Sarah has one dormant family company; classification remains clean.",
      "phaseId": "phase4",
      "highlightSkills": [
        "director-cross-directorship-checker"
      ],
      "mode": "REPLAY",
      "body": "No phoenix pattern or dissolved-company concern. Sarah has one dormant family company; classification remains clean.",
      "view": "skill",
      "metricFocus": "director-cross-directorship-checker",
      "duration": 3.2
    },
    {
      "step": 25,
      "title": "Phase 5 — Credit data assembly",
      "caption": "credit-data-assembler takes control. Assemble bureau, Open Banking, HMRC, alternative data and charges register information.",
      "phaseId": "phase5",
      "highlightSkills": [],
      "mode": "REPLAY",
      "body": "Output target: phase_5_credit_data.json | Skills in scope: 5",
      "view": "phaseIntro",
      "metricFocus": "",
      "duration": 3.5
    },
    {
      "step": 26,
      "title": "Bureau Orchestration Agent",
      "caption": "bureau-orchestration-agent runs under credit-data-assembler. Commercial bureaux consolidate to a solid SME picture: Experian Delphi 78, Equifax B+, CreditSafe 72.",
      "phaseId": "phase5",
      "highlightSkills": [
        "bureau-orchestration-agent"
      ],
      "mode": "REPLAY",
      "body": "Commercial bureaux consolidate to a solid SME picture: Experian Delphi 78, Equifax B+, CreditSafe 72.",
      "view": "skill",
      "metricFocus": "bureau-orchestration-agent",
      "duration": 3.2
    },
    {
      "step": 27,
      "title": "Open Banking Agent",
      "caption": "open-banking-agent runs under credit-data-assembler. Open Banking shows £847k trailing credits, £38.4k average monthly balance, low volatility, one returned payment, no overdraft excursion.",
      "phaseId": "phase5",
      "highlightSkills": [
        "open-banking-agent"
      ],
      "mode": "REPLAY",
      "body": "Open Banking shows £847k trailing credits, £38.4k average monthly balance, low volatility, one returned payment, no overdraft excursion.",
      "view": "skill",
      "metricFocus": "open-banking-agent",
      "duration": 3.2
    },
    {
      "step": 28,
      "title": "Hmrc Direct Verification Agent",
      "caption": "hmrc-direct-verification-agent runs under credit-data-assembler. HMRC-style data verifies VAT turnover £851.3k, 11.2% YoY growth, 6 employees, PAYE clean, corporation tax paid.",
      "phaseId": "phase5",
      "highlightSkills": [
        "hmrc-direct-verification-agent"
      ],
      "mode": "REPLAY",
      "body": "HMRC-style data verifies VAT turnover £851.3k, 11.2% YoY growth, 6 employees, PAYE clean, corporation tax paid.",
      "view": "skill",
      "metricFocus": "hmrc-direct-verification-agent",
      "duration": 3.2
    },
    {
      "step": 29,
      "title": "Alternative Data Agent",
      "caption": "alternative-data-agent runs under credit-data-assembler. Xero-style management data corroborates the case: £854.1k revenue, 41.2% gross margin, low overdue payables.",
      "phaseId": "phase5",
      "highlightSkills": [
        "alternative-data-agent"
      ],
      "mode": "REPLAY",
      "body": "Xero-style management data corroborates the case: £854.1k revenue, 41.2% gross margin, low overdue payables.",
      "view": "skill",
      "metricFocus": "alternative-data-agent",
      "duration": 3.2
    },
    {
      "step": 30,
      "title": "Charges Register And Prior Security Agent",
      "caption": "charges-register-and-prior-security-agent runs under credit-data-assembler. Existing First-Bank floating charge of £38k identified; to be cleared at drawdown with satisfaction letter required.",
      "phaseId": "phase5",
      "highlightSkills": [
        "charges-register-and-prior-security-agent"
      ],
      "mode": "REPLAY",
      "body": "Existing First-Bank floating charge of £38k identified; to be cleared at drawdown with satisfaction letter required.",
      "view": "skill",
      "metricFocus": "charges-register-and-prior-security-agent",
      "duration": 3.2
    },
    {
      "step": 31,
      "title": "Phase 6 — Modelling + security",
      "caption": "risk-modeller takes control. Run affordability, PD, security valuation, PG feasibility, LGD, EAD and risk rating.",
      "phaseId": "phase6",
      "highlightSkills": [],
      "mode": "REPLAY",
      "body": "Output target: phase_6_modelling.json | Skills in scope: 9",
      "view": "phaseIntro",
      "metricFocus": "",
      "duration": 3.5
    },
    {
      "step": 32,
      "title": "Affordability Agent",
      "caption": "affordability-agent runs under risk-modeller. Affordability passes: monthly repayment about £3,070; free cash flow £74.4k; DSCR 2.02x; stress test passes.",
      "phaseId": "phase6",
      "highlightSkills": [
        "affordability-agent"
      ],
      "mode": "REPLAY",
      "body": "Affordability passes: monthly repayment about £3,070; free cash flow £74.4k; DSCR 2.02x; stress test passes.",
      "view": "skill",
      "metricFocus": "affordability-agent",
      "duration": 3.2
    },
    {
      "step": 33,
      "title": "Pd Scoring Agent",
      "caption": "pd-scoring-agent runs under risk-modeller. 12-month PD estimated at 1.8%, portfolio grade B+, with consistent bureau/HMRC/OB evidence.",
      "phaseId": "phase6",
      "highlightSkills": [
        "pd-scoring-agent"
      ],
      "mode": "REPLAY",
      "body": "12-month PD estimated at 1.8%, portfolio grade B+, with consistent bureau/HMRC/OB evidence.",
      "view": "skill",
      "metricFocus": "pd-scoring-agent",
      "duration": 3.2
    },
    {
      "step": 34,
      "title": "Floating Charge Valuation Agent",
      "caption": "floating-charge-valuation-agent runs under risk-modeller. Floating charge asset base valued after haircuts and s176A-style prescribed-part carve-out; net contribution feeds security composite.",
      "phaseId": "phase6",
      "highlightSkills": [
        "floating-charge-valuation-agent"
      ],
      "mode": "REPLAY",
      "body": "Floating charge asset base valued after haircuts and s176A-style prescribed-part carve-out; net contribution feeds security composite.",
      "view": "skill",
      "metricFocus": "floating-charge-valuation-agent",
      "duration": 3.2
    },
    {
      "step": 35,
      "title": "Fixed Charge Valuation Agent",
      "caption": "fixed-charge-valuation-agent runs under risk-modeller. Specialist equipment valued: £60k declared value, £38.5k net realisable forced-sale estimate.",
      "phaseId": "phase6",
      "highlightSkills": [
        "fixed-charge-valuation-agent"
      ],
      "mode": "REPLAY",
      "body": "Specialist equipment valued: £60k declared value, £38.5k net realisable forced-sale estimate.",
      "view": "skill",
      "metricFocus": "fixed-charge-valuation-agent",
      "duration": 3.2
    },
    {
      "step": 36,
      "title": "Personal Guarantee Feasibility Agent",
      "caption": "personal-guarantee-feasibility-agent runs under risk-modeller. PG capacity passes but DIR-001 property is jointly held with spouse, triggering Etridge/Boland condition before PG signing.",
      "phaseId": "phase6",
      "highlightSkills": [
        "personal-guarantee-feasibility-agent"
      ],
      "mode": "REPLAY",
      "body": "PG capacity passes but DIR-001 property is jointly held with spouse, triggering Etridge/Boland condition before PG signing.",
      "view": "skill",
      "metricFocus": "personal-guarantee-feasibility-agent",
      "duration": 3.2
    },
    {
      "step": 37,
      "title": "Security Composite Agent",
      "caption": "security-composite-agent runs under risk-modeller. Recovery waterfall composes fixed charge, PGs and floating charge while avoiding double-counting the equipment.",
      "phaseId": "phase6",
      "highlightSkills": [
        "security-composite-agent"
      ],
      "mode": "REPLAY",
      "body": "Recovery waterfall composes fixed charge, PGs and floating charge while avoiding double-counting the equipment.",
      "view": "skill",
      "metricFocus": "security-composite-agent",
      "duration": 3.2
    },
    {
      "step": 38,
      "title": "Lgd Modelling Agent",
      "caption": "lgd-modelling-agent runs under risk-modeller. LGD estimated at 28% with personal guarantees and security package in place.",
      "phaseId": "phase6",
      "highlightSkills": [
        "lgd-modelling-agent"
      ],
      "mode": "REPLAY",
      "body": "LGD estimated at 28% with personal guarantees and security package in place.",
      "view": "skill",
      "metricFocus": "lgd-modelling-agent",
      "duration": 3.2
    },
    {
      "step": 39,
      "title": "Ead Modelling Agent",
      "caption": "ead-modelling-agent runs under risk-modeller. Term-loan EAD profile amortises from £150k to zero over 60 months; average exposure £78.6k.",
      "phaseId": "phase6",
      "highlightSkills": [
        "ead-modelling-agent"
      ],
      "mode": "REPLAY",
      "body": "Term-loan EAD profile amortises from £150k to zero over 60 months; average exposure £78.6k.",
      "view": "skill",
      "metricFocus": "ead-modelling-agent",
      "duration": 3.2
    },
    {
      "step": 40,
      "title": "Risk Rating Agent",
      "caption": "risk-rating-agent runs under risk-modeller. Composite grade B+ / tier_1_prime; expected loss about £396; no qualitative notching required.",
      "phaseId": "phase6",
      "highlightSkills": [
        "risk-rating-agent"
      ],
      "mode": "REPLAY",
      "body": "Composite grade B+ / tier_1_prime; expected loss about £396; no qualitative notching required.",
      "view": "skill",
      "metricFocus": "risk-rating-agent",
      "duration": 3.2
    },
    {
      "step": 41,
      "title": "Phase 7 — Decision + pricing",
      "caption": "decision-maker takes control. Synthesize upstream evidence into decision, pricing and drawdown conditions.",
      "phaseId": "phase7",
      "highlightSkills": [],
      "mode": "REPLAY",
      "body": "Output target: phase_7_decision.json | Skills in scope: 2",
      "view": "phaseIntro",
      "metricFocus": "",
      "duration": 3.5
    },
    {
      "step": 42,
      "title": "Decision Pricing Agent",
      "caption": "decision-pricing-agent runs under decision-maker. Decision engine returns accept_with_conditions for £150k / 60 months / 8.4% indicative rate and four drawdown conditions.",
      "phaseId": "phase7",
      "highlightSkills": [
        "decision-pricing-agent"
      ],
      "mode": "REPLAY",
      "body": "Decision engine returns accept_with_conditions for £150k / 60 months / 8.4% indicative rate and four drawdown conditions.",
      "view": "skill",
      "metricFocus": "decision-pricing-agent",
      "duration": 3.2
    },
    {
      "step": 43,
      "title": "Sme Pricing Strategy Agent",
      "caption": "sme-pricing-strategy-agent runs under decision-maker. Final rate remains 8.4%; arrangement fee 1.0%; broker commission 1.5%; effective APR 9.5%; fair-value check passes.",
      "phaseId": "phase7",
      "highlightSkills": [
        "sme-pricing-strategy-agent"
      ],
      "mode": "REPLAY",
      "body": "Final rate remains 8.4%; arrangement fee 1.0%; broker commission 1.5%; effective APR 9.5%; fair-value check passes.",
      "view": "skill",
      "metricFocus": "sme-pricing-strategy-agent",
      "duration": 3.2
    },
    {
      "step": 44,
      "title": "Phase G — Governance overlays",
      "caption": "governance-auditor takes control. Attach Consumer Duty, fairness, vulnerability, model inventory and adverse-action governance overlays.",
      "phaseId": "gov",
      "highlightSkills": [],
      "mode": "REPLAY",
      "body": "Output target: governance_overlays.json | Skills in scope: 5",
      "view": "phaseIntro",
      "metricFocus": "",
      "duration": 3.5
    },
    {
      "step": 45,
      "title": "Consumer Duty Outcomes Agent",
      "caption": "consumer-duty-outcomes-agent runs under governance-auditor. Products and services, price and value, understanding and support outcomes pass for the micro-enterprise case.",
      "phaseId": "gov",
      "highlightSkills": [
        "consumer-duty-outcomes-agent"
      ],
      "mode": "REPLAY",
      "body": "Products and services, price and value, understanding and support outcomes pass for the micro-enterprise case.",
      "view": "skill",
      "metricFocus": "consumer-duty-outcomes-agent",
      "duration": 3.2
    },
    {
      "step": 46,
      "title": "Fairness Monitoring Agent",
      "caption": "fairness-monitoring-agent runs under governance-auditor. Case sits within portfolio baseline tolerance; no region, deprivation or SIC drift alert required.",
      "phaseId": "gov",
      "highlightSkills": [
        "fairness-monitoring-agent"
      ],
      "mode": "REPLAY",
      "body": "Case sits within portfolio baseline tolerance; no region, deprivation or SIC drift alert required.",
      "view": "skill",
      "metricFocus": "fairness-monitoring-agent",
      "duration": 3.2
    },
    {
      "step": 47,
      "title": "Vulnerable Customer Agent",
      "caption": "vulnerable-customer-agent runs under governance-auditor. No vulnerability indicators detected for either principal; standard handling is appropriate.",
      "phaseId": "gov",
      "highlightSkills": [
        "vulnerable-customer-agent"
      ],
      "mode": "REPLAY",
      "body": "No vulnerability indicators detected for either principal; standard handling is appropriate.",
      "view": "skill",
      "metricFocus": "vulnerable-customer-agent",
      "duration": 3.2
    },
    {
      "step": 48,
      "title": "Model Inventory Agent",
      "caption": "model-inventory-agent runs under governance-auditor. Model inventory entry records PD, LGD, EAD, affordability, risk-rating and pricing model usage for audit.",
      "phaseId": "gov",
      "highlightSkills": [
        "model-inventory-agent"
      ],
      "mode": "REPLAY",
      "body": "Model inventory entry records PD, LGD, EAD, affordability, risk-rating and pricing model usage for audit.",
      "view": "skill",
      "metricFocus": "model-inventory-agent",
      "duration": 3.2
    },
    {
      "step": 49,
      "title": "Adverse Action Agent",
      "caption": "adverse-action-agent runs under governance-auditor. This conditional branch is shown but not triggered because the case is accepted with conditions. Conditional branch shown for governance completeness. Not triggered because Highland is accepted with conditions.",
      "phaseId": "gov",
      "highlightSkills": [
        "adverse-action-agent"
      ],
      "mode": "REPLAY",
      "body": "Conditional branch shown for governance completeness. Not triggered because Highland is accepted with conditions.",
      "view": "skill",
      "metricFocus": "adverse-action-agent",
      "duration": 3.2
    },
    {
      "step": 50,
      "title": "Case ledger complete",
      "caption": "All phase outputs are now visible in the case ledger: intake, consent, KYB, principal verification, credit data, modelling, decision and governance overlays.",
      "phaseId": "gov",
      "highlightSkills": [],
      "mode": "REPLAY",
      "body": "The UI shows the exact files a production operations team, auditor, or engineer would inspect when challenging the decision.",
      "view": "ledger",
      "metricFocus": "",
      "duration": 4.0
    },
    {
      "step": 51,
      "title": "Final decision: ACCEPT WITH CONDITIONS",
      "caption": "The final outcome is accept with conditions: release prior floating charge, run Etridge process for Lachlan, standard PG for Sarah, and specify equipment security schedule at drawdown.",
      "phaseId": "phase7",
      "highlightSkills": [
        "decision-pricing-agent",
        "sme-pricing-strategy-agent"
      ],
      "mode": "REPLAY",
      "body": "Approved amount £150,000 | Term 60 months | Final rate 8.4% | Risk grade B+ | Consumer Duty fair-value check passes.",
      "view": "decision",
      "metricFocus": "",
      "duration": 6.0
    },
    {
      "step": 52,
      "title": "Production fit",
      "caption": "For the real platform, keep the same React/Node shell and replace the replay data provider with permissioned live connectors and audited agent execution.",
      "phaseId": "front",
      "highlightSkills": [],
      "mode": "LIVE ADAPTER",
      "body": "No real data is gathered in this package. The source code includes a live-mode adapter boundary so engineers can wire Companies House, bureaux, Open Banking, HMRC and Land Registry safely.",
      "view": "architecture",
      "metricFocus": "",
      "duration": 5.0
    }
  ],
  "ledgerFiles": [
    {
      "file": "ui_seed_payload.json",
      "status": "complete",
      "summary": "Four-field one-page UI seed captured and validated."
    },
    {
      "file": "companies_house_profile.json",
      "status": "complete",
      "summary": "Companies House company profile call mapped to KYB input."
    },
    {
      "file": "phase_1_intake.json",
      "status": "complete",
      "summary": "Qualified application and canonical payload created."
    },
    {
      "file": "phase_2_consent_purpose.json",
      "status": "complete",
      "summary": "Consent token bundle and purpose validation complete."
    },
    {
      "file": "phase_3_kyb_psc.json",
      "status": "complete",
      "summary": "KYB verified and PSC chain mapped."
    },
    {
      "file": "phase_4_per_principal.json",
      "status": "complete",
      "summary": "Two principal lanes verified and aggregated."
    },
    {
      "file": "phase_5_credit_data.json",
      "status": "complete",
      "summary": "Bureau, OB, HMRC, alt-data and charges register assembled."
    },
    {
      "file": "phase_6_modelling.json",
      "status": "complete",
      "summary": "Risk, security, PG feasibility, LGD/EAD/rating complete."
    },
    {
      "file": "phase_7_decision.json",
      "status": "complete",
      "summary": "Accept with conditions and pricing returned."
    },
    {
      "file": "governance_overlays.json",
      "status": "complete",
      "summary": "Consumer Duty, fairness, vulnerability and model inventory complete."
    },
    {
      "file": "case_summary.json",
      "status": "complete",
      "summary": "Final consolidated case summary written."
    }
  ],
  "legalSources": [
    {
      "label": "FCA Consumer Duty overview",
      "url": "https://www.fca.org.uk/firms/consumer-duty/about"
    },
    {
      "label": "ICO rights related to automated decision-making including profiling",
      "url": "https://ico.org.uk/for-organisations/uk-gdpr-guidance-and-resources/individual-rights/individual-rights/rights-related-to-automated-decision-making-including-profiling/"
    },
    {
      "label": "PRA SS1/23 Model risk management principles for banks",
      "url": "https://www.bankofengland.co.uk/prudential-regulation/publication/2023/may/model-risk-management-principles-for-banks-ss"
    },
    {
      "label": "Companies House / GOV.UK PSC guidance",
      "url": "https://www.gov.uk/guidance/people-with-significant-control-pscs"
    },
    {
      "label": "RBS v Etridge House of Lords judgment",
      "url": "https://publications.parliament.uk/pa/ld200102/ldjudgmt/jd011011/etridg-1.htm"
    },
    {
      "label": "Insolvency Act 1986 section 176A prescribed part",
      "url": "https://www.legislation.gov.uk/ukpga/1986/45/section/176A"
    },
    {
      "label": "Bank Referral Scheme consultation / GOV.UK",
      "url": "https://www.gov.uk/government/consultations/commercial-credit-data-sharing-and-bank-referral-scheme-consultation-and-call-for-evidence--2/bank-referral-scheme-consultation-and-call-for-evidence"
    },
    {
      "label": "Companies House API overview",
      "url": "https://developer.company-information.service.gov.uk/"
    },
    {
      "label": "Companies House company profile endpoint",
      "url": "https://developer-specs.company-information.service.gov.uk/companies-house-public-data-api/reference/company-profile/company-profile"
    },
    {
      "label": "Companies House API authentication",
      "url": "https://developer.company-information.service.gov.uk/authentication"
    }
  ],
  "uiSeed": {
    "company_registration_number": "10428671",
    "applicant": {
      "name": "Lachlan MacKenzie",
      "residential_address": "12 Strathblane Road, Milngavie, Glasgow, G62 8DJ",
      "date_of_birth": "1981-03-22"
    },
    "captured_from": "one-page React/HTML intake screen",
    "field_policy": "Only company registration number and primary applicant name, residential address and date of birth are taken from the UI seed. Facility details, credit metrics, security values, bureau outputs and offer logic remain synthetic replay data for this internal demonstration.",
    "purpose": "Seed the case and demonstrate the Companies House connector boundary without pretending to run a full live credit file."
  },
  "companiesHouse": {
    "mode_note": "Video/standalone replay returns this demo response. Node live mode calls Companies House only when COMPANIES_HOUSE_API_KEY or CH_API_KEY is configured.",
    "api_call": {
      "method": "GET",
      "url_template": "https://api.company-information.service.gov.uk/company/{companyNumber}",
      "demo_url": "https://api.company-information.service.gov.uk/company/10428671",
      "auth_header": "Authorization: Basic base64(COMPANIES_HOUSE_API_KEY + ':')",
      "accept": "application/json",
      "path_parameter": "companyNumber from UI company_registration_number"
    },
    "request_from_ui": {
      "companyNumber": "10428671"
    },
    "demo_response": {
      "company_name": "Highland Engineering Consultants Ltd",
      "company_number": "10428671",
      "company_status": "active",
      "company_type": "ltd",
      "jurisdiction": "scotland",
      "date_of_creation": "2016-10-17",
      "registered_office_address": {
        "address_line_1": "Suite 4, 2 Atlantic Quay",
        "locality": "Glasgow",
        "postal_code": "G2 8GA",
        "country": "Scotland"
      },
      "sic_codes": [
        "71121"
      ],
      "has_charges": true,
      "links": {
        "self": "/company/10428671",
        "officers": "/company/10428671/officers",
        "persons_with_significant_control": "/company/10428671/persons-with-significant-control",
        "charges": "/company/10428671/charges"
      }
    },
    "mapped_fields": {
      "case.applicant.company_number": "company_number",
      "case.applicant.legal_name": "company_name",
      "case.applicant.status": "company_status",
      "case.applicant.registered_office": "registered_office_address",
      "phase_3_kyb_psc.company_profile_source": "companies_house_profile"
    },
    "controls": [
      "API key stays server-side in Node; browser never receives the secret.",
      "HTTP status and raw payload hash are logged to the case ledger.",
      "A 401, 404 or company_status != active would pause KYB rather than continue to offer.",
      "Replay fallback is clearly labelled so the demo remains deterministic."
    ]
  },
  "updates": [
    {
      "date": "2026-05-27",
      "label": "Feedback update: UI seed + Companies House connector",
      "summary": "Added one-page UI seed capture for company number and primary applicant identity fields; added Companies House profile lookup step and live Node endpoint; downstream replay remains unchanged through offer."
    }
  ]
};
export default demoData;

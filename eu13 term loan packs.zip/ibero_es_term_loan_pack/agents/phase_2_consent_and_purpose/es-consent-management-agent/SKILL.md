---
name: es-consent-management-agent
description: |
  Capture, validate, and issue scoped consent tokens for all downstream data pulls — commercial bureau, consumer bureau (per director), Open Banking, AEAT MTD APIs, Registro de la Propiedad. Records consent provenance and provides a revocation handle.
---

# Consent Management Agent

Without valid scoped consent, downstream agents cannot pull external data lawfully. This agent is the consent gatekeeper.

## Input contract

```yaml
consent_request:
  case_id: string
  applicant_company_number: string
  director_principal_ids: [string]
  scopes_requested:
    - bureau_commercial
    - bureau_consumer_per_director
    - open_banking
    - hmrc_mtd_vat
    - hmrc_mtd_paye
    - hmrc_mtd_ct
    - land_registry_named_directors
  consent_capture_evidence:                 # signed forms or e-sign payloads
    - scope: string
      evidence_type: enum                   # signed_form | esign | api_callback
      timestamp: datetime
      ip_address: string                    # for online consent
      signature_hash: string
```

## Output contract

```yaml
consent_token_bundle:
  case_id: string
  tokens:
    - scope: string
      token_id: string
      issued_at: datetime
      expires_at: datetime
      revocation_handle: string
      evidence_pointer: string              # link to audit evidence
  scopes_granted: [string]
  scopes_refused: [string]
  outcome: enum                             # complete | partial | consent_required
```

## Decision logic

```
For each scope_requested:
  Find matching consent_capture_evidence entry.
  Validate evidence (signature, timestamp recency, IP if online).
  If valid:
    Issue scoped token with appropriate expiry (24h to 90 days depending on scope).
    Append to tokens list.
  Else:
    Append to scopes_refused.

if all requested scopes granted: outcome = complete
elif some granted: outcome = partial
else: outcome = consent_required
```

## Worked example (Ibero Engineering S.L. case)

Input:
```yaml
consent_request:
  case_id: "IBE-2026-04-001"
  applicant_company_number: "B-12345678"
  director_principal_ids: ["DIR-001", "DIR-002"]
  scopes_requested:
    - bureau_commercial
    - bureau_consumer_per_director
    - open_banking
    - hmrc_mtd_vat
    - hmrc_mtd_paye
    - hmrc_mtd_ct
    - land_registry_named_directors
  consent_capture_evidence:
    - scope: bureau_commercial
      evidence_type: esign
      timestamp: "2026-04-12T09:14:22Z"
      ip_address: "82.x.x.x"
      signature_hash: "[hash]"
    # (similar entries for other 6 scopes)
```

Output:
```yaml
consent_token_bundle:
  case_id: "IBE-2026-04-001"
  tokens:
    - scope: bureau_commercial
      token_id: "TKN-bureau-com-2026-04-12-001"
      issued_at: "2026-04-12T09:14:30Z"
      expires_at: "2026-07-11T09:14:30Z"
      revocation_handle: "REV-001"
    # (similar entries for other 6 tokens)
  scopes_granted: [bureau_commercial, bureau_consumer_per_director, open_banking,
                   hmrc_mtd_vat, hmrc_mtd_paye, hmrc_mtd_ct, land_registry_named_directors]
  scopes_refused: []
  outcome: complete
```

All 7 scopes granted with e-signed evidence. Tokens issued with scope-appropriate expiries (bureau 90d; AEAT ties to MTD OAuth lifecycle; Registro de la Propiedad per-query).

## Bright lines

- Consent without evidence (no signed form, no e-sign hash) — cannot issue token; refused
- Consent older than scope-specific staleness threshold — refused; require refresh

## Operational rules

- Tokens are scope-specific — never issue a single token covering multiple scopes
- Revocation handles are issued at token issuance; revocation propagates within 60 seconds
- Consent evidence is retained for 6 years post-relationship (DPA 2018 + CNMV + BdE record-keeping)
- IP-based fraud signals (unusual location, VPN exit nodes) flagged but not blocking

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| No evidence for requested scope | Refuse that scope only; other scopes unaffected |
| Evidence signature invalid | Refuse; alert to fraud agent |
| Evidence timestamp in future | Refuse; clock-skew investigation |


## Spain-specific operational notes

This agent operates within the Spanish lending framework — Banco de España + CNMV joint regulatory perimeter, Ley 10/2014 for banking supervision, LCC (Ley 16/2011) for consumer credit, LRCCI (Ley 5/2019) for mortgage credit.

- **CIRBE €9k threshold:** Banco de España central credit register. Commercial risks >€9,000 mandatory contribution. Small SME facilities frequently below threshold — limited CIRBE visibility for genuine SME risk.
- **ASNEF / BADEXCUG strict access:** Spanish consumer bureau access has the strictest legal review requirement in EU. Operational onboarding must include legal basis attestation. ASNEF for negative; BADEXCUG for comprehensive — separate access agreements required.
- **LRCCI notarial requirement (AGNCN):** Mortgage origination requires AGNCN (Acta de Información Notarial Previa) — notarial pre-contractual information act. Cannot bypass; significant operational integration with notary network.
- **Tarjeta revolving usury (2020 Supreme Court):** Revolving credit cards subject to enhanced disclosure post-2020 Supreme Court rulings on usury. APR materially above market average is voidable.
- **Bizum ubiquity:** Mobile P2P payment platform with near-universal Spanish adoption; PSD2 integration via participating banks.
- **NIE administrative complexity:** Foreign residents require NIE (Número de Identidad de Extranjero) — multiple issuing authorities, common source of onboarding friction.
- **Cross-reference:** `country-es-lending-policy-agent` provides full ES jurisdictional context.

## Statutory hooks

- Spain GDPR Article 6 (lawful basis) + Article 7 (consent conditions)
- Data Protection Act 2018
- PSD2 / Open Banking RTS (consent requirements for account access)
- Finance Act 2017 (AEAT MTD consent scope)

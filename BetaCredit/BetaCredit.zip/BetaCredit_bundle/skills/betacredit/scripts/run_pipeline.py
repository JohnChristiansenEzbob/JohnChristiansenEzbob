#!/usr/bin/env python3
"""
run_pipeline.py — execute one or more BetaCredit notebooks in order via
nbconvert. Runs notebook 00 first (if needed) so df_all.parquet is in
place before any modelling notebook reads it.

Usage:
    # Run the whole pipeline (00 then 01-07)
    python run_pipeline.py --all

    # Run just notebook 04 (assumes df_all.parquet already exists)
    python run_pipeline.py 04

    # Run 00 then 02 then 07
    python run_pipeline.py 00 02 07

    # Specify the working directory containing the notebooks
    python run_pipeline.py --cwd /path/to/BetaCredit_bundle 04 05
"""
from __future__ import annotations
import argparse
import shutil
import subprocess
import sys
from pathlib import Path

NOTEBOOK_FILENAMES = {
    "00": "00_data_ingestion.ipynb",
    "01": "01_exploratory_data_analysis.ipynb",
    "02": "02_pd_models_shap_lime.ipynb",
    "03": "03_lgd_ead_stress.ipynb",
    "04": "04_sicr_staging.ipynb",
    "05": "05_fairness_responsible_ai.ipynb",
    "06": "06_rl_reweighting.ipynb",
    "07": "07_portfolio_ecl_capital.ipynb",
}


def execute(notebook_name: str, cwd: Path, timeout: int) -> bool:
    """Execute a notebook in-place via nbconvert. Returns True on success."""
    print(f"\n{'='*60}")
    print(f"Executing {notebook_name} ...")
    print('='*60)

    cmd = [
        sys.executable, "-m", "nbconvert",
        "--to", "notebook",
        "--execute", notebook_name,
        "--output", f"_executed_{notebook_name.replace('.ipynb', '')}.ipynb",
        f"--ExecutePreprocessor.timeout={timeout}",
    ]
    try:
        subprocess.run(cmd, cwd=cwd, check=True)
        print(f"✓ {notebook_name} completed")
        return True
    except subprocess.CalledProcessError as e:
        print(f"✗ {notebook_name} FAILED — see traceback above")
        return False


def main() -> int:
    ap = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ap.add_argument("notebooks", nargs="*",
                    help='Notebooks to run, e.g. "04" or "04 05". '
                         'Use 00..07 (two-digit prefixes).')
    ap.add_argument("--all", action="store_true",
                    help="Run notebooks 00 through 07 in order")
    ap.add_argument("--cwd", default=".",
                    help="Working directory containing the notebooks "
                         "(default: current directory)")
    ap.add_argument("--timeout", type=int, default=600,
                    help="Per-cell timeout in seconds (default: 600)")
    args = ap.parse_args()

    cwd = Path(args.cwd).resolve()
    if not (cwd / "00_data_ingestion.ipynb").exists():
        print(f"Error: 00_data_ingestion.ipynb not found in {cwd}", file=sys.stderr)
        print("Use --cwd to point to the BetaCredit bundle directory.", file=sys.stderr)
        return 2

    if args.all:
        keys = ["00", "01", "02", "03", "04", "05", "06", "07"]
    elif args.notebooks:
        keys = [k.zfill(2) for k in args.notebooks]
    else:
        ap.error("Pass at least one notebook number, or --all.")

    # Validate and run
    bad = [k for k in keys if k not in NOTEBOOK_FILENAMES]
    if bad:
        print(f"Unknown notebooks: {bad}. Valid: {list(NOTEBOOK_FILENAMES)}",
              file=sys.stderr)
        return 2

    failures = []
    for key in keys:
        ok = execute(NOTEBOOK_FILENAMES[key], cwd, args.timeout)
        if not ok:
            failures.append(key)

    print(f"\n{'='*60}")
    if failures:
        print(f"FAILED notebooks: {failures}")
        return 1
    print(f"All {len(keys)} notebooks completed.")
    print(f"Look for _executed_*.ipynb in {cwd} to see outputs.")
    return 0


if __name__ == "__main__":
    sys.exit(main())

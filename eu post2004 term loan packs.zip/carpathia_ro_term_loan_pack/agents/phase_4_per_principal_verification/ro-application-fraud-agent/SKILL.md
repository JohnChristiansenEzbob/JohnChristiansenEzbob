---
name: ro-application-fraud-agent
description: |
  Detect application-stage fraud indicators per principal — synthetic identity patterns, document tampering signals, velocity rules (repeated applications), Biroul de Credit negative + CRC Protective Registration / National Fraud Database hits, device fingerprinting signals. Returns a fraud score (0-100) with classification.
---

# Application Fraud Agent

First-line application fraud screen. Identity-orchestration confirms the person is real and the documents are real; this agent confirms the application itself isn't suspicious.

## Input contract

```yaml
fraud_request:
  principal_id: string
  case_id: string
  name: string
  dob: date
  current_residential_address: string
  application_metadata:
    device_fingerprint: string
    ip_address: string
    submission_timestamp: datetime
    browser_locale: string
  cifas_check_consent: boolean
```

## Output contract

```yaml
fraud_assessment:
  principal_id: string
  fraud_score: integer                      # 0-100; 0=clean, 100=high risk
  classification: enum                      # low | medium | high
  signals:
    cifas_markers: [string]                 # nullable
    velocity_signals: [string]              # multiple recent applications etc.
    device_signals: [string]                # VPN, automation, mismatched locale etc.
    synthetic_identity_signals: [string]
  outcome: enum                             # proceed | refer | block_high_risk_fraud
  reason_codes: [string]
```

## Decision logic

```
Lookup Biroul de Credit negative + CRC National Fraud Database (consent-gated).
Apply velocity rules (same identity in N applications in past M days).
Device fingerprint analysis (known fraud-associated devices, automation).
Synthetic identity detection (DOB-name combinations, address-credit history mismatches).

Compute composite fraud_score.

if cifas_markers include "fraud" (Category 6) marker:
  outcome = block_high_risk_fraud           # BRIGHT LINE; Biroul de Credit negative + CRC fraud marker is decline

elif fraud_score >= 70:
  outcome = block_high_risk_fraud

elif fraud_score >= 40:
  outcome = refer

else:
  outcome = proceed
```

## Worked example (Carpathia Engineering SRL case)

Input:
```yaml
fraud_request:
  principal_id: DIR-001
  case_id: "CAR-2026-04-001"
  name: "Lachlan MacKenzie"
  dob: "1981-03-22"
  current_residential_address: "12 Strathblane Road, Milngavie, București, G62 8DJ"
  application_metadata:
    device_fingerprint: "[hash]"
    ip_address: "82.x.x.x"
    submission_timestamp: "2026-04-12T09:14:22Z"
    browser_locale: "en-GB"
  cifas_check_consent: true
```

Output:
```yaml
fraud_assessment:
  principal_id: DIR-001
  fraud_score: 12
  classification: low
  signals:
    cifas_markers: []
    velocity_signals: []
    device_signals: []
    synthetic_identity_signals: []
  outcome: proceed
  reason_codes: ["UK_APPLICATION_FRAUD_LOW_RISK"]
```

Clean fraud screen. Romania IP, en-GB locale matching declared residence, no Biroul de Credit negative + CRC markers, no velocity issues. Sarah Chen returns similar low-risk shape.

## Bright lines

- Biroul de Credit negative + CRC Category 6 fraud marker → AUTO-DECLINE; cannot override without explicit dispensation
- Confirmed synthetic identity (fabricated person) → AUTO-DECLINE + SAR

## Operational rules

- Biroul de Credit negative + CRC lookup requires explicit consent; absence of consent → cannot perform that check (not blocking by itself)
- Velocity rules windowed (e.g. >3 applications in 30 days flags)
- Device fingerprints retained in fraud history for pattern detection

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Biroul de Credit negative + CRC unavailable | Refer; cannot make decision without check (over a critical limit) |
| Device fingerprint missing | Score conservatively; some signals unusable |


## Romania-specific operational notes

Operates within the Romanian framework — BNR + ASF supervision, OUG 50/2010 for consumer credit, OUG 52/2016 for mortgage credit, Legea 129/2019 for AML.

- **Biroul de Credit + CRC dual registers:** Biroul de Credit (private, consumer) + Centrala Riscului de Credit (BNR-operated central). Combined visibility.
- **CNP universal identifier:** Cod numeric personal; restricted-use under GDPR.
- **Prima Casă / Noua Casă legacy:** State-guaranteed mortgage schemes shape mortgage origination expectations.
- **ANPC consumer protection:** National Authority for Consumer Protection active in financial services.
- **RON currency:** Outside Eurozone; floating. FX consideration material.
- **Cross-reference:** `country-ro-lending-policy-agent` (Country Policy Pack stub).

## Statutory hooks

- Fraud Act 2006
- ONRC UBO data (failure to prevent fraud — must have reasonable procedures)
- Romania Legea 129/2019 (transaction monitoring + identity)
- Biroul de Credit negative + CRC Code of Practice

"""
risk_models.data_ingestion
==========================

Third-party data ingestion for BetaCredit.

This module lets users feed real borrower data into the BetaCredit pipeline
from CSV, TXT (delimited), Excel, JSON, or Parquet files instead of relying
on the synthetic ``generate_borrowers()`` function in notebook 01.

The output is a pandas DataFrame whose schema matches ``df_all`` exactly,
so it drops straight into notebooks 02–07 (PD, LGD/EAD, SICR, fairness,
RL re-weighting, portfolio ECL).

Quick start
-----------
    from risk_models.data_ingestion import ingest

    result = ingest("my_book.csv", asset_class="sme_unsecured")
    df_all = result.dataframe
    print(result.report)

For files that already contain an ``asset_class`` column for every row,
omit the ``asset_class`` argument:

    result = ingest("portfolio.xlsx")
    df_all = result.dataframe

Column-name mapping
-------------------
The ingester matches your file's columns to the canonical BetaCredit
schema using:

  1. exact match
  2. case- and underscore-insensitive match
  3. an alias table covering common bureau / OB / accounting field names
  4. an explicit ``column_map`` argument you can pass in

Anything still unmatched is reported but does not block ingestion as long
as all *required* fields are present.
"""

from __future__ import annotations

import json
import re
import warnings
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

__all__ = [
    "CANONICAL_SCHEMA",
    "REQUIRED_COLUMNS",
    "VALID_ASSET_CLASSES",
    "COLUMN_ALIASES",
    "IngestionResult",
    "IngestionError",
    "ingest",
    "ingest_dataframe",
    "validate_schema",
    "describe_schema",
]


# ─────────────────────────────────────────────────────────────────────────────
# Canonical schema
# ─────────────────────────────────────────────────────────────────────────────

VALID_ASSET_CLASSES: tuple[str, ...] = (
    "sme_unsecured",
    "sme_secured",
    "consumer_unsecured",
    "residential_mortgage",
    "buy_to_let",
    "motor_finance",
    "invoice_finance",
    "asset_finance",
)

# (dtype, min, max, required, description)
# `min`/`max` of None means "no bound".
# `required=True` columns must be present (post-mapping) or ingestion fails.
CANONICAL_SCHEMA: dict[str, dict[str, Any]] = {
    "asset_class": {
        "dtype": "category",
        "required": True,
        "allowed": VALID_ASSET_CLASSES,
        "desc": "One of the eight BetaCredit asset classes.",
    },
    "bureau_score": {
        "dtype": "int",
        "required": True,
        "min": 300, "max": 999,
        "desc": "UK bureau score (Experian / Equifax / TransUnion scale).",
    },
    "cashflow_coverage": {
        "dtype": "float",
        "required": True,
        "min": 0.0, "max": 10.0,
        "desc": "Cashflow coverage ratio (DSCR-equivalent).",
    },
    "ltv": {
        "dtype": "float",
        "required": True,
        "min": 0.0, "max": 1.5,
        "desc": "Loan-to-value ratio. For unsecured, set to a uniform proxy in [0,1].",
    },
    "loan_amount": {
        "dtype": "float",
        "required": True,
        "min": 0.0, "max": None,
        "desc": "Drawn principal at origination (£).",
    },
    "loan_term_months": {
        "dtype": "int",
        "required": True,
        "min": 1, "max": 600,
        "desc": "Contractual term in months.",
    },
    "default_flag": {
        "dtype": "int",
        "required": True,
        "allowed": (0, 1),
        "desc": "1 if borrower defaulted in the observation window, else 0.",
    },

    # Optional behavioural / bureau fields
    "num_prior_defaults": {
        "dtype": "int", "required": False, "min": 0, "max": 20,
        "default": 0,
        "desc": "Count of prior defaults on bureau file.",
    },
    "months_since_adverse": {
        "dtype": "float", "required": False, "min": 0, "max": 9999,
        "default": 9999.0,
        "desc": "Months since most recent adverse event. 9999 sentinel = never.",
    },
    "age_years": {
        "dtype": "float", "required": False, "min": 18, "max": 100,
        "default": 42.0,
        "desc": "Borrower / principal age (consumer) or company age proxy.",
    },
    "utilisation_rate": {
        "dtype": "float", "required": False, "min": 0.0, "max": 1.0,
        "default": 0.3,
        "desc": "Revolving credit utilisation [0,1].",
    },
    "open_banking_income_stability": {
        "dtype": "float", "required": False, "min": 0.0, "max": 1.0,
        "default": 0.72,
        "desc": "Open Banking income-stability score [0,1].",
    },
    "gnn_connected_party_risk": {
        "dtype": "float", "required": False, "min": 0.0, "max": 1.0,
        "default": 0.0,
        "desc": "Graph-neural-network connected-party risk score [0,1].",
    },
    "months_banking_relationship": {
        "dtype": "float", "required": False, "min": 0, "max": 600,
        "default": 36.0,
        "desc": "Months since account opened with primary bank.",
    },
    "num_active_credit_lines": {
        "dtype": "int", "required": False, "min": 0, "max": 50,
        "default": 2,
        "desc": "Active credit facilities on bureau.",
    },

    # SME-specific
    "time_in_business_months": {
        "dtype": "float", "required": False, "min": 0, "max": 1200,
        "default": 0.0,
        "desc": "SME only. Months since incorporation. 0 for non-SME.",
    },
    "annual_revenue": {
        "dtype": "float", "required": False, "min": 0, "max": None,
        "default": None,  # filled per-row from a sensible distribution proxy
        "desc": "Annual turnover (£). For consumer, household income proxy.",
    },
    "hmrc_revenue_match_ratio": {
        "dtype": "float", "required": False, "min": 0.3, "max": 1.5,
        "default": 1.0,
        "desc": "Ratio of HMRC-filed turnover to declared turnover. 1.0 for non-SME.",
    },

    # Asset-class-specific
    "vehicle_age_months": {
        "dtype": "float", "required": False, "min": 0, "max": 360,
        "default": 0.0,
        "desc": "Motor finance only. Vehicle age at origination in months.",
    },
    "invoice_dilution_rate": {
        "dtype": "float", "required": False, "min": 0.0, "max": 0.5,
        "default": 0.0,
        "desc": "Invoice finance only. Historical dilution rate [0,0.5].",
    },

    # Demographics for fairness analysis (notebook 05)
    "gender": {
        "dtype": "category", "required": False,
        "allowed": ("M", "F", "Other"),
        "default": "Other",
        "desc": "Self-reported gender. Used by fairness notebook only.",
    },
    "age_band": {
        "dtype": "category", "required": False,
        "allowed": ("18-25", "25-35", "35-45", "45-55", "55-65", "65+"),
        "default": None,  # derived from age_years if missing
        "desc": "Age band. Derived from age_years if absent.",
    },
    "region": {
        "dtype": "category", "required": False,
        "allowed": ("London", "SE England", "N England", "Scotland", "Wales", "NI"),
        "default": "N England",
        "desc": "UK region.",
    },

    # Origination date — optional but unlocks vintage / cohort analysis
    # (notebook 01 chart, back-tester cohort breakdown). If supplied as a
    # string, ISO format (YYYY-MM-DD) is required; the ingester coerces
    # via pandas.to_datetime and rejects rows that fail to parse.
    "origination_date": {
        "dtype": "datetime64[ns]", "required": False,
        "default": None,
        "desc": "Date the loan was originated. Drives vintage analysis.",
    },
    "vintage_quarter": {
        "dtype": "string", "required": False,
        "default": None,
        "desc": "Origination year-quarter (e.g. '2023Q3'). "
                "Auto-derived from origination_date when that column is present.",
    },

    # v1.2 LGD component columns — all optional. Any subset can be supplied;
    # missing components fall back to the asset-class default. lgd_observed
    # takes priority over everything (overrides the component formula).
    "lgd_observed": {
        "dtype": "float", "required": False,
        "min": 0.0, "max": 1.0,
        "default": None,
        "desc": "Pre-computed LGD value (e.g. from an internal model). "
                "When supplied, used directly and overrides the component formula.",
    },
    "collateral_value": {
        "dtype": "float", "required": False,
        "min": 0.0,
        "default": None,
        "desc": "£ value of collateral at origination. Drives the collateral-recovery "
                "component of LGD. Use 0 for genuinely unsecured loans.",
    },
    "cure_prob": {
        "dtype": "float", "required": False,
        "min": 0.0, "max": 1.0,
        "default": None,
        "desc": "Probability the loan cures without going to recovery. "
                "Dominates LGD for unsecured asset classes.",
    },
    "recovery_costs": {
        "dtype": "float", "required": False,
        "min": 0.0, "max": 1.0,
        "default": None,
        "desc": "Workout costs (legal, admin, asset management) as a "
                "fraction of EAD. Basel IV Article 181 economic-loss definition.",
    },
    "time_to_resolution_months": {
        "dtype": "int", "required": False,
        "min": 0, "max": 120,
        "default": None,
        "desc": "Expected months from default to final resolution. "
                "Drives the discounting component of LGD.",
    },
}

REQUIRED_COLUMNS: tuple[str, ...] = tuple(
    name for name, spec in CANONICAL_SCHEMA.items() if spec.get("required")
)


# ─────────────────────────────────────────────────────────────────────────────
# Column aliases — common third-party / bureau / accounting names
# ─────────────────────────────────────────────────────────────────────────────

COLUMN_ALIASES: dict[str, tuple[str, ...]] = {
    "asset_class": ("product", "product_type", "loan_type", "portfolio_segment", "segment"),
    "bureau_score": ("credit_score", "experian_score", "equifax_score", "transunion_score",
                     "fico", "fico_score", "score", "bureau"),
    "cashflow_coverage": ("dscr", "debt_service_coverage", "ccr", "cash_coverage",
                          "coverage_ratio", "cash_flow_coverage"),
    "ltv": ("loan_to_value", "ltv_ratio", "ltv_pct", "ltv_percentage"),
    "loan_amount": ("principal", "drawn_amount", "advance", "balance_at_origination",
                    "loan_value", "facility_amount", "limit"),
    "loan_term_months": ("term_months", "term", "tenor_months", "tenor",
                         "maturity_months"),
    "default_flag": ("default", "is_default", "default_indicator", "y", "target",
                     "bad_flag", "bad", "delinq_90", "ever_90dpd"),
    "num_prior_defaults": ("prior_defaults", "previous_defaults", "ccj_count",
                           "num_ccjs", "adverse_events"),
    "months_since_adverse": ("months_since_default", "months_since_ccj",
                             "msla", "time_since_adverse"),
    "age_years": ("age", "borrower_age", "principal_age"),
    "utilisation_rate": ("utilization_rate", "credit_utilisation",
                         "credit_utilization", "utilisation", "utilization", "util"),
    "open_banking_income_stability": ("ob_income_stability", "income_stability",
                                       "ob_stability", "open_banking_stability"),
    "gnn_connected_party_risk": ("gnn_risk", "connected_party_risk", "graph_risk",
                                  "network_risk"),
    "months_banking_relationship": ("relationship_months", "tenure_months",
                                     "months_with_bank", "account_tenure"),
    "num_active_credit_lines": ("active_credit_lines", "open_accounts",
                                 "num_open_accounts", "credit_lines"),
    "time_in_business_months": ("years_trading", "company_age_months", "trading_months",
                                 "tib_months", "tib"),
    "annual_revenue": ("turnover", "revenue", "annual_turnover", "income",
                       "annual_income", "household_income"),
    "hmrc_revenue_match_ratio": ("hmrc_match", "hmrc_ratio", "hmrc_revenue_match"),
    "vehicle_age_months": ("car_age_months", "asset_age_months", "vehicle_age"),
    "invoice_dilution_rate": ("dilution_rate", "dilution"),
    "gender": ("sex",),
    "age_band": ("age_group", "age_bracket"),
    "region": ("country_region", "uk_region", "geography", "geo"),
    "origination_date": ("open_date", "origination_dt", "start_date", "drawdown_date",
                          "completion_date", "loan_date", "issue_date", "date_originated",
                          "advance_date", "booked_date"),
    # v1.2 LGD component aliases
    "lgd_observed": ("lgd", "loss_given_default", "observed_lgd",
                     "lgd_realised", "lgd_actual"),
    "collateral_value": ("security_value", "collateral_amount", "property_value",
                          "secured_value", "asset_value"),
    "cure_prob": ("cure_rate", "cure_probability", "prob_cure", "cure_pct"),
    "recovery_costs": ("workout_costs", "recovery_cost_pct", "cost_to_recover",
                        "loss_costs"),
    "time_to_resolution_months": ("time_to_resolution", "workout_months",
                                    "recovery_time_months", "ttr_months"),
}


# ─────────────────────────────────────────────────────────────────────────────
# Asset-class normalisation (third-party files often use different labels)
# ─────────────────────────────────────────────────────────────────────────────

ASSET_CLASS_ALIASES: dict[str, str] = {
    # SME unsecured
    "sme": "sme_unsecured",
    "sme_unsecured": "sme_unsecured",
    "sme unsecured": "sme_unsecured",
    "small_business_unsecured": "sme_unsecured",
    "business_unsecured": "sme_unsecured",
    # SME secured
    "sme_secured": "sme_secured",
    "sme secured": "sme_secured",
    "small_business_secured": "sme_secured",
    "business_secured": "sme_secured",
    # Consumer
    "consumer": "consumer_unsecured",
    "consumer_unsecured": "consumer_unsecured",
    "consumer unsecured": "consumer_unsecured",
    "personal_loan": "consumer_unsecured",
    "personal": "consumer_unsecured",
    "unsecured_personal": "consumer_unsecured",
    # Mortgage
    "mortgage": "residential_mortgage",
    "residential": "residential_mortgage",
    "residential_mortgage": "residential_mortgage",
    "owner_occupied": "residential_mortgage",
    "first_charge_mortgage": "residential_mortgage",
    # BTL
    "btl": "buy_to_let",
    "buy_to_let": "buy_to_let",
    "buy-to-let": "buy_to_let",
    "buy to let": "buy_to_let",
    "btl_mortgage": "buy_to_let",
    # Motor
    "motor": "motor_finance",
    "motor_finance": "motor_finance",
    "auto": "motor_finance",
    "auto_finance": "motor_finance",
    "car_finance": "motor_finance",
    "hp": "motor_finance",
    "pcp": "motor_finance",
    # Invoice
    "invoice": "invoice_finance",
    "invoice_finance": "invoice_finance",
    "factoring": "invoice_finance",
    "invoice_discounting": "invoice_finance",
    # Asset finance
    "asset": "asset_finance",
    "asset_finance": "asset_finance",
    "equipment_finance": "asset_finance",
    "leasing": "asset_finance",
}


# ─────────────────────────────────────────────────────────────────────────────
# Result + error types
# ─────────────────────────────────────────────────────────────────────────────

class IngestionError(ValueError):
    """Raised when a file cannot be ingested into the canonical schema."""


@dataclass
class IngestionResult:
    """Output of a successful ingestion call."""

    dataframe: pd.DataFrame
    source: str
    rows_in: int
    rows_out: int
    column_map_used: dict[str, str] = field(default_factory=dict)
    unmapped_source_columns: list[str] = field(default_factory=list)
    coerced_defaults: dict[str, int] = field(default_factory=dict)
    rejected_rows: dict[str, int] = field(default_factory=dict)
    warnings_: list[str] = field(default_factory=list)

    @property
    def report(self) -> str:
        """Human-readable ingestion summary suitable for notebook output."""
        lines = [
            "BetaCredit Ingestion Report",
            "=" * 56,
            f"Source                : {self.source}",
            f"Rows read             : {self.rows_in:,}",
            f"Rows accepted         : {self.rows_out:,}",
            f"Rows rejected         : {self.rows_in - self.rows_out:,}",
        ]
        if self.column_map_used:
            lines.append("")
            lines.append("Column mapping applied:")
            for src, canonical in self.column_map_used.items():
                if src != canonical:
                    lines.append(f"  {src!r:35s} → {canonical}")
        if self.coerced_defaults:
            lines.append("")
            lines.append("Optional fields filled with defaults:")
            for col, n in self.coerced_defaults.items():
                lines.append(f"  {col:40s} {n:,} rows")
        if self.rejected_rows:
            lines.append("")
            lines.append("Rejected rows by reason:")
            for reason, n in self.rejected_rows.items():
                lines.append(f"  {reason:40s} {n:,} rows")
        if self.unmapped_source_columns:
            lines.append("")
            lines.append("Source columns not mapped (ignored):")
            lines.append("  " + ", ".join(self.unmapped_source_columns))
        if self.warnings_:
            lines.append("")
            lines.append("Warnings:")
            for w in self.warnings_:
                lines.append(f"  • {w}")
        lines.append("=" * 56)
        return "\n".join(lines)

    def __repr__(self) -> str:  # pragma: no cover
        return (
            f"IngestionResult(source={self.source!r}, "
            f"rows={self.rows_out:,}, columns={self.dataframe.shape[1]})"
        )


# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────

def describe_schema() -> pd.DataFrame:
    """Return the canonical BetaCredit schema as a DataFrame for documentation."""
    rows = []
    for name, spec in CANONICAL_SCHEMA.items():
        rows.append({
            "field": name,
            "type": spec.get("dtype"),
            "required": spec.get("required", False),
            "min": spec.get("min", ""),
            "max": spec.get("max", ""),
            "allowed": ", ".join(map(str, spec["allowed"]))[:60] if "allowed" in spec else "",
            "default": spec.get("default", ""),
            "description": spec.get("desc", ""),
        })
    return pd.DataFrame(rows)


def ingest(
    source: str | Path,
    *,
    asset_class: str | None = None,
    column_map: dict[str, str] | None = None,
    sep: str | None = None,
    sheet_name: str | int | None = 0,
    encoding: str = "utf-8",
    strict: bool = False,
    drop_invalid_rows: bool = True,
) -> IngestionResult:
    """
    Read a third-party data file and convert it to BetaCredit canonical schema.

    Parameters
    ----------
    source : str or Path
        Path to the file. Supported extensions: .csv, .tsv, .psv, .txt,
        .xlsx, .xls, .json, .jsonl, .ndjson, .parquet, .pq.
    asset_class : str, optional
        Asset class to assign to every row if the file does not contain
        an ``asset_class`` column. Must be one of ``VALID_ASSET_CLASSES``
        or a recognised alias.
    column_map : dict[str, str], optional
        Explicit override mapping ``{file_column: canonical_column}``.
        Takes precedence over auto-detection.
    sep : str, optional
        Delimiter for text files. Auto-detected if omitted.
    sheet_name : str or int, default 0
        Sheet to read from Excel files.
    encoding : str, default 'utf-8'
        File encoding for text files.
    strict : bool, default False
        If True, any row that violates a range check causes the whole
        ingestion to fail. If False, invalid rows are dropped (or kept
        with a warning if ``drop_invalid_rows=False``).
    drop_invalid_rows : bool, default True
        Whether out-of-range rows are dropped (True) or kept with NaN
        clipping (False).

    Returns
    -------
    IngestionResult
        ``.dataframe`` is the cleaned, schema-conformant DataFrame.
    """
    source = Path(source)
    if not source.exists():
        raise IngestionError(f"File not found: {source}")

    raw = _read_file(source, sep=sep, sheet_name=sheet_name, encoding=encoding)

    return ingest_dataframe(
        raw,
        asset_class=asset_class,
        column_map=column_map,
        strict=strict,
        drop_invalid_rows=drop_invalid_rows,
        source_name=str(source),
    )


def ingest_dataframe(
    df: pd.DataFrame,
    *,
    asset_class: str | None = None,
    column_map: dict[str, str] | None = None,
    strict: bool = False,
    drop_invalid_rows: bool = True,
    source_name: str = "<DataFrame>",
) -> IngestionResult:
    """
    Same as :func:`ingest`, but takes an already-loaded DataFrame.

    Useful when the data comes from a database query, an API call, or
    any other in-memory source.
    """
    rows_in = len(df)
    warns: list[str] = []
    coerced: dict[str, int] = {}
    rejected: dict[str, int] = {}

    # 1) Build column map (auto + explicit override)
    auto_map = _auto_column_map(df.columns)
    final_map = {**auto_map, **(column_map or {})}
    df = df.rename(columns=final_map)

    unmapped = [c for c in df.columns if c not in CANONICAL_SCHEMA]

    # 2) Inject asset_class if user passed it explicitly
    if asset_class is not None:
        normalised = _normalise_asset_class(asset_class)
        if normalised is None:
            raise IngestionError(
                f"Unknown asset_class {asset_class!r}. "
                f"Must be one of: {', '.join(VALID_ASSET_CLASSES)}"
            )
        if "asset_class" in df.columns:
            warns.append(
                f"asset_class={asset_class!r} passed but file already has an "
                f"'asset_class' column; the explicit argument was ignored."
            )
        else:
            df["asset_class"] = normalised
    elif "asset_class" in df.columns:
        # Normalise existing labels
        df["asset_class"] = df["asset_class"].astype(str).str.strip().str.lower()
        before = df["asset_class"].copy()
        df["asset_class"] = df["asset_class"].map(
            lambda v: _normalise_asset_class(v) or v
        )
        bad_mask = ~df["asset_class"].isin(VALID_ASSET_CLASSES)
        if bad_mask.any():
            bad_vals = sorted(set(before[bad_mask].head(20)))
            msg = (
                f"{int(bad_mask.sum()):,} rows have unrecognised asset_class values: "
                f"{bad_vals}. Add them to ASSET_CLASS_ALIASES or fix the file."
            )
            if strict:
                raise IngestionError(msg)
            warns.append(msg)
            rejected["unrecognised_asset_class"] = int(bad_mask.sum())
            df = df[~bad_mask].copy()
    else:
        raise IngestionError(
            "No 'asset_class' column in file and no asset_class argument given. "
            f"Pass one of: {', '.join(VALID_ASSET_CLASSES)}"
        )

    # 3) Required columns check
    missing_required = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing_required:
        raise IngestionError(
            "Required columns are missing from the file (after column mapping):\n"
            f"  {missing_required}\n\n"
            "Use the `column_map` argument to map your file's columns explicitly, "
            "or rename them in the source file. Run `describe_schema()` to see "
            "the full canonical schema."
        )

    # 4) Type coercion + range validation
    df, rejected_step, coerced_step, warns_step = _coerce_and_validate(
        df, strict=strict, drop_invalid_rows=drop_invalid_rows
    )
    for k, v in rejected_step.items():
        rejected[k] = rejected.get(k, 0) + v
    coerced.update(coerced_step)
    warns.extend(warns_step)

    # 4.5) Drop any rows with NaN in a required column. Coercion above can
    # turn non-numeric strings into NaN; without this step downstream
    # `astype(int)` calls (in modelling notebooks) would fail.
    for req in REQUIRED_COLUMNS:
        if req not in df.columns:
            continue
        na_mask = df[req].isna()
        n_na = int(na_mask.sum())
        if n_na:
            reason = f"nan_in_required_{req}"
            if strict:
                raise IngestionError(
                    f"{n_na:,} rows have NaN in required column {req!r}. "
                    f"Run with strict=False to drop them automatically."
                )
            rejected[reason] = rejected.get(reason, 0) + n_na
            df = df[~na_mask].copy()

    # 5) Fill optional columns with sensible defaults
    df, defaulted = _fill_optional_defaults(df)
    for col, n in defaulted.items():
        coerced[col] = coerced.get(col, 0) + n

    # 6) Derive age_band from age_years if missing
    if "age_band" not in df.columns or df["age_band"].isna().all():
        df["age_band"] = pd.cut(
            df["age_years"],
            bins=[0, 25, 35, 45, 55, 65, 200],
            labels=["18-25", "25-35", "35-45", "45-55", "55-65", "65+"],
            include_lowest=True,
        ).astype(str)

    # 7) Reorder to canonical schema order, keep extras at the end
    canonical_cols = [c for c in CANONICAL_SCHEMA if c in df.columns]
    extras = [c for c in df.columns if c not in CANONICAL_SCHEMA]
    df = df[canonical_cols + extras].reset_index(drop=True)

    # 8) Sanity check on default rate
    dr = df["default_flag"].mean()
    if dr == 0 or dr == 1:
        warns.append(
            f"Default rate is {dr:.0%} — model training will not be possible "
            f"without both classes present. Check that 'default_flag' is correctly mapped."
        )
    elif dr > 0.5:
        warns.append(
            f"Default rate is unusually high ({dr:.1%}). "
            f"Verify the polarity of 'default_flag' (1 should mean default)."
        )

    return IngestionResult(
        dataframe=df,
        source=source_name,
        rows_in=rows_in,
        rows_out=len(df),
        column_map_used={k: v for k, v in final_map.items() if k != v},
        unmapped_source_columns=unmapped,
        coerced_defaults=coerced,
        rejected_rows=rejected,
        warnings_=warns,
    )


def validate_schema(df: pd.DataFrame) -> list[str]:
    """
    Return a list of human-readable schema violations for ``df``, or an empty
    list if the DataFrame is fully conformant.

    Useful as a final check before passing a frame to a model.
    """
    issues: list[str] = []
    for col in REQUIRED_COLUMNS:
        if col not in df.columns:
            issues.append(f"missing required column: {col!r}")
    for col, spec in CANONICAL_SCHEMA.items():
        if col not in df.columns:
            continue
        s = df[col]
        if "min" in spec and spec["min"] is not None:
            below = (pd.to_numeric(s, errors="coerce") < spec["min"]).sum()
            if below:
                issues.append(f"{col}: {below:,} values below min={spec['min']}")
        if "max" in spec and spec["max"] is not None:
            above = (pd.to_numeric(s, errors="coerce") > spec["max"]).sum()
            if above:
                issues.append(f"{col}: {above:,} values above max={spec['max']}")
        if "allowed" in spec:
            bad = (~s.isin(spec["allowed"]) & s.notna()).sum()
            if bad:
                issues.append(
                    f"{col}: {bad:,} values not in allowed set "
                    f"{tuple(spec['allowed'])[:5]}{'...' if len(spec['allowed'])>5 else ''}"
                )
    return issues


# ─────────────────────────────────────────────────────────────────────────────
# Internals
# ─────────────────────────────────────────────────────────────────────────────

def _read_file(
    path: Path,
    *,
    sep: str | None,
    sheet_name: str | int | None,
    encoding: str,
) -> pd.DataFrame:
    suffix = path.suffix.lower()

    if suffix in {".csv"}:
        return pd.read_csv(path, sep=sep or ",", encoding=encoding)

    if suffix in {".tsv"}:
        return pd.read_csv(path, sep=sep or "\t", encoding=encoding)

    if suffix in {".psv"}:
        return pd.read_csv(path, sep=sep or "|", encoding=encoding)

    if suffix in {".txt"}:
        # Sniff delimiter if not given
        if sep is None:
            with open(path, "r", encoding=encoding, errors="replace") as f:
                sample = f.read(8192)
            sep = _sniff_delimiter(sample)
        return pd.read_csv(path, sep=sep, encoding=encoding, engine="python")

    if suffix in {".xlsx", ".xls", ".xlsm"}:
        return pd.read_excel(path, sheet_name=sheet_name)

    if suffix in {".json"}:
        # Try records-array first, fall back to JSON-Lines
        try:
            return pd.read_json(path)
        except ValueError:
            return pd.read_json(path, lines=True)

    if suffix in {".jsonl", ".ndjson"}:
        return pd.read_json(path, lines=True)

    if suffix in {".parquet", ".pq"}:
        return pd.read_parquet(path)

    raise IngestionError(
        f"Unsupported file extension {suffix!r}. "
        f"Supported: .csv .tsv .psv .txt .xlsx .xls .json .jsonl .parquet"
    )


def _sniff_delimiter(sample: str) -> str:
    """Lightweight delimiter detection for .txt files."""
    candidates = [",", "\t", "|", ";"]
    counts = {c: sample.count(c) for c in candidates}
    best, best_count = max(counts.items(), key=lambda kv: kv[1])
    if best_count == 0:
        raise IngestionError(
            "Could not detect a delimiter in .txt file. Pass `sep=...` explicitly."
        )
    return best


def _normalise_name(name: str) -> str:
    """Normalise a column name for fuzzy matching."""
    return re.sub(r"[\s\-]+", "_", str(name).strip().lower())


def _auto_column_map(columns: list[str]) -> dict[str, str]:
    """
    Build a {source_col: canonical_col} map using:
      1. exact match
      2. case/underscore-insensitive match
      3. alias table
    """
    mapping: dict[str, str] = {}

    canon_normalised = {_normalise_name(c): c for c in CANONICAL_SCHEMA}
    alias_normalised: dict[str, str] = {}
    for canonical, aliases in COLUMN_ALIASES.items():
        for a in aliases:
            alias_normalised[_normalise_name(a)] = canonical

    for col in columns:
        if col in CANONICAL_SCHEMA:
            mapping[col] = col
            continue
        norm = _normalise_name(col)
        if norm in canon_normalised:
            mapping[col] = canon_normalised[norm]
        elif norm in alias_normalised:
            mapping[col] = alias_normalised[norm]
    return mapping


def _normalise_asset_class(value: str) -> str | None:
    if value is None:
        return None
    key = _normalise_name(value)
    if key in ASSET_CLASS_ALIASES:
        return ASSET_CLASS_ALIASES[key]
    if value in VALID_ASSET_CLASSES:
        return value
    return None


def _coerce_and_validate(
    df: pd.DataFrame,
    *,
    strict: bool,
    drop_invalid_rows: bool,
) -> tuple[pd.DataFrame, dict[str, int], dict[str, int], list[str]]:
    rejected: dict[str, int] = {}
    coerced: dict[str, int] = {}
    warns: list[str] = []

    for col, spec in CANONICAL_SCHEMA.items():
        if col not in df.columns:
            continue

        # Type coercion
        dtype = spec.get("dtype")
        if dtype in ("int", "float"):
            before_nan = df[col].isna().sum()
            df[col] = pd.to_numeric(df[col], errors="coerce")
            after_nan = df[col].isna().sum()
            if after_nan > before_nan:
                warns.append(
                    f"{col}: {int(after_nan - before_nan):,} non-numeric values "
                    f"coerced to NaN."
                )
            if dtype == "int" and not df[col].isna().all():
                # Round and cast where possible (keep NaN)
                df[col] = df[col].round()
        elif dtype == "datetime64[ns]":
            # Best-effort date parsing — handles ISO, UK (DD/MM/YYYY), US,
            # and Excel serial dates without explicit format strings.
            before_nan = df[col].isna().sum()
            df[col] = pd.to_datetime(df[col], errors="coerce")
            after_nan = df[col].isna().sum()
            if after_nan > before_nan:
                warns.append(
                    f"{col}: {int(after_nan - before_nan):,} unparseable date "
                    f"values coerced to NaT."
                )

        # Range checks
        invalid_mask = pd.Series(False, index=df.index)
        if spec.get("min") is not None:
            invalid_mask |= df[col] < spec["min"]
        if spec.get("max") is not None:
            invalid_mask |= df[col] > spec["max"]
        if "allowed" in spec:
            invalid_mask |= ~df[col].isin(spec["allowed"]) & df[col].notna()

        n_invalid = int(invalid_mask.sum())
        if n_invalid:
            reason = f"out_of_range_in_{col}"
            if strict:
                raise IngestionError(
                    f"{n_invalid:,} rows have invalid values in {col!r}. "
                    f"Run with strict=False to drop them automatically."
                )
            rejected[reason] = rejected.get(reason, 0) + n_invalid
            if drop_invalid_rows:
                df = df[~invalid_mask].copy()
            else:
                df.loc[invalid_mask, col] = np.nan

        # Final dtype tightening for required ints (now safe — NaNs filtered)
        if dtype == "int" and spec.get("required") and not df[col].isna().any():
            df[col] = df[col].astype(int)

    return df, rejected, coerced, warns


def _fill_optional_defaults(df: pd.DataFrame) -> tuple[pd.DataFrame, dict[str, int]]:
    """Fill optional columns that are missing or all-NaN with sensible defaults."""
    filled: dict[str, int] = {}
    for col, spec in CANONICAL_SCHEMA.items():
        if spec.get("required"):
            continue
        if col not in df.columns:
            default = spec.get("default")
            if default is None:
                continue
            df[col] = default
            filled[col] = len(df)
            continue
        # Column is present but may have NaNs
        n_na = int(df[col].isna().sum())
        if n_na and "default" in spec and spec["default"] is not None:
            df[col] = df[col].fillna(spec["default"])
            filled[col] = n_na
    # annual_revenue special-case: if absent or all-NaN, leave it NaN — most
    # downstream notebooks don't require it, and forcing a fake number could
    # mislead the SME affordability checks.

    # vintage_quarter derivation: when origination_date is present and
    # parseable, derive the year-quarter string ("2023Q3"). This is what
    # the vintage chart in notebook 01 and the cohort breakdown in the
    # back-tester actually read.
    if "origination_date" in df.columns and df["origination_date"].notna().any():
        derived = df["origination_date"].dt.to_period("Q").astype(str)
        if "vintage_quarter" not in df.columns or df["vintage_quarter"].isna().all():
            df["vintage_quarter"] = derived
            filled["vintage_quarter"] = int(derived.notna().sum())
        else:
            # Fill only the NaN cells, preserve any explicit values
            mask = df["vintage_quarter"].isna()
            if mask.any():
                df.loc[mask, "vintage_quarter"] = derived[mask]
                filled["vintage_quarter"] = int(mask.sum())

    return df, filled

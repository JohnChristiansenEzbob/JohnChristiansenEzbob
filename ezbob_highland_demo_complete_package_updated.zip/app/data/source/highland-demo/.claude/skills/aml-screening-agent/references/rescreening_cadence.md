# Rescreening Cadence

Frequency at which existing customers must be rescreened against sanctions, PEP, and adverse media lists. Based on FCA expectations, JMLSG guidance, and standard industry practice for SME lending books.

## Risk tiers

Each customer carries a calculated AML risk tier based on:
- Sector (high-risk SIC y/n)
- Jurisdictional exposure (UBO chain, trading geography)
- Product (term loan vs invoice finance vs RCF — different velocity profiles)
- PEP status (any subject with PEP flag triggers tier escalation)
- Recent material changes

| Tier | Examples | Periodic rescreen | Event-driven |
|---|---|---|---|
| Standard | UK-only SME, low-risk SIC, no PEP, < £250k facility | Annual | Always |
| Elevated | Mid-risk SIC, UK-only, no PEP, > £250k | Semi-annual | Always |
| Enhanced | High-risk SIC OR foreign UBO chain OR > £1m | Quarterly | Always |
| EDD | PEP present OR high-risk jurisdiction OR sanctions near-miss history | Monthly | Always |

## Event-driven triggers (apply to all tiers)

Rescreen immediately when any of:

- **Sanctions list update.** OFSI consolidated list updates are typically weekly but can be intra-day on geopolitical events. Run the entire book against new entries within 24 hours of publication.
- **Material customer change.** New director, new UBO, change of control, change of registered office to a different jurisdiction, change of trading name.
- **Adverse media on a customer or its UBO.** A news monitoring feed flags an entity or individual already on the book.
- **Increase in facility / new product.** Treat as a new application for screening purposes.
- **Customer-initiated change** that introduces new natural persons (corporate restructuring, share issuance).

## How the agent encodes this

The agent's output `monitoring_schedule.next_screening_due` is the **earliest** of:
- The periodic cadence date
- The next known sanctions list publication date (worst case ~7 days)

`trigger_events` lists the change events that would also require an immediate rescreen, so the firm's CLM system can subscribe.

## Practical notes

The list-update sweep is computationally cheap (you compare the **delta** of the new list against the entire customer base, not the full lists), and it's the rescreening that catches more real hits than periodic scheduling, particularly during fast-moving sanctions episodes (Russia 2022, ongoing).

For the SME lending portfolio, the dominant cost is the false-positive triage, not the screening calls themselves. Investing in good name normalisation and structured triage rules pays back materially.

## Audit retention

Screening evidence (the call payload, the hit details, the disposition rationale) must be retained for 5 years after the customer relationship ends, per MLR 2017 Reg 40. Each rescreen produces a new evidence record — never overwrite the prior one.

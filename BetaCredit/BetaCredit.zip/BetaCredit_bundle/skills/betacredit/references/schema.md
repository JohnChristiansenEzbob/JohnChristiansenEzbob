# BetaCredit Canonical Schema

Every borrower row that flows through BetaCredit — whether ingested by notebook 00, scored by `CreditDecisionAgent`, or read from `df_all.parquet` — conforms to a fixed canonical schema of 24 columns. This file documents every column.

The schema is enforced by `risk_models.data_ingestion.ingest()`. Files in non-canonical formats are mapped via an alias table and validated against the ranges below; rows failing validation are rejected with an audit trail.

## Required columns (7)

A file without all seven of these fails ingestion outright.

| Field | Type | Range | Meaning |
|---|---|---|---|
| `asset_class` | category | 8 values | One of the eight canonical asset classes (see `asset_classes.md`). Aliases like "Mortgage", "BTL", "Auto", "Factoring" are recognised. |
| `bureau_score` | int | 300–999 | UK bureau score (Experian / Equifax / TransUnion scale). |
| `cashflow_coverage` | float | 0.0–10.0 | Debt-service coverage ratio (DSCR), or a DSCR-equivalent cashflow signal. |
| `ltv` | float | 0.0–1.5 | Loan-to-value. Use 0.0 for unsecured products. |
| `loan_amount` | float | > 0 | Drawn principal at origination, in pounds sterling. |
| `loan_term_months` | int | 1–600 | Contractual term in months. |
| `default_flag` | int | 0 or 1 | Default outcome in the observation window (1 = defaulted). |

## Optional columns (16)

Missing optional columns are filled with sensible defaults so the suite can run on incomplete data, with the ingestion report logging exactly which fields were defaulted.

| Field | Type | Range | Default | Used by |
|---|---|---|---|---|
| `num_prior_defaults` | int | 0–20 | 0 | PD model, RL agent |
| `months_since_adverse` | int | 0–9999 | 9999 (never) | PD model |
| `utilisation_rate` | float | 0.0–1.0 | asset-class mean | PD model |
| `gnn_connected_party_risk` | float | 0.0–1.0 | 0.5 | PD model (graph signal) |
| `open_banking_income_stability` | float | 0.0–1.0 | 0.7 | PD model |
| `months_banking_relationship` | int | 0–600 | 24 | PD model |
| `num_active_credit_lines` | int | 0–50 | 3 | PD model |
| `hmrc_revenue_match_ratio` | float | 0.0–2.0 | 1.0 | SME PD model |
| `time_in_business_months` | int | 0–600 | 60 | SME PD model |
| `vehicle_age_months` | int | 0–240 | 24 | Motor finance LGD |
| `invoice_dilution_rate` | float | 0.0–1.0 | 0.05 | Invoice finance LGD |
| `dpd` | int | 0–365 | 0 | SICR engine (Stage 1/2/3) |
| `forbearance_flag` | int | 0 or 1 | 0 | SICR engine |
| `gender` | string | M/F/Other | "Unknown" | Fairness analysis (nb 05) |
| `age_band` | string | <30, 30-50, 50+ | derived from `age_years` | Fairness analysis |
| `region` | string | UK region | "N England" | Fairness analysis |
| `origination_date` | datetime | any | — | Notebook 01 vintage chart, back-tester cohort breakdown |
| `vintage_quarter` | string | "YYYYQN" | auto-derived from `origination_date` | Same as above |
| `lgd_observed` | float | 0.0–1.0 | — | LGD model override (v1.2) |
| `collateral_value` | float | ≥ 0 | asset-class default | LGD model collateral component (v1.2) |
| `cure_prob` | float | 0.0–1.0 | asset-class default | LGD model cure-rate component (v1.2) |
| `recovery_costs` | float | 0.0–1.0 | asset-class default | LGD model costs component (v1.2) |
| `time_to_resolution_months` | int | 0–120 | asset-class default | LGD model discount component (v1.2) |

### Date handling

`origination_date` is recognised under many aliases — `open_date`, `origination_dt`, `start_date`, `drawdown_date`, `completion_date`, `loan_date`, `issue_date`, `date_originated`, `advance_date`, `booked_date`. Date parsing is best-effort via `pandas.to_datetime`; ISO (YYYY-MM-DD), UK (DD/MM/YYYY), US (MM/DD/YYYY), and Excel serial dates are all handled. Unparseable values become NaT with a warning in the ingestion report.

`vintage_quarter` is auto-derived from `origination_date` as `"YYYYQn"` (e.g. `"2023Q3"`). If you supply your own `vintage_quarter` column, it is used as-is.

## LGD component aliases (v1.2)

The five v1.2 LGD-component columns are recognised under several common names:

- `lgd_observed` ← `lgd`, `loss_given_default`, `observed_lgd`, `lgd_realised`, `lgd_actual`
- `collateral_value` ← `security_value`, `collateral_amount`, `property_value`, `secured_value`, `asset_value`
- `cure_prob` ← `cure_rate`, `cure_probability`, `prob_cure`, `cure_pct`
- `recovery_costs` ← `workout_costs`, `recovery_cost_pct`, `cost_to_recover`, `loss_costs`
- `time_to_resolution_months` ← `time_to_resolution`, `workout_months`, `recovery_time_months`, `ttr_months`

When any of the four component fields appear in the borrower row, the agent engages the LGD component formula instead of the asset-class default. When `lgd_observed` is present it overrides the formula entirely. See `references/lgd_components.md` for the formula and asset-class calibration.

## Helper functions

| Call | Returns |
|---|---|
| `describe_schema()` | DataFrame describing every field (dtype, range, default, description) |
| `validate_schema(df)` | List of human-readable schema violations, empty if df is conformant |
| `REQUIRED_COLUMNS` | Tuple of the 7 required field names |
| `VALID_ASSET_CLASSES` | Tuple of the 8 canonical asset-class strings |

## Common ingestion mistakes

- **Inverted polarity on `default_flag`.** If the file has 1 = good, 0 = bad, the ingester will warn about a 100% default rate and the PD model will be inverted. Flip before ingesting.
- **Unrecognised asset_class spelling.** "PCP" maps to motor_finance; "factoring" to invoice_finance; "owner_occupied" to residential_mortgage. Anything truly unrecognised raises `IngestionError`.
- **Synthesised demographic defaults distort fairness analysis.** If `gender`, `age_band`, or `region` are missing, the ingester fills them but the fairness report in notebook 05 will reflect those defaults rather than real demographics. Always check the IngestionResult report for "filled with defaults" entries against the protected attributes before running fairness diagnostics.

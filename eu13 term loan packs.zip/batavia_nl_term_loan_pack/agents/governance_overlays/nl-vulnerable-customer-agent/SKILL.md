---
name: nl-vulnerable-customer-agent
description: |
  Detect indicators of customer vulnerability — financial, health, life events, capability — and flag for enhanced support. For SME lending the principals can be vulnerable even where the company is not. Sole traders are particularly in scope.
---

# Vulnerable Customer Agent

Vulnerability is a AFM AFK 2.0 cross-cutting requirement. Many vulnerability signals are subtle; this agent looks across all signals consistently.

## Input contract

```yaml
vulnerability_check_request:
  case_id: string
  applicant_legal_form: enum                # limited_company | partnership | sole_trader
  principal_signals_per_director:
    - principal_id: string
      bureau_signals: [string]              # recent defaults, multiple credit applications, etc.
      application_signals: [string]         # life-event indicators in application text
      stated_vulnerabilities: [string]      # explicitly declared
```

## Output contract

```yaml
vulnerability_assessment:
  case_id: string
  vulnerability_flags:
    - principal_id: string
      flag_type: enum                       # financial | health | life_event | capability | digital_capability
      severity: enum                        # low | medium | high
      source: enum                          # bureau | application | declared | inferred
      treatment_marker: enum                # enhanced_support | clear_communication | extended_timeframe
  enhanced_support_required: boolean
  audit_ledger_entry_id: string
  reason_codes: [string]
```

## Decision logic

```
For each principal:
  Check bureau signals (recent defaults, multiple applications, etc.)
  Check application signals (life events in stated purpose, contact patterns)
  Check declared vulnerabilities

Sole traders + micro-businesses: principals' personal vulnerability is materially relevant.

If any flag at medium/high severity: enhanced_support_required = true.
```

## Worked example (Batavia Engineering B.V. case)

Input:
```yaml
vulnerability_check_request:
  case_id: "BAT-2026-04-001"
  applicant_legal_form: limited_company
  principal_signals_per_director:
    - principal_id: DIR-001
      bureau_signals: []
      application_signals: []
      stated_vulnerabilities: []
    - principal_id: DIR-002
      bureau_signals: []
      application_signals: []
      stated_vulnerabilities: []
```

Output:
```yaml
vulnerability_assessment:
  case_id: "BAT-2026-04-001"
  vulnerability_flags: []
  enhanced_support_required: false
  audit_ledger_entry_id: "VC-2026-04-12-HE-001"
  reason_codes: ["UK_VULNERABILITY_NO_FLAGS_STANDARD_HANDLING"]
```

No vulnerability flags for Highland's directors. Standard handling. Both directors are stable, well-established, no adverse signals.

## Bright lines

- (no statutory bright lines for this agent)

## Operational rules

- Vulnerability is a sensitive attribute — handle in line with DPA 2018 + AFM guidance
- Treatment markers are advisory to channel staff, not blocking
- Declared vulnerabilities are first-class — never override applicant's own statement

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Vulnerability signal but principal disputes | Record dispute; treat per applicant's preference |


## Netherlands-specific operational notes

This agent operates within the Dutch lending framework — DNB (prudential) and AFM (conduct) twin peaks supervision, Wft (Wet financieel toezicht) as foundational, BW Book 7 sections 57-73 for consumer credit, Wwft for AML.

- **Twin peaks supervision:** DNB handles prudential, AFM handles conduct. Operational engagement is with both, not unified. Different reporting cadences and supervisory styles.
- **BKR query:** Functional gate for consumer credit; AFM expects it. Stichting BKR governance includes member contribution + consultation.
- **NIBUD norms:** Operational affordability standard for consumer credit (Nationaal Instituut voor Budgetvoorlichting). AFM expects NIBUD adherence; deviations require documented justification.
- **NHG (Nationale Hypotheek Garantie):** State guarantee scheme for mortgages below €435,000 (2026 threshold); provides materially lower risk weight + rate. Eligibility independently verified.
- **LTI/LTV macroprudential limits:** Set by DNB; statutory and enforced. LTV typically 100% for first home, lower for subsequent; LTI tightened post-2013.
- **Aflossingsvrij mortgages:** Historically dominant interest-only product; affordability stress testing must account for non-amortising structure.
- **Cross-reference:** `country-nl-lending-policy-agent` provides full NL jurisdictional context.

## Statutory hooks

- AFM FG21/1 (Vulnerable Customers)
- AFM AFM AFK 2.0
- Equality Act 2010 (disability)
- Netherlands GDPR (special category data — health)

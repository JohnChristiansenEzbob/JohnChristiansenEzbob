import React, { useMemo, useState } from 'react';
import demoData from './data/demoData.js';
import './styles.css';

const initialCompanyProfile = {
  mode: 'replay',
  source: 'demo-companies-house-profile',
  httpStatus: 200,
  request: {
    method: demoData.companiesHouse.api_call.method,
    url: demoData.companiesHouse.api_call.demo_url,
    auth: 'server-side Basic auth header redacted'
  },
  profile: demoData.companiesHouse.demo_response,
  mappedFields: demoData.companiesHouse.mapped_fields
};

function App() {
  const [stepIndex, setStepIndex] = useState(0);
  const [mode, setMode] = useState('replay');
  const [uiSeed, setUiSeed] = useState(demoData.uiSeed);
  const [companyProfile, setCompanyProfile] = useState(initialCompanyProfile);
  const [lookupState, setLookupState] = useState('ready');
  const [adapterResponse, setAdapterResponse] = useState(null);

  const step = demoData.steps[stepIndex];
  const phase = demoData.phases.find(p => p.id === step.phaseId) || demoData.phases[0];
  const activeSkills = (step.highlightSkills || []).map(id => demoData.skills.find(s => s.id === id)).filter(Boolean);
  const activeSkill = activeSkills[0];
  const progress = ((stepIndex + 1) / demoData.steps.length) * 100;

  async function callCompaniesHouse(runMode = 'replay') {
    setLookupState('running');
    try {
      const res = await fetch('/api/company-profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ companyNumber: uiSeed.company_registration_number, mode: runMode })
      });
      const payload = await res.json();
      if (!res.ok) throw new Error(payload.error || 'Companies House lookup failed');
      setCompanyProfile(payload);
      setLookupState(runMode === 'live' && payload.mode === 'live' ? 'live-complete' : 'replay-complete');
    } catch (err) {
      setLookupState('fallback');
      setCompanyProfile({ ...initialCompanyProfile, note: `${err.message}. Falling back to deterministic replay profile.` });
    }
  }

  async function runLiveAdapter() {
    setMode('live');
    try {
      const res = await fetch('/api/start-application', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...uiSeed, mode: 'live' })
      });
      const payload = await res.json();
      setAdapterResponse(payload);
      if (payload.companyProfile) setCompanyProfile(payload.companyProfile);
    } catch (err) {
      setAdapterResponse({ status: 'fallback', note: 'Live adapter unavailable; deterministic replay remains active.', error: err.message });
    }
  }

  return (
    <div className="app">
      <div className="header">
        <div className="logo"><div className="logo-mark">e</div><div>ezbob <span className="product">{demoData.brand.product}</span></div></div>
        <div className="header-right">
          <button className="pill" onClick={() => setMode('replay')}>Replay mode</button>
          <button className="pill live" onClick={runLiveAdapter}>Live adapter</button>
          <div className="pill warn">Synthetic replay after CH</div>
          <div className="pill">Step {stepIndex + 1}/{demoData.steps.length}</div>
        </div>
      </div>
      <div className="progressbar"><div style={{ width: `${progress}%` }} /></div>
      <div className="main">
        <CasePanel companyProfile={companyProfile}/>
        <div className="panel center">
          <div className="focus">
            <Flow phaseId={step.phaseId}/>
            <h1>{step.title}</h1>
            <div className="sub">{phase.name} · {phase.subagent} · {phase.output || 'demo control'}</div>
            <FocusBody
              step={step}
              activeSkill={activeSkill}
              phase={phase}
              uiSeed={uiSeed}
              setUiSeed={setUiSeed}
              companyProfile={companyProfile}
              callCompaniesHouse={callCompaniesHouse}
              lookupState={lookupState}
              adapterResponse={adapterResponse}
            />
          </div>
        </div>
        <ActivityPanel phase={phase} activeSkillIds={step.highlightSkills || []}/>
      </div>
      <div className="caption"><div className="caption-label">CAPTION</div><div className="caption-text">{step.caption}</div></div>
      <div className="step-controls">
        <button className="pill" onClick={() => setStepIndex(Math.max(0, stepIndex - 1))}>Back</button>
        <button className="pill live" onClick={() => setStepIndex(Math.min(demoData.steps.length - 1, stepIndex + 1))}>Next</button>
      </div>
    </div>
  );
}

function CasePanel({ companyProfile }) {
  const m = demoData.metrics;
  const status = companyProfile?.profile?.company_status || demoData.companiesHouse.demo_response.company_status;
  return <div className="panel panel-pad">
    <div className="panel-title">Case file <span>{demoData.caseSummary.case_id}</span></div>
    <div className="case-name">{demoData.caseSummary.borrower}</div>
    <div className="case-id">Company {demoData.caseSummary.company_number} · CH status {status} · synthetic replay</div>
    <div className="metric-grid">{['Facility','Term','DSCR','PD 12m','LGD','Risk grade'].map(k => <div className="metric" key={k}><div className="metric-label">{k}</div><div className="metric-value">{m[k]}</div></div>)}</div>
    <div className="panel-title">UI seed used</div>
    <div className="mini-list">
      <div className="mini-item"><span className="dot"/><span><b>Company number</b><br/>{demoData.uiSeed.company_registration_number}</span></div>
      <div className="mini-item"><span className="dot"/><span><b>Primary applicant</b><br/>{demoData.uiSeed.applicant.name} · {demoData.uiSeed.applicant.date_of_birth}</span></div>
    </div>
    <div className="warning">Only the UI seed and Companies House profile are shown as connector data. The downstream credit journey remains synthetic replay until offer.</div>
  </div>;
}

function Flow({ phaseId }) {
  const ix = demoData.phases.findIndex(p => p.id === phaseId);
  return <div className="flow">{demoData.phases.slice(1).map((p, i) => <div key={p.id} className={`flow-card ${i < ix - 1 ? 'done' : ''} ${p.id === phaseId ? 'current' : ''}`}><div className="flow-num">{p.id === 'gov' ? 'G' : '0' + p.number}</div><div className="flow-name">{p.name}</div></div>)}</div>;
}

function SkillGrid({ active = [] }) {
  const set = new Set(active);
  return <div className="skill-grid">{demoData.skills.map(s => <div key={s.id} className={`skill-chip ${set.has(s.id) ? 'active' : ''} ${s.caseStatus === 'conditional' ? 'conditional' : ''}`}>{s.name}</div>)}</div>;
}

function SkillDetail({ skill }) {
  if (!skill) return null;
  return <>
    <h2>{skill.name}</h2>
    <p>{skill.description}</p>
    <div className="tag-row"><span className="tag green">{skill.caseStatus || 'active'}</span>{(skill.statutoryHooks || []).slice(0, 3).map(h => <span className="tag" key={h}>{h}</span>)}</div>
    <div className="logic">{skill.logic || skill.keyOutput}</div>
  </>;
}

function FocusBody(props) {
  const { step, activeSkill, phase, uiSeed, setUiSeed, companyProfile, callCompaniesHouse, lookupState, adapterResponse } = props;
  const grid = <SkillGrid active={step.highlightSkills}/>;

  if (step.view === 'uiSeed') return <TwoCards left={<UiSeedForm uiSeed={uiSeed} setUiSeed={setUiSeed}/>} right={<SeedPolicy/>}/>;
  if (step.view === 'companiesHouse') return <TwoCards left={<CompaniesHouseCall uiSeed={uiSeed} companyProfile={companyProfile} callCompaniesHouse={callCompaniesHouse} lookupState={lookupState}/>} right={<CompaniesHouseResponse companyProfile={companyProfile}/>}/>;
  if (step.view === 'workflowHandoff') return <TwoCards left={<WorkflowHandoff companyProfile={companyProfile}/>} right={<AdapterState adapterResponse={adapterResponse}/>}/>;
  if (step.view === 'decision') return <TwoCards left={<Conditions/>} right={<DecisionMetrics/>}/>;
  if (step.view === 'architecture') return <TwoCards left={<Architecture/>} right={grid}/>;
  if (step.view === 'phaseIntro') return <TwoCards left={<PhaseIntro phase={phase}/>} right={grid}/>;

  return <TwoCards left={activeSkill ? <SkillDetail skill={activeSkill}/> : <><h2>{phase.subagent}</h2><p>{phase.summary || step.body}</p><p><b>Output:</b> {phase.output}</p></>} right={grid}/>;
}

function TwoCards({ left, right }) {
  return <div className="focus-body"><div className="big-card">{left}</div><div className="big-card">{right}</div></div>;
}

function UiSeedForm({ uiSeed, setUiSeed }) {
  const applicant = uiSeed.applicant || {};
  const updateApplicant = (field, value) => setUiSeed({ ...uiSeed, applicant: { ...applicant, [field]: value } });
  return <>
    <h2>One-page intake seed</h2>
    <div className="form-grid compact-form">
      <label className="field"><span>Company registration number</span><input value={uiSeed.company_registration_number} onChange={e => setUiSeed({ ...uiSeed, company_registration_number: e.target.value })}/></label>
      <label className="field"><span>Applicant name</span><input value={applicant.name} onChange={e => updateApplicant('name', e.target.value)}/></label>
      <label className="field wide"><span>Applicant residential address</span><input value={applicant.residential_address} onChange={e => updateApplicant('residential_address', e.target.value)}/></label>
      <label className="field"><span>Applicant date of birth</span><input value={applicant.date_of_birth} onChange={e => updateApplicant('date_of_birth', e.target.value)}/></label>
    </div>
    <div className="warning">This page deliberately avoids loading the full profile file. It seeds only the agreed UI fields.</div>
  </>;
}

function SeedPolicy() {
  return <>
    <h2>Data split</h2>
    <div className="mini-list">
      <div className="mini-item"><span className="dot"/><span><b>From UI</b><br/>Company number, applicant name, address and date of birth.</span></div>
      <div className="mini-item"><span className="dot"/><span><b>From Companies House</b><br/>Public company profile, status, registered office, SIC and links.</span></div>
      <div className="mini-item"><span className="dot"/><span><b>Still synthetic</b><br/>Loan profile, credit metrics, security values, bureau data and offer.</span></div>
    </div>
    <div className="logic">{demoData.uiSeed.field_policy}</div>
  </>;
}

function CompaniesHouseCall({ uiSeed, companyProfile, callCompaniesHouse, lookupState }) {
  const url = demoData.companiesHouse.api_call.url_template.replace('{companyNumber}', uiSeed.company_registration_number);
  return <>
    <h2>Companies House connector</h2>
    <div className="request-card">
      <div className="method">GET</div>
      <div className="url">{url}</div>
    </div>
    <div className="logic">{`fetch('/api/company-profile', {\n  method: 'POST',\n  headers: { 'Content-Type': 'application/json' },\n  body: JSON.stringify({\n    companyNumber: '${uiSeed.company_registration_number}',\n    mode: 'live'\n  })\n})\n\n// Server-side outbound call:\nGET ${url}\nAuthorization: Basic base64(CH_API_KEY + ':')`}</div>
    <div className="button-row">
      <button className="pill" onClick={() => callCompaniesHouse('replay')}>Replay lookup</button>
      <button className="pill live" onClick={() => callCompaniesHouse('live')}>Live lookup</button>
    </div>
    <div className="smallnote">State: {lookupState} · current source: {companyProfile?.source}</div>
  </>;
}

function CompaniesHouseResponse({ companyProfile }) {
  const profile = companyProfile?.profile || demoData.companiesHouse.demo_response;
  return <>
    <h2>Profile mapped into KYB</h2>
    <div className="kv-list">
      <div><span>Company name</span><strong>{profile.company_name}</strong></div>
      <div><span>Status</span><strong>{profile.company_status}</strong></div>
      <div><span>Type / jurisdiction</span><strong>{profile.company_type} · {profile.jurisdiction}</strong></div>
      <div><span>Registered office</span><strong>{formatAddress(profile.registered_office_address)}</strong></div>
      <div><span>SIC</span><strong>{(profile.sic_codes || []).join(', ')}</strong></div>
    </div>
    <div className="warning">HTTP status, source and payload hash are ledgered. 401, 404 or inactive status pauses KYB in live mode.</div>
  </>;
}

function WorkflowHandoff({ companyProfile }) {
  const boxes = [
    ['UI seed', 'company number + applicant identity fields'],
    ['Companies House', `profile source: ${companyProfile?.source || 'replay'}`],
    ['Intake orchestrator', 'normalise and open case ledger'],
    ['Rest of journey', 'skills continue as replay until offer']
  ];
  return <><h2>Handoff map</h2><div className="handoff-list">{boxes.map((b, i) => <div className="handoff-step" key={b[0]}><div className="handoff-step-num">{i + 1}</div><div><strong>{b[0]}</strong><span>{b[1]}</span></div></div>)}</div></>;
}

function AdapterState({ adapterResponse }) {
  return <>
    <h2>Adapter contract</h2>
    <div className="logic">{JSON.stringify(adapterResponse || {
      endpoint: '/api/start-application',
      next: 'customer-onboarding-orchestrator',
      downstream: 'synthetic replay from Phase 1 to offer',
      companyHouse: '/api/company-profile'
    }, null, 2)}</div>
  </>;
}

function Architecture() {
  const boxes = [['Front-end UI','React lender operations screen'], ['Node API','Mode switch + CH connector'], ['Orchestrator','7 phases + governance'], ['Skills','36 specialist contracts'], ['Case ledger','JSON evidence files + audit']];
  return <><div className="arch">{boxes.map(b => <div className="arch-box" key={b[0]}><strong>{b[0]}</strong><span>{b[1]}</span></div>)}</div><div className="warning">Replay remains deterministic; live mode requires API credentials and production-grade access controls.</div></>;
}

function PhaseIntro({ phase }) {
  return <><h2>{phase.subagent}</h2><p>{phase.summary}</p><p><b>Ledger output:</b> {phase.output}</p><div className="tag-row">{(phase.skills || []).map(s => <span className="tag" key={s}>{s}</span>)}</div></>;
}

function Conditions() {
  return <div className="conditions">{demoData.conditions.map((c, i) => <div className="condition" key={c}><b>Condition {i + 1}</b><br/>{c}</div>)}</div>;
}

function DecisionMetrics() {
  return <><h2>Decision data</h2><div className="metric-grid">{Object.entries(demoData.metrics).map(([k, v]) => <div className="metric" key={k}><div className="metric-label">{k}</div><div className="metric-value">{v}</div></div>)}</div></>;
}

function ActivityPanel({ phase, activeSkillIds }) {
  const set = new Set(activeSkillIds);
  const skills = (phase.skills && phase.skills.length ? phase.skills : demoData.skills.map(s => s.id)).map(id => demoData.skills.find(s => s.id === id)).filter(Boolean);
  return <div className="panel panel-pad activity">
    <div className="panel-title">Agent activity stream <span>{phase.output}</span></div>
    <div className="activity-stream">{skills.slice(0, 8).map(s => <div key={s.id} className={`event ${set.has(s.id) ? 'active' : ''} ${s.caseStatus === 'conditional' ? 'cond' : ''}`}><div className="event-icon">{set.has(s.id) ? '▶' : '✓'}</div><div><div className="event-title">{s.name}</div><div className="event-desc">{s.keyOutput || s.description}</div></div></div>)}</div>
    <div className="panel-title" style={{ marginTop: 14 }}>Workflow contract</div>
    <div className="mini-list"><div className="mini-item"><span className="dot"/><span>UI seed and Companies House profile are ledgered before Phase 1.</span></div><div className="mini-item"><span className="dot"/><span>Each phase writes structured JSON before the next phase unlocks.</span></div><div className="mini-item"><span className="dot"/><span>Governance overlays remain visible to product, credit and engineering teams.</span></div></div>
  </div>;
}

function formatAddress(address = {}) {
  return [address.premises, address.address_line_1, address.address_line_2, address.locality, address.region, address.postal_code, address.country].filter(Boolean).join(', ');
}

export default App;

---
name: lu-lead-qualification-agent
description: |
  Policy-fit pre-screen for Luxembourg SME credit applications. Tests the inbound case against the lender's credit policy envelope — product range, amount band, prohibited sectors, geographic restrictions, broker accreditation status. Returns qualification outcome before any external data is pulled.
---

# Lead Qualification Agent

Cheap, fast pre-screen. Filter out applications that cannot possibly succeed under current policy before spending money on bureau pulls or ACD calls.

## Input contract

```yaml
qualification_request:
  case_id: string
  facility_type: enum
  facility_amount_eur: integer
  facility_term_months: integer
  applicant_company_number: string
  sic_codes: [string]                      # primary SIC code
  channel: enum
  broker_fca_reference: string             # nullable
  geographic_region: string                # GB-SCT, GB-ENG, GB-WLS, GB-NIR
```

## Output contract

```yaml
qualification_outcome:
  case_id: string
  outcome: enum                            # pass | refer | decline_policy
  product_match: string                    # specific product variant matched
  fail_reasons: [string]                   # populated if outcome != pass
  reason_codes: [string]
```

## Decision logic

```
if facility_amount_eur not in product.amount_band:
  outcome = decline_policy
  reason_codes += [UK_LEAD_AMOUNT_OUTSIDE_BAND]

if facility_term_months not in product.term_band:
  outcome = decline_policy
  reason_codes += [UK_LEAD_TERM_OUTSIDE_BAND]

if primary_sic_code in PROHIBITED_SECTORS:
  outcome = decline_policy
  reason_codes += [UK_LEAD_PROHIBITED_SECTOR]

if channel == "broker":
  if broker_fca_reference not in ACCREDITED_BROKERS:
    outcome = refer
    reason_codes += [UK_LEAD_BROKER_NOT_ACCREDITED]

if geographic_region not in COVERED_REGIONS:
  outcome = decline_policy
  reason_codes += [UK_LEAD_REGION_NOT_COVERED]

if outcome == None:
  outcome = pass
  product_match = match_product_variant(facility_type, amount, term)
```

## Worked example (Ardennes Engineering S.à r.l. case)

Input:
```yaml
qualification_request:
  case_id: "ARD-2026-04-001"
  facility_type: term_loan
  facility_amount_eur: 150000
  facility_term_months: 60
  applicant_company_number: "B 123456"
  sic_codes: ["71121"]
  channel: broker
  broker_fca_reference: "555444"
  geographic_region: "GB-SCT"
```

Output:
```yaml
qualification_outcome:
  case_id: "ARD-2026-04-001"
  outcome: pass
  product_match: "UK_term_loan_v3"
  fail_reasons: []
  reason_codes: ["UK_LEAD_QUALIFICATION_PASS"]
```

Highland's €150k 5-year term loan is well within product band (€25k-€500k, 12-84 months). SIC 71121 (engineering consulting) is not prohibited. Broker Highland Capital Partners is CSSF-accredited. Scotland is covered. Clear pass.

## Bright lines

- Prohibited sectors (e.g. crypto exchanges, gambling, adult content) — automatic decline_policy
- Sanctioned regions / jurisdictions — automatic decline_policy
- Non-accredited broker — automatic refer (cannot auto-approve via unaccredited channel)

## Operational rules

- Policy data (prohibited sectors, accredited brokers, regions) is versioned and loaded from a controlled config
- Pre-screen is cheap and synchronous — must complete within 200ms
- Policy changes require named credit-policy committee sign-off; the agent does not have discretion to override

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Policy config unavailable | Fail-safe to refer (do not auto-approve) |
| SIC code missing | Refer; cannot apply sector policy without it |
| Region inferable from registered office | Use registered office region as default |


## Luxembourg-specific operational notes

This agent operates within the Luxembourgish lending framework — CSSF as unified supervisor (banking, investment funds, payment services, insurance via CAA), with ECB SSM for significant institutions. Loi du 5 avril 1993 is the foundational banking law.

- **EU financial centre context:** Luxembourg's banking sector is heavily skewed toward private banking, fund administration, and cross-border services. Domestic consumer lending is a smaller proportion of activity than peer EU jurisdictions.
- **Trilingual jurisdiction:** French is primary for legal documents; German and Luxembourgish (Lëtzebuergesch) also constitutional. Customer-facing materials commonly trilingual.
- **CSSF supervisory style:** Investment fund and private banking focus means CSSF supervisory rhythm and reporting differs from peer prudential supervisors. Banking supervision sits within the unified CSSF.
- **Limited domestic credit visibility:** No central consumer credit register equivalent to FR FICP or BE CKP; lender visibility relies on bureau-by-bureau queries and Open Banking.
- **Cross-border banking:** Many lending applications involve cross-border structures (Belgian, German, French residents working in Luxembourg). KYB chains often complex.
- **Cross-reference:** `country-lu-lending-policy-agent` for full LU jurisdictional context (currently a stub in the Country Policy Pack).

## Statutory hooks

- CSSF CSSF customer protection framework (clear product-customer fit at first touch)
- Financial Promotions regime (lender must only offer products it advertises)

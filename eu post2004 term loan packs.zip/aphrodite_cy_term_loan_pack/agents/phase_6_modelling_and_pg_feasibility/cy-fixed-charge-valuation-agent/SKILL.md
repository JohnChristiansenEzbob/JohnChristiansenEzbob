---
name: cy-fixed-charge-valuation-agent
description: |
  Value proposed fixed charges over specific assets — commercial property (RICS Red Book
  methodology), chattels and equipment (secondary-market valuation), vehicles, and
  specific receivables (e.g. blocks assignment in invoice finance). Returns a forced-sale
  net realisable value per asset plus time-to-realise and enforcement cost estimate. Distinct
  from floating-charge-valuation-agent which addresses the whole asset base; this agent
  values each fixed asset specifically.
---

# Fixed Charge Valuation Agent

Fixed charges rank ahead of floating charges in distribution waterfall AND ahead of the
prescribed-part carve-out under s176A IA 1986. They are materially more valuable than
floating charges in default scenarios — but only if the asset valuation is realistic.

## Input contract

```yaml
fixed_charge_valuation_request:
  case_id: string
  proposed_fixed_charges:
    - asset_id: string
      asset_class: enum                        # commercial_property | chattel_equipment |
                                               # vehicles | residential_property | specific_receivables
      description: string
      declared_value_gbp: integer              # applicant's stated value
      valuation_evidence:
        - source: enum                         # RICS_valuation | supplier_quote | hmlr_index |
                                               # secondary_market_listing | applicant_estimate
          evidence_date: date
          evidence_value_gbp: integer
      age_years: float                         # for depreciable assets
      condition: enum                          # new | good | fair | poor
      proposed_rank: enum                      # first | second | third
  industry_sic_primary: string
  region: string
```

## Output contract

```yaml
fixed_charge_valuation:
  case_id: string
  per_asset_valuations:
    - asset_id: string
      asset_class: enum
      valuation_method: enum                   # RICS_red_book | chattel_secondary_market |
                                               # depreciation_curve | hmlr_index
      open_market_value_gbp: integer           # market value, willing buyer/seller
      forced_sale_value_gbp: integer           # constrained sale, typical 70-85% of OMV
      enforcement_costs_gbp: integer           # legal + agent + court fees
      net_realisable_gbp: integer              # forced_sale - enforcement_costs
      time_to_realise_months: integer
      rank_adjustment_applied: float
  total_net_realisable_fixed_gbp: integer
  reason_codes: [string]
```

## Decision logic

```
For each proposed fixed charge:

COMMERCIAL PROPERTY:
  Required: RICS Red Book valuation OR HMLR index-adjusted purchase price
  Open market value = best evidence
  Forced sale value = OMV × 0.80   (RICS typical forced-sale discount)
  Enforcement costs = max(€8,000, forced_sale × 0.06)
  Time to realise: 9-15 months

CHATTEL / EQUIPMENT:
  Required: supplier quote (new) OR secondary-market listing (used)
  Open market value:
    if new: declared_value × 0.95   (immediate depreciation on first use)
    if used: secondary_market_value
  Apply depreciation curve based on age:
    0-1y: 0.70 | 1-3y: 0.50 | 3-5y: 0.35 | 5-10y: 0.20 | >10y: 0.10
  Forced sale = open_market × 0.75   (chattel auction realises 70-80%)
  Enforcement costs = max(€3,000, forced_sale × 0.10)
  Time to realise: 2-4 months

VEHICLES:
  HPI / DVLA + secondary market check
  Forced sale = trade value (not retail)
  Enforcement costs = max(€500, forced_sale × 0.05)
  Time to realise: 1 month

RESIDENTIAL PROPERTY (where charged as security, rare for SME term loan):
  RICS valuation required
  Forced sale = OMV × 0.85
  Enforcement costs = max(€10,000, forced_sale × 0.07)
  Time to realise: 12-18 months
  ADDITIONAL: check for occupation rights, mortgagee priority

SPECIFIC RECEIVABLES (block assignment):
  Verified ageing required
  Realisable = aged < 90 days × 0.85 (collection in default with assignment)

Apply rank adjustment for second/third rank:
  second rank: net × 0.50 (prior creditor takes priority)
  third rank: net × 0.20

Sum total_net_realisable_fixed.
```

## Worked example (Aphrodite Engineering Ltd)

Input (lender takes fixed charge over the specific testing equipment to be acquired with the facility):
```yaml
fixed_charge_valuation_request:
  case_id: "APH-2026-04-001"
  proposed_fixed_charges:
    - asset_id: FX-001
      asset_class: chattel_equipment
      description: "Non-destructive testing equipment (phased array ultrasonic + radiographic) — Phased Array Cyprus Ltd"
      declared_value_gbp: 60000
      valuation_evidence:
        - source: supplier_quote
          evidence_date: "2026-03-28"
          evidence_value_gbp: 60000
      age_years: 0.0
      condition: new
      proposed_rank: first
  industry_sic_primary: "71121"
  region: "GB-SCT"
```

Output:
```yaml
fixed_charge_valuation:
  case_id: "APH-2026-04-001"
  per_asset_valuations:
    - asset_id: FX-001
      asset_class: chattel_equipment
      valuation_method: chattel_secondary_market
      open_market_value_gbp: 57000               # 60000 × 0.95 (immediate-use haircut)
      forced_sale_value_gbp: 42750               # 57000 × 0.75 chattel auction
      enforcement_costs_gbp: 4275                # 10% of forced sale
      net_realisable_gbp: 38475
      time_to_realise_months: 3
      rank_adjustment_applied: 1.0               # first rank, no adjustment
  total_net_realisable_fixed_gbp: 38475
  reason_codes: ["UK_FIXED_CHARGE_CHATTEL_NEW_EQUIPMENT_FIRST_RANK"]
```

The specific fixed charge over the testing equipment would realise approximately €38k in
a default scenario — about 25% of the facility. Note the chattel haircut sequence: 60k
declared → 57k OMV (immediate-use discount) → 43k forced sale (chattel auction) → 38k
net after enforcement costs. This is materially better than the same equipment sitting
under just the floating charge (where it would be subject to prescribed-part carve-out
and rank below preferential creditors).

If Highland's facility also took a charge over commercial property (which it doesn't —
they're leasing the new Nicosia office), the per-asset block would include a property
entry with RICS-based valuation.

## Bright lines

- Commercial property charge without RICS valuation — REFUSE valuation; require RICS Red Book before any reliance on the asset
- Chattel charge over assets that move or that the customer can dispose of without notice (vehicles in particular) — require additional registration / asset tracking; otherwise discount by 50%
- Specific receivables assignment with no verified debtor or no debtor consent — treat as floating, not fixed

## Operational rules

- RICS valuations have a 12-week shelf life; older valuations require revalidation
- Equipment age determined as at the date of perfection of the charge, not at application
- Forced-sale discounts policy-controlled; refreshed annually from realised outcomes
- The agent does NOT commission RICS valuations — it works from supplied evidence; if absent, refers to the underwriter

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| No valuation evidence beyond applicant declaration | Decline that asset's inclusion in security calculations |
| Evidence date >12 weeks for property | Require refresh |
| Asset class not in policy schedule | Refer; cannot value |
| Multiple charges over same asset claimed | Resolve rank from charges register; defer to charges-register-and-prior-security-agent for hierarchy |


## Cyprus-specific operational notes

Operates within the Cypriot framework — Central Bank of Cyprus + CySEC supervision, Consumer Credit Agreements Law, AML Law enforced via MOKAS.

- **ARTEMIS centrality:** ARTEMIS Bank Information Systems is the primary Cyprus credit bureau; operational relationship is essential.
- **Post-2013 crisis legacy:** The 2013 deposit bail-in left structural scars; borrower and depositor behaviour remains crisis-aware. Historical defaults common; distinguish current from legacy positions.
- **International business sector:** Large offshore/international company presence; KYB chains frequently involve cross-border structures requiring enhanced UBO scrutiny.
- **English in commerce:** English commonly accepted alongside Greek in commercial contracts.
- **Cross-reference:** `country-cy-lending-policy-agent` (Country Policy Pack stub).

## Statutory hooks

- Companies Act 2006 Part 25
- Law of Property Act 1925
- Bills of Sale Acts 1878-1882 (chattel mortgages — rarely used for businesses but relevant)
- RICS Red Book (valuation standards)
- Consumer Credit Agreements Law (where applicable to chattel security on sole-trader applicants)

# ezbob Highland Engineering Demo Package

This package contains the updated internal demo assets:

- `app/` — React/JavaScript and Node source.
- `app/intake-one-page.html` — one-page UI seed form that captures company number and applicant name/address/DOB, then calls the Companies House adapter.
- `app/standalone-demo.html` — self-contained replay UI used for the MP4.
- `app/data/case_state/HE-2026-04-001/ui_seed_payload.json` — representative UI seed ledger artefact.
- `app/data/case_state/HE-2026-04-001/companies_house_profile.json` — representative Companies House profile ledger artefact.
- `ezbob_highland_demo_video.mp4` — captioned MP4 walkthrough.
- `ezbob_highland_demo_explainer.docx` — detailed Word explainer.

The update addresses the requested feedback: use only a small set of fields from the UI, show the Companies House call, then let the rest of the synthetic Highland Engineering journey run unchanged through offer.

The video remains deterministic. Live Companies House lookup is supported by the Node adapter only when `COMPANIES_HOUSE_API_KEY` or `CH_API_KEY` is configured.

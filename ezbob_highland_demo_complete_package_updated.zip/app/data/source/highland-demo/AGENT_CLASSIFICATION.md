# Agent Classification — Skill vs Subagent

This document records the rationale for how each of the 36 original agents maps to Anthropic's two orchestration primitives in this Claude Code deployment.

## The principle

| Primitive | Use when… |
|---|---|
| **Skill** (`.claude/skills/<name>/SKILL.md`) | The agent is a deterministic capability — input → procedure → structured output. No context window of its own; lives inside the calling subagent's context. Cheap, composable, deterministic. |
| **Subagent** (`.claude/agents/<name>.md`) | The agent needs an isolated context window. Either (a) it's an orchestrator coordinating multiple skills, or (b) it does heavy reading the parent doesn't need to retain, or (c) it should run in parallel with other instances of itself. |

In this deployment, **all 36 original agents become Skills**. Their behaviour is procedural, deterministic, and contract-driven. The orchestration layer — what coordinates the journey, what runs in parallel, what holds state across phases — is implemented as **8 new phase-level Subagents** that I added.

The original 36 agents are kept verbatim. Nothing was rewritten.

## The 8 new subagents

These are the orchestration primitives. Each owns a phase (or the cross-cutting governance overlay), holds the working context for that phase, and invokes the skills that do the actual work.

| Subagent | Phase | Skills it invokes |
|---|---|---|
| `intake-coordinator` | 1 | `customer-onboarding-orchestrator`, `data-capture-agent`, `lead-qualification-agent` |
| `consent-purpose-coordinator` | 2 | `consent-management-agent`, `needs-discovery-agent`, `purpose-validation-agent` |
| `kyb-psc-coordinator` | 3 | `kyb-verifier`, `ubo-mapper`, `psc-complex-structure-recursor` (conditional) |
| `principal-verifier` (× N principals, in parallel) | 4 | `identity-orchestration-agent`, `aml-screening-agent`, `application-fraud-agent`, `director-financial-difficulty-checker`, `director-cross-directorship-checker` |
| `credit-data-assembler` | 5 | `bureau-orchestration-agent`, `open-banking-agent`, `hmrc-direct-verification-agent`, `alternative-data-agent`, `charges-register-and-prior-security-agent` |
| `risk-modeller` | 6 | `affordability-agent`, `pd-scoring-agent`, `floating-charge-valuation-agent`, `fixed-charge-valuation-agent`, `personal-guarantee-feasibility-agent`, `security-composite-agent`, `lgd-modelling-agent`, `ead-modelling-agent`, `risk-rating-agent` |
| `decision-maker` | 7 | `decision-pricing-agent`, `sme-pricing-strategy-agent` |
| `governance-auditor` | cross-cutting | `consumer-duty-outcomes-agent`, `fairness-monitoring-agent`, `vulnerable-customer-agent`, `model-inventory-agent`, `adverse-action-agent` (conditional) |

## Why this split, agent by agent

### Phase 1 — Intake (3 skills, 1 subagent)

- `customer-onboarding-orchestrator` → **Skill.** The original SKILL.md calls it a "control-flow primitive — does not perform external lookups or credit reasoning." Pure procedure; ideal skill shape.
- `data-capture-agent` → **Skill.** Schema normalisation. Stateless transform.
- `lead-qualification-agent` → **Skill.** Policy envelope check; deterministic.

### Phase 2 — Consent + Purpose (3 skills)

All three are procedural, no orchestration of other agents, all skills.

### Phase 3 — KYB + PSC (3 skills, conditional invocation)

- `kyb-verifier` → **Skill.** Companies House lookup + verdict.
- `ubo-mapper` → **Skill.** Standard PSC chain mapping. Returns a flag for whether to recurse.
- `psc-complex-structure-recursor` → **Skill.** This was a borderline call — recursion through corporate PSCs sounds like it might want its own context. In practice the input space is bounded (Companies House data) and the output is structured. Skill is the right fit; the recursion happens inside the skill's logic.

### Phase 4 — Per-principal verification (5 skills + 1 subagent)

- `multi-principal-fan-out-orchestrator` → **Subagent (`principal-verifier`).** This is the key architectural decision. The original SKILL.md describes coordinating parallel verification across all principals. In Anthropic's model, parallelism comes from spawning multiple subagents in one turn — so the fan-out is implemented at the **parent orchestrator** level (in `CLAUDE.md`), invoking N parallel instances of `principal-verifier`. Each instance handles one principal's full check set. Context isolation here is genuine: per-principal verification involves bureau pulls, fraud signals, directorship traces — lots of intermediate data the main orchestrator doesn't need to retain.
- `identity-orchestration-agent` → **Skill.** Despite the "orchestration" in the name, this orchestrates *external services* (document verification, biometric, electoral roll) not Claude agents. Skill shape.
- `aml-screening-agent`, `application-fraud-agent`, `director-financial-difficulty-checker`, `director-cross-directorship-checker` → **Skills.** All deterministic per-principal checks.

### Phase 5 — Credit data assembly (5 skills)

- `bureau-orchestration-agent` → **Skill.** Same reasoning as `identity-orchestration-agent` — orchestrates external bureau APIs, not Claude agents.
- `open-banking-agent`, `hmrc-direct-verification-agent`, `alternative-data-agent`, `charges-register-and-prior-security-agent` → **Skills.** Data pullers + structured outputs.

### Phase 6 — Modelling + security val + PG feasibility (9 skills)

This is the heaviest phase by skill count and the most dependency-laden. All nine are skills because each is a procedural calculation with a typed contract. The internal ordering (security composite must run before LGD) is enforced by the `risk-modeller` subagent's prompt, not by skill metadata.

### Phase 7 — Decision (2 skills)

- `decision-pricing-agent` → **Skill.** Synthesis function.
- `sme-pricing-strategy-agent` → **Skill.** Pricing overlay function.

### Governance overlays (5 skills)

All five are skills. The original architecture diagram shows them running "throughout" the journey. In a production deployment these would fire on each phase transition via SDK hooks. For the demo they are consolidated in the `governance-auditor` subagent which runs once at the end — easier to demonstrate, the same skills are invoked.

## Why nothing was rewritten

Each of the 36 original `SKILL.md` files is already in the canonical Skills format: YAML frontmatter with `name` and `description`, markdown body with input/output contracts and decision logic. They drop into `.claude/skills/` unchanged. The subagent layer was added on top; the original artefacts were not modified.

This matters for governance — if these skills represent reviewed and signed-off credit policy logic, you don't want to touch them to enable demonstration.

## The Anthropic platform constraint that shaped this design

Subagents in Claude Code **cannot spawn further subagents** (the `Agent` tool is not exposed inside a subagent's tool list). That means:

- A subagent CAN invoke skills freely.
- A subagent CANNOT invoke another subagent.
- Parallel fan-out (Phase 4) must happen at the **top-level orchestrator** — the parent spawns N subagents in one turn.

This is why `principal-verifier` is invoked from `CLAUDE.md` rather than from a Phase 4 wrapper subagent. The original `multi-principal-fan-out-orchestrator` description maps onto the parent orchestrator's behaviour, not onto a wrapping subagent.

If at some point Anthropic relaxes this constraint or you migrate to the Claude Agent SDK (where the same restriction applies but you have programmatic control over the agent loop), the architecture can stay essentially the same — only the parent of the parallel fan-out shifts.

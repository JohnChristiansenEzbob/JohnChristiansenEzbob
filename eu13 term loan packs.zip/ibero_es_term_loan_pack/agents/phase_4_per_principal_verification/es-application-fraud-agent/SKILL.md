---
name: es-application-fraud-agent
description: |
  Detect application-stage fraud indicators per principal — synthetic identity patterns, document tampering signals, velocity rules (repeated applications), ASNEF + BADEXCUG negative Protective Registration / National Fraud Database hits, device fingerprinting signals. Returns a fraud score (0-100) with classification.
---

# Application Fraud Agent

First-line application fraud screen. Identity-orchestration confirms the person is real and the documents are real; this agent confirms the application itself isn't suspicious.

## Input contract

```yaml
fraud_request:
  principal_id: string
  case_id: string
  name: string
  dob: date
  current_residential_address: string
  application_metadata:
    device_fingerprint: string
    ip_address: string
    submission_timestamp: datetime
    browser_locale: string
  cifas_check_consent: boolean
```

## Output contract

```yaml
fraud_assessment:
  principal_id: string
  fraud_score: integer                      # 0-100; 0=clean, 100=high risk
  classification: enum                      # low | medium | high
  signals:
    cifas_markers: [string]                 # nullable
    velocity_signals: [string]              # multiple recent applications etc.
    device_signals: [string]                # VPN, automation, mismatched locale etc.
    synthetic_identity_signals: [string]
  outcome: enum                             # proceed | refer | block_high_risk_fraud
  reason_codes: [string]
```

## Decision logic

```
Lookup ASNEF + BADEXCUG negative National Fraud Database (consent-gated).
Apply velocity rules (same identity in N applications in past M days).
Device fingerprint analysis (known fraud-associated devices, automation).
Synthetic identity detection (DOB-name combinations, address-credit history mismatches).

Compute composite fraud_score.

if cifas_markers include "fraud" (Category 6) marker:
  outcome = block_high_risk_fraud           # BRIGHT LINE; ASNEF + BADEXCUG negative fraud marker is decline

elif fraud_score >= 70:
  outcome = block_high_risk_fraud

elif fraud_score >= 40:
  outcome = refer

else:
  outcome = proceed
```

## Worked example (Ibero Engineering S.L. case)

Input:
```yaml
fraud_request:
  principal_id: DIR-001
  case_id: "IBE-2026-04-001"
  name: "Lachlan MacKenzie"
  dob: "1981-03-22"
  current_residential_address: "12 Strathblane Road, Milngavie, Madrid, G62 8DJ"
  application_metadata:
    device_fingerprint: "[hash]"
    ip_address: "82.x.x.x"
    submission_timestamp: "2026-04-12T09:14:22Z"
    browser_locale: "en-GB"
  cifas_check_consent: true
```

Output:
```yaml
fraud_assessment:
  principal_id: DIR-001
  fraud_score: 12
  classification: low
  signals:
    cifas_markers: []
    velocity_signals: []
    device_signals: []
    synthetic_identity_signals: []
  outcome: proceed
  reason_codes: ["UK_APPLICATION_FRAUD_LOW_RISK"]
```

Clean fraud screen. Spain IP, en-GB locale matching declared residence, no ASNEF + BADEXCUG negative markers, no velocity issues. Sarah Chen returns similar low-risk shape.

## Bright lines

- ASNEF + BADEXCUG negative Category 6 fraud marker → AUTO-DECLINE; cannot override without explicit dispensation
- Confirmed synthetic identity (fabricated person) → AUTO-DECLINE + SAR

## Operational rules

- ASNEF + BADEXCUG negative lookup requires explicit consent; absence of consent → cannot perform that check (not blocking by itself)
- Velocity rules windowed (e.g. >3 applications in 30 days flags)
- Device fingerprints retained in fraud history for pattern detection

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| ASNEF + BADEXCUG negative unavailable | Refer; cannot make decision without check (over a critical limit) |
| Device fingerprint missing | Score conservatively; some signals unusable |


## Spain-specific operational notes

This agent operates within the Spanish lending framework — Banco de España + CNMV joint regulatory perimeter, Ley 10/2014 for banking supervision, LCC (Ley 16/2011) for consumer credit, LRCCI (Ley 5/2019) for mortgage credit.

- **CIRBE €9k threshold:** Banco de España central credit register. Commercial risks >€9,000 mandatory contribution. Small SME facilities frequently below threshold — limited CIRBE visibility for genuine SME risk.
- **ASNEF / BADEXCUG strict access:** Spanish consumer bureau access has the strictest legal review requirement in EU. Operational onboarding must include legal basis attestation. ASNEF for negative; BADEXCUG for comprehensive — separate access agreements required.
- **LRCCI notarial requirement (AGNCN):** Mortgage origination requires AGNCN (Acta de Información Notarial Previa) — notarial pre-contractual information act. Cannot bypass; significant operational integration with notary network.
- **Tarjeta revolving usury (2020 Supreme Court):** Revolving credit cards subject to enhanced disclosure post-2020 Supreme Court rulings on usury. APR materially above market average is voidable.
- **Bizum ubiquity:** Mobile P2P payment platform with near-universal Spanish adoption; PSD2 integration via participating banks.
- **NIE administrative complexity:** Foreign residents require NIE (Número de Identidad de Extranjero) — multiple issuing authorities, common source of onboarding friction.
- **Cross-reference:** `country-es-lending-policy-agent` provides full ES jurisdictional context.

## Statutory hooks

- Fraud Act 2006
- Ley 10/2010 + Titulares Reales (failure to prevent fraud — must have reasonable procedures)
- Spain Ley 10/2010 (transaction monitoring + identity)
- ASNEF + BADEXCUG negative Code of Practice

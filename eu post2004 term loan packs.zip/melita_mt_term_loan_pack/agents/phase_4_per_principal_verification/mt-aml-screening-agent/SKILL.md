---
name: mt-aml-screening-agent
description: |
  Screen a single natural-person principal against sanctions lists (Maltese + EU consolidated list, UN, EU, US OFAC where applicable), Politically Exposed Persons (PEPs) registers, and adverse media. Returns clear / hit / review verdict.
---

# AML Screening Agent

Statutory AML screening. Every natural-person principal must be screened.

## Input contract

```yaml
aml_request:
  principal_id: string
  case_id: string
  name: string
  prior_names: [string]                     # nullable
  dob: date
  nationality: string
  country_of_residence: string
```

## Output contract

```yaml
aml_result:
  principal_id: string
  sanctions_check:
    ofsi: enum                              # clear | hit | review
    un: enum
    eu: enum
    ofac: enum                              # if scope warrants
  peps_check:
    status: enum                            # clear | domestic_pep | foreign_pep | family_close_associate
    pep_country: string                     # nullable
  adverse_media_check:
    status: enum                            # clear | minor | material
    sources: [string]                       # nullable
  composite_status: enum                    # clear | hit | review
  reason_codes: [string]
```

## Decision logic

```
Screen name (+ prior names) + DOB against:
  - Maltese + EU consolidated list (UK)
  - UN sanctions list
  - EU sanctions list
  - OFAC SDN list (where principal's nationality / residence in scope)
  - PEPs register (typically World-Check or similar)
  - Adverse media (last 5 years)

if ANY sanctions list returns a confirmed hit:
  composite_status = hit                     # BRIGHT LINE

elif PEPs status in [foreign_pep, family_close_associate]:
  composite_status = review                  # mandatory EDD

elif adverse_media_check.status == material:
  composite_status = review

else:
  composite_status = clear
```

## Worked example (Melita Engineering Ltd case)

Input:
```yaml
aml_request:
  principal_id: DIR-001
  case_id: "MEL-2026-04-001"
  name: "Lachlan MacKenzie"
  dob: "1981-03-22"
  nationality: "British"
  country_of_residence: "Scotland, Malta"
```

Output:
```yaml
aml_result:
  principal_id: DIR-001
  sanctions_check:
    ofsi: clear
    un: clear
    eu: clear
    ofac: clear
  peps_check:
    status: clear
    pep_country: null
  adverse_media_check:
    status: clear
    sources: []
  composite_status: clear
  reason_codes: ["UK_AML_CLEAR_ALL_LISTS"]
```

Clean AML screen. Both principals return clear across all lists. If a sanctions hit had appeared, the multi-principal-fan-out-orchestrator would aggregate to block_and_sar (bright line).

## Bright lines

- Maltese + EU consolidated list hit → BLOCK (mandatory under Malta financial sanctions regime)
- UN / EU / OFAC hit (within applicable jurisdictional scope) → BLOCK
- Tipping-off rule: customer-facing communication must not reveal the underlying reason

## Operational rules

- Fuzzy matching with name variations + transliteration handled by the screening engine
- Confirmed hits require MLRO sign-off before any case action
- False positives recorded with disposition for future model tuning
- PEPs status is not a decline trigger per se but mandates enhanced due diligence (EDD)

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Screening engine unavailable | Refer; cannot proceed without screening |
| Match returned with low confidence | Manual review by MLRO; do not auto-block or auto-clear |


## Malta-specific operational notes

Operates within the Maltese framework — MFSA supervision, Consumer Credit Regulations, PMLA enforced via FIAU.

- **Post-greylisting scrutiny:** Malta was FATF grey-listed 2021-2022 (since removed). AML/CFT expectations remain elevated; enhanced CDD operationally consequential, especially for international business clients.
- **iGaming + international sectors:** Large remote gaming and international business presence; KYB chains often involve cross-border structures and require enhanced UBO scrutiny.
- **English co-official:** English is co-official and dominant in financial services; contracts commonly in English.
- **Small domestic bureau market:** Limited domestic consumer bureau; CRIF and CreditSafe provide coverage; Central Bank of Malta operates the Central Credit Register.
- **Cross-reference:** `country-mt-lending-policy-agent` (Country Policy Pack stub).

## Statutory hooks

- Malta Prevention of Money Laundering Act (PMLA)
- Malta Sanctions and Anti-Money Laundering Act 2018
- Financial Sanctions Notice (Maltese + EU)
- MFSA SYSC 6.3
- Proceeds of Crime Act 2002 (POCA) — tipping-off and SAR obligations

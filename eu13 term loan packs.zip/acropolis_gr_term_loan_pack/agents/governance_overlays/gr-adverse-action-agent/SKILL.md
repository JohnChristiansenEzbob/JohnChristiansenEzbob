---
name: gr-adverse-action-agent
description: |
  Generate decline / refer reason codes in both regulatory taxonomy and customer-facing language. Triggered when decision-pricing-agent renders a decline or refer outcome. Ensures the right-to-explanation under Greece GDPR Article 22 is fulfilled and the LSB-compliant decline notice is prepared.
---

# Adverse Action Agent

When the answer is no, the customer (and any future ombudsman / Greek Ombudsman review) is entitled to know why. Adverse-action handles the why.

## Input contract

```yaml
adverse_action_request:
  case_id: string
  decision_outcome: enum                    # refer | decline
  decline_reasons: [string]                 # regulatory taxonomy reason codes
  decline_reasons_evidence:                 # which upstream agents raised each reason
    - reason_code: string
      origin_agent: string
      evidence_pointer: string
```

## Output contract

```yaml
adverse_action_output:
  case_id: string
  customer_facing_decline_letter_text: string
  reason_codes_internal: [string]
  reason_codes_customer: [string]           # plain-English translations
  right_to_explanation_text: string
  appeal_route_text: string
  bank_referral_scheme_eligibility: boolean # if declined & lender is designated
  audit_ledger_entry_id: string
  reason_codes: [string]
```

## Decision logic

```
For each regulatory reason_code:
  Look up canonical customer-facing translation.

Compose decline letter:
  - Outcome statement (clear, plain English)
  - Reasons (top 3-5, prioritised by materiality)
  - Right to explanation + request channel
  - Appeal route
  - Bank Referral Scheme notice if applicable
  - Vulnerability-aware language adjustments

Set bank_referral_scheme_eligibility based on lender designation + outcome.
```

## Worked example (Acropolis Engineering AE case)

Input:
```yaml
(not triggered for Highland — accept outcome.
This agent would fire if outcome had been refer or decline.)
```

Output:
```yaml
(not triggered for Highland — accept outcome.
Example shape for a hypothetical decline:

adverse_action_output:
  case_id: "ACR-2026-04-001"
  customer_facing_decline_letter_text: "..."
  reason_codes_customer:
    - "Your business's recent trading performance does not currently meet our affordability requirements."
    - "There is an existing charge on the company that would need to be released before we could provide new funding."
  right_to_explanation_text: "..."
  appeal_route_text: "..."
  bank_referral_scheme_eligibility: true)
```

Not triggered for Highland (accept outcome). Documented here for completeness — would fire on refer / decline path.

## Bright lines

- Tipping-off cases: decline letter must NOT reveal underlying suspicion
- Customer-facing reasons cannot be more specific than regulatory codes allow

## Operational rules

- Plain English required (Flesch Reading Ease >= 60)
- Reasons prioritised by materiality, not first-discovered
- Vulnerability-aware language for flagged principals
- Appeal route must be a real working channel, not a black hole

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Reason code with no customer translation | Generic + escalate translation to product |
| Decline reasons inconsistent | Refer to compliance |


## Greece-specific operational notes

This agent operates within the Greek lending framework — Bank of Greece supervisory perimeter, Banking Law 5021/2023, Law 4557/2018 for AML, post-2010 crisis NPL legacy materially shaping market structure.

- **TIRESIAS centrality:** Both consumer and commercial credit bureau roles operationally consolidated in TIRESIAS. Operational relationship is essential — no Greek consumer credit decision is meaningful without TIRESIAS visibility.
- **Post-crisis NPL legacy:** Substantial Greek NPL portfolio sold to specialist servicers (intrum, Cepal, doValue, Quant Servicer). Borrowers may have historical defaults; current creditworthiness assessment must distinguish current from historical positions.
- **Katseli Law (3869/2010):** Over-indebted households framework allowing court-supervised debt restructuring. Operationally consequential — borrowers with Katseli filings have specific protections; lending decisions must account.
- **AFM ubiquity:** Tax Registration Number (AFM) is the universal Greek financial identifier; required for any account-opening, lending, or property transaction.
- **Tax clearance certificate:** Operational must-have for business credit — proof of current tax compliance with AADE.
- **Cross-reference:** `country-gr-lending-policy-agent` for full GR jurisdictional context (currently a stub in the Country Policy Pack).

## Statutory hooks

- Greece GDPR Article 22 (right to explanation for automated decisions)
- BoG BoG consumer protection (consumer understanding outcome)
- Hellenic Bank Association standards for Business Customers
- SBEE Act 2015 (Bank Referral Scheme on decline)

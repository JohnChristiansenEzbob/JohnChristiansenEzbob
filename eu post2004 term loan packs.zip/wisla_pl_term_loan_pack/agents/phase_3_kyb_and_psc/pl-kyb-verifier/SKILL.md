---
name: pl-kyb-verifier
description: |
  Verify the applicant company at KRS (Krajowy Rejestr Sądowy) — active status, registered office currency, accounts filing currency, no strike-off proposed. Establishes the foundational fact that the company is a real, currently-trading legal entity.
---

# KYB Verifier

Foundational KYB. Everything downstream assumes the company is real and active. Cheap, fast, and decisive.

## Input contract

```yaml
kyb_request:
  case_id: string
  company_number: string
```

## Output contract

```yaml
kyb_result:
  case_id: string
  company_number: string
  status: enum                              # active | dissolved | liquidation | proposed_for_strike_off | not_found
  incorporation_date: date
  age_months: integer
  registered_office: string
  registered_office_verified: boolean
  sic_codes: [string]
  accounts_filing_status: enum              # up_to_date | overdue | first_accounts_pending
  last_accounts_made_up_to: date            # nullable
  next_accounts_due: date                   # nullable
  confirmation_statement_status: enum
  outcome: enum                             # verified | refer_filings_overdue | block_dissolved_or_strike_off
  reason_codes: [string]
```

## Decision logic

```
KRS (Krajowy Rejestr Sądowy) API call by company_number.

if status in [dissolved, liquidation]:
  outcome = block_dissolved_or_strike_off

elif status == proposed_for_strike_off:
  outcome = block_dissolved_or_strike_off    # BRIGHT LINE

elif status == not_found:
  outcome = block_dissolved_or_strike_off
  reason_codes += [UK_COMPANIES_HOUSE_NOT_FOUND]

elif accounts_filing_status == overdue:
  outcome = refer_filings_overdue            # not a hard block but material

else:
  outcome = verified
```

## Worked example (Wisła Engineering Sp. z o.o. case)

Input:
```yaml
kyb_request:
  case_id: "WIS-2026-04-001"
  company_number: "KRS 0000123456"
```

Output:
```yaml
kyb_result:
  case_id: "WIS-2026-04-001"
  company_number: "KRS 0000123456"
  status: active
  incorporation_date: "2017-09-14"
  age_months: 102
  registered_office: "Suite 4, 2 Atlantic Quay, Warszawa, G2 8GA"
  registered_office_verified: true
  sic_codes: ["71121"]
  accounts_filing_status: up_to_date
  last_accounts_made_up_to: "2025-09-30"
  next_accounts_due: "2026-06-30"
  confirmation_statement_status: up_to_date
  outcome: verified
  reason_codes: ["UK_KYB_ACTIVE_CURRENT_FILINGS"]
```

Highland is active, 102 months old (past the high-risk early years), accounts up to date, confirmation statement filed. Clean verification.

## Bright lines

- Company dissolved or in liquidation → BLOCK; no facility can be advanced
- Company proposed for strike-off → BLOCK pending applicant explanation
- Company not found at KRS (Krajowy Rejestr Sądowy) → BLOCK; suspect fraud

## Operational rules

- KRS (Krajowy Rejestr Sądowy) data is authoritative for legal status
- Registered office must match the applicant-declared trading address sufficiently (or have valid explanation)
- Accounts overdue is a material refer signal but not always a decline (recent incorporation, ongoing extension request)

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| KRS (Krajowy Rejestr Sądowy) API timeout | Refer; retry |
| Company number invalid format | Block; data-capture should have caught this |
| Registered office unverified (PO Box, virtual office) | Refer; require physical trading address |


## Poland-specific operational notes

Operates within the Polish framework — KNF + NBP supervision, Consumer Credit Act, Mortgage Credit Act, AML Act enforced via GIIF.

- **BIK centrality:** Biuro Informacji Kredytowej is the largest CEE credit bureau and central to Polish consumer + SME lending. Comprehensive coverage; operational relationship essential.
- **CHF mortgage litigation legacy:** Poland's Swiss-franc mortgage saga has produced a massive ongoing court caseload (borrower-favourable CJEU + Supreme Court rulings). FX lending to unhedged retail borrowers carries litigation tail risk; legacy CHF books remain contentious.
- **Express Elixir instant payments:** Operational instant settlement; widely used.
- **profil zaufany / mojeID:** Polish e-government identity used for online onboarding.
- **PLN currency:** Outside Eurozone; floating. FX consideration material for larger facilities.
- **Cross-reference:** `country-pl-lending-policy-agent` (Country Policy Pack stub).

## Statutory hooks

- Companies Act 2006
- CRBR (Centralny Rejestr Beneficjentów Rzeczywistych) (KRS (Krajowy Rejestr Sądowy) register integrity)
- Poland AML Act

# PSC Classification Reference

The UK Persons with Significant Control regime (Companies Act 2006 Part 21A, in force from 6 April 2016, expanded 26 June 2017) defines five conditions under which a person is a PSC. The Companies House register encodes these as `nature_of_control` strings.

## The five conditions

1. **Ownership of shares** — directly or indirectly holds more than 25% of the shares
2. **Voting rights** — directly or indirectly holds more than 25% of the voting rights
3. **Right to appoint or remove a majority of the board** of directors
4. **Right to exercise, or actually exercises, significant influence or control** over the company
5. **Significant influence or control over a trust or firm** which itself meets one of conditions 1–4

## Banded reporting

Conditions 1 and 2 are reported in bands, not exact percentages:

| Band | String suffix |
|---|---|
| > 25% but ≤ 50% | `_25_to_50_pct` |
| > 50% but ≤ 75% | `_50_to_75_pct` |
| > 75% | `_75_to_100_pct` |

Example values from the Companies House API:
- `ownership-of-shares-25-to-50-percent`
- `ownership-of-shares-50-to-75-percent`
- `ownership-of-shares-75-to-100-percent`
- `voting-rights-25-to-50-percent`
- `voting-rights-50-to-75-percent`
- `voting-rights-75-to-100-percent`
- `right-to-appoint-and-remove-directors`
- `significant-influence-or-control`

## Computing effective ownership

For propagation through corporate chains, use the **midpoint** of the declared band as the working percentage, with band edges retained for sensitivity:

| Band | Midpoint | Lower | Upper |
|---|---|---|---|
| 25–50% | 37.5 | 25 | 50 |
| 50–75% | 62.5 | 50 | 75 |
| 75–100% | 87.5 | 75 | 100 |

Multiply midpoints through the chain. Aggregate across multiple paths to the same individual.

A person is a UBO at the 25% threshold if **either**:
- Their summed effective ownership (using midpoints) is ≥ 25%, **or**
- Any single path reaches them with a band that crosses 25% at the lower edge

Edge case: a chain of two 50%-stakes gives a midpoint of 39%, which crosses the threshold. A chain of two 25–50% bands gives midpoint 14% but the upper edge is 25%, so the individual is a "potential UBO" (worth listing as a minor beneficial owner with pct band 0–25).

## Relevant Legal Entities (RLEs)

A corporate shareholder counts as an RLE — and therefore terminates the recursion under simplified due diligence — only if **all** of the following hold:

1. It would itself be a PSC of the company under the standard tests, AND
2. It is itself **subject to disclosure obligations** (UK PSC regime, EEA equivalent, OECD jurisdiction with PSC-equivalent disclosure), AND
3. It either:
   - Has its voting shares admitted to trading on a regulated market in the UK or EEA (or specified equivalents — see JMLSG), OR
   - Is a UK-incorporated company keeping its own PSC register, OR
   - Is a UK-regulated firm (FCA / PRA register entry)

If only (1) and (2) hold, the entity is **registrable but not exempt** — recurse anyway.

## Other Registrable Persons (ORPs)

Any other entity (typically non-UK corporates outside the EEA equivalent regimes) that meets the PSC test but is not an RLE. Companies House records them as PSCs, but the responsibility to identify the underlying natural persons rests with the customer's due diligence — pull them from foreign corporate registries where available, otherwise flag `UBO_FOREIGN_CHAIN_UNVERIFIABLE`.

## Statements and "no PSC" cases

Companies House also records PSC-related statements:

- `no-individual-or-entity-with-signficant-control` (yes, the typo is in the official enum) — emit `UBO_NO_PSC_REGISTERED`
- `psc-exists-but-not-identified` — flag as INCOMPLETE
- `psc-details-not-confirmed` — flag as INCOMPLETE
- `psc-contacted-but-no-response` — flag as INCOMPLETE
- `restrictions-notice-issued-to-psc` — HARD flag for AML; suggests obstruction

## Senior Managing Official (SMO) fallback

Where no individual meets the 25% threshold under any condition, MLR 2017 Reg 6(9)(b)(ii) requires identifying the senior managing official (typically the CEO or chair). Pull from the active officers list; record their role explicitly so the AML screen knows to treat them as the residual UBO rather than as an ordinary director.

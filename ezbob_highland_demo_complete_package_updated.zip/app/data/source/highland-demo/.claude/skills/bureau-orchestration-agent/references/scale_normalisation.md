# Bureau Scale Normalisation

Each commercial credit bureau has its own grade scale. The blender produces a unified ezbob scale (0–100 numeric, A–E band) that downstream agents consume. This document records the mapping and the rationale.

## The unified ezbob blended scale

| Band | Numeric range | Plain-English |
|---|---|---|
| A | 80–100 | Very low risk |
| B | 65–79 | Low risk |
| C | 50–64 | Moderate risk |
| D | 35–49 | Elevated risk |
| E | 0–34 | High risk |

The numeric scale is monotone: higher = lower default risk. The bands are designed to align (approximately) with PD bands of < 1%, 1–3%, 3–7%, 7–15%, > 15% on a 12-month horizon for the SME population.

## Per-bureau mapping

### Experian (Commercial Delphi)

Experian commercial scores typically run 0–100, with their own band structure ("Very Low", "Low", "Below Average", "Average", "Above Average", "High Risk", "Maximum Risk"). Map as:

| Experian band | Experian score range | ezbob numeric | ezbob band |
|---|---|---|---|
| Very Low Risk | 81–100 | 90 | A |
| Low Risk | 51–80 | 72 | B |
| Below Average | 26–50 | 55 | C |
| Average | 16–25 | 45 | D |
| Above Average / High | 6–15 | 30 | E |
| Maximum / Caution | 0–5 | 15 | E |

The midpoint mapping gives a reasonable starting calibration. Re-anchor against ezbob's own bad-rate experience quarterly.

### Equifax (Risk Score Plus / business rating)

Equifax produces a numerical score plus a 1–100 risk rating. Use the risk rating (higher = lower risk, like the ezbob scale).

| Equifax rating | ezbob numeric | ezbob band |
|---|---|---|
| 81–100 | direct map (subtract 0) | A |
| 61–80 | direct map | B |
| 41–60 | direct map | C |
| 26–40 | direct map | D |
| 0–25 | direct map | E |

Roughly 1:1 numerically; band edges differ slightly. Re-anchor quarterly.

### CreditSafe

CreditSafe uses a 0–100 score plus a band ("Very Low", "Low", "Moderate", "High", "Not Recommended").

| CreditSafe band | Score range | ezbob numeric | ezbob band |
|---|---|---|---|
| Very Low Risk | 71–100 | 85 | A |
| Low Risk | 51–70 | 68 | B |
| Moderate Risk | 30–50 | 50 | C |
| High Risk | 21–29 | 40 | D |
| Not Recommended | 0–20 | 18 | E |

### Dun & Bradstreet (D&B)

D&B's Failure Score (1–100, higher = lower risk) plus a Rating (e.g. "5A1"). Use the Failure Score for numeric blending; the alpha-numeric Rating goes into evidence, not the blender.

| D&B Failure Score | ezbob numeric | ezbob band |
|---|---|---|
| 81–100 | direct map | A |
| 61–80 | direct map | B |
| 41–60 | direct map | C |
| 21–40 | direct map | D |
| 0–20 | direct map | E |

## Blending arithmetic

Default `weighted_consensus` uses fixed weights from the firm's policy file. As of the current calibration:

| Bureau | Weight | Rationale |
|---|---|---|
| Experian | 0.40 | Strongest UK SME commercial coverage and depth of trade data |
| CreditSafe | 0.35 | Best filed-accounts coverage at the smaller end; complements Experian on micros |
| Equifax | 0.20 | Used primarily for director consumer files; weight reflects narrower commercial role |
| D&B | 0.05 | Used for international or large-corporate exposure; rare in SME book |

Where a bureau didn't return a match, redistribute its weight pro-rata across the bureaux that did. If all return blanks, emit `BUREAU_NEITHER_COMMERCIAL_MATCHED` and let `decision-pricing-agent` decide whether to refer or decline-without-bureau.

## Disagreement classification

Compute the standard deviation of the per-bureau ezbob-numeric scores across bureaux that returned a value:

| Stddev | Classification | Action |
|---|---|---|
| 0–7 | Aligned | Blend numerically |
| 7–14 | Minor | Blend, flag |
| 14+ | Material | Do not auto-blend; emit `BUREAU_MATERIAL_DISAGREEMENT`; refer |

For the ezbob 0–100 scale, a stddev of 14 is roughly equivalent to one full grade band of disagreement.

## Calibration cadence

Re-anchor the per-bureau mappings quarterly. Inputs:
- ezbob's own 12-month default rate by bureau-supplied band (vintaged)
- Movement in any bureau's own scoring methodology (bureaux do periodically recalibrate)
- Material change in the SME population mix

Calibration changes are versioned. Every blender output carries `version` so historical decisions can be replayed against the version of the blender that produced them — important for both regulatory replay rights and model risk lineage under PRA SS1/23.

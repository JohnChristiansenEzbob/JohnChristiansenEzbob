---
name: nl-alternative-data-agent
description: |
  Pull supplementary financial data from accounting platforms (Xero, QuickBooks, Sage) and trade-data providers. Returns recent management accounts, gross margin, overdue payables/receivables, and any other structured operational data the applicant has chosen to share.
---

# Alternative Data Agent

Closes the gap between filed accounts (9-12 months old) and Belastingdienst data. Management accounts give the most recent picture of operating performance.

## Input contract

```yaml
alt_data_request:
  case_id: string
  applicant_company_number: string
  platforms_connected: [enum]               # xero | quickbooks | sage
  consent_token: string
```

## Output contract

```yaml
alt_data_summary:
  case_id: string
  platforms_used: [enum]
  revenue_ttm_gbp: integer
  gross_margin_pct: float
  operating_profit_ttm_gbp: integer
  overdue_payables_gbp: integer
  overdue_receivables_gbp: integer
  days_sales_outstanding: integer
  inventory_value_gbp: integer              # nullable; goods-based businesses only
  ttm_end_period: date
  reason_codes: [string]
```

## Decision logic

```
For each connected platform:
  - pull last 12 months of P&L
  - pull aged debtors + creditors
  - pull inventory if applicable

Reconcile against bureau + OB:
  - revenue_ttm vs OB credits — should be close (within 15%)
  - if material divergence → flag for downstream cross-check
```

## Worked example (Batavia Engineering B.V. case)

Input:
```yaml
alt_data_request:
  case_id: "BAT-2026-04-001"
  applicant_company_number: "12345678"
  platforms_connected: [xero]
  consent_token: "TKN-alt-xero-2026-04-12"
```

Output:
```yaml
alt_data_summary:
  case_id: "BAT-2026-04-001"
  platforms_used: [xero]
  revenue_ttm_gbp: 854100
  gross_margin_pct: 41.2
  operating_profit_ttm_gbp: 118400
  overdue_payables_gbp: 4200
  overdue_receivables_gbp: 11800
  days_sales_outstanding: 38
  inventory_value_gbp: null
  ttm_end_period: "2026-03-31"
  reason_codes: ["UK_ALT_DATA_XERO_CURRENT_PERIOD_RETRIEVED"]
```

Xero gives the very recent picture: €854k revenue TTM (matches Belastingdienst VAT €851k and OB €847k credits — excellent consistency), 41.2% gross margin, modest overdues. Strong operational picture.

## Bright lines

- (no statutory bright lines for this agent)

## Operational rules

- Cross-reference revenue against Belastingdienst VAT (where available) and OB credits — 15%+ delta is investigative
- Service businesses: gross margin proxied; inventory will be null
- Multiple platforms connected: aggregate consistently or flag discrepancy

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Platform connection broken (token expired) | Refer; user must reconnect |
| Data appears stale (last sync > 90 days) | Use but flag staleness |


## Netherlands-specific operational notes

This agent operates within the Dutch lending framework — DNB (prudential) and AFM (conduct) twin peaks supervision, Wft (Wet financieel toezicht) as foundational, BW Book 7 sections 57-73 for consumer credit, Wwft for AML.

- **Twin peaks supervision:** DNB handles prudential, AFM handles conduct. Operational engagement is with both, not unified. Different reporting cadences and supervisory styles.
- **BKR query:** Functional gate for consumer credit; AFM expects it. Stichting BKR governance includes member contribution + consultation.
- **NIBUD norms:** Operational affordability standard for consumer credit (Nationaal Instituut voor Budgetvoorlichting). AFM expects NIBUD adherence; deviations require documented justification.
- **NHG (Nationale Hypotheek Garantie):** State guarantee scheme for mortgages below €435,000 (2026 threshold); provides materially lower risk weight + rate. Eligibility independently verified.
- **LTI/LTV macroprudential limits:** Set by DNB; statutory and enforced. LTV typically 100% for first home, lower for subsequent; LTI tightened post-2013.
- **Aflossingsvrij mortgages:** Historically dominant interest-only product; affordability stress testing must account for non-amortising structure.
- **Cross-reference:** `country-nl-lending-policy-agent` provides full NL jurisdictional context.

## Statutory hooks

- Netherlands GDPR / DPA 2018
- AFM AFM AFK 2.0 (use of accurate, recent data)

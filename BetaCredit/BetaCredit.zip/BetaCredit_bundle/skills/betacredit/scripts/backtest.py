#!/usr/bin/env python3
"""
backtest.py — back-test a CreditDecisionAgent policy against a labelled
book of loans and print precision/recall, AUC, profit at policy, threshold
sweep, and cohort breakdowns.

Usage:
    # Basic — uses default thresholds and economics
    python backtest.py path/to/loans.parquet

    # Custom approval profit and default loss
    python backtest.py path/to/loans.parquet \\
        --approval_profit 1500 --default_loss 12000

    # Save the per-threshold sweep and per-vintage breakdown to CSVs
    python backtest.py loans.parquet --threshold_csv th.csv --vintage_csv v.csv
"""
from __future__ import annotations
import argparse
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent.parent
sys.path.insert(0, str(ROOT / "backend"))

import pandas as pd

from risk_models import CreditDecisionAgent, BackTestEconomics
from risk_models.data_ingestion import ingest


def load_loans(path: str) -> pd.DataFrame:
    p = Path(path)
    if p.suffix.lower() == ".parquet":
        return pd.read_parquet(p)
    return ingest(path).dataframe


def main() -> int:
    ap = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ap.add_argument("path", help="Path to the labelled loan file")
    ap.add_argument("--approval_profit", type=float, default=1200.0,
                    help="Profit per approved good loan (£)")
    ap.add_argument("--default_loss",    type=float, default=8500.0,
                    help="Loss per approved defaulter (£)")
    ap.add_argument("--threshold_csv",   help="Save threshold sweep to CSV")
    ap.add_argument("--vintage_csv",     help="Save vintage breakdown to CSV")
    ap.add_argument("--asset_csv",       help="Save asset-class breakdown to CSV")
    args = ap.parse_args()

    df = load_loans(args.path)
    print(f"Loaded {len(df):,} loans from {args.path}")
    if "default_flag" not in df.columns:
        print("Error: default_flag column required for back-testing.",
              file=sys.stderr)
        return 2

    eco = BackTestEconomics(
        approval_profit=args.approval_profit,
        default_loss_per_loan=args.default_loss,
    )
    agent = CreditDecisionAgent()
    result = agent.backtest(df, economics=eco)

    print()
    print(result.summary())
    print()
    print("Threshold sweep (DECLINE-threshold relative shift in %):")
    print(result.by_threshold.to_string(index=False))

    if result.by_vintage is not None:
        print()
        print("Vintage breakdown:")
        print(result.by_vintage.to_string(index=False))

    if result.by_asset_class is not None:
        print()
        print("Asset class breakdown:")
        print(result.by_asset_class.to_string(index=False))

    if args.threshold_csv:
        result.by_threshold.to_csv(args.threshold_csv, index=False)
        print(f"\nThreshold sweep → {args.threshold_csv}")
    if args.vintage_csv and result.by_vintage is not None:
        result.by_vintage.to_csv(args.vintage_csv, index=False)
        print(f"Vintage breakdown → {args.vintage_csv}")
    if args.asset_csv and result.by_asset_class is not None:
        result.by_asset_class.to_csv(args.asset_csv, index=False)
        print(f"Asset class breakdown → {args.asset_csv}")

    return 0


if __name__ == "__main__":
    sys.exit(main())

---
name: pt-lgd-modelling-agent
description: |
  Estimate Loss Given Default — the percentage of exposure expected to be lost if the borrower defaults. Combines security position (from charges-register), personal guarantee feasibility (from pg-feasibility), and recovery model assumptions to produce a forward-looking LGD.
---

# LGD Modelling Agent

LGD drives both expected credit loss (IFRS 9) and risk-based pricing. Get LGD wrong and pricing is wrong.

## Input contract

```yaml
lgd_request:
  case_id: string
  facility_amount_eur: integer
  proposed_security_type: enum
  charges_register_outcome: object          # from charges-register-and-prior-security-agent
  pg_feasibility_outcomes: [object]         # per-guarantor; from personal-guarantee-feasibility-agent
  industry: string                          # SIC code; influences recovery on liquidation
```

## Output contract

```yaml
lgd_estimate:
  case_id: string
  lgd_baseline_pct: float                   # before PG enforcement
  lgd_with_pg_pct: float                    # after PG realisation
  recovery_components:
    floating_charge_realisation_gbp: integer
    pg_realisation_attributable_gbp: integer
    industry_recovery_assumption_pct: float
  model_version: string
  reason_codes: [string]
```

## Decision logic

```
expected_facility_at_default = facility_amount * EAD_factor  # from ead-modelling-agent
expected_recovery_from_floating = (floating_charge_position_value * industry_recovery_factor)
expected_recovery_from_pg = sum(pg_feasibility.net_realisable_pg_cover_lower)

if NO PG:
  lgd_with_pg = lgd_baseline
else:
  lgd_with_pg = max(0, (EAD - expected_recovery_from_floating - expected_recovery_from_pg) / EAD)
```

## Worked example (Lusitânia Engineering Lda. case)

Input:
```yaml
lgd_request:
  case_id: "LUS-2026-04-001"
  facility_amount_eur: 150000
  proposed_security_type: term_loan_debenture
  charges_register_outcome:
    new_lender_rank: first
    estimated_recovery_at_default_gbp: 92000
  pg_feasibility_outcomes:
    - principal_id: DIR-001
      net_realisable_pg_cover_lower_bound_gbp: 113100
    - principal_id: DIR-002
      net_realisable_pg_cover_lower_bound_gbp: 158000
  industry: "71121"
```

Output:
```yaml
lgd_estimate:
  case_id: "LUS-2026-04-001"
  lgd_baseline_pct: 0.38
  lgd_with_pg_pct: 0.28
  recovery_components:
    floating_charge_realisation_gbp: 92000
    pg_realisation_attributable_gbp: 90000   # capped at PG amount per principal
    industry_recovery_assumption_pct: 0.61
  model_version: "SME_LGD_v2.1"
  reason_codes: ["UK_LGD_28_PCT_WITH_PGS_IN_PLACE"]
```

Baseline LGD 38% — after first-rank floating charge realisation. PGs from both directors take LGD down to 28%. Substantial recovery uplift from PGs, which justifies the PG requirement.

## Bright lines

- (no statutory bright lines for this agent)

## Operational rules

- PG realisation is capped at the PG face value per principal
- Industry recovery assumptions refreshed annually based on portfolio actuals
- Boland-triggered PG cover: discount to lower bound × 0.6 (Etridge process risk)
- Cross-validate against historical portfolio LGDs in same SIC band

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| No PG and no security | LGD baseline at industry mean — typically high (>60%) |
| Recovery assumptions inconsistent with industry data | Refer model risk for review |


## Portugal-specific operational notes

This agent operates within the Portuguese lending framework — BdP and CMVM joint regulatory perimeter, Decreto-Lei 298/92 (Regime Geral das Instituições de Crédito) for banking, Decreto-Lei 133/2009 for consumer credit, Lei 83/2017 for AML.

- **CRC €50 threshold:** Banco de Portugal central credit register has the broadest visibility threshold in the EU — effectively covers all consumer credit and almost all commercial credit. Mandatory contribution + consultation. Operationally raises the visibility floor significantly above Spanish CIRBE (€9k), Italian Centrale dei Rischi (€30k).
- **Statutory TAEG ceiling:** BdP publishes quarterly TAEG (APR) caps per consumer credit category. Exceeding is contract invalidity — not just disclosure issue.
- **Cartão de Cidadão integration:** Portuguese citizen card is the operational gold standard for EU national ID — integrates national ID + tax + social security + electoral + health on one card. Strong eID infrastructure.
- **e-fatura mandatory e-invoicing:** Creates rich verification source for SME turnover. Tax invoices are real-time matched with SAFT-PT submissions.
- **SIBS API Market:** Portuguese banking infrastructure provides standardised PSD2 interface — reduces AISP integration complexity vs. peer EU jurisdictions.
- **MB Way mobile payment:** Operationally ubiquitous; SIBS-operated mobile P2P + e-commerce payment.
- **Cross-reference:** `country-pt-lending-policy-agent` provides full PT jurisdictional context.

## Statutory hooks

- BdP model risk supervision + ECB SREP (model risk management)
- IFRS 9 (ECL calculation)
- Basel III/IV (capital — internal models where applicable)

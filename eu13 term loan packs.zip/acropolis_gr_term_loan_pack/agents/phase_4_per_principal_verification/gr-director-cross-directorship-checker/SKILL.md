---
name: gr-director-cross-directorship-checker
description: |
  Trace each director's other directorships across Greece active and dissolved companies via
  GEMI (General Commercial Registry) director search. Identify cross-default risk (linked companies in arrears
  with this lender), phoenix-director patterns (serial company failures with same director),
  and concentration patterns (portfolio director vs synthetic-entity fraud). Returns
  classification per director: clean | monitor | phoenix_risk | cross_default_risk.
---

# Director Cross-Directorship Checker

## Input contract

```yaml
principal_id: string
name: string
dob: date                                 # used with month+year for CH director search keying
current_residential_address: string
lender_portfolio_lookup_consent: boolean  # internal lookup against own arrears book
```

## Output contract

```yaml
cross_directorship_assessment:
  principal_id: string
  total_lifetime_directorships: integer
  active_directorships: integer
  dissolved_with_insolvency_count_7y: integer
  strike_off_count_7y: integer
  same_trade_after_dissolution: boolean
  cross_default_active_arrears_lender_portfolio: boolean
  diverse_sic_code_count: integer
  classification: enum                    # clean | monitor | phoenix_risk | cross_default_risk | portfolio_director
  reason_codes: [string]
```

## Decision logic

```
GEMI (General Commercial Registry) director search by name + DOB month/year.
For each directorship: fetch company status + incorporation/dissolution dates.
Compute pattern metrics.

if dissolved_with_insolvency_count_7y >= 2 OR same_trade_after_dissolution:
  classification = phoenix_risk           # BRIGHT LINE — refer to underwriter

elif strike_off_count_7y >= 3:
  classification = phoenix_risk

elif cross_default_active_arrears_lender_portfolio:
  classification = cross_default_risk     # BRIGHT LINE — decline pending override

elif active_directorships >= 5 AND diverse_sic_code_count >= 4:
  classification = portfolio_director     # Not negative; understand pattern

elif active_directorships >= 2:
  classification = monitor

else:
  classification = clean
```

## Worked example (Lachlan MacKenzie — DIR-001)

Input:
```yaml
principal_id: DIR-001
name: "Lachlan MacKenzie"
dob: "1981-03-22"
current_residential_address: "12 Strathblane Road, Milngavie, Athens, G62 8DJ"
lender_portfolio_lookup_consent: true
```

Output:
```yaml
cross_directorship_assessment:
  principal_id: DIR-001
  total_lifetime_directorships: 1
  active_directorships: 1
  dissolved_with_insolvency_count_7y: 0
  strike_off_count_7y: 0
  same_trade_after_dissolution: false
  cross_default_active_arrears_lender_portfolio: false
  diverse_sic_code_count: 1
  classification: clean
  reason_codes: ["UK_DIRECTOR_CROSS_DIRECTORSHIP_CLEAN"]
```

Sarah Chen has 2 active directorships (this + a dormant family company) and identical
clean classification — does not meet portfolio-director threshold (5+).

## Bright lines

- `classification = phoenix_risk` → AUTOMATIC REFER. Phoenix patterns are a leading UK
  SME fraud signal; cannot auto-approve.
- `classification = cross_default_risk` (active arrears in lender's own portfolio) →
  AUTOMATIC DECLINE pending underwriter override.

## Operational rules

- Director name matching is fuzzy. Under-include rather than over-include where ambiguous
  (false positives are worse than false negatives in director matching).
- Multiple directorships in genuinely different groups ≠ phoenix; require explicit
  dissolution-with-insolvency pattern.
- Audit log must include the full directorship list (company numbers), not just the
  classification.


## Greece-specific operational notes

This agent operates within the Greek lending framework — Bank of Greece supervisory perimeter, Banking Law 5021/2023, Law 4557/2018 for AML, post-2010 crisis NPL legacy materially shaping market structure.

- **TIRESIAS centrality:** Both consumer and commercial credit bureau roles operationally consolidated in TIRESIAS. Operational relationship is essential — no Greek consumer credit decision is meaningful without TIRESIAS visibility.
- **Post-crisis NPL legacy:** Substantial Greek NPL portfolio sold to specialist servicers (intrum, Cepal, doValue, Quant Servicer). Borrowers may have historical defaults; current creditworthiness assessment must distinguish current from historical positions.
- **Katseli Law (3869/2010):** Over-indebted households framework allowing court-supervised debt restructuring. Operationally consequential — borrowers with Katseli filings have specific protections; lending decisions must account.
- **AFM ubiquity:** Tax Registration Number (AFM) is the universal Greek financial identifier; required for any account-opening, lending, or property transaction.
- **Tax clearance certificate:** Operational must-have for business credit — proof of current tax compliance with AADE.
- **Cross-reference:** `country-gr-lending-policy-agent` for full GR jurisdictional context (currently a stub in the Country Policy Pack).

## Statutory hooks

- Law 4548/2018 (Societies Anonymous)
- Insolvency Act 1986
- Company Directors Disqualification Act 1986
- Greece Law 4557/2018
- Law 4557/2018 + Central Register of Beneficial Owners (failure to prevent fraud)

---
name: si-consent-management-agent
description: |
  Capture, validate, and issue scoped consent tokens for all downstream data pulls — commercial bureau, consumer bureau (per director), Open Banking, FURS MTD APIs, Zemljiška knjiga. Records consent provenance and provides a revocation handle.
---

# Consent Management Agent

Without valid scoped consent, downstream agents cannot pull external data lawfully. This agent is the consent gatekeeper.

## Input contract

```yaml
consent_request:
  case_id: string
  applicant_company_number: string
  director_principal_ids: [string]
  scopes_requested:
    - bureau_commercial
    - bureau_consumer_per_director
    - open_banking
    - hmrc_mtd_vat
    - hmrc_mtd_paye
    - hmrc_mtd_ct
    - land_registry_named_directors
  consent_capture_evidence:                 # signed forms or e-sign payloads
    - scope: string
      evidence_type: enum                   # signed_form | esign | api_callback
      timestamp: datetime
      ip_address: string                    # for online consent
      signature_hash: string
```

## Output contract

```yaml
consent_token_bundle:
  case_id: string
  tokens:
    - scope: string
      token_id: string
      issued_at: datetime
      expires_at: datetime
      revocation_handle: string
      evidence_pointer: string              # link to audit evidence
  scopes_granted: [string]
  scopes_refused: [string]
  outcome: enum                             # complete | partial | consent_required
```

## Decision logic

```
For each scope_requested:
  Find matching consent_capture_evidence entry.
  Validate evidence (signature, timestamp recency, IP if online).
  If valid:
    Issue scoped token with appropriate expiry (24h to 90 days depending on scope).
    Append to tokens list.
  Else:
    Append to scopes_refused.

if all requested scopes granted: outcome = complete
elif some granted: outcome = partial
else: outcome = consent_required
```

## Worked example (Triglav Engineering d.o.o. case)

Input:
```yaml
consent_request:
  case_id: "TRI-2026-04-001"
  applicant_company_number: "1234567000"
  director_principal_ids: ["DIR-001", "DIR-002"]
  scopes_requested:
    - bureau_commercial
    - bureau_consumer_per_director
    - open_banking
    - hmrc_mtd_vat
    - hmrc_mtd_paye
    - hmrc_mtd_ct
    - land_registry_named_directors
  consent_capture_evidence:
    - scope: bureau_commercial
      evidence_type: esign
      timestamp: "2026-04-12T09:14:22Z"
      ip_address: "82.x.x.x"
      signature_hash: "[hash]"
    # (similar entries for other 6 scopes)
```

Output:
```yaml
consent_token_bundle:
  case_id: "TRI-2026-04-001"
  tokens:
    - scope: bureau_commercial
      token_id: "TKN-bureau-com-2026-04-12-001"
      issued_at: "2026-04-12T09:14:30Z"
      expires_at: "2026-07-11T09:14:30Z"
      revocation_handle: "REV-001"
    # (similar entries for other 6 tokens)
  scopes_granted: [bureau_commercial, bureau_consumer_per_director, open_banking,
                   hmrc_mtd_vat, hmrc_mtd_paye, hmrc_mtd_ct, land_registry_named_directors]
  scopes_refused: []
  outcome: complete
```

All 7 scopes granted with e-signed evidence. Tokens issued with scope-appropriate expiries (bureau 90d; FURS ties to MTD OAuth lifecycle; Zemljiška knjiga per-query).

## Bright lines

- Consent without evidence (no signed form, no e-sign hash) — cannot issue token; refused
- Consent older than scope-specific staleness threshold — refused; require refresh

## Operational rules

- Tokens are scope-specific — never issue a single token covering multiple scopes
- Revocation handles are issued at token issuance; revocation propagates within 60 seconds
- Consent evidence is retained for 6 years post-relationship (DPA 2018 + Banka Slovenije record-keeping)
- IP-based fraud signals (unusual location, VPN exit nodes) flagged but not blocking

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| No evidence for requested scope | Refuse that scope only; other scopes unaffected |
| Evidence signature invalid | Refuse; alert to fraud agent |
| Evidence timestamp in future | Refuse; clock-skew investigation |


## Slovenia-specific operational notes

Operates within the Slovenian framework — Banka Slovenije supervision, Consumer Credit Act, AML Act.

- **SISBON + SISBIZ dual registers:** Bank of Slovenia operates both the consumer (SISBON) and commercial (SISBIZ) credit registers — strong centralised visibility.
- **First post-2004 Eurozone member (2007):** EUR-denominated; no FX consideration.
- **EMŠO universal identifier:** Unique Master Citizen Number; restricted-use under GDPR.
- **AJPES:** Central registry agency for company + UBO data.
- **Cross-reference:** `country-si-lending-policy-agent` (Country Policy Pack stub).

## Statutory hooks

- Slovenia GDPR Article 6 (lawful basis) + Article 7 (consent conditions)
- Data Protection Act 2018
- PSD2 / Open Banking RTS (consent requirements for account access)
- Finance Act 2017 (FURS MTD consent scope)

---
name: pt-affordability-agent
description: |
  Compute BdP + CMVM-compliant affordability: monthly repayment burden against free cash flow, debt service coverage ratio (DSCR), surplus income after commitments. For term loans, uses TTM cash flow from AT + OB + alt data as the base. Returns a compliant / non-compliant verdict with the calculation evidence.
---

# Affordability Agent

Statutory affordability test. The decision-pricing-agent cannot proceed to accept without an affordability pass.

## Input contract

```yaml
affordability_request:
  case_id: string
  facility_amount_eur: integer
  facility_term_months: integer
  indicative_rate_pct: float                # tentative; will be refined post-decision
  ob_summary: object                        # from open-banking-agent
  hmrc_record: object                       # from hmrc-direct-verification-agent
  alt_data_summary: object                  # from alternative-data-agent
  existing_facility_burden_gbp_per_month: integer
  proposed_repayment_structure: enum        # capital_and_interest | interest_only_then_bullet | bullet
```

## Output contract

```yaml
affordability_assessment:
  case_id: string
  monthly_repayment_gbp: integer
  ttm_revenue_gbp: integer
  ttm_operating_cash_flow_gbp: integer
  ttm_existing_debt_service_gbp: integer
  ttm_free_cash_flow_gbp: integer
  dscr: float
  surplus_after_repayment_gbp_per_month: integer
  fca_compliant: boolean
  outcome: enum                             # affordable | marginal | unaffordable
  stress_test_passed: boolean               # at rate +200bps
  reason_codes: [string]
```

## Decision logic

```
monthly_repayment = annuity(facility_amount, term, indicative_rate)
ttm_operating_cash_flow = best estimate from AT profit + OB net + alt data operating profit
ttm_free_cash_flow = ttm_operating_cash_flow - ttm_existing_debt_service
dscr = ttm_free_cash_flow / (12 * monthly_repayment)

stress_rate = indicative_rate + 2.0%
stress_monthly = annuity(facility_amount, term, stress_rate)
stress_dscr = ttm_free_cash_flow / (12 * stress_monthly)

if dscr >= 1.25 AND stress_dscr >= 1.10:
  outcome = affordable; fca_compliant = true
elif dscr >= 1.10 AND stress_dscr >= 1.00:
  outcome = marginal; fca_compliant = true
else:
  outcome = unaffordable; fca_compliant = false
```

## Worked example (Lusitânia Engineering Lda. case)

Input:
```yaml
affordability_request:
  case_id: "LUS-2026-04-001"
  facility_amount_eur: 150000
  facility_term_months: 60
  indicative_rate_pct: 8.4
  existing_facility_burden_gbp_per_month: 1100  # for the €38k existing facility to be cleared
  proposed_repayment_structure: capital_and_interest
```

Output:
```yaml
affordability_assessment:
  case_id: "LUS-2026-04-001"
  monthly_repayment_gbp: 3070
  ttm_revenue_gbp: 851300
  ttm_operating_cash_flow_gbp: 92700
  ttm_existing_debt_service_gbp: 13200
  ttm_free_cash_flow_gbp: 74400              # net of existing facility being cleared at drawdown
  dscr: 2.02
  surplus_after_repayment_gbp_per_month: 3130
  fca_compliant: true
  outcome: affordable
  stress_test_passed: true
  reason_codes: ["UK_AFFORDABILITY_AFFORDABLE_DSCR_2_02"]
```

Strong affordability. DSCR 2.02x — twice the cover. Stress test at 10.4% still passes. Existing facility cleared at drawdown so debt service decreases net.

## Bright lines

- dscr < 1.0 stressed → AUTOMATIC DECLINE (cannot demonstrate affordability under stress)
- Free cash flow negative or zero → AUTOMATIC DECLINE
- BdP + CMVM-compliant calculation methodology must be documented in audit log

## Operational rules

- Use the LOWER of AT profit + OB cash flow + alt data — conservatism
- Stress test at +200bps minimum (some lenders use +300bps for term > 60m)
- If facility has phased drawdown, model based on full-drawn position

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Cash flow data inconsistent across AT/OB/alt | Refer; manual reconciliation needed |
| No AT data available (recently incorporated) | Refer; cannot rely on OB alone for affordability |
| Existing debt service unverifiable | Conservative estimate; flag for verification |


## Portugal-specific operational notes

This agent operates within the Portuguese lending framework — BdP and CMVM joint regulatory perimeter, Decreto-Lei 298/92 (Regime Geral das Instituições de Crédito) for banking, Decreto-Lei 133/2009 for consumer credit, Lei 83/2017 for AML.

- **CRC €50 threshold:** Banco de Portugal central credit register has the broadest visibility threshold in the EU — effectively covers all consumer credit and almost all commercial credit. Mandatory contribution + consultation. Operationally raises the visibility floor significantly above Spanish CIRBE (€9k), Italian Centrale dei Rischi (€30k).
- **Statutory TAEG ceiling:** BdP publishes quarterly TAEG (APR) caps per consumer credit category. Exceeding is contract invalidity — not just disclosure issue.
- **Cartão de Cidadão integration:** Portuguese citizen card is the operational gold standard for EU national ID — integrates national ID + tax + social security + electoral + health on one card. Strong eID infrastructure.
- **e-fatura mandatory e-invoicing:** Creates rich verification source for SME turnover. Tax invoices are real-time matched with SAFT-PT submissions.
- **SIBS API Market:** Portuguese banking infrastructure provides standardised PSD2 interface — reduces AISP integration complexity vs. peer EU jurisdictions.
- **MB Way mobile payment:** Operationally ubiquitous; SIBS-operated mobile P2P + e-commerce payment.
- **Cross-reference:** `country-pt-lending-policy-agent` provides full PT jurisdictional context.

## Statutory hooks

- Decreto-Lei 133/2009 5.2A (responsible lending — consumer credit)
- BdP + CMVM BdP customer protection
- APB (Associação Portuguesa de Bancos) standards for Business Customers

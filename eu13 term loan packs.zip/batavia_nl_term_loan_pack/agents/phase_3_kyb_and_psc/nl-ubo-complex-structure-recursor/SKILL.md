---
name: nl-ubo-complex-structure-recursor
description: |
  Resolve Netherlands Person of Significant Control (PSC) structures beyond the standard 25%+ direct
  ownership chain that ubo-mapper handles. Recurse through corporate PSCs to find ultimate
  natural persons; surface beneficiaries of trust-as-PSC structures; handle overseas-entity
  PSCs requiring Register of Overseas Entities (UBO Register framework) verification; flatten multi-layer
  corporate chains. Returns a complete list of ultimate natural-person PSCs plus the full
  path trace for audit. Flags trust, overseas, and anomalous patterns for Enhanced Due
  Diligence (EDD).
---

# PSC Complex Structure Recursor

## Input contract

```yaml
applicant_company_number: string          # required, e.g. "12345678"
initial_psc_list:                          # the PSC list returned by ubo-mapper
  - psc_id: string
    natural_person: boolean
    name: string
    nature_of_control: [enum]
    # plus the standard PSC fields where natural_person = true
recursion_depth_limit: integer            # default 6
```

## Output contract

```yaml
psc_resolved_structure:
  applicant_company_number: string
  ultimate_natural_person_pscs:
    - name: string
      effective_beneficial_ownership_pct: float   # multiplicative through chain
      path_trace: [string]                        # ["AppCo (50%) → MidCo (60%) → X"]
      nature_of_control_origin: [enum]
  edd_flags:                                       # may be empty
    - flag_type: enum                              # corporate_chain | trust_pcs | overseas_pcs | nominee_suspected | depth_limit_reached
      detail: string
  outcome: enum                                    # structure_resolved | eccta_non_compliance_block | edd_required
  reason_codes: [string]
```

## Decision logic

```
Walk PSC graph breadth-first. For each non-natural-person PSC:
  - corporate Netherlands → recurse into its PSC list
  - corporate overseas → query Register of Overseas Entities
      if not registered → outcome = eccta_non_compliance_block (BRIGHT LINE)
  - trust → seek trust deed; if absent → edd_required + add edd_flag
  - partnership/LLP → traverse partners
  - nominee detected → edd_required + escalate

Stop when all leaves are natural persons OR recursion depth reached.
Compute beneficial ownership multiplicatively through the chain.
```

## Worked example (Batavia Engineering B.V.)

Input:
```yaml
applicant_company_number: "12345678"
initial_psc_list:
  - psc_id: PSC-001
    natural_person: true
    name: "Lachlan MacKenzie"
    nature_of_control: ["ownership_of_shares_50_to_75_percent"]
  - psc_id: PSC-002
    natural_person: true
    name: "Sarah Chen"
    nature_of_control: ["ownership_of_shares_25_to_50_percent"]
```

Output:
```yaml
psc_resolved_structure:
  applicant_company_number: "12345678"
  ultimate_natural_person_pscs:
    - name: "Lachlan MacKenzie"
      effective_beneficial_ownership_pct: 60.0
      path_trace: ["Batavia Engineering B.V. Consultants Ltd → Lachlan MacKenzie"]
      nature_of_control_origin: ["ownership_of_shares_50_to_75_percent"]
    - name: "Sarah Chen"
      effective_beneficial_ownership_pct: 40.0
      path_trace: ["Batavia Engineering B.V. Consultants Ltd → Sarah Chen"]
      nature_of_control_origin: ["ownership_of_shares_25_to_50_percent"]
  edd_flags: []
  outcome: structure_resolved
  reason_codes: ["UK_PSC_NATURAL_PERSON_CHAIN_RESOLVED"]
```

In this case both PSCs are natural persons directly — no recursion needed. The agent
short-circuits to `structure_resolved` cleanly. A more complex case (e.g. Highland
owned 60% by a Netherlands holding company owned 100% by an overseas entity) would recurse
through the chain, hit the Register of Overseas Entities check, and either resolve
to a natural person or block on UBO Register framework non-compliance.

## Bright lines

- Overseas-entity PSC without valid Register of Overseas Entities registration → BLOCK
  (`eccta_non_compliance_block`). Hard regulatory blocker; agent has no discretion.
- Detected nominee declarations → cannot auto-resolve; refer to MLRO for assessment.
- Recursion depth limit reached without natural-person resolution → escalate to EDD.

## Operational rules

- Preserve the full path trace in the decision log even when long — auditors may need it.
- Where trust deeds are not accessible, the agent must NOT fabricate beneficiary identity.
  Surface as `INCOMPLETE` and refer.
- Applicant-declared structure mismatching KvK (Kamer van Koophandel) data → flag for fraud review.


## Netherlands-specific operational notes

This agent operates within the Dutch lending framework — DNB (prudential) and AFM (conduct) twin peaks supervision, Wft (Wet financieel toezicht) as foundational, BW Book 7 sections 57-73 for consumer credit, Wwft for AML.

- **Twin peaks supervision:** DNB handles prudential, AFM handles conduct. Operational engagement is with both, not unified. Different reporting cadences and supervisory styles.
- **BKR query:** Functional gate for consumer credit; AFM expects it. Stichting BKR governance includes member contribution + consultation.
- **NIBUD norms:** Operational affordability standard for consumer credit (Nationaal Instituut voor Budgetvoorlichting). AFM expects NIBUD adherence; deviations require documented justification.
- **NHG (Nationale Hypotheek Garantie):** State guarantee scheme for mortgages below €435,000 (2026 threshold); provides materially lower risk weight + rate. Eligibility independently verified.
- **LTI/LTV macroprudential limits:** Set by DNB; statutory and enforced. LTV typically 100% for first home, lower for subsequent; LTI tightened post-2013.
- **Aflossingsvrij mortgages:** Historically dominant interest-only product; affordability stress testing must account for non-amortising structure.
- **Cross-reference:** `country-nl-lending-policy-agent` provides full NL jurisdictional context.

## Statutory hooks

- BW Book 2 (Rechtspersonen) Part 21A (PSC regime)
- Wwft + UBO Register (failure to prevent fraud, Register of Overseas Entities, identity verification)
- Netherlands Wwft — EDD where non-natural-person beneficial owner, overseas component, or trust
- Belastingdienst Trust Registration Service
- AFM SYSC 6.3

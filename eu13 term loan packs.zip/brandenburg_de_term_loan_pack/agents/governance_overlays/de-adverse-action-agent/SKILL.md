---
name: de-adverse-action-agent
description: |
  Generate decline / refer reason codes in both regulatory taxonomy and customer-facing language. Triggered when decision-pricing-agent renders a decline or refer outcome. Ensures the right-to-explanation under Germany GDPR Article 22 is fulfilled and the LSB-compliant decline notice is prepared.
---

# Adverse Action Agent

When the answer is no, the customer (and any future ombudsman / Ombudsmann der privaten Banken review) is entitled to know why. Adverse-action handles the why.

## Input contract

```yaml
adverse_action_request:
  case_id: string
  decision_outcome: enum                    # refer | decline
  decline_reasons: [string]                 # regulatory taxonomy reason codes
  decline_reasons_evidence:                 # which upstream agents raised each reason
    - reason_code: string
      origin_agent: string
      evidence_pointer: string
```

## Output contract

```yaml
adverse_action_output:
  case_id: string
  customer_facing_decline_letter_text: string
  reason_codes_internal: [string]
  reason_codes_customer: [string]           # plain-English translations
  right_to_explanation_text: string
  appeal_route_text: string
  bank_referral_scheme_eligibility: boolean # if declined & lender is designated
  audit_ledger_entry_id: string
  reason_codes: [string]
```

## Decision logic

```
For each regulatory reason_code:
  Look up canonical customer-facing translation.

Compose decline letter:
  - Outcome statement (clear, plain English)
  - Reasons (top 3-5, prioritised by materiality)
  - Right to explanation + request channel
  - Appeal route
  - Bank Referral Scheme notice if applicable
  - Vulnerability-aware language adjustments

Set bank_referral_scheme_eligibility based on lender designation + outcome.
```

## Worked example (Brandenburg Engineering GmbH case)

Input:
```yaml
(not triggered for Highland — accept outcome.
This agent would fire if outcome had been refer or decline.)
```

Output:
```yaml
(not triggered for Highland — accept outcome.
Example shape for a hypothetical decline:

adverse_action_output:
  case_id: "BRA-2026-04-001"
  customer_facing_decline_letter_text: "..."
  reason_codes_customer:
    - "Your business's recent trading performance does not currently meet our affordability requirements."
    - "There is an existing charge on the company that would need to be released before we could provide new funding."
  right_to_explanation_text: "..."
  appeal_route_text: "..."
  bank_referral_scheme_eligibility: true)
```

Not triggered for Highland (accept outcome). Documented here for completeness — would fire on refer / decline path.

## Bright lines

- Tipping-off cases: decline letter must NOT reveal underlying suspicion
- Customer-facing reasons cannot be more specific than regulatory codes allow

## Operational rules

- Plain English required (Flesch Reading Ease >= 60)
- Reasons prioritised by materiality, not first-discovered
- Vulnerability-aware language for flagged principals
- Appeal route must be a real working channel, not a black hole

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Reason code with no customer translation | Generic + escalate translation to product |
| Decline reasons inconsistent | Refer to compliance |


## Germany-specific operational notes

This agent operates within the German lending framework — BaFin supervisory perimeter (with Bundesbank joint prudential and ECB SSM for significant institutions), BGB §§ 491-505e for consumer credit, KWG (Kreditwesengesetz) for banking, GwG for AML.

- **SCHUFA monopoly:** SCHUFA holds the effective monopoly on consumer credit data. BDSG §29 consent (Einwilligung) is mandatory before any SCHUFA query — operational rigour matters; querying without consent is a data protection breach with material fines.
- **Notar requirement:** German property transfers require notarial certification (Notar). This is structural — mortgage origination must accommodate notarial step and cannot bypass it.
- **Cooperative + savings dominance:** Sparkassen and Volksbanken/Raiffeisenbanken collectively dominate German consumer + SME credit. Hausbank (house bank) culture means existing relationships are sticky.
- **Long-fixed-rate culture:** German mortgages commonly fixed for 10-30 years; affordability stress testing must reflect this product structure, not UK SVR conventions.
- **Transparenzregister:** UBO register (5AMLD-compliant). Threshold 25%+. Public access restricted post-CJEU ruling; financial institutions retain access via legitimate interest.
- **Cross-reference:** `country-de-lending-policy-agent` provides full DE jurisdictional context.

## Statutory hooks

- Germany GDPR Article 22 (right to explanation for automated decisions)
- BaFin BGB Verbraucherschutz framework (consumer understanding outcome)
- Bankenverband-Standards für Firmenkundenkredite for Business Customers
- SBEE Act 2015 (Bank Referral Scheme on decline)

from pathlib import Path
import json, subprocess, shutil
from playwright.sync_api import sync_playwright
root = Path(__file__).resolve().parents[1]
data = json.loads((root / 'data' / 'demo-data.json').read_text())
frames = root / 'video_frames'
shutil.rmtree(frames, ignore_errors=True)
frames.mkdir(parents=True)
html = (root / 'standalone-demo.html').read_text(encoding='utf-8')
with sync_playwright() as p:
    browser = p.chromium.launch(executable_path='/usr/bin/chromium', args=['--no-sandbox', '--disable-dev-shm-usage'])
    page = browser.new_page(viewport={'width': 1280, 'height': 720}, device_scale_factor=1)
    page.set_content(html, wait_until='load')
    for i in range(len(data['steps'])):
        page.evaluate(f'window.renderDemoStep({i})')
        page.screenshot(path=str(frames / f'frame_{i:03d}.png'), full_page=False)
    browser.close()
concat = []
for i, step in enumerate(data['steps']):
    concat.append(f"file '{frames / f'frame_{i:03d}.png'}'")
    concat.append(f"duration {step.get('duration', 5.5)}")
concat.append(f"file '{frames / f'frame_{len(data['steps'])-1:03d}.png'}'")
(frames / 'concat.txt').write_text('\n'.join(concat) + '\n')
out = root / 'ezbob_highland_demo_video.mp4'
subprocess.run(['ffmpeg','-y','-f','concat','-safe','0','-i',str(frames/'concat.txt'),'-vf','fps=8,format=yuv420p','-c:v','libx264','-preset','ultrafast','-crf','30','-movflags','+faststart',str(out)], check=True)
print(out)

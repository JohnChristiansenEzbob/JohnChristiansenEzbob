---
name: fi-lgd-modelling-agent
description: |
  Estimate Loss Given Default — the percentage of exposure expected to be lost if the borrower defaults. Combines security position (from charges-register), personal guarantee feasibility (from pg-feasibility), and recovery model assumptions to produce a forward-looking LGD.
---

# LGD Modelling Agent

LGD drives both expected credit loss (IFRS 9) and risk-based pricing. Get LGD wrong and pricing is wrong.

## Input contract

```yaml
lgd_request:
  case_id: string
  facility_amount_eur: integer
  proposed_security_type: enum
  charges_register_outcome: object          # from charges-register-and-prior-security-agent
  pg_feasibility_outcomes: [object]         # per-guarantor; from personal-guarantee-feasibility-agent
  industry: string                          # SIC code; influences recovery on liquidation
```

## Output contract

```yaml
lgd_estimate:
  case_id: string
  lgd_baseline_pct: float                   # before PG enforcement
  lgd_with_pg_pct: float                    # after PG realisation
  recovery_components:
    floating_charge_realisation_gbp: integer
    pg_realisation_attributable_gbp: integer
    industry_recovery_assumption_pct: float
  model_version: string
  reason_codes: [string]
```

## Decision logic

```
expected_facility_at_default = facility_amount * EAD_factor  # from ead-modelling-agent
expected_recovery_from_floating = (floating_charge_position_value * industry_recovery_factor)
expected_recovery_from_pg = sum(pg_feasibility.net_realisable_pg_cover_lower)

if NO PG:
  lgd_with_pg = lgd_baseline
else:
  lgd_with_pg = max(0, (EAD - expected_recovery_from_floating - expected_recovery_from_pg) / EAD)
```

## Worked example (Sisu Engineering Oy case)

Input:
```yaml
lgd_request:
  case_id: "SIS-2026-04-001"
  facility_amount_eur: 150000
  proposed_security_type: term_loan_debenture
  charges_register_outcome:
    new_lender_rank: first
    estimated_recovery_at_default_gbp: 92000
  pg_feasibility_outcomes:
    - principal_id: DIR-001
      net_realisable_pg_cover_lower_bound_gbp: 113100
    - principal_id: DIR-002
      net_realisable_pg_cover_lower_bound_gbp: 158000
  industry: "71121"
```

Output:
```yaml
lgd_estimate:
  case_id: "SIS-2026-04-001"
  lgd_baseline_pct: 0.38
  lgd_with_pg_pct: 0.28
  recovery_components:
    floating_charge_realisation_gbp: 92000
    pg_realisation_attributable_gbp: 90000   # capped at PG amount per principal
    industry_recovery_assumption_pct: 0.61
  model_version: "SME_LGD_v2.1"
  reason_codes: ["UK_LGD_28_PCT_WITH_PGS_IN_PLACE"]
```

Baseline LGD 38% — after first-rank floating charge realisation. PGs from both directors take LGD down to 28%. Substantial recovery uplift from PGs, which justifies the PG requirement.

## Bright lines

- (no statutory bright lines for this agent)

## Operational rules

- PG realisation is capped at the PG face value per principal
- Industry recovery assumptions refreshed annually based on portfolio actuals
- Boland-triggered PG cover: discount to lower bound × 0.6 (Etridge process risk)
- Cross-validate against historical portfolio LGDs in same SIC band

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| No PG and no security | LGD baseline at industry mean — typically high (>60%) |
| Recovery assumptions inconsistent with industry data | Refer model risk for review |


## Finland-specific operational notes

This agent operates within the Finnish lending framework — FIN-FSA (Finanssivalvonta) as unified supervisor, Credit Institutions Act for banking, Consumer Protection Act ch 7 for consumer credit, AML Act 444/2017 for AML.

- **FIN-FSA positive credit register (2024+):** Operational positive credit data register at the supervisor — uncommon in EU. Materially raises lender visibility.
- **Suomen Asiakastieto positive data:** Even before FIN-FSA register, Asiakastieto offered positive credit data — Finland was atypical for EU in this regard.
- **Bilingual constitutional requirement:** Finnish + Swedish; Swedish-speaking minority has constitutional rights to financial services in Swedish. Operational disclosure in Swedish for Swedish-speaking customers.
- **Bank-issued e-ID universal:** Finnish banks issue universal e-ID credentials used across financial services and government interactions. PSD2 SCA operationally seamless.
- **Suomi.fi authentication:** Government identity hub. Strong integration.
- **HETU privacy:** Henkilötunnus is restricted-use; over-collection or unnecessary retention is privacy breach under GDPR + Finnish Data Protection Act.
- **Cross-reference:** `country-fi-lending-policy-agent` for full FI jurisdictional context (currently a stub in the Country Policy Pack).

## Statutory hooks

- FIN-FSA model risk supervision + ECB SREP (model risk management)
- IFRS 9 (ECL calculation)
- Basel III/IV (capital — internal models where applicable)

# BetaCredit LGD Component Decomposition (v1.2)

In v1.2, BetaCredit's LGD model decomposes each loan's loss-given-default into four economically interpretable components. The user can supply any subset of the components per loan (via optional schema columns) and the remainder are filled from asset-class defaults. Alternatively, a pre-computed `lgd_observed` value bypasses the formula entirely.

## The formula

```
LGD = (1 − cure_prob) × max(0, 1 − [collateral_recovery + unsecured_recovery − costs] × discount / EAD)
```

Where:

- `collateral_recovery = min(collateral_value × haircut, EAD)` — what you get from realising security, capped at EAD
- `unsecured_recovery = (EAD − collateral_recovery) × unsecured_recovery_rate` — debt collection on the unsecured remainder
- `costs = EAD × recovery_costs` — legal/admin/asset-management costs (Basel IV Article 181 economic-loss definition)
- `discount = (1 + 5%)^(-time_to_resolution_months / 12)` — discount future recoveries to present value
- `cure_prob` — probability the loan cures without entering recovery (applied last, multiplicatively)

The `(1 − cure_prob)` factor reflects the observed empirical fact that not every defaulted loan ends in recovery — a significant share cure (return to performing). For unsecured products the cure rate is the *single biggest driver* of LGD; for mortgages it is dominated by collateral value.

## Two entry paths

### Path 1 — `lgd_observed` override

If the borrower row carries `lgd_observed`, the agent uses it directly. The component fields are populated where supplied (so the dashboard still shows what you know), but the formula is skipped. Use this when you have a calibrated internal LGD model and want BetaCredit to consume its output without re-modelling.

```python
agent.decide_one({
    "asset_class": "sme_unsecured",
    "bureau_score": 620,
    "cashflow_coverage": 1.3,
    "ltv": 0,
    "loan_amount": 50_000,
    "loan_term_months": 36,
    "default_flag": 0,
    "lgd_observed": 0.42,        # ← bypass model, use this directly
})
```

`CreditDecision.lgd_source` will be `"observed"`.

### Path 2 — component inputs

Supply any of the four component fields. Missing components fall back to the asset-class default. This is the common case for a real lender: you know your collateral value (you valued it at origination) and maybe your typical recovery costs, but cure probability is harder to set per-loan.

```python
agent.decide_one({
    # … required canonical fields …
    "collateral_value": 350_000,
    "cure_prob": 0.50,
    "recovery_costs": 0.07,
    "time_to_resolution_months": 18,
})
```

`CreditDecision.lgd_source` will be `"computed_from_components"`. The full decomposition is exposed via `CreditDecision.lgd_components` — a dict with `cure_prob`, `collateral_recovery`, `unsecured_recovery`, `recovery_costs`, `discount_factor`, `lgd_workout`.

### Path 3 — asset-class default (no inputs)

When the row has none of the LGD fields, the formula runs with asset-class defaults. The results match the v1.0 calibration exactly (55% / 35% / 72% / 14% / 16% / 44% / 28% / 38% for the eight classes). This is the backward-compatible path.

`CreditDecision.lgd_source` will be `"asset_class_default"`.

## Asset-class calibration

The defaults reflect UK lending benchmarks and Basel IV Article 181 supervisory tables. They are encoded in `risk_models.lgd_models._LGD_PARAMS` and are the values used when the user does not supply per-loan overrides.

| Asset class | Haircut | Cure prob | Unsecured recovery | Costs | TTR months |
|---|---|---|---|---|---|
| `sme_unsecured` | — | 39.5% | 20% | 10% | 24 |
| `sme_secured` | 75% | 49.1% | 15% | 12% | 18 |
| `consumer_unsecured` | — | 20.6% | 18% | 8% | 18 |
| `residential_mortgage` | 85% | 24.6% | 5% | 8% | 30 |
| `buy_to_let` | 80% | 14.9% | 5% | 9% | 28 |
| `motor_finance` | 65% | 14.7% | 10% | 7% | 12 |
| `invoice_finance` | 90% | 47.8% | 20% | 6% | 9 |
| `asset_finance` | 70% | 46.6% | 12% | 10% | 15 |

The cure_prob values were tuned numerically so the component formula reproduces the v1.0 headline LGDs at each asset class's typical EAD. They land in plausible ranges (15-50%) consistent with UK lending recovery research.

The discount rate is fixed at 5% nominal per Basel IV Article 181. The haircut represents the fraction of collateral value that can be realised in workout (forced-sale discount, time-to-sell loss, transaction costs combined).

## Component aliases recognised at ingestion

The data ingester maps these common names to the canonical columns automatically:

| Canonical | Recognised aliases |
|---|---|
| `lgd_observed` | `lgd`, `loss_given_default`, `observed_lgd`, `lgd_realised`, `lgd_actual` |
| `collateral_value` | `security_value`, `collateral_amount`, `property_value`, `secured_value`, `asset_value` |
| `cure_prob` | `cure_rate`, `cure_probability`, `prob_cure`, `cure_pct` |
| `recovery_costs` | `workout_costs`, `recovery_cost_pct`, `cost_to_recover`, `loss_costs` |
| `time_to_resolution_months` | `time_to_resolution`, `workout_months`, `recovery_time_months`, `ttr_months` |

The example `mortgage_book.xlsx` carries `property_value` and `workout_costs`; the BTL JSONL carries `security_value` and `cure_rate`. Both flow through ingestion to the canonical names.

## Notebook 03 visualisations

Notebook 03 has a v1.2 section showing two views of the decomposition:

1. **Cure protection waterfall** — for each asset class, two stacked bars: the workout LGD (height = pre-cure) and the final LGD (height = post-cure). The gap visualises how much loss the cure rate prevents. Unsecured products show large gaps; mortgages and BTL show small gaps because cure is already low for those products.

2. **Sensitivity tornado** — for each asset class, the basis-points LGD impact of an adverse one-standard-deviation shift in each component (-10pp cure, -20% collateral, +5pp costs, +12 months workout). Confirms qualitatively which component matters most for each asset class.

The expected pattern: mortgages and BTL are dominated by `collateral_value` and `recovery_costs` (the HPI-stress story); consumer unsecured and motor finance are dominated by `cure_prob`; SME and invoice finance are mixed.

## When to use which path

| Situation | Recommended path |
|---|---|
| Quick exploratory scoring of new applications | Asset-class default (no LGD inputs) |
| Known collateral, want to see HPI sensitivity | Component path with `collateral_value` set |
| Internal LGD model already computes the final value | `lgd_observed` override |
| Regulatory submission requiring full audit trail | Component path with all four fields supplied |
| Stress testing with adverse component shifts | Component path + scenario-shifted defaults |

For regulatory work the component path is the right answer because each driver of the LGD has its own line in the audit trail. The model risk team can see exactly which component a given LGD came from and challenge the firm's calibration of each one independently.

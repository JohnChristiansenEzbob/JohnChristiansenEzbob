---
name: fi-customer-onboarding-orchestrator
description: |
  Case lifecycle coordinator for Finland SME credit applications. Opens the case ledger, assigns the case_id, validates the inbound payload shape, dispatches downstream agents in correct phase order, and maintains case state across the journey. Control-flow primitive — does not perform external lookups or credit reasoning.
---

# Customer Onboarding Orchestrator

Every case starts here. The orchestrator owns the case_id, the phase pointer, and the right to dispatch downstream agents. It writes the canonical case ledger entries that the audit trail relies on.

## Input contract

```yaml
inbound_application:
  channel: enum                            # broker | branch | online | api
  applicant_name: string
  applicant_company_number: string
  facility_type: enum                      # term_loan | revolving_credit | invoice_finance | asset_finance
  facility_amount_eur: integer
  facility_term_months: integer            # nullable
  contact_name: string
  contact_email: string
  contact_phone: string
  application_date: date
  broker_firm: string                      # nullable (only if channel = broker)
  broker_fca_reference: string             # nullable
```

## Output contract

```yaml
case_state:
  case_id: string                          # e.g. SIS-2026-04-001
  status: enum                             # active | paused | terminated
  current_phase: integer                   # 1..7
  channel: enum
  case_type: enum                          # UK_term_loan | UK_revolving | ...
  audit_ledger_initialised: boolean
  next_phase_unlocked: boolean
  dispatched_agents: [string]              # what fires next
```

## Decision logic

```
if inbound_application.facility_type not in ALLOWED_PRODUCTS:
  status = terminated
  reason_codes = [UK_PRODUCT_NOT_OFFERED]
elif required_fields_missing(inbound_application):
  status = paused
  reason_codes = [UK_INTAKE_INCOMPLETE_PAYLOAD]
else:
  case_id = generate(applicant_company_number, application_date)
  initialise_ledger(case_id)
  status = active
  current_phase = 1
  dispatch([lead-qualification-agent, data-capture-agent])
```

## Worked example (Sisu Engineering Oy case)

Input:
```yaml
inbound_application:
  channel: broker
  applicant_name: "Sisu Engineering Oy Consultants Ltd"
  applicant_company_number: "1234567-8"
  facility_type: term_loan
  facility_amount_eur: 150000
  facility_term_months: 60
  contact_name: "Lachlan MacKenzie"
  contact_email: "lachlan@highlandeng.example.co.uk"
  contact_phone: "+44 141 555 0182"
  application_date: "2026-04-12"
  broker_firm: "Highland Capital Partners"
  broker_fca_reference: "555444"
```

Output:
```yaml
case_state:
  case_id: "SIS-2026-04-001"
  status: active
  current_phase: 1
  channel: broker
  case_type: UK_term_loan
  audit_ledger_initialised: true
  next_phase_unlocked: true
  dispatched_agents: ["lead-qualification-agent", "data-capture-agent"]
```

Standard happy-path intake. Broker channel with valid FIN-FSA reference, facility within the term-loan product envelope, all required fields present. Case opened, ledger initialised, downstream agents dispatched.

## Bright lines

- Inbound payload missing required field (applicant_company_number, facility_amount_eur) → status=paused; cannot proceed
- Facility type not in the lender's product catalogue → status=terminated
- Duplicate case_id detected → status=terminated; existing case_id surfaced to broker

## Operational rules

- case_id is immutable once issued
- Audit ledger is append-only (WORM equivalent)
- All downstream agent dispatch goes through this orchestrator — no direct agent-to-agent calls
- Case state changes emit a ledger entry with timestamp + actor identity

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Required field missing | Pause case; surface specific missing field to broker via channel |
| Duplicate case detected | Terminate new case; return existing case_id |
| Ledger initialisation fails | Terminate; alarm to ops |
| Broker FIN-FSA reference invalid | Pause; require broker accreditation check |


## Finland-specific operational notes

This agent operates within the Finnish lending framework — FIN-FSA (Finanssivalvonta) as unified supervisor, Credit Institutions Act for banking, Consumer Protection Act ch 7 for consumer credit, AML Act 444/2017 for AML.

- **FIN-FSA positive credit register (2024+):** Operational positive credit data register at the supervisor — uncommon in EU. Materially raises lender visibility.
- **Suomen Asiakastieto positive data:** Even before FIN-FSA register, Asiakastieto offered positive credit data — Finland was atypical for EU in this regard.
- **Bilingual constitutional requirement:** Finnish + Swedish; Swedish-speaking minority has constitutional rights to financial services in Swedish. Operational disclosure in Swedish for Swedish-speaking customers.
- **Bank-issued e-ID universal:** Finnish banks issue universal e-ID credentials used across financial services and government interactions. PSD2 SCA operationally seamless.
- **Suomi.fi authentication:** Government identity hub. Strong integration.
- **HETU privacy:** Henkilötunnus is restricted-use; over-collection or unnecessary retention is privacy breach under GDPR + Finnish Data Protection Act.
- **Cross-reference:** `country-fi-lending-policy-agent` for full FI jurisdictional context (currently a stub in the Country Policy Pack).

## Statutory hooks

- FIN-FSA FIN-FSA customer protection (case ownership + auditability)
- FIN-FSA SYSC 3 (systems and controls)
- Finland GDPR / DPA 2018 (lawful basis at intake)

---
name: be-charges-register-and-prior-security-agent
description: |
  Pull existing security registered against the applicant company via KBO/BCE (Kruispuntbank van Ondernemingen / Banque-Carrefour des Entreprises) charges
  register (fixed charges, floating charges, debentures, all-asset security) and Registres des biens fonciers
  Business Gateway (where the applicant owns commercial property). Returns ranked list of
  existing charges with creditor identity, registration date, charge type, and outstanding
  estimate. Material for secured lending decisions — the new lender's recoverable position
  depends entirely on the priority of existing charges.
---

# Charges Register and Prior Security Agent

## Input contract

```yaml
applicant_company_number: string
applicant_declared_properties: [string]   # list of Belgium property addresses applicant owns
consent_land_registry: boolean            # service terms require declaration
proposed_security_type: enum              # term_loan_debenture | fixed_charge_specific_asset | property_charge | floating_only | unsecured
proposed_facility_amount_eur: integer
```

## Output contract

```yaml
prior_security_schedule:
  applicant_company_number: string
  outstanding_charges:
    - charge_code: string
      creditor: string
      charge_type: enum                   # fixed | floating | all_asset_debenture | specific_property | negative_pledge
      registered: date
      estimated_outstanding_gbp: integer
      satisfaction_letter_pending: boolean
      cleared_by_drawdown: boolean        # if applicant has committed to clear at completion
  land_registry_properties:
    - property_address: string
      ownership: enum                     # sole | joint | tenants_in_common | leasehold
      estimated_value_gbp: integer
      registered_charges:
        - priority: integer               # 1, 2, 3...
          creditor: string
          outstanding_estimate_gbp: integer
      restrictions_or_cautions: [string]
  prospective_security_position:
    new_lender_rank: enum                 # first | second | third | unsecured_in_practice
    estimated_recovery_at_default_gbp: integer
    pricing_uplift_recommended_pct: float # nullable; for subordinated positions
  outcome: enum                           # clear | refer_subordination_negotiation | refer_security_subordinated
  reason_codes: [string]
```

## Decision logic

```
KBO/BCE (Kruispuntbank van Ondernemingen / Banque-Carrefour des Entreprises) Charges Register API → returns list of charges.
Registres des biens fonciers Business Gateway for each declared property → returns proprietor + charges.

For each charge:
  - Classify type
  - Resolve creditor identity (KBO/BCE (Kruispuntbank van Ondernemingen / Banque-Carrefour des Entreprises) search by creditor name)
  - Estimate outstanding (from charge document text where parseable)
  - Apply satisfaction-pending logic

Compute prospective security position:
  - If existing floating charge to designated rival lender → outcome = refer_subordination_negotiation
  - If existing all-asset debenture, no satisfaction date, no committed clearance → outcome = refer_security_subordinated
  - If applicant has committed to clear at drawdown (satisfaction_letter_pending = true AND cleared_by_drawdown = true) →
    proceed; flag as drawdown_condition
  - Else → clear (new lender takes first-rank or appropriately ranked security)
```

## Worked example (Manneken Engineering NV/SA)

Input:
```yaml
applicant_company_number: "0123.456.789"
applicant_declared_properties: []         # applicant doesn't own its premises — leasing
consent_land_registry: true
proposed_security_type: term_loan_debenture
proposed_facility_amount_eur: 150000
```

Output:
```yaml
prior_security_schedule:
  applicant_company_number: "0123.456.789"
  outstanding_charges:
    - charge_code: "CH-2021-04-18-A"
      creditor: "First-Bank Plc (synthetic)"
      charge_type: floating
      registered: "2021-04-18"
      estimated_outstanding_gbp: 38000
      satisfaction_letter_pending: true
      cleared_by_drawdown: true
  land_registry_properties: []            # applicant owns no commercial property
  prospective_security_position:
    new_lender_rank: first                # after existing charge cleared at drawdown
    estimated_recovery_at_default_gbp: 92000   # ~60% of facility, post-clearance
    pricing_uplift_recommended_pct: 0.0
  outcome: clear
  reason_codes: ["UK_CHARGES_REGISTER_CLEAR_AFTER_PRIOR_CLEARANCE_AT_DRAWDOWN"]
```

This is the classic "refinancing-as-condition" pattern. Highland has one existing
floating charge to First-Bank Plc (€38k outstanding). Highland has committed to clear it
at drawdown (satisfaction letter pending). New lender becomes first-rank floating charge
holder. Outcome is `clear` with the clearance becoming a drawdown condition surfaced to
the decision-pricing-agent.

## Bright lines

- Existing floating charge to rival designated lender without committed clearance →
  AUTOMATIC REFER. Cannot take a new floating charge without negotiated subordination /
  waiver letters.
- Existing all-asset debenture, no satisfaction date, no committed clearance → AUTOMATIC
  REFER for security subordination.
- Registres des biens fonciers restriction preventing disposition without third-party consent → cannot
  use that property as security without obtaining the consent.

## Operational rules

- An apparently-stale charge may still legally encumber the asset (KBO/BCE (Kruispuntbank van Ondernemingen / Banque-Carrefour des Entreprises) does
  not auto-release). Always flag for human confirmation; do NOT recommend "ignore".
- Property identification by company number against registered proprietor — never by
  applicant name alone (false-positive risk).
- Registres des biens fonciers pulls are paid per query — batch where possible.


## Belgium-specific operational notes

This agent operates within the Belgian lending framework — NBB (prudential, including CKP operation) and FSMA (conduct) twin peaks, Code de droit économique Books VII (consumer) + VIII (KBO), Loi du 18 septembre 2017 for AML.

- **Regional language obligation:** SECCI and contract MUST be in the customer's regional language — French (Wallonie), Dutch (Flanders), German (Eastern Cantons), or bilingual (Brussels Capital). This is statutory and contracts in the wrong language are invalid.
- **CKP mandatory consumer query:** Statutory mandatory before consumer credit decision; non-query invalidates agreement. NBB-operated central consumer credit register.
- **Statutory rate caps:** Code de droit économique Book VII sets statutory rate caps per consumer credit category — exceeding is contract invalidity.
- **itsme universal:** Belgian mobile identity platform widely adopted; integrates with PSD2 SCA. Most consumer onboarding uses itsme.
- **Cooperative + commercial bank mix:** Belfius (state-related cooperative legacy), KBC (cooperative origin), BNP Paribas Fortis (commercial), ING Belgium — diverse market structure.
- **Cross-reference:** `country-be-lending-policy-agent` provides full BE jurisdictional context.

## Statutory hooks

- Code des sociétés et des associations Part 25 (charges registration)
- Land Registration Act 2002
- Insolvency Act 1986 (priority of charges in liquidation)
- Law of Property Act 1925

---
name: ie-fairness-monitoring-agent
description: |
  Monitor decision outcomes for fairness across protected attribute proxies (region, deprivation index, SIC code where it correlates with protected attributes). Returns demographic parity statistics, drift indicators, and any breach signals. Operates per-case (current decision vs portfolio baseline) and aggregate (rolling portfolio statistics).
---

# Fairness Monitoring Agent

Continuous fairness oversight. EU AI Act + CBI Consumer Protection Code 2026 + (where applicable) Equality Act 2010 require demonstrable fairness in automated credit decisioning.

## Input contract

```yaml
fairness_check_request:
  case_id: string
  decision_outcome: enum                    # accept | refer | decline
  applicant_attributes_proxy:
    region: string
    deprivation_quintile: integer           # IMD 1-5
    sic_code: string
  portfolio_baseline_ref: string            # reference to current baseline snapshot
```

## Output contract

```yaml
fairness_check_result:
  case_id: string
  this_case_in_distribution: boolean
  demographic_parity_delta: float           # vs baseline
  drift_indicators:
    region_drift: boolean
    deprivation_drift: boolean
    sic_drift: boolean
  within_tolerance: boolean
  alert_required: boolean
  audit_ledger_entry_id: string
  reason_codes: [string]
```

## Decision logic

```
Compare this case's outcome distribution against portfolio baseline.
Compute demographic parity delta on each protected attribute proxy.

Tolerance thresholds (configurable):
  - region parity delta <= 0.05 (5%)
  - deprivation parity delta <= 0.05
  - sic parity delta <= 0.05

if any delta > tolerance: drift_indicator = true

Rolling alerts:
  - Sustained drift >4 weeks → alert + reportable under AI Directive 2024
  - Single case in extreme outlier → flag for manual review
```

## Worked example (Hibernia Engineering case)

Input:
```yaml
fairness_check_request:
  case_id: "HIB-2026-04-001"
  decision_outcome: accept
  applicant_attributes_proxy:
    region: "GB-SCT"
    deprivation_quintile: 4                # mid-upper (Milngavie postcode)
    sic_code: "71121"
  portfolio_baseline_ref: "fairness_baseline_2026Q1"
```

Output:
```yaml
fairness_check_result:
  case_id: "HIB-2026-04-001"
  this_case_in_distribution: true
  demographic_parity_delta: 0.03
  drift_indicators:
    region_drift: false
    deprivation_drift: false
    sic_drift: false
  within_tolerance: true
  alert_required: false
  audit_ledger_entry_id: "FM-2026-04-12-HE-001"
  reason_codes: ["UK_FAIRNESS_WITHIN_TOLERANCE"]
```

This single case is within distribution and consistent with baseline. No drift signals. No alert required. Audit ledger updated.

## Bright lines

- Sustained breach >4 weeks → MUST notify CBI + reportable under (where applicable) AI Algorithmic Directive

## Operational rules

- Protected attribute proxies, not protected attributes themselves (cannot collect race/ethnicity for credit)
- Baseline refreshed quarterly
- Per-case alerts are advisory; portfolio alerts are mandatory action

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Baseline data stale | Use cautiously; flag refresh required |
| Outlier case but no clear protected attribute correlation | Flag for human review |

## Ireland-specific operational notes

This agent operates within the Irish lending framework — Central Bank of Ireland (CBI) supervisory perimeter, Consumer Protection Code 2026 (effective March 2026), Consumer Credit Act 1995 for consumer credit, and EU regulations directly applicable as Ireland is an EU member state. See `country-ie-lending-policy-agent` for the complete jurisdictional context.

- Equality Act not applicable in IE; equivalent: Equal Status Acts 2000-2018
- Protected characteristics under Equal Status Acts: gender, civil status, family
  status, age, disability, sexual orientation, religion, race, membership of the
  Traveller community, victim of domestic, sexual or gender-based violence (since 2024)
- DPC supervises GDPR application — relevant for protected-characteristic monitoring
- CBI Diversity & Inclusion framework also relevant
## Statutory hooks

- Equality Act 2010 (indirect discrimination via correlated attributes)
- CBI Consumer Protection Code 2026
- EU AI Act (high-risk classification — credit scoring) where applicable
- CBI model risk requirements (incorporating CBI model risk requirements for IE-domiciled subsidiaries of Ireland firms)

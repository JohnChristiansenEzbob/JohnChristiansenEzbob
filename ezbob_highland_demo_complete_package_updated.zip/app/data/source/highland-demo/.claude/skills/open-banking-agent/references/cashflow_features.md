# Cashflow Feature Catalogue

The features the open-banking-agent computes and emits, organised by what they're used for downstream. Affordability, scoring, and decisioning each lean on different subsets.

## Volume features

| Feature | Definition | Used by |
|---|---|---|
| `turnover_12m` | Sum of inflows excluding intra-account transfers and refunds, last 12 months | Affordability, scoring |
| `turnover_3m` | Same, last 3 months | Affordability (recency) |
| `turnover_growth_12m_yoy` | Latest 12m vs prior 12m | Scoring |
| `turnover_volatility_12m` | Std dev / mean of monthly turnover | Affordability stress |
| `outflows_12m` | Sum of outflows excluding intra-account transfers | Affordability |
| `net_cashflow_12m` | Inflows − outflows | Affordability |

## Margin proxies

True margin requires P&L. Open banking can only proxy:

| Feature | Definition |
|---|---|
| `cash_margin_pct_12m` | net_cashflow / turnover, last 12 months — overstates margin (ignores capex, tax, depreciation) |
| `recurring_outflow_pct_12m` | Recurring committed outflows / turnover — useful as a fixed-cost proxy |
| `discretionary_outflow_pct_12m` | One-off outflows / turnover — variable cost proxy |

Use these as **directional** signals only; for affordability stress, default to conservative margin assumptions (sector-typical, not entity-observed).

## Liquidity features

| Feature | Definition |
|---|---|
| `avg_eod_balance_12m` | Average end-of-day balance across all current accounts |
| `min_balance_12m` | Minimum end-of-day balance |
| `min_balance_3m` | Minimum end-of-day balance, last 3 months |
| `days_below_zero_12m` | Count of days with negative balance |
| `days_below_threshold_12m` | Count of days below 25% of avg_eod_balance |
| `overdraft_utilisation_pct_12m` | Average overdraft utilisation (where overdraft visible) |

## Stress signals

| Feature | Definition |
|---|---|
| `bounced_payments_12m` | Count of returned direct debits or unpaid card transactions |
| `bounced_payments_3m` | Same, recent 3 months — recency matters more |
| `late_tax_payment_count_12m` | HMRC outflows that don't follow regular cadence (suggests catch-up payments) |
| `unauthorised_overdraft_days_12m` | Days where balance went below agreed overdraft limit |

## Recurring items

Detected via amount + counterparty + date clustering. Each recurring item carries:

- `frequency`: weekly / monthly / quarterly / annual
- `stability`: 0–1; how consistently the amount and timing recur
- `median_amount`
- `category`: rent / payroll / tax / lease / subscription / loan_repayment / utilities

Used by affordability to compute committed outflows separately from variable outflows.

## Sector KPIs

Applied selectively based on the entity's SIC.

### Retail (47.xx, 56.xx)
- `card_receipts_pct` — fraction of inflows from card acquirers (Stripe, Square, Adyen, Worldpay)
- `cash_deposit_pct` — branch cash deposits as % of inflows
- `seasonality_index` — month-of-year effect
- `average_transaction_value` — for card receipts where merchant data permits

### Construction & trades (41.xx–43.xx)
- `large_milestone_receipts_count` — single inflows > 3× median monthly turnover
- `payment_timing_lumpiness` — coefficient of variation of monthly turnover
- `subcontractor_outflow_pct` — flagged subcontractor payments

### B2B services (62.xx, 70.xx, 71.xx, 73.xx)
- `dso_proxy` — gap between dominant invoicing pattern and dominant receipt pattern
- `top_customer_concentration_pct` — % of inflows from largest counterparty
- `top_3_customer_concentration_pct`

### Hospitality (55.xx, 56.xx)
- `weekend_revenue_pct` — Sat+Sun share of inflows
- `peak_month_share` — share of annual turnover in peak month (seasonality)

### Tech / SaaS (62.xx)
- `recurring_revenue_pct` — % of inflows that match a recurring monthly pattern
- `r_and_d_credit_received` — HMRC R&D credit visible

## Owner-specific

| Feature | Definition |
|---|---|
| `owner_drawings_12m` | Outflows tagged as drawings or shareholder distributions |
| `owner_drawings_pct_of_turnover` | drawings / turnover |
| `owner_drawings_pct_of_net_cashflow` | drawings / net_cashflow — high values flag a stripped-out business |

## Quality features

| Feature | Definition |
|---|---|
| `coverage_pct` | (Days with at least one transaction observed) / (Days in lookback window) |
| `account_count` | Number of distinct accounts consented |
| `single_account_flag` | Boolean — only one account consented |
| `intra_account_transfer_pct` | Transfers between own accounts as % of gross flow |

## Notes on use

The features here aren't independent — `turnover`, `net_cashflow`, `committed_outflows`, and `liquidity` co-vary heavily. Affordability uses them in a structured DSCR / ICR framework rather than as independent inputs to a model.

Scoring (PD/LGD/EAD) uses them as features in the AlphaCredit feature pipeline — but with proper treatment for monotonicity, missing values, and stability over time.

The category taxonomy (which feeds `category` on each recurring item) is in `category_taxonomy.md`.

---
name: fi-lead-qualification-agent
description: |
  Policy-fit pre-screen for Finland SME credit applications. Tests the inbound case against the lender's credit policy envelope — product range, amount band, prohibited sectors, geographic restrictions, broker accreditation status. Returns qualification outcome before any external data is pulled.
---

# Lead Qualification Agent

Cheap, fast pre-screen. Filter out applications that cannot possibly succeed under current policy before spending money on bureau pulls or Vero calls.

## Input contract

```yaml
qualification_request:
  case_id: string
  facility_type: enum
  facility_amount_eur: integer
  facility_term_months: integer
  applicant_company_number: string
  sic_codes: [string]                      # primary SIC code
  channel: enum
  broker_fca_reference: string             # nullable
  geographic_region: string                # GB-SCT, GB-ENG, GB-WLS, GB-NIR
```

## Output contract

```yaml
qualification_outcome:
  case_id: string
  outcome: enum                            # pass | refer | decline_policy
  product_match: string                    # specific product variant matched
  fail_reasons: [string]                   # populated if outcome != pass
  reason_codes: [string]
```

## Decision logic

```
if facility_amount_eur not in product.amount_band:
  outcome = decline_policy
  reason_codes += [UK_LEAD_AMOUNT_OUTSIDE_BAND]

if facility_term_months not in product.term_band:
  outcome = decline_policy
  reason_codes += [UK_LEAD_TERM_OUTSIDE_BAND]

if primary_sic_code in PROHIBITED_SECTORS:
  outcome = decline_policy
  reason_codes += [UK_LEAD_PROHIBITED_SECTOR]

if channel == "broker":
  if broker_fca_reference not in ACCREDITED_BROKERS:
    outcome = refer
    reason_codes += [UK_LEAD_BROKER_NOT_ACCREDITED]

if geographic_region not in COVERED_REGIONS:
  outcome = decline_policy
  reason_codes += [UK_LEAD_REGION_NOT_COVERED]

if outcome == None:
  outcome = pass
  product_match = match_product_variant(facility_type, amount, term)
```

## Worked example (Sisu Engineering Oy case)

Input:
```yaml
qualification_request:
  case_id: "SIS-2026-04-001"
  facility_type: term_loan
  facility_amount_eur: 150000
  facility_term_months: 60
  applicant_company_number: "1234567-8"
  sic_codes: ["71121"]
  channel: broker
  broker_fca_reference: "555444"
  geographic_region: "GB-SCT"
```

Output:
```yaml
qualification_outcome:
  case_id: "SIS-2026-04-001"
  outcome: pass
  product_match: "UK_term_loan_v3"
  fail_reasons: []
  reason_codes: ["UK_LEAD_QUALIFICATION_PASS"]
```

Highland's €150k 5-year term loan is well within product band (€25k-€500k, 12-84 months). SIC 71121 (engineering consulting) is not prohibited. Broker Highland Capital Partners is FIN-FSA-accredited. Scotland is covered. Clear pass.

## Bright lines

- Prohibited sectors (e.g. crypto exchanges, gambling, adult content) — automatic decline_policy
- Sanctioned regions / jurisdictions — automatic decline_policy
- Non-accredited broker — automatic refer (cannot auto-approve via unaccredited channel)

## Operational rules

- Policy data (prohibited sectors, accredited brokers, regions) is versioned and loaded from a controlled config
- Pre-screen is cheap and synchronous — must complete within 200ms
- Policy changes require named credit-policy committee sign-off; the agent does not have discretion to override

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Policy config unavailable | Fail-safe to refer (do not auto-approve) |
| SIC code missing | Refer; cannot apply sector policy without it |
| Region inferable from registered office | Use registered office region as default |


## Finland-specific operational notes

This agent operates within the Finnish lending framework — FIN-FSA (Finanssivalvonta) as unified supervisor, Credit Institutions Act for banking, Consumer Protection Act ch 7 for consumer credit, AML Act 444/2017 for AML.

- **FIN-FSA positive credit register (2024+):** Operational positive credit data register at the supervisor — uncommon in EU. Materially raises lender visibility.
- **Suomen Asiakastieto positive data:** Even before FIN-FSA register, Asiakastieto offered positive credit data — Finland was atypical for EU in this regard.
- **Bilingual constitutional requirement:** Finnish + Swedish; Swedish-speaking minority has constitutional rights to financial services in Swedish. Operational disclosure in Swedish for Swedish-speaking customers.
- **Bank-issued e-ID universal:** Finnish banks issue universal e-ID credentials used across financial services and government interactions. PSD2 SCA operationally seamless.
- **Suomi.fi authentication:** Government identity hub. Strong integration.
- **HETU privacy:** Henkilötunnus is restricted-use; over-collection or unnecessary retention is privacy breach under GDPR + Finnish Data Protection Act.
- **Cross-reference:** `country-fi-lending-policy-agent` for full FI jurisdictional context (currently a stub in the Country Policy Pack).

## Statutory hooks

- FIN-FSA FIN-FSA customer protection (clear product-customer fit at first touch)
- Financial Promotions regime (lender must only offer products it advertises)

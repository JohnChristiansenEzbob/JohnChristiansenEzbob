---
name: nl-consent-management-agent
description: |
  Capture, validate, and issue scoped consent tokens for all downstream data pulls — commercial bureau, consumer bureau (per director), Open Banking, Belastingdienst MTD APIs, Kadaster. Records consent provenance and provides a revocation handle.
---

# Consent Management Agent

Without valid scoped consent, downstream agents cannot pull external data lawfully. This agent is the consent gatekeeper.

## Input contract

```yaml
consent_request:
  case_id: string
  applicant_company_number: string
  director_principal_ids: [string]
  scopes_requested:
    - bureau_commercial
    - bureau_consumer_per_director
    - open_banking
    - hmrc_mtd_vat
    - hmrc_mtd_paye
    - hmrc_mtd_ct
    - land_registry_named_directors
  consent_capture_evidence:                 # signed forms or e-sign payloads
    - scope: string
      evidence_type: enum                   # signed_form | esign | api_callback
      timestamp: datetime
      ip_address: string                    # for online consent
      signature_hash: string
```

## Output contract

```yaml
consent_token_bundle:
  case_id: string
  tokens:
    - scope: string
      token_id: string
      issued_at: datetime
      expires_at: datetime
      revocation_handle: string
      evidence_pointer: string              # link to audit evidence
  scopes_granted: [string]
  scopes_refused: [string]
  outcome: enum                             # complete | partial | consent_required
```

## Decision logic

```
For each scope_requested:
  Find matching consent_capture_evidence entry.
  Validate evidence (signature, timestamp recency, IP if online).
  If valid:
    Issue scoped token with appropriate expiry (24h to 90 days depending on scope).
    Append to tokens list.
  Else:
    Append to scopes_refused.

if all requested scopes granted: outcome = complete
elif some granted: outcome = partial
else: outcome = consent_required
```

## Worked example (Batavia Engineering B.V. case)

Input:
```yaml
consent_request:
  case_id: "BAT-2026-04-001"
  applicant_company_number: "12345678"
  director_principal_ids: ["DIR-001", "DIR-002"]
  scopes_requested:
    - bureau_commercial
    - bureau_consumer_per_director
    - open_banking
    - hmrc_mtd_vat
    - hmrc_mtd_paye
    - hmrc_mtd_ct
    - land_registry_named_directors
  consent_capture_evidence:
    - scope: bureau_commercial
      evidence_type: esign
      timestamp: "2026-04-12T09:14:22Z"
      ip_address: "82.x.x.x"
      signature_hash: "[hash]"
    # (similar entries for other 6 scopes)
```

Output:
```yaml
consent_token_bundle:
  case_id: "BAT-2026-04-001"
  tokens:
    - scope: bureau_commercial
      token_id: "TKN-bureau-com-2026-04-12-001"
      issued_at: "2026-04-12T09:14:30Z"
      expires_at: "2026-07-11T09:14:30Z"
      revocation_handle: "REV-001"
    # (similar entries for other 6 tokens)
  scopes_granted: [bureau_commercial, bureau_consumer_per_director, open_banking,
                   hmrc_mtd_vat, hmrc_mtd_paye, hmrc_mtd_ct, land_registry_named_directors]
  scopes_refused: []
  outcome: complete
```

All 7 scopes granted with e-signed evidence. Tokens issued with scope-appropriate expiries (bureau 90d; Belastingdienst ties to MTD OAuth lifecycle; Kadaster per-query).

## Bright lines

- Consent without evidence (no signed form, no e-sign hash) — cannot issue token; refused
- Consent older than scope-specific staleness threshold — refused; require refresh

## Operational rules

- Tokens are scope-specific — never issue a single token covering multiple scopes
- Revocation handles are issued at token issuance; revocation propagates within 60 seconds
- Consent evidence is retained for 6 years post-relationship (DPA 2018 + AFM record-keeping)
- IP-based fraud signals (unusual location, VPN exit nodes) flagged but not blocking

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| No evidence for requested scope | Refuse that scope only; other scopes unaffected |
| Evidence signature invalid | Refuse; alert to fraud agent |
| Evidence timestamp in future | Refuse; clock-skew investigation |


## Netherlands-specific operational notes

This agent operates within the Dutch lending framework — DNB (prudential) and AFM (conduct) twin peaks supervision, Wft (Wet financieel toezicht) as foundational, BW Book 7 sections 57-73 for consumer credit, Wwft for AML.

- **Twin peaks supervision:** DNB handles prudential, AFM handles conduct. Operational engagement is with both, not unified. Different reporting cadences and supervisory styles.
- **BKR query:** Functional gate for consumer credit; AFM expects it. Stichting BKR governance includes member contribution + consultation.
- **NIBUD norms:** Operational affordability standard for consumer credit (Nationaal Instituut voor Budgetvoorlichting). AFM expects NIBUD adherence; deviations require documented justification.
- **NHG (Nationale Hypotheek Garantie):** State guarantee scheme for mortgages below €435,000 (2026 threshold); provides materially lower risk weight + rate. Eligibility independently verified.
- **LTI/LTV macroprudential limits:** Set by DNB; statutory and enforced. LTV typically 100% for first home, lower for subsequent; LTI tightened post-2013.
- **Aflossingsvrij mortgages:** Historically dominant interest-only product; affordability stress testing must account for non-amortising structure.
- **Cross-reference:** `country-nl-lending-policy-agent` provides full NL jurisdictional context.

## Statutory hooks

- Netherlands GDPR Article 6 (lawful basis) + Article 7 (consent conditions)
- Data Protection Act 2018
- PSD2 / Open Banking RTS (consent requirements for account access)
- Finance Act 2017 (Belastingdienst MTD consent scope)

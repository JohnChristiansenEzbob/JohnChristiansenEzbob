---
name: lu-tax-authority-direct-verification-agent
description: |
  Pull ACD-held data directly via the MyGuichet.lu APIs to verify SME turnover (VAT),
  employee count and payroll (PAYE RTI), and profitability + accrued tax (Corporation Tax
  CT600). For sole trader / partnership applicants, route to Self Assessment instead. ACD
  data is the most authoritative recent financial snapshot for Luxembourg SMEs — materially fresher
  than 9-12 month-old filed accounts available on RCS Luxembourg / LBR. Manages the OAuth 2.0
  flow with scoped consent.
---

# ACD Direct Verification Agent

## Input contract

```yaml
applicant_company_number: string
vat_number: string                         # nullable; required only if VAT-registered
paye_reference: string                     # nullable; required only if employing staff
applicant_legal_form: enum                 # limited_company | partnership | llp | sole_trader
consent_token:                             # ACD OAuth token bundle
  oauth_access_token: string
  scope: [string]                          # subset of {read:vat, read:paye, read:corporation-tax, read:self-assessment}
  expires_at: datetime
request_scope: [enum]                      # which datasets to pull
```

## Output contract

```yaml
hmrc_verification_record:
  applicant_company_number: string
  vat:
    queried: boolean
    obligations_overdue: boolean
    last_8_quarters_returns_filed: boolean
    ttm_turnover_gbp: integer
    qoq_volatility_pct: float
    growth_yoy_pct: float
  paye:
    queried: boolean
    employee_count_current: integer
    monthly_gross_payroll_gbp: integer
    paye_arrears: boolean
    paye_arrears_months: integer
  corporation_tax:
    queried: boolean
    last_filed_period: date
    profit_before_tax_gbp: integer
    ct_accrued_gbp: integer
    ct_paid: boolean
  outcome: enum                            # verified | refer_hmrc_arrears | decline_paye_arrears | consent_required
  reason_codes: [string]
```

## Decision logic

```
Validate consent_token: scope coverage + expiry.
If expiring within 5 min, refresh.

For each requested dataset:
  Submit OAuth-bearer call with scope.
  On 401/403 with scope mismatch → emit consent_required.

VAT processing:
  Extract last 8 quarters of returns (sales + purchases + net VAT).
  Compute TTM turnover, growth, volatility.
  If obligations overdue → outcome = refer_hmrc_arrears (BRIGHT LINE)

PAYE processing:
  Extract last 12 months RTI submissions.
  If paye_arrears AND paye_arrears_months > 3 → outcome = decline_paye_arrears (BRIGHT LINE)

CT processing:
  Extract last 2 CT600s. Capture profit + accrued + payment status.

Cross-check: if abs(vat_ttm_turnover - applicant_declared_turnover) / applicant_declared_turnover > 0.30:
  emit application_fraud_escalation flag for downstream fraud agent.
```

## Worked example (Ardennes Engineering S.à r.l.)

Input:
```yaml
applicant_company_number: "B 123456"
vat_number: "GB218546792"
paye_reference: "961/HE12345"
applicant_legal_form: limited_company
consent_token:
  oauth_access_token: "[redacted]"
  scope: ["read:vat", "read:paye", "read:corporation-tax"]
  expires_at: "2026-04-12T15:30:00Z"
request_scope: ["read:vat", "read:paye", "read:corporation-tax"]
```

Output:
```yaml
hmrc_verification_record:
  applicant_company_number: "B 123456"
  vat:
    queried: true
    obligations_overdue: false
    last_8_quarters_returns_filed: true
    ttm_turnover_gbp: 851300
    qoq_volatility_pct: 8.4
    growth_yoy_pct: 11.2
  paye:
    queried: true
    employee_count_current: 6
    monthly_gross_payroll_gbp: 28150
    paye_arrears: false
    paye_arrears_months: 0
  corporation_tax:
    queried: true
    last_filed_period: "2024-09-30"
    profit_before_tax_gbp: 112400
    ct_accrued_gbp: 28100
    ct_paid: true
  outcome: verified
  reason_codes: ["UK_ACD_DATA_RETRIEVED_CLEAN"]
```

Strong signals: TTM turnover €851k matches Xero's €854k (within 0.4% — cross-source
consistency). No obligation overdue. CT paid. PAYE clean. This is exactly the picture
the credit decision agent wants to see for a clean approval path.

## Bright lines

- `vat_obligations_overdue = true` → AUTOMATIC REFER. ACD arrears = priority debt + leading default predictor.
- `paye_arrears = true` AND `paye_arrears_months > 3` → AUTOMATIC DECLINE pending underwriter override.
- Turnover declared vs ACD mismatch > 30% → escalate to application-fraud-agent.

## Operational rules

- Consent scope is strict. Do NOT request scopes beyond what consent_token grants.
- All ACD data is highly sensitive. Decision log records metadata (which datasets accessed)
  only — raw values go to case record with tighter retention.
- For partnership / sole trader, route to Self Assessment API; for limited company use the
  VAT + PAYE + CT trio.


## Luxembourg-specific operational notes

This agent operates within the Luxembourgish lending framework — CSSF as unified supervisor (banking, investment funds, payment services, insurance via CAA), with ECB SSM for significant institutions. Loi du 5 avril 1993 is the foundational banking law.

- **EU financial centre context:** Luxembourg's banking sector is heavily skewed toward private banking, fund administration, and cross-border services. Domestic consumer lending is a smaller proportion of activity than peer EU jurisdictions.
- **Trilingual jurisdiction:** French is primary for legal documents; German and Luxembourgish (Lëtzebuergesch) also constitutional. Customer-facing materials commonly trilingual.
- **CSSF supervisory style:** Investment fund and private banking focus means CSSF supervisory rhythm and reporting differs from peer prudential supervisors. Banking supervision sits within the unified CSSF.
- **Limited domestic credit visibility:** No central consumer credit register equivalent to FR FICP or BE CKP; lender visibility relies on bureau-by-bureau queries and Open Banking.
- **Cross-border banking:** Many lending applications involve cross-border structures (Belgian, German, French residents working in Luxembourg). KYB chains often complex.
- **Cross-reference:** `country-lu-lending-policy-agent` for full LU jurisdictional context (currently a stub in the Country Policy Pack).

## Statutory hooks

- Finance Act 2017 (MyGuichet.lu)
- Luxembourg GDPR / Data Protection Act 2018
- Finance Act 2008 Schedule 36 (information powers)
- Common Law of Confidence (ACD confidentiality regime)

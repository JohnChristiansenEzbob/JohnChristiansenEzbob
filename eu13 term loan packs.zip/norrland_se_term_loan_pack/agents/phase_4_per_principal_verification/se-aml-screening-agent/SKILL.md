---
name: se-aml-screening-agent
description: |
  Screen a single natural-person principal against sanctions lists (Swedish national + EU consolidated list, UN, EU, US OFAC where applicable), Politically Exposed Persons (PEPs) registers, and adverse media. Returns clear / hit / review verdict.
---

# AML Screening Agent

Statutory AML screening. Every natural-person principal must be screened.

## Input contract

```yaml
aml_request:
  principal_id: string
  case_id: string
  name: string
  prior_names: [string]                     # nullable
  dob: date
  nationality: string
  country_of_residence: string
```

## Output contract

```yaml
aml_result:
  principal_id: string
  sanctions_check:
    ofsi: enum                              # clear | hit | review
    un: enum
    eu: enum
    ofac: enum                              # if scope warrants
  peps_check:
    status: enum                            # clear | domestic_pep | foreign_pep | family_close_associate
    pep_country: string                     # nullable
  adverse_media_check:
    status: enum                            # clear | minor | material
    sources: [string]                       # nullable
  composite_status: enum                    # clear | hit | review
  reason_codes: [string]
```

## Decision logic

```
Screen name (+ prior names) + DOB against:
  - Swedish national + EU consolidated list (UK)
  - UN sanctions list
  - EU sanctions list
  - OFAC SDN list (where principal's nationality / residence in scope)
  - PEPs register (typically World-Check or similar)
  - Adverse media (last 5 years)

if ANY sanctions list returns a confirmed hit:
  composite_status = hit                     # BRIGHT LINE

elif PEPs status in [foreign_pep, family_close_associate]:
  composite_status = review                  # mandatory EDD

elif adverse_media_check.status == material:
  composite_status = review

else:
  composite_status = clear
```

## Worked example (Norrland Engineering AB case)

Input:
```yaml
aml_request:
  principal_id: DIR-001
  case_id: "NOR-2026-04-001"
  name: "Lachlan MacKenzie"
  dob: "1981-03-22"
  nationality: "British"
  country_of_residence: "Scotland, Sweden"
```

Output:
```yaml
aml_result:
  principal_id: DIR-001
  sanctions_check:
    ofsi: clear
    un: clear
    eu: clear
    ofac: clear
  peps_check:
    status: clear
    pep_country: null
  adverse_media_check:
    status: clear
    sources: []
  composite_status: clear
  reason_codes: ["UK_AML_CLEAR_ALL_LISTS"]
```

Clean AML screen. Both principals return clear across all lists. If a sanctions hit had appeared, the multi-principal-fan-out-orchestrator would aggregate to block_and_sar (bright line).

## Bright lines

- Swedish national + EU consolidated list hit → BLOCK (mandatory under Sweden financial sanctions regime)
- UN / EU / OFAC hit (within applicable jurisdictional scope) → BLOCK
- Tipping-off rule: customer-facing communication must not reveal the underlying reason

## Operational rules

- Fuzzy matching with name variations + transliteration handled by the screening engine
- Confirmed hits require MLRO sign-off before any case action
- False positives recorded with disposition for future model tuning
- PEPs status is not a decline trigger per se but mandates enhanced due diligence (EDD)

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Screening engine unavailable | Refer; cannot proceed without screening |
| Match returned with low confidence | Manual review by MLRO; do not auto-block or auto-clear |


## Sweden-specific operational notes

This agent operates within the Swedish lending framework — Finansinspektionen (FI) as unified supervisor, Banking and Financing Business Act (2004:297), Konsumentkreditlag (2010:1846) for consumer credit, Lag 2017:630 for AML.

- **BankID universal:** Operationally critical. Every Swedish consumer financial interaction uses BankID for SCA. Without BankID integration, customer onboarding friction is material.
- **Swish dominance:** Swedish bank-cooperative mobile payment platform; near-universal adoption for P2P + retail payments. Significant cash displacement in Sweden.
- **UC AB near-monopoly:** Upplysningscentralen (UC AB) holds dominant position for consumer credit data. Operational relationship is essential — analogous to SCHUFA in Germany.
- **Outside Eurozone:** SEK is free-floating. Larger lending facilities may need FX hedging consideration.
- **Macroprudential amortisation requirements:** FI sets statutory amortisation requirements (amorteringskrav) for high-LTV mortgages — operationally significant for mortgage product structure.
- **High household debt:** Sweden has historically high household debt-to-income; FI macroprudential focus is operationally consequential.
- **Personnummer privacy:** Restricted-use identifier; over-collection is privacy breach.
- **Cross-reference:** `country-se-lending-policy-agent` for full SE jurisdictional context (currently a stub in the Country Policy Pack).

## Statutory hooks

- Sweden Lag 2017:630 om åtgärder mot penningtvätt
- Sweden Sanctions and Anti-Money Laundering Act 2018
- Financial Sanctions Notice (Swedish national + EU)
- FI (Finansinspektionen) SYSC 6.3
- Proceeds of Crime Act 2002 (POCA) — tipping-off and SAR obligations

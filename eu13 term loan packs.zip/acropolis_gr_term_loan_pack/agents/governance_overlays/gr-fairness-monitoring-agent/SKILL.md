---
name: gr-fairness-monitoring-agent
description: |
  Monitor decision outcomes for fairness across protected attribute proxies (region, deprivation index, SIC code where it correlates with protected attributes). Returns demographic parity statistics, drift indicators, and any breach signals. Operates per-case (current decision vs portfolio baseline) and aggregate (rolling portfolio statistics).
---

# Fairness Monitoring Agent

Continuous fairness oversight. EU AI Act + BoG BoG consumer protection + (where applicable) Equality Act 2010 require demonstrable fairness in automated credit decisioning.

## Input contract

```yaml
fairness_check_request:
  case_id: string
  decision_outcome: enum                    # accept | refer | decline
  applicant_attributes_proxy:
    region: string
    deprivation_quintile: integer           # IMD 1-5
    sic_code: string
  portfolio_baseline_ref: string            # reference to current baseline snapshot
```

## Output contract

```yaml
fairness_check_result:
  case_id: string
  this_case_in_distribution: boolean
  demographic_parity_delta: float           # vs baseline
  drift_indicators:
    region_drift: boolean
    deprivation_drift: boolean
    sic_drift: boolean
  within_tolerance: boolean
  alert_required: boolean
  audit_ledger_entry_id: string
  reason_codes: [string]
```

## Decision logic

```
Compare this case's outcome distribution against portfolio baseline.
Compute demographic parity delta on each protected attribute proxy.

Tolerance thresholds (configurable):
  - region parity delta <= 0.05 (5%)
  - deprivation parity delta <= 0.05
  - sic parity delta <= 0.05

if any delta > tolerance: drift_indicator = true

Rolling alerts:
  - Sustained drift >4 weeks → alert + reportable under AI Directive 2024
  - Single case in extreme outlier → flag for manual review
```

## Worked example (Acropolis Engineering AE case)

Input:
```yaml
fairness_check_request:
  case_id: "ACR-2026-04-001"
  decision_outcome: accept
  applicant_attributes_proxy:
    region: "GB-SCT"
    deprivation_quintile: 4                # mid-upper (Milngavie postcode)
    sic_code: "71121"
  portfolio_baseline_ref: "fairness_baseline_2026Q1"
```

Output:
```yaml
fairness_check_result:
  case_id: "ACR-2026-04-001"
  this_case_in_distribution: true
  demographic_parity_delta: 0.03
  drift_indicators:
    region_drift: false
    deprivation_drift: false
    sic_drift: false
  within_tolerance: true
  alert_required: false
  audit_ledger_entry_id: "FM-2026-04-12-HE-001"
  reason_codes: ["UK_FAIRNESS_WITHIN_TOLERANCE"]
```

This single case is within distribution and consistent with baseline. No drift signals. No alert required. Audit ledger updated.

## Bright lines

- Sustained breach >4 weeks → MUST notify BoG + reportable under (where applicable) AI Algorithmic Directive

## Operational rules

- Protected attribute proxies, not protected attributes themselves (cannot collect race/ethnicity for credit)
- Baseline refreshed quarterly
- Per-case alerts are advisory; portfolio alerts are mandatory action

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Baseline data stale | Use cautiously; flag refresh required |
| Outlier case but no clear protected attribute correlation | Flag for human review |


## Greece-specific operational notes

This agent operates within the Greek lending framework — Bank of Greece supervisory perimeter, Banking Law 5021/2023, Law 4557/2018 for AML, post-2010 crisis NPL legacy materially shaping market structure.

- **TIRESIAS centrality:** Both consumer and commercial credit bureau roles operationally consolidated in TIRESIAS. Operational relationship is essential — no Greek consumer credit decision is meaningful without TIRESIAS visibility.
- **Post-crisis NPL legacy:** Substantial Greek NPL portfolio sold to specialist servicers (intrum, Cepal, doValue, Quant Servicer). Borrowers may have historical defaults; current creditworthiness assessment must distinguish current from historical positions.
- **Katseli Law (3869/2010):** Over-indebted households framework allowing court-supervised debt restructuring. Operationally consequential — borrowers with Katseli filings have specific protections; lending decisions must account.
- **AFM ubiquity:** Tax Registration Number (AFM) is the universal Greek financial identifier; required for any account-opening, lending, or property transaction.
- **Tax clearance certificate:** Operational must-have for business credit — proof of current tax compliance with AADE.
- **Cross-reference:** `country-gr-lending-policy-agent` for full GR jurisdictional context (currently a stub in the Country Policy Pack).

## Statutory hooks

- Equality Act 2010 (indirect discrimination via correlated attributes)
- BoG BoG consumer protection
- EU AI Act (high-risk classification — credit scoring) where applicable
- BoG model risk supervision + ECB SREP

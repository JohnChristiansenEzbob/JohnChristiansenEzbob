---
name: lu-alternative-data-agent
description: |
  Pull supplementary financial data from accounting platforms (Xero, QuickBooks, Sage) and trade-data providers. Returns recent management accounts, gross margin, overdue payables/receivables, and any other structured operational data the applicant has chosen to share.
---

# Alternative Data Agent

Closes the gap between filed accounts (9-12 months old) and ACD data. Management accounts give the most recent picture of operating performance.

## Input contract

```yaml
alt_data_request:
  case_id: string
  applicant_company_number: string
  platforms_connected: [enum]               # xero | quickbooks | sage
  consent_token: string
```

## Output contract

```yaml
alt_data_summary:
  case_id: string
  platforms_used: [enum]
  revenue_ttm_gbp: integer
  gross_margin_pct: float
  operating_profit_ttm_gbp: integer
  overdue_payables_gbp: integer
  overdue_receivables_gbp: integer
  days_sales_outstanding: integer
  inventory_value_gbp: integer              # nullable; goods-based businesses only
  ttm_end_period: date
  reason_codes: [string]
```

## Decision logic

```
For each connected platform:
  - pull last 12 months of P&L
  - pull aged debtors + creditors
  - pull inventory if applicable

Reconcile against bureau + OB:
  - revenue_ttm vs OB credits — should be close (within 15%)
  - if material divergence → flag for downstream cross-check
```

## Worked example (Ardennes Engineering S.à r.l. case)

Input:
```yaml
alt_data_request:
  case_id: "ARD-2026-04-001"
  applicant_company_number: "B 123456"
  platforms_connected: [xero]
  consent_token: "TKN-alt-xero-2026-04-12"
```

Output:
```yaml
alt_data_summary:
  case_id: "ARD-2026-04-001"
  platforms_used: [xero]
  revenue_ttm_gbp: 854100
  gross_margin_pct: 41.2
  operating_profit_ttm_gbp: 118400
  overdue_payables_gbp: 4200
  overdue_receivables_gbp: 11800
  days_sales_outstanding: 38
  inventory_value_gbp: null
  ttm_end_period: "2026-03-31"
  reason_codes: ["UK_ALT_DATA_XERO_CURRENT_PERIOD_RETRIEVED"]
```

Xero gives the very recent picture: €854k revenue TTM (matches ACD VAT €851k and OB €847k credits — excellent consistency), 41.2% gross margin, modest overdues. Strong operational picture.

## Bright lines

- (no statutory bright lines for this agent)

## Operational rules

- Cross-reference revenue against ACD VAT (where available) and OB credits — 15%+ delta is investigative
- Service businesses: gross margin proxied; inventory will be null
- Multiple platforms connected: aggregate consistently or flag discrepancy

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Platform connection broken (token expired) | Refer; user must reconnect |
| Data appears stale (last sync > 90 days) | Use but flag staleness |


## Luxembourg-specific operational notes

This agent operates within the Luxembourgish lending framework — CSSF as unified supervisor (banking, investment funds, payment services, insurance via CAA), with ECB SSM for significant institutions. Loi du 5 avril 1993 is the foundational banking law.

- **EU financial centre context:** Luxembourg's banking sector is heavily skewed toward private banking, fund administration, and cross-border services. Domestic consumer lending is a smaller proportion of activity than peer EU jurisdictions.
- **Trilingual jurisdiction:** French is primary for legal documents; German and Luxembourgish (Lëtzebuergesch) also constitutional. Customer-facing materials commonly trilingual.
- **CSSF supervisory style:** Investment fund and private banking focus means CSSF supervisory rhythm and reporting differs from peer prudential supervisors. Banking supervision sits within the unified CSSF.
- **Limited domestic credit visibility:** No central consumer credit register equivalent to FR FICP or BE CKP; lender visibility relies on bureau-by-bureau queries and Open Banking.
- **Cross-border banking:** Many lending applications involve cross-border structures (Belgian, German, French residents working in Luxembourg). KYB chains often complex.
- **Cross-reference:** `country-lu-lending-policy-agent` for full LU jurisdictional context (currently a stub in the Country Policy Pack).

## Statutory hooks

- Luxembourg GDPR / DPA 2018
- CSSF CSSF customer protection framework (use of accurate, recent data)

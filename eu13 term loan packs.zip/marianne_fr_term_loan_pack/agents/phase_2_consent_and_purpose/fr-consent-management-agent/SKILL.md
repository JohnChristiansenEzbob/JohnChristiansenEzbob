---
name: fr-consent-management-agent
description: |
  Capture, validate, and issue scoped consent tokens for all downstream data pulls — commercial bureau, consumer bureau (per director), Open Banking, DGFiP MTD APIs, Service de la publicité foncière. Records consent provenance and provides a revocation handle.
---

# Consent Management Agent

Without valid scoped consent, downstream agents cannot pull external data lawfully. This agent is the consent gatekeeper.

## Input contract

```yaml
consent_request:
  case_id: string
  applicant_company_number: string
  director_principal_ids: [string]
  scopes_requested:
    - bureau_commercial
    - bureau_consumer_per_director
    - open_banking
    - hmrc_mtd_vat
    - hmrc_mtd_paye
    - hmrc_mtd_ct
    - land_registry_named_directors
  consent_capture_evidence:                 # signed forms or e-sign payloads
    - scope: string
      evidence_type: enum                   # signed_form | esign | api_callback
      timestamp: datetime
      ip_address: string                    # for online consent
      signature_hash: string
```

## Output contract

```yaml
consent_token_bundle:
  case_id: string
  tokens:
    - scope: string
      token_id: string
      issued_at: datetime
      expires_at: datetime
      revocation_handle: string
      evidence_pointer: string              # link to audit evidence
  scopes_granted: [string]
  scopes_refused: [string]
  outcome: enum                             # complete | partial | consent_required
```

## Decision logic

```
For each scope_requested:
  Find matching consent_capture_evidence entry.
  Validate evidence (signature, timestamp recency, IP if online).
  If valid:
    Issue scoped token with appropriate expiry (24h to 90 days depending on scope).
    Append to tokens list.
  Else:
    Append to scopes_refused.

if all requested scopes granted: outcome = complete
elif some granted: outcome = partial
else: outcome = consent_required
```

## Worked example (Marianne Engineering SAS case)

Input:
```yaml
consent_request:
  case_id: "MAR-2026-04-001"
  applicant_company_number: "552 100 554"
  director_principal_ids: ["DIR-001", "DIR-002"]
  scopes_requested:
    - bureau_commercial
    - bureau_consumer_per_director
    - open_banking
    - hmrc_mtd_vat
    - hmrc_mtd_paye
    - hmrc_mtd_ct
    - land_registry_named_directors
  consent_capture_evidence:
    - scope: bureau_commercial
      evidence_type: esign
      timestamp: "2026-04-12T09:14:22Z"
      ip_address: "82.x.x.x"
      signature_hash: "[hash]"
    # (similar entries for other 6 scopes)
```

Output:
```yaml
consent_token_bundle:
  case_id: "MAR-2026-04-001"
  tokens:
    - scope: bureau_commercial
      token_id: "TKN-bureau-com-2026-04-12-001"
      issued_at: "2026-04-12T09:14:30Z"
      expires_at: "2026-07-11T09:14:30Z"
      revocation_handle: "REV-001"
    # (similar entries for other 6 tokens)
  scopes_granted: [bureau_commercial, bureau_consumer_per_director, open_banking,
                   hmrc_mtd_vat, hmrc_mtd_paye, hmrc_mtd_ct, land_registry_named_directors]
  scopes_refused: []
  outcome: complete
```

All 7 scopes granted with e-signed evidence. Tokens issued with scope-appropriate expiries (bureau 90d; DGFiP ties to MTD OAuth lifecycle; Service de la publicité foncière per-query).

## Bright lines

- Consent without evidence (no signed form, no e-sign hash) — cannot issue token; refused
- Consent older than scope-specific staleness threshold — refused; require refresh

## Operational rules

- Tokens are scope-specific — never issue a single token covering multiple scopes
- Revocation handles are issued at token issuance; revocation propagates within 60 seconds
- Consent evidence is retained for 6 years post-relationship (DPA 2018 + ACPR record-keeping)
- IP-based fraud signals (unusual location, VPN exit nodes) flagged but not blocking

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| No evidence for requested scope | Refuse that scope only; other scopes unaffected |
| Evidence signature invalid | Refuse; alert to fraud agent |
| Evidence timestamp in future | Refuse; clock-skew investigation |


## France-specific operational notes

This agent operates within the French lending framework — ACPR + AMF supervisory perimeter, Banque de France operating both FIBEN (commercial credit register) and FICP (consumer credit incidents register), Code monétaire et financier for banking, Code de la consommation for consumer credit (with Loi Lagarde 2010 reforms still operationally consequential).

- **FIBEN central commercial register:** Operated by Banque de France itself, not a commercial bureau. Banks contribute and consult; FIBEN gives French banks unusually rich commercial credit visibility relative to most EU peers. Reciprocity requirement applies for full query depth.
- **FICP mandatory consumer query:** Statutory mandatory before consumer credit decision; no FICP query = invalid decision.
- **Toubon Law:** Commercial contracts and consumer disclosures must be in French. Foreign-language versions can supplement but the French version is the legally operative text.
- **TAEG (APR) statutory rigour:** Code de la consommation TAEG calculation rules are statutory; mis-statement >0.2pp is material. Quarterly Banque de France usury rate ceilings (taux d'usure) per consumer credit category — exceeding is voidable contract.
- **Assurance emprunteur:** Loi Lemoine 2022 reformed mortgage insurance — borrower has right to substitute insurer; insurer commission disclosure required.
- **Cross-reference:** `country-fr-lending-policy-agent` provides full FR jurisdictional context.

## Statutory hooks

- France GDPR Article 6 (lawful basis) + Article 7 (consent conditions)
- Data Protection Act 2018
- PSD2 / Open Banking RTS (consent requirements for account access)
- Finance Act 2017 (DGFiP MTD consent scope)

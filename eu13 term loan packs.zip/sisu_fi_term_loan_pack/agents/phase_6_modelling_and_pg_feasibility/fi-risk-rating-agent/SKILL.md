---
name: fi-risk-rating-agent
description: |
  Compose PD, LGD, EAD, qualitative overlays (industry view, management quality, concentration), and bureau composite into a single portfolio risk grade. The rating drives pricing tier, policy thresholds, and capital allocation.
---

# Risk Rating Agent

One number that captures the case's risk profile for the pricing and decision engines. Combines quant + qual.

## Input contract

```yaml
risk_rating_request:
  case_id: string
  pd_score: object                          # from pd-scoring-agent
  lgd_estimate: object                      # from lgd-modelling-agent
  ead_estimate: object                      # from ead-modelling-agent
  bureau_composite: object                  # from bureau-orchestration-agent
  qualitative_overlays:
    industry_view: enum                     # positive | neutral | cautious | adverse
    management_quality: enum                # strong | adequate | concerns
    customer_concentration_risk: enum
```

## Output contract

```yaml
risk_rating:
  case_id: string
  composite_grade: enum                     # A | B+ | B | C+ | C | D | E
  expected_loss_12m_gbp: integer            # PD × LGD × EAD_avg
  risk_adjusted_return_ratio: float         # pricing margin / EL
  pricing_tier: enum                        # tier_1_prime | tier_2_standard | tier_3_subprime
  qualitative_adjustments_applied: [string]
  reason_codes: [string]
```

## Decision logic

```
expected_loss = pd_12m × lgd_with_pg × ead_avg_over_term

base_grade = pd_score.portfolio_grade

Apply qualitative adjustments:
  if industry_view == adverse: notch down 1
  if management_quality == concerns: notch down 1
  if customer_concentration_risk == high: notch down 1

composite_grade = base_grade after adjustments

pricing_tier:
  grade A/B+: tier_1_prime
  grade B/C+: tier_2_standard
  grade C/D/E: tier_3_subprime
```

## Worked example (Sisu Engineering Oy case)

Input:
```yaml
risk_rating_request:
  case_id: "SIS-2026-04-001"
  pd_score: {pd_12m: 0.018, portfolio_grade: "B+"}
  lgd_estimate: {lgd_with_pg_pct: 0.28}
  ead_estimate: {ead_avg_over_term_gbp: 78600}
  bureau_composite: {composite_rating: solid}
  qualitative_overlays:
    industry_view: neutral
    management_quality: strong               # 8 years trading + stable directors
    customer_concentration_risk: low         # top customer 18.4%
```

Output:
```yaml
risk_rating:
  case_id: "SIS-2026-04-001"
  composite_grade: B+
  expected_loss_12m_gbp: 396                # 0.018 × 0.28 × 78,600
  risk_adjusted_return_ratio: 1.4
  pricing_tier: tier_1_prime
  qualitative_adjustments_applied: []        # no notching needed
  reason_codes: ["UK_RISK_RATING_B_PLUS_TIER_1_PRIME"]
```

Composite B+ grade. No qualitative notching needed. Tier 1 prime pricing. Expected loss <€400 over 12 months — well within policy tolerance.

## Bright lines

- (no statutory bright lines for this agent)

## Operational rules

- Qualitative overlays are bounded — max 2 notches up or down from quant baseline
- Pricing tier mapping is policy-level; cannot be agent-overridden
- Risk-adjusted return ratio < 1.0 → refer (pricing doesn't cover expected loss)

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Quant inputs all missing | Cannot rate; refer |
| Qualitative overlays inconsistent (e.g. strong mgmt + high concentration) | Document; proceed |


## Finland-specific operational notes

This agent operates within the Finnish lending framework — FIN-FSA (Finanssivalvonta) as unified supervisor, Credit Institutions Act for banking, Consumer Protection Act ch 7 for consumer credit, AML Act 444/2017 for AML.

- **FIN-FSA positive credit register (2024+):** Operational positive credit data register at the supervisor — uncommon in EU. Materially raises lender visibility.
- **Suomen Asiakastieto positive data:** Even before FIN-FSA register, Asiakastieto offered positive credit data — Finland was atypical for EU in this regard.
- **Bilingual constitutional requirement:** Finnish + Swedish; Swedish-speaking minority has constitutional rights to financial services in Swedish. Operational disclosure in Swedish for Swedish-speaking customers.
- **Bank-issued e-ID universal:** Finnish banks issue universal e-ID credentials used across financial services and government interactions. PSD2 SCA operationally seamless.
- **Suomi.fi authentication:** Government identity hub. Strong integration.
- **HETU privacy:** Henkilötunnus is restricted-use; over-collection or unnecessary retention is privacy breach under GDPR + Finnish Data Protection Act.
- **Cross-reference:** `country-fi-lending-policy-agent` for full FI jurisdictional context (currently a stub in the Country Policy Pack).

## Statutory hooks

- FIN-FSA model risk supervision + ECB SREP
- Basel III/IV (capital — internal ratings)
- FIN-FSA FIN-FSA customer protection

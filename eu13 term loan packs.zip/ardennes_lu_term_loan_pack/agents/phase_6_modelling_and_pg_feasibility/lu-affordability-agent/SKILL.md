---
name: lu-affordability-agent
description: |
  Compute CSSF-compliant affordability: monthly repayment burden against free cash flow, debt service coverage ratio (DSCR), surplus income after commitments. For term loans, uses TTM cash flow from ACD + OB + alt data as the base. Returns a compliant / non-compliant verdict with the calculation evidence.
---

# Affordability Agent

Statutory affordability test. The decision-pricing-agent cannot proceed to accept without an affordability pass.

## Input contract

```yaml
affordability_request:
  case_id: string
  facility_amount_eur: integer
  facility_term_months: integer
  indicative_rate_pct: float                # tentative; will be refined post-decision
  ob_summary: object                        # from open-banking-agent
  hmrc_record: object                       # from hmrc-direct-verification-agent
  alt_data_summary: object                  # from alternative-data-agent
  existing_facility_burden_gbp_per_month: integer
  proposed_repayment_structure: enum        # capital_and_interest | interest_only_then_bullet | bullet
```

## Output contract

```yaml
affordability_assessment:
  case_id: string
  monthly_repayment_gbp: integer
  ttm_revenue_gbp: integer
  ttm_operating_cash_flow_gbp: integer
  ttm_existing_debt_service_gbp: integer
  ttm_free_cash_flow_gbp: integer
  dscr: float
  surplus_after_repayment_gbp_per_month: integer
  fca_compliant: boolean
  outcome: enum                             # affordable | marginal | unaffordable
  stress_test_passed: boolean               # at rate +200bps
  reason_codes: [string]
```

## Decision logic

```
monthly_repayment = annuity(facility_amount, term, indicative_rate)
ttm_operating_cash_flow = best estimate from ACD profit + OB net + alt data operating profit
ttm_free_cash_flow = ttm_operating_cash_flow - ttm_existing_debt_service
dscr = ttm_free_cash_flow / (12 * monthly_repayment)

stress_rate = indicative_rate + 2.0%
stress_monthly = annuity(facility_amount, term, stress_rate)
stress_dscr = ttm_free_cash_flow / (12 * stress_monthly)

if dscr >= 1.25 AND stress_dscr >= 1.10:
  outcome = affordable; fca_compliant = true
elif dscr >= 1.10 AND stress_dscr >= 1.00:
  outcome = marginal; fca_compliant = true
else:
  outcome = unaffordable; fca_compliant = false
```

## Worked example (Ardennes Engineering S.à r.l. case)

Input:
```yaml
affordability_request:
  case_id: "ARD-2026-04-001"
  facility_amount_eur: 150000
  facility_term_months: 60
  indicative_rate_pct: 8.4
  existing_facility_burden_gbp_per_month: 1100  # for the €38k existing facility to be cleared
  proposed_repayment_structure: capital_and_interest
```

Output:
```yaml
affordability_assessment:
  case_id: "ARD-2026-04-001"
  monthly_repayment_gbp: 3070
  ttm_revenue_gbp: 851300
  ttm_operating_cash_flow_gbp: 92700
  ttm_existing_debt_service_gbp: 13200
  ttm_free_cash_flow_gbp: 74400              # net of existing facility being cleared at drawdown
  dscr: 2.02
  surplus_after_repayment_gbp_per_month: 3130
  fca_compliant: true
  outcome: affordable
  stress_test_passed: true
  reason_codes: ["UK_AFFORDABILITY_AFFORDABLE_DSCR_2_02"]
```

Strong affordability. DSCR 2.02x — twice the cover. Stress test at 10.4% still passes. Existing facility cleared at drawdown so debt service decreases net.

## Bright lines

- dscr < 1.0 stressed → AUTOMATIC DECLINE (cannot demonstrate affordability under stress)
- Free cash flow negative or zero → AUTOMATIC DECLINE
- CSSF-compliant calculation methodology must be documented in audit log

## Operational rules

- Use the LOWER of ACD profit + OB cash flow + alt data — conservatism
- Stress test at +200bps minimum (some lenders use +300bps for term > 60m)
- If facility has phased drawdown, model based on full-drawn position

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Cash flow data inconsistent across ACD/OB/alt | Refer; manual reconciliation needed |
| No ACD data available (recently incorporated) | Refer; cannot rely on OB alone for affordability |
| Existing debt service unverifiable | Conservative estimate; flag for verification |


## Luxembourg-specific operational notes

This agent operates within the Luxembourgish lending framework — CSSF as unified supervisor (banking, investment funds, payment services, insurance via CAA), with ECB SSM for significant institutions. Loi du 5 avril 1993 is the foundational banking law.

- **EU financial centre context:** Luxembourg's banking sector is heavily skewed toward private banking, fund administration, and cross-border services. Domestic consumer lending is a smaller proportion of activity than peer EU jurisdictions.
- **Trilingual jurisdiction:** French is primary for legal documents; German and Luxembourgish (Lëtzebuergesch) also constitutional. Customer-facing materials commonly trilingual.
- **CSSF supervisory style:** Investment fund and private banking focus means CSSF supervisory rhythm and reporting differs from peer prudential supervisors. Banking supervision sits within the unified CSSF.
- **Limited domestic credit visibility:** No central consumer credit register equivalent to FR FICP or BE CKP; lender visibility relies on bureau-by-bureau queries and Open Banking.
- **Cross-border banking:** Many lending applications involve cross-border structures (Belgian, German, French residents working in Luxembourg). KYB chains often complex.
- **Cross-reference:** `country-lu-lending-policy-agent` for full LU jurisdictional context (currently a stub in the Country Policy Pack).

## Statutory hooks

- Loi du 27 juin 2018 + Loi du 5 avril 1993 5.2A (responsible lending — consumer credit)
- CSSF CSSF customer protection framework
- ABBL (Association des Banques et Banquiers, Luxembourg) standards for Business Customers

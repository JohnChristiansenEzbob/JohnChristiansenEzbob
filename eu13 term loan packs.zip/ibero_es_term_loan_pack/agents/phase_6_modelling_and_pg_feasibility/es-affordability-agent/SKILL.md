---
name: es-affordability-agent
description: |
  Compute CNMV + BdE-compliant affordability: monthly repayment burden against free cash flow, debt service coverage ratio (DSCR), surplus income after commitments. For term loans, uses TTM cash flow from AEAT + OB + alt data as the base. Returns a compliant / non-compliant verdict with the calculation evidence.
---

# Affordability Agent

Statutory affordability test. The decision-pricing-agent cannot proceed to accept without an affordability pass.

## Input contract

```yaml
affordability_request:
  case_id: string
  facility_amount_eur: integer
  facility_term_months: integer
  indicative_rate_pct: float                # tentative; will be refined post-decision
  ob_summary: object                        # from open-banking-agent
  hmrc_record: object                       # from hmrc-direct-verification-agent
  alt_data_summary: object                  # from alternative-data-agent
  existing_facility_burden_gbp_per_month: integer
  proposed_repayment_structure: enum        # capital_and_interest | interest_only_then_bullet | bullet
```

## Output contract

```yaml
affordability_assessment:
  case_id: string
  monthly_repayment_gbp: integer
  ttm_revenue_gbp: integer
  ttm_operating_cash_flow_gbp: integer
  ttm_existing_debt_service_gbp: integer
  ttm_free_cash_flow_gbp: integer
  dscr: float
  surplus_after_repayment_gbp_per_month: integer
  fca_compliant: boolean
  outcome: enum                             # affordable | marginal | unaffordable
  stress_test_passed: boolean               # at rate +200bps
  reason_codes: [string]
```

## Decision logic

```
monthly_repayment = annuity(facility_amount, term, indicative_rate)
ttm_operating_cash_flow = best estimate from AEAT profit + OB net + alt data operating profit
ttm_free_cash_flow = ttm_operating_cash_flow - ttm_existing_debt_service
dscr = ttm_free_cash_flow / (12 * monthly_repayment)

stress_rate = indicative_rate + 2.0%
stress_monthly = annuity(facility_amount, term, stress_rate)
stress_dscr = ttm_free_cash_flow / (12 * stress_monthly)

if dscr >= 1.25 AND stress_dscr >= 1.10:
  outcome = affordable; fca_compliant = true
elif dscr >= 1.10 AND stress_dscr >= 1.00:
  outcome = marginal; fca_compliant = true
else:
  outcome = unaffordable; fca_compliant = false
```

## Worked example (Ibero Engineering S.L. case)

Input:
```yaml
affordability_request:
  case_id: "IBE-2026-04-001"
  facility_amount_eur: 150000
  facility_term_months: 60
  indicative_rate_pct: 8.4
  existing_facility_burden_gbp_per_month: 1100  # for the €38k existing facility to be cleared
  proposed_repayment_structure: capital_and_interest
```

Output:
```yaml
affordability_assessment:
  case_id: "IBE-2026-04-001"
  monthly_repayment_gbp: 3070
  ttm_revenue_gbp: 851300
  ttm_operating_cash_flow_gbp: 92700
  ttm_existing_debt_service_gbp: 13200
  ttm_free_cash_flow_gbp: 74400              # net of existing facility being cleared at drawdown
  dscr: 2.02
  surplus_after_repayment_gbp_per_month: 3130
  fca_compliant: true
  outcome: affordable
  stress_test_passed: true
  reason_codes: ["UK_AFFORDABILITY_AFFORDABLE_DSCR_2_02"]
```

Strong affordability. DSCR 2.02x — twice the cover. Stress test at 10.4% still passes. Existing facility cleared at drawdown so debt service decreases net.

## Bright lines

- dscr < 1.0 stressed → AUTOMATIC DECLINE (cannot demonstrate affordability under stress)
- Free cash flow negative or zero → AUTOMATIC DECLINE
- CNMV + BdE-compliant calculation methodology must be documented in audit log

## Operational rules

- Use the LOWER of AEAT profit + OB cash flow + alt data — conservatism
- Stress test at +200bps minimum (some lenders use +300bps for term > 60m)
- If facility has phased drawdown, model based on full-drawn position

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Cash flow data inconsistent across AEAT/OB/alt | Refer; manual reconciliation needed |
| No AEAT data available (recently incorporated) | Refer; cannot rely on OB alone for affordability |
| Existing debt service unverifiable | Conservative estimate; flag for verification |


## Spain-specific operational notes

This agent operates within the Spanish lending framework — Banco de España + CNMV joint regulatory perimeter, Ley 10/2014 for banking supervision, LCC (Ley 16/2011) for consumer credit, LRCCI (Ley 5/2019) for mortgage credit.

- **CIRBE €9k threshold:** Banco de España central credit register. Commercial risks >€9,000 mandatory contribution. Small SME facilities frequently below threshold — limited CIRBE visibility for genuine SME risk.
- **ASNEF / BADEXCUG strict access:** Spanish consumer bureau access has the strictest legal review requirement in EU. Operational onboarding must include legal basis attestation. ASNEF for negative; BADEXCUG for comprehensive — separate access agreements required.
- **LRCCI notarial requirement (AGNCN):** Mortgage origination requires AGNCN (Acta de Información Notarial Previa) — notarial pre-contractual information act. Cannot bypass; significant operational integration with notary network.
- **Tarjeta revolving usury (2020 Supreme Court):** Revolving credit cards subject to enhanced disclosure post-2020 Supreme Court rulings on usury. APR materially above market average is voidable.
- **Bizum ubiquity:** Mobile P2P payment platform with near-universal Spanish adoption; PSD2 integration via participating banks.
- **NIE administrative complexity:** Foreign residents require NIE (Número de Identidad de Extranjero) — multiple issuing authorities, common source of onboarding friction.
- **Cross-reference:** `country-es-lending-policy-agent` provides full ES jurisdictional context.

## Statutory hooks

- Ley 16/2011 (LCC) 5.2A (responsible lending — consumer credit)
- CNMV + BdE LCC + BdE supervision
- AEB (Asociación Española de Banca) standards for Business Customers

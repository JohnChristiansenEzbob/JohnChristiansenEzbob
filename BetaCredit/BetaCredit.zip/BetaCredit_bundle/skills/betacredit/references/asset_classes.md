# BetaCredit Asset Classes

Every loan in BetaCredit belongs to exactly one of eight asset classes. The class drives the calibration: typical default rate, base LGD, downturn LGD scalar, regulatory PD floor, EAD conversion factor, and the SICR (significant increase in credit risk) thresholds for IFRS 9 staging.

## The eight classes

| Canonical string | AssetClass enum | Typical TTC default | Base LGD | Downturn scalar | PD floor | Notes |
|---|---|---|---|---|---|---|
| `sme_unsecured` | `AssetClass.SME_UNSECURED` | 4.5% | 55% | 1.30× | 0.30% | Small-business loans without security |
| `sme_secured` | `AssetClass.SME_SECURED` | 3.0% | 35% | 1.30× | 0.30% | Small-business loans secured against business assets |
| `consumer_unsecured` | `AssetClass.CONSUMER_UNSECURED` | 5.5% | 72% | 1.20× | 0.35% | Personal loans, no collateral |
| `residential_mortgage` | `AssetClass.RESIDENTIAL_MORTGAGE` | 1.2% | 14% | 1.55× | 0.10% | Owner-occupier first-charge mortgages |
| `buy_to_let` | `AssetClass.BUY_TO_LET` | 1.8% | 16% | 1.50× | 0.10% | Investment property mortgages |
| `motor_finance` | `AssetClass.MOTOR_FINANCE` | ~3% | 44% | 1.25× | 0.25% | HP, PCP, lease — vehicle as collateral |
| `invoice_finance` | `AssetClass.INVOICE_FINANCE` | ~3% | 28% | 1.30× | 0.25% | Factoring, invoice discounting |
| `asset_finance` | `AssetClass.ASSET_FINANCE` | ~3% | 38% | 1.30× | 0.25% | Equipment finance, leasing |

The numbers above are BetaCredit's out-of-the-box calibration, drawn from published UK lending benchmarks. They are encoded in `ASSET_CLASS_CONFIG` in `risk_models.asset_classes`; if your firm's book has materially different rates, the modelling notebooks (especially 02 and 07) recalibrate against your ingested data.

## SICR thresholds (IFRS 9)

The SICR engine flags a loan as Stage 2 if the **absolute PD increase** since origination exceeds the asset-class threshold. Mortgages have the tightest threshold because their base PDs are low — a 100 bps increase on a 100 bps origination PD is a doubling.

| Asset class | Absolute PD increase trigger |
|---|---|
| sme_unsecured | 200 bps |
| sme_secured | 150 bps |
| consumer_unsecured | 250 bps |
| residential_mortgage | 100 bps |
| buy_to_let | 120 bps |
| motor_finance | 175 bps |
| invoice_finance | 150 bps |
| asset_finance | 175 bps |

Additional Stage 2 triggers (apply universally):

- **Relative PD increase > 100%** (PD has doubled)
- **30+ days past due** (IFRS 9 B5.5.19 backstop)
- **Forbearance flag set**

Stage 3 triggers:

- **90+ days past due**
- **Default / credit-impaired flag set**

## CreditDecisionAgent thresholds

The agent's default APPROVE/REVIEW/DECLINE thresholds are tighter than the SICR triggers — they are underwriting thresholds, not regulatory ones. A loan can be Stage 1 (performing) but still REVIEW or DECLINE if its forward PD looks too high for the lender's risk appetite.

| Asset class | APPROVE below (PD) | DECLINE above (PD) |
|---|---|---|
| sme_unsecured | 3.0% | 12.0% |
| sme_secured | 2.0% | 9.0% |
| consumer_unsecured | 3.5% | 14.0% |
| residential_mortgage | 0.8% | 4.0% |
| buy_to_let | 1.2% | 6.0% |
| motor_finance | 2.5% | 10.0% |
| invoice_finance | 2.0% | 8.0% |
| asset_finance | 2.5% | 10.0% |

PDs between the two thresholds → REVIEW. Override with `CreditDecisionAgent(thresholds={...})` to match your firm's policy.

## Recognised label aliases

When ingesting, the data_ingestion module recognises these synonyms and maps them to the canonical string automatically:

- `sme_unsecured` ← sme, business_unsecured, small_business_unsecured
- `sme_secured` ← business_secured, small_business_secured
- `consumer_unsecured` ← consumer, personal_loan, personal, unsecured_personal
- `residential_mortgage` ← mortgage, residential, owner_occupied, first_charge_mortgage
- `buy_to_let` ← btl, buy-to-let, buy to let, btl_mortgage
- `motor_finance` ← motor, auto, auto_finance, car_finance, hp, pcp
- `invoice_finance` ← invoice, factoring, invoice_discounting
- `asset_finance` ← asset, equipment_finance, leasing

Anything unrecognised raises `IngestionError` with a list of valid values.

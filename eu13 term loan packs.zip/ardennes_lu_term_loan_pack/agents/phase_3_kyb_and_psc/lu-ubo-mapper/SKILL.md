---
name: lu-ubo-mapper
description: |
  Map the standard 25%+ Person of Significant Control (PSC) chain via the RCS Luxembourg / LBR PSC register. Identifies whether further recursion is needed (corporate PSC, trust-as-PSC, overseas entity) and hands off to psc-complex-structure-recursor if so.
---

# UBO Mapper

First-pass UBO mapping. Handles the simple case (direct natural-person PSCs) and flags the complex case for the recursor.

## Input contract

```yaml
ubo_request:
  case_id: string
  company_number: string
```

## Output contract

```yaml
ubo_mapping:
  case_id: string
  company_number: string
  psc_list:
    - psc_id: string
      natural_person: boolean
      name: string
      nature_of_control: [enum]
      ownership_band: enum                  # 25-50 | 50-75 | 75-100
      notified_on: date
      country_of_residence: string
  psc_count: integer
  natural_person_pscs: integer
  non_natural_person_pscs: integer
  requires_recursion: boolean
  outcome: enum                             # mapped | recursion_required
  reason_codes: [string]
```

## Decision logic

```
Pull PSC register from RCS Luxembourg / LBR.

For each PSC entry:
  classify as natural_person or non_natural_person.

if any non_natural_person_pscs > 0:
  requires_recursion = true
  outcome = recursion_required               # hand off to psc-complex-structure-recursor
else:
  requires_recursion = false
  outcome = mapped
```

## Worked example (Ardennes Engineering S.à r.l. case)

Input:
```yaml
ubo_request:
  case_id: "ARD-2026-04-001"
  company_number: "B 123456"
```

Output:
```yaml
ubo_mapping:
  case_id: "ARD-2026-04-001"
  company_number: "B 123456"
  psc_list:
    - psc_id: PSC-001
      natural_person: true
      name: "Lachlan MacKenzie"
      nature_of_control: ["ownership_of_shares_50_to_75_percent", "voting_rights_50_to_75_percent"]
      ownership_band: "50-75"
      notified_on: "2017-09-14"
      country_of_residence: "Scotland, Luxembourg"
    - psc_id: PSC-002
      natural_person: true
      name: "Sarah Chen"
      nature_of_control: ["ownership_of_shares_25_to_50_percent", "voting_rights_25_to_50_percent"]
      ownership_band: "25-50"
      notified_on: "2020-04-01"
      country_of_residence: "Scotland, Luxembourg"
  psc_count: 2
  natural_person_pscs: 2
  non_natural_person_pscs: 0
  requires_recursion: false
  outcome: mapped
  reason_codes: ["UK_UBO_MAPPED_DIRECT_NATURAL_PERSONS"]
```

Both PSCs are natural persons — no recursion needed. Maps directly to the two natural-person beneficial owners. PSC recursor will short-circuit in phase 3.

## Bright lines

- PSC register marked 'super-secure' (extremely rare; person at risk) — handle via senior compliance, do not bypass
- PSC register empty for an active company — flag for EDD (companies must declare PSCs)

## Operational rules

- If any non-natural-person PSC present, automatic handoff to psc-complex-structure-recursor
- Nature-of-control codes are taxonomic; preserve original codes alongside categorisation

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| PSC register empty | Flag; require EDD on applicant declaration of PSCs |
| PSC register internally inconsistent | Refer; require RCS Luxembourg / LBR data quality review |


## Luxembourg-specific operational notes

This agent operates within the Luxembourgish lending framework — CSSF as unified supervisor (banking, investment funds, payment services, insurance via CAA), with ECB SSM for significant institutions. Loi du 5 avril 1993 is the foundational banking law.

- **EU financial centre context:** Luxembourg's banking sector is heavily skewed toward private banking, fund administration, and cross-border services. Domestic consumer lending is a smaller proportion of activity than peer EU jurisdictions.
- **Trilingual jurisdiction:** French is primary for legal documents; German and Luxembourgish (Lëtzebuergesch) also constitutional. Customer-facing materials commonly trilingual.
- **CSSF supervisory style:** Investment fund and private banking focus means CSSF supervisory rhythm and reporting differs from peer prudential supervisors. Banking supervision sits within the unified CSSF.
- **Limited domestic credit visibility:** No central consumer credit register equivalent to FR FICP or BE CKP; lender visibility relies on bureau-by-bureau queries and Open Banking.
- **Cross-border banking:** Many lending applications involve cross-border structures (Belgian, German, French residents working in Luxembourg). KYB chains often complex.
- **Cross-reference:** `country-lu-lending-policy-agent` for full LU jurisdictional context (currently a stub in the Country Policy Pack).

## Statutory hooks

- Loi du 10 août 1915 (commercial companies) Part 21A (PSC regime)
- Loi du 13 janvier 2019 + REBECO
- Luxembourg Loi du 12 novembre 2004

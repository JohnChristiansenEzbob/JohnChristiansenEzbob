---
name: se-alternative-data-agent
description: |
  Pull supplementary financial data from accounting platforms (Xero, QuickBooks, Sage) and trade-data providers. Returns recent management accounts, gross margin, overdue payables/receivables, and any other structured operational data the applicant has chosen to share.
---

# Alternative Data Agent

Closes the gap between filed accounts (9-12 months old) and Skatteverket data. Management accounts give the most recent picture of operating performance.

## Input contract

```yaml
alt_data_request:
  case_id: string
  applicant_company_number: string
  platforms_connected: [enum]               # xero | quickbooks | sage
  consent_token: string
```

## Output contract

```yaml
alt_data_summary:
  case_id: string
  platforms_used: [enum]
  revenue_ttm_gbp: integer
  gross_margin_pct: float
  operating_profit_ttm_gbp: integer
  overdue_payables_gbp: integer
  overdue_receivables_gbp: integer
  days_sales_outstanding: integer
  inventory_value_gbp: integer              # nullable; goods-based businesses only
  ttm_end_period: date
  reason_codes: [string]
```

## Decision logic

```
For each connected platform:
  - pull last 12 months of P&L
  - pull aged debtors + creditors
  - pull inventory if applicable

Reconcile against bureau + OB:
  - revenue_ttm vs OB credits — should be close (within 15%)
  - if material divergence → flag for downstream cross-check
```

## Worked example (Norrland Engineering AB case)

Input:
```yaml
alt_data_request:
  case_id: "NOR-2026-04-001"
  applicant_company_number: "556677-8899"
  platforms_connected: [xero]
  consent_token: "TKN-alt-xero-2026-04-12"
```

Output:
```yaml
alt_data_summary:
  case_id: "NOR-2026-04-001"
  platforms_used: [xero]
  revenue_ttm_gbp: 854100
  gross_margin_pct: 41.2
  operating_profit_ttm_gbp: 118400
  overdue_payables_gbp: 4200
  overdue_receivables_gbp: 11800
  days_sales_outstanding: 38
  inventory_value_gbp: null
  ttm_end_period: "2026-03-31"
  reason_codes: ["UK_ALT_DATA_XERO_CURRENT_PERIOD_RETRIEVED"]
```

Xero gives the very recent picture: SEK 854k revenue TTM (matches Skatteverket VAT SEK 851k and OB SEK 847k credits — excellent consistency), 41.2% gross margin, modest overdues. Strong operational picture.

## Bright lines

- (no statutory bright lines for this agent)

## Operational rules

- Cross-reference revenue against Skatteverket VAT (where available) and OB credits — 15%+ delta is investigative
- Service businesses: gross margin proxied; inventory will be null
- Multiple platforms connected: aggregate consistently or flag discrepancy

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Platform connection broken (token expired) | Refer; user must reconnect |
| Data appears stale (last sync > 90 days) | Use but flag staleness |


## Sweden-specific operational notes

This agent operates within the Swedish lending framework — Finansinspektionen (FI) as unified supervisor, Banking and Financing Business Act (2004:297), Konsumentkreditlag (2010:1846) for consumer credit, Lag 2017:630 for AML.

- **BankID universal:** Operationally critical. Every Swedish consumer financial interaction uses BankID for SCA. Without BankID integration, customer onboarding friction is material.
- **Swish dominance:** Swedish bank-cooperative mobile payment platform; near-universal adoption for P2P + retail payments. Significant cash displacement in Sweden.
- **UC AB near-monopoly:** Upplysningscentralen (UC AB) holds dominant position for consumer credit data. Operational relationship is essential — analogous to SCHUFA in Germany.
- **Outside Eurozone:** SEK is free-floating. Larger lending facilities may need FX hedging consideration.
- **Macroprudential amortisation requirements:** FI sets statutory amortisation requirements (amorteringskrav) for high-LTV mortgages — operationally significant for mortgage product structure.
- **High household debt:** Sweden has historically high household debt-to-income; FI macroprudential focus is operationally consequential.
- **Personnummer privacy:** Restricted-use identifier; over-collection is privacy breach.
- **Cross-reference:** `country-se-lending-policy-agent` for full SE jurisdictional context (currently a stub in the Country Policy Pack).

## Statutory hooks

- Sweden GDPR / DPA 2018
- FI (Finansinspektionen) FI customer protection (use of accurate, recent data)

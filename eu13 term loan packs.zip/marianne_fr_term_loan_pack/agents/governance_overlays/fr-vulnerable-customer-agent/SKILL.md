---
name: fr-vulnerable-customer-agent
description: |
  Detect indicators of customer vulnerability — financial, health, life events, capability — and flag for enhanced support. For SME lending the principals can be vulnerable even where the company is not. Sole traders are particularly in scope.
---

# Vulnerable Customer Agent

Vulnerability is a ACPR Recommandation + Code de la consommation cross-cutting requirement. Many vulnerability signals are subtle; this agent looks across all signals consistently.

## Input contract

```yaml
vulnerability_check_request:
  case_id: string
  applicant_legal_form: enum                # limited_company | partnership | sole_trader
  principal_signals_per_director:
    - principal_id: string
      bureau_signals: [string]              # recent defaults, multiple credit applications, etc.
      application_signals: [string]         # life-event indicators in application text
      stated_vulnerabilities: [string]      # explicitly declared
```

## Output contract

```yaml
vulnerability_assessment:
  case_id: string
  vulnerability_flags:
    - principal_id: string
      flag_type: enum                       # financial | health | life_event | capability | digital_capability
      severity: enum                        # low | medium | high
      source: enum                          # bureau | application | declared | inferred
      treatment_marker: enum                # enhanced_support | clear_communication | extended_timeframe
  enhanced_support_required: boolean
  audit_ledger_entry_id: string
  reason_codes: [string]
```

## Decision logic

```
For each principal:
  Check bureau signals (recent defaults, multiple applications, etc.)
  Check application signals (life events in stated purpose, contact patterns)
  Check declared vulnerabilities

Sole traders + micro-businesses: principals' personal vulnerability is materially relevant.

If any flag at medium/high severity: enhanced_support_required = true.
```

## Worked example (Marianne Engineering SAS case)

Input:
```yaml
vulnerability_check_request:
  case_id: "MAR-2026-04-001"
  applicant_legal_form: limited_company
  principal_signals_per_director:
    - principal_id: DIR-001
      bureau_signals: []
      application_signals: []
      stated_vulnerabilities: []
    - principal_id: DIR-002
      bureau_signals: []
      application_signals: []
      stated_vulnerabilities: []
```

Output:
```yaml
vulnerability_assessment:
  case_id: "MAR-2026-04-001"
  vulnerability_flags: []
  enhanced_support_required: false
  audit_ledger_entry_id: "VC-2026-04-12-HE-001"
  reason_codes: ["UK_VULNERABILITY_NO_FLAGS_STANDARD_HANDLING"]
```

No vulnerability flags for Highland's directors. Standard handling. Both directors are stable, well-established, no adverse signals.

## Bright lines

- (no statutory bright lines for this agent)

## Operational rules

- Vulnerability is a sensitive attribute — handle in line with DPA 2018 + ACPR guidance
- Treatment markers are advisory to channel staff, not blocking
- Declared vulnerabilities are first-class — never override applicant's own statement

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Vulnerability signal but principal disputes | Record dispute; treat per applicant's preference |


## France-specific operational notes

This agent operates within the French lending framework — ACPR + AMF supervisory perimeter, Banque de France operating both FIBEN (commercial credit register) and FICP (consumer credit incidents register), Code monétaire et financier for banking, Code de la consommation for consumer credit (with Loi Lagarde 2010 reforms still operationally consequential).

- **FIBEN central commercial register:** Operated by Banque de France itself, not a commercial bureau. Banks contribute and consult; FIBEN gives French banks unusually rich commercial credit visibility relative to most EU peers. Reciprocity requirement applies for full query depth.
- **FICP mandatory consumer query:** Statutory mandatory before consumer credit decision; no FICP query = invalid decision.
- **Toubon Law:** Commercial contracts and consumer disclosures must be in French. Foreign-language versions can supplement but the French version is the legally operative text.
- **TAEG (APR) statutory rigour:** Code de la consommation TAEG calculation rules are statutory; mis-statement >0.2pp is material. Quarterly Banque de France usury rate ceilings (taux d'usure) per consumer credit category — exceeding is voidable contract.
- **Assurance emprunteur:** Loi Lemoine 2022 reformed mortgage insurance — borrower has right to substitute insurer; insurer commission disclosure required.
- **Cross-reference:** `country-fr-lending-policy-agent` provides full FR jurisdictional context.

## Statutory hooks

- ACPR FG21/1 (Vulnerable Customers)
- ACPR ACPR Recommandation + Code de la consommation
- Equality Act 2010 (disability)
- France GDPR (special category data — health)

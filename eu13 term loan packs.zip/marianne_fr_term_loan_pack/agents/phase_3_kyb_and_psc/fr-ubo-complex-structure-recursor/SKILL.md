---
name: fr-ubo-complex-structure-recursor
description: |
  Resolve France Person of Significant Control (PSC) structures beyond the standard 25%+ direct
  ownership chain that ubo-mapper handles. Recurse through corporate PSCs to find ultimate
  natural persons; surface beneficiaries of trust-as-PSC structures; handle overseas-entity
  PSCs requiring Register of Overseas Entities (RBE framework) verification; flatten multi-layer
  corporate chains. Returns a complete list of ultimate natural-person PSCs plus the full
  path trace for audit. Flags trust, overseas, and anomalous patterns for Enhanced Due
  Diligence (EDD).
---

# PSC Complex Structure Recursor

## Input contract

```yaml
applicant_company_number: string          # required, e.g. "552 100 554"
initial_psc_list:                          # the PSC list returned by ubo-mapper
  - psc_id: string
    natural_person: boolean
    name: string
    nature_of_control: [enum]
    # plus the standard PSC fields where natural_person = true
recursion_depth_limit: integer            # default 6
```

## Output contract

```yaml
psc_resolved_structure:
  applicant_company_number: string
  ultimate_natural_person_pscs:
    - name: string
      effective_beneficial_ownership_pct: float   # multiplicative through chain
      path_trace: [string]                        # ["AppCo (50%) → MidCo (60%) → X"]
      nature_of_control_origin: [enum]
  edd_flags:                                       # may be empty
    - flag_type: enum                              # corporate_chain | trust_pcs | overseas_pcs | nominee_suspected | depth_limit_reached
      detail: string
  outcome: enum                                    # structure_resolved | eccta_non_compliance_block | edd_required
  reason_codes: [string]
```

## Decision logic

```
Walk PSC graph breadth-first. For each non-natural-person PSC:
  - corporate France → recurse into its PSC list
  - corporate overseas → query Register of Overseas Entities
      if not registered → outcome = eccta_non_compliance_block (BRIGHT LINE)
  - trust → seek trust deed; if absent → edd_required + add edd_flag
  - partnership/LLP → traverse partners
  - nominee detected → edd_required + escalate

Stop when all leaves are natural persons OR recursion depth reached.
Compute beneficial ownership multiplicatively through the chain.
```

## Worked example (Marianne Engineering SAS)

Input:
```yaml
applicant_company_number: "552 100 554"
initial_psc_list:
  - psc_id: PSC-001
    natural_person: true
    name: "Lachlan MacKenzie"
    nature_of_control: ["ownership_of_shares_50_to_75_percent"]
  - psc_id: PSC-002
    natural_person: true
    name: "Sarah Chen"
    nature_of_control: ["ownership_of_shares_25_to_50_percent"]
```

Output:
```yaml
psc_resolved_structure:
  applicant_company_number: "552 100 554"
  ultimate_natural_person_pscs:
    - name: "Lachlan MacKenzie"
      effective_beneficial_ownership_pct: 60.0
      path_trace: ["Marianne Engineering SAS Consultants Ltd → Lachlan MacKenzie"]
      nature_of_control_origin: ["ownership_of_shares_50_to_75_percent"]
    - name: "Sarah Chen"
      effective_beneficial_ownership_pct: 40.0
      path_trace: ["Marianne Engineering SAS Consultants Ltd → Sarah Chen"]
      nature_of_control_origin: ["ownership_of_shares_25_to_50_percent"]
  edd_flags: []
  outcome: structure_resolved
  reason_codes: ["UK_PSC_NATURAL_PERSON_CHAIN_RESOLVED"]
```

In this case both PSCs are natural persons directly — no recursion needed. The agent
short-circuits to `structure_resolved` cleanly. A more complex case (e.g. Highland
owned 60% by a France holding company owned 100% by an overseas entity) would recurse
through the chain, hit the Register of Overseas Entities check, and either resolve
to a natural person or block on RBE framework non-compliance.

## Bright lines

- Overseas-entity PSC without valid Register of Overseas Entities registration → BLOCK
  (`eccta_non_compliance_block`). Hard regulatory blocker; agent has no discretion.
- Detected nominee declarations → cannot auto-resolve; refer to MLRO for assessment.
- Recursion depth limit reached without natural-person resolution → escalate to EDD.

## Operational rules

- Preserve the full path trace in the decision log even when long — auditors may need it.
- Where trust deeds are not accessible, the agent must NOT fabricate beneficiary identity.
  Surface as `INCOMPLETE` and refer.
- Applicant-declared structure mismatching Infogreffe (RCS) / INPI data → flag for fraud review.


## France-specific operational notes

This agent operates within the French lending framework — ACPR + AMF supervisory perimeter, Banque de France operating both FIBEN (commercial credit register) and FICP (consumer credit incidents register), Code monétaire et financier for banking, Code de la consommation for consumer credit (with Loi Lagarde 2010 reforms still operationally consequential).

- **FIBEN central commercial register:** Operated by Banque de France itself, not a commercial bureau. Banks contribute and consult; FIBEN gives French banks unusually rich commercial credit visibility relative to most EU peers. Reciprocity requirement applies for full query depth.
- **FICP mandatory consumer query:** Statutory mandatory before consumer credit decision; no FICP query = invalid decision.
- **Toubon Law:** Commercial contracts and consumer disclosures must be in French. Foreign-language versions can supplement but the French version is the legally operative text.
- **TAEG (APR) statutory rigour:** Code de la consommation TAEG calculation rules are statutory; mis-statement >0.2pp is material. Quarterly Banque de France usury rate ceilings (taux d'usure) per consumer credit category — exceeding is voidable contract.
- **Assurance emprunteur:** Loi Lemoine 2022 reformed mortgage insurance — borrower has right to substitute insurer; insurer commission disclosure required.
- **Cross-reference:** `country-fr-lending-policy-agent` provides full FR jurisdictional context.

## Statutory hooks

- Code de commerce + Code civil Part 21A (PSC regime)
- RBE + Loi Sapin II (failure to prevent fraud, Register of Overseas Entities, identity verification)
- France CMF Livre V — EDD where non-natural-person beneficial owner, overseas component, or trust
- DGFiP Trust Registration Service
- ACPR SYSC 6.3

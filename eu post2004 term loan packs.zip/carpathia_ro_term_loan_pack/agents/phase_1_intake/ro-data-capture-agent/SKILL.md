---
name: ro-data-capture-agent
description: |
  Structured information capture from any origination channel. Normalises the raw broker / online / API payload into the canonical case object schema. Validates required fields, normalises currency and dates, flags missing data for follow-up.
---

# Data Capture Agent

Turn the raw inbound payload into a clean, structured case object that all downstream agents can consume reliably.

## Input contract

```yaml
raw_application_payload:
  source_channel: enum
  source_payload_raw: object                # arbitrary shape from broker/online form
  payload_schema_version: string
```

## Output contract

```yaml
case_object:
  case_id: string
  applicant:
    company_number: string
    name: string
    registered_office: string
    sic_codes: [string]
  facility:
    type: enum
    amount_ron: integer
    term_months: integer
    purpose_raw: string
  contact:
    primary_name: string
    primary_email: string
    primary_phone: string
    role: string
  channel: enum
  broker:                                   # nullable
    firm: string
    fca_reference: string
  validation_warnings: [string]
  field_count_populated: integer
```

## Decision logic

```
parse(raw_application_payload) against schema version.
For each field:
  - validate format (e.g. company_number = 8 digits, email regex, phone E.164)
  - normalise (currency to integer RON, dates to ISO 8601)
  - if invalid: append to validation_warnings

If any required field missing or invalid: emit case_object with warnings populated.
Downstream orchestrator decides whether to pause or proceed.
```

## Worked example (Carpathia Engineering SRL case)

Input:
```yaml
raw_application_payload:
  source_channel: broker
  source_payload_raw:
    company_no: "J40/1234/2026"
    co_name: "Carpathia Engineering SRL Consultants Ltd"
    facility: "term loan"
    amount: "150,000.00"
    term_yrs: 5
    contact: "Lachlan MacKenzie"
    contact_email: "lachlan@highlandeng.example.co.uk"
    contact_phone: "0141 555 0182"
  payload_schema_version: "broker_v3.2"
```

Output:
```yaml
case_object:
  case_id: "CAR-2026-04-001"
  applicant:
    company_number: "J40/1234/2026"
    name: "Carpathia Engineering SRL Consultants Ltd"
    registered_office: "Suite 4, 2 Atlantic Quay, București, G2 8GA"
    sic_codes: ["71121"]
  facility:
    type: term_loan
    amount_ron: 150000
    term_months: 60                         # normalised from 5 yrs
    purpose_raw: "Premises fit-out + testing equipment"
  contact:
    primary_name: "Lachlan MacKenzie"
    primary_email: "lachlan@highlandeng.example.co.uk"
    primary_phone: "+441415550182"          # normalised to E.164
    role: "Managing Director"
  channel: broker
  broker:
    firm: "Highland Capital Partners"
    fca_reference: "555444"
  validation_warnings: []
  field_count_populated: 47
```

Broker payload normalised — amount string '150,000.00' becomes integer 150000, term '5 yrs' becomes 60 months, phone normalised to E.164. No validation warnings.

## Bright lines

- (no statutory bright lines for this agent)

## Operational rules

- Field normalisation is deterministic — same input always produces same output
- Currency normalised to integer RON (no fractional pence at this stage)
- Dates normalised to ISO 8601
- Phone numbers normalised to E.164
- Validation warnings are non-blocking — downstream agents see them and decide

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Payload schema version unknown | Refer to ops; cannot parse safely |
| Required field present but unparseable | Warning logged; field left null; case proceeds |
| Optional field unparseable | Warning logged; field left null; case proceeds |


## Romania-specific operational notes

Operates within the Romanian framework — BNR + ASF supervision, OUG 50/2010 for consumer credit, OUG 52/2016 for mortgage credit, Legea 129/2019 for AML.

- **Biroul de Credit + CRC dual registers:** Biroul de Credit (private, consumer) + Centrala Riscului de Credit (BNR-operated central). Combined visibility.
- **CNP universal identifier:** Cod numeric personal; restricted-use under GDPR.
- **Prima Casă / Noua Casă legacy:** State-guaranteed mortgage schemes shape mortgage origination expectations.
- **ANPC consumer protection:** National Authority for Consumer Protection active in financial services.
- **RON currency:** Outside Eurozone; floating. FX consideration material.
- **Cross-reference:** `country-ro-lending-policy-agent` (Country Policy Pack stub).

## Statutory hooks

- Romania GDPR (data minimisation — capture only what's needed)
- BNR BNR + ANPC consumer protection (clear capture of customer's stated needs)

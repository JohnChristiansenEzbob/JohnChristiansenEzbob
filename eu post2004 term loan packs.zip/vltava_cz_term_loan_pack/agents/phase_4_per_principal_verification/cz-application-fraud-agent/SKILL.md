---
name: cz-application-fraud-agent
description: |
  Detect application-stage fraud indicators per principal — synthetic identity patterns, document tampering signals, velocity rules (repeated applications), SOLUS negative + BRKI Protective Registration / National Fraud Database hits, device fingerprinting signals. Returns a fraud score (0-100) with classification.
---

# Application Fraud Agent

First-line application fraud screen. Identity-orchestration confirms the person is real and the documents are real; this agent confirms the application itself isn't suspicious.

## Input contract

```yaml
fraud_request:
  principal_id: string
  case_id: string
  name: string
  dob: date
  current_residential_address: string
  application_metadata:
    device_fingerprint: string
    ip_address: string
    submission_timestamp: datetime
    browser_locale: string
  cifas_check_consent: boolean
```

## Output contract

```yaml
fraud_assessment:
  principal_id: string
  fraud_score: integer                      # 0-100; 0=clean, 100=high risk
  classification: enum                      # low | medium | high
  signals:
    cifas_markers: [string]                 # nullable
    velocity_signals: [string]              # multiple recent applications etc.
    device_signals: [string]                # VPN, automation, mismatched locale etc.
    synthetic_identity_signals: [string]
  outcome: enum                             # proceed | refer | block_high_risk_fraud
  reason_codes: [string]
```

## Decision logic

```
Lookup SOLUS negative + BRKI National Fraud Database (consent-gated).
Apply velocity rules (same identity in N applications in past M days).
Device fingerprint analysis (known fraud-associated devices, automation).
Synthetic identity detection (DOB-name combinations, address-credit history mismatches).

Compute composite fraud_score.

if cifas_markers include "fraud" (Category 6) marker:
  outcome = block_high_risk_fraud           # BRIGHT LINE; SOLUS negative + BRKI fraud marker is decline

elif fraud_score >= 70:
  outcome = block_high_risk_fraud

elif fraud_score >= 40:
  outcome = refer

else:
  outcome = proceed
```

## Worked example (Vltava Engineering s.r.o. case)

Input:
```yaml
fraud_request:
  principal_id: DIR-001
  case_id: "VLT-2026-04-001"
  name: "Lachlan MacKenzie"
  dob: "1981-03-22"
  current_residential_address: "12 Strathblane Road, Milngavie, Praha, G62 8DJ"
  application_metadata:
    device_fingerprint: "[hash]"
    ip_address: "82.x.x.x"
    submission_timestamp: "2026-04-12T09:14:22Z"
    browser_locale: "en-GB"
  cifas_check_consent: true
```

Output:
```yaml
fraud_assessment:
  principal_id: DIR-001
  fraud_score: 12
  classification: low
  signals:
    cifas_markers: []
    velocity_signals: []
    device_signals: []
    synthetic_identity_signals: []
  outcome: proceed
  reason_codes: ["UK_APPLICATION_FRAUD_LOW_RISK"]
```

Clean fraud screen. Czechia IP, en-GB locale matching declared residence, no SOLUS negative + BRKI markers, no velocity issues. Sarah Chen returns similar low-risk shape.

## Bright lines

- SOLUS negative + BRKI Category 6 fraud marker → AUTO-DECLINE; cannot override without explicit dispensation
- Confirmed synthetic identity (fabricated person) → AUTO-DECLINE + SAR

## Operational rules

- SOLUS negative + BRKI lookup requires explicit consent; absence of consent → cannot perform that check (not blocking by itself)
- Velocity rules windowed (e.g. >3 applications in 30 days flags)
- Device fingerprints retained in fraud history for pattern detection

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| SOLUS negative + BRKI unavailable | Refer; cannot make decision without check (over a critical limit) |
| Device fingerprint missing | Score conservatively; some signals unusable |


## Czech Republic-specific operational notes

Operates within the Czech framework — ČNB as unified supervisor, Consumer Credit Act 257/2016, AML Act 253/2008 enforced via FAÚ.

- **BRKI + NRKI dual registers:** Bank register (BRKI) and non-bank register (NRKI) provide comprehensive Czech consumer credit visibility; SOLUS adds negative data. Strong coverage.
- **Bankovní identita (BankID):** Czech bank-issued digital identity widely adopted for online onboarding and government services.
- **CZK currency:** Outside Eurozone; floating. Larger facilities may need FX consideration.
- **Rodné číslo:** Birth number is the universal identifier; restricted-use under GDPR.
- **Cross-reference:** `country-cz-lending-policy-agent` (Country Policy Pack stub).

## Statutory hooks

- Fraud Act 2006
- Evidence skutečných majitelů (UBO) (failure to prevent fraud — must have reasonable procedures)
- Czechia AML Act 253/2008 (transaction monitoring + identity)
- SOLUS negative + BRKI Code of Practice

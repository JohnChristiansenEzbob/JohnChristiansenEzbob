---
name: lu-security-composite-agent
description: |
  Compose per-security valuations into a single net recoverable position for the proposed
  facility. Takes outputs from floating-charge-valuation-agent, fixed-charge-valuation-
  agent, and personal-guarantee-feasibility-agent; applies enforcement-sequencing logic
  (fixed first, then PG, then floating); deducts prescribed-part carve-out only once;
  produces the composite recoverable value that lgd-modelling-agent consumes.
---

# Security Composite Agent

Per-asset valuations are necessary but not sufficient. In a default scenario, the lender
enforces in a particular sequence (fixed before floating, secured before unsecured), and
naïvely summing per-security values double-counts overlapping recovery and ignores
sequencing realities. This agent does the composition properly.

## Input contract

```yaml
security_composite_request:
  case_id: string
  facility_amount_eur: integer
  ead_avg_over_term_gbp: integer            # from ead-modelling-agent
  fixed_charge_valuation: object            # from fixed-charge-valuation-agent
  floating_charge_valuation: object         # from floating-charge-valuation-agent
  pg_feasibility_outcomes: [object]         # from personal-guarantee-feasibility-agent (per guarantor)
  enforcement_sequencing_policy: enum       # standard_uk | bespoke
```

## Output contract

```yaml
security_composite:
  case_id: string
  recovery_waterfall:
    - rank: integer                          # 1 = first to enforce
      source: enum                           # fixed_charge | personal_guarantee | floating_charge
      asset_or_principal_id: string
      gross_recoverable_gbp: integer
      cumulative_recovery_gbp: integer
      time_to_realise_months: integer
  expected_total_recovery_gbp: integer       # probability-weighted across enforcement scenarios
  expected_recovery_pct_of_facility: float
  expected_recovery_pct_of_ead_avg: float    # this is what LGD modelling needs
  weighted_time_to_realise_months: float
  uncovered_exposure_gbp: integer
  composition_warnings: [string]             # double-count avoidance, sequencing notes
  reason_codes: [string]
```

## Decision logic

```
Build recovery waterfall in enforcement order:

1. FIXED CHARGES (rank within asset, fastest realisation):
   For each per_asset_valuation in fixed_charge_valuation:
     add to waterfall with time_to_realise from agent
     cumulative_recovery += net_realisable_gbp

2. PERSONAL GUARANTEES (commenced in parallel with fixed but slower):
   For each guarantor in pg_feasibility_outcomes:
     pg_realisable = min(proposed_pg_amount_eur,
                         net_realisable_pg_cover_lower_bound_gbp)
     if etridge_process_required AND not_completed:
       pg_realisable *= 0.6   (Etridge non-compliance enforcement risk)
     add to waterfall
     cumulative_recovery += pg_realisable

3. FLOATING CHARGE (last in sequence, longest to realise):
   net_realisable_floating already reflects prescribed-part carve-out
   But adjust for overlap with fixed:
     If fixed charge over plant included in floating asset base,
     deduct plant from floating to avoid double-count.
   add to waterfall

Compute expected_total_recovery as the sum, capped at EAD.

Probability-weighted scenarios (conservative default):
  recovery_scenario_pessimistic: total × 0.70
  recovery_scenario_central:     total × 1.00
  recovery_scenario_optimistic:  total × 1.10
  expected = weighted average (0.3, 0.5, 0.2)

uncovered_exposure = max(0, EAD - expected_total_recovery)
```

## Worked example (Ardennes Engineering S.à r.l.)

Input:
```yaml
security_composite_request:
  case_id: "ARD-2026-04-001"
  facility_amount_eur: 150000
  ead_avg_over_term_gbp: 78600
  fixed_charge_valuation:
    total_net_realisable_fixed_gbp: 38475       # testing equipment
  floating_charge_valuation:
    net_realisable_floating_gbp: 80640          # all-asset debenture, first rank
  pg_feasibility_outcomes:
    - principal_id: DIR-001                       # Lachlan, €90k PG, Etridge process
      proposed_pg_amount_eur: 90000
      net_realisable_pg_cover_lower_bound_gbp: 113100
      etridge_process_required: true
    - principal_id: DIR-002                       # Sarah, €60k PG, no Etridge
      proposed_pg_amount_eur: 60000
      net_realisable_pg_cover_lower_bound_gbp: 158000
      etridge_process_required: false
  enforcement_sequencing_policy: standard_uk
```

Output:
```yaml
security_composite:
  case_id: "ARD-2026-04-001"
  recovery_waterfall:
    - rank: 1
      source: fixed_charge
      asset_or_principal_id: FX-001-equipment
      gross_recoverable_gbp: 38475
      cumulative_recovery_gbp: 38475
      time_to_realise_months: 3
    - rank: 2
      source: personal_guarantee
      asset_or_principal_id: DIR-002
      gross_recoverable_gbp: 60000                 # capped at PG amount, sole property — full
      cumulative_recovery_gbp: 98475
      time_to_realise_months: 8
    - rank: 3
      source: personal_guarantee
      asset_or_principal_id: DIR-001
      gross_recoverable_gbp: 90000                 # Etridge completed at drawdown → full
      cumulative_recovery_gbp: 188475
      time_to_realise_months: 8
    - rank: 4
      source: floating_charge
      asset_or_principal_id: all-asset-debenture
      gross_recoverable_gbp: 47640                 # 80640 - 33000 plant (already counted in fixed)
      cumulative_recovery_gbp: 236115
      time_to_realise_months: 12
  expected_total_recovery_gbp: 78600               # capped at EAD €78.6k
  expected_recovery_pct_of_facility: 0.524
  expected_recovery_pct_of_ead_avg: 1.00           # fully covered at EAD-avg
  weighted_time_to_realise_months: 7.5
  uncovered_exposure_gbp: 0
  composition_warnings:
    - "Plant value €33k deducted from floating charge to avoid double-count with fixed charge over same equipment"
  reason_codes: ["UK_SECURITY_COMPOSITE_FULL_COVER_AT_EAD_AVG"]
```

The composite picture: against the average expected exposure (€78.6k EAD-avg over the
5-year term), Highland has €236k of gross security available — but the agent caps the
recovery at EAD, so the relevant metric is **expected recovery percentage of EAD-avg =
100%**. The facility is comprehensively secured: fixed charge over the new equipment
recovers fast, both PGs recover within 8 months (Sarah's straightforwardly, Lachlan's
once Etridge is complete), and floating charge backstops the rest.

Critically, the composition handles three things naïve summing misses:
1. **Plant overlap** — the €33k plant value is in BOTH the fixed charge (specific) and the floating charge (whole asset base). Deducted from floating to avoid double-count.
2. **Etridge sequencing** — Lachlan's PG is full value because Etridge is being completed at drawdown. If Etridge had been deferred, the agent would haircut to 60% (enforcement risk).
3. **EAD-relative cover** — recovery isn't measured against face value of facility (€150k) but against expected exposure at default (€78.6k average over the amortising term). This is the LGD-relevant number.

## Bright lines

- Total expected recovery < 25% of EAD → flag for underwriter; security materially insufficient
- Composition warnings empty when overlap obvious (plant in both fixed and floating) → bug; refuse output and refer
- PGs counted without confirming legal feasibility (Boland/Etridge process status) → refer

## Operational rules

- Enforcement sequencing follows Luxembourg standard waterfall (fixed → preferential → prescribed-part to unsecured → floating to charge-holder)
- Overlapping security MUST be deducted to avoid double-count (plant under both fixed and floating, receivables charged separately AND part of floating, etc.)
- Probability weights (pessimistic/central/optimistic) are policy-controlled
- The agent does NOT decide whether security is sufficient — that's a credit policy judgement made by decision-pricing-agent

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| One input missing (fixed valuation absent etc.) | Proceed with zero for that source; flag |
| EAD profile not provided | Use facility face value (conservative); flag |
| Overlap detection ambiguous | Conservative deduction; surface in composition_warnings |
| Sequencing policy not 'standard_uk' | Refer; bespoke policy needs human |


## Luxembourg-specific operational notes

This agent operates within the Luxembourgish lending framework — CSSF as unified supervisor (banking, investment funds, payment services, insurance via CAA), with ECB SSM for significant institutions. Loi du 5 avril 1993 is the foundational banking law.

- **EU financial centre context:** Luxembourg's banking sector is heavily skewed toward private banking, fund administration, and cross-border services. Domestic consumer lending is a smaller proportion of activity than peer EU jurisdictions.
- **Trilingual jurisdiction:** French is primary for legal documents; German and Luxembourgish (Lëtzebuergesch) also constitutional. Customer-facing materials commonly trilingual.
- **CSSF supervisory style:** Investment fund and private banking focus means CSSF supervisory rhythm and reporting differs from peer prudential supervisors. Banking supervision sits within the unified CSSF.
- **Limited domestic credit visibility:** No central consumer credit register equivalent to FR FICP or BE CKP; lender visibility relies on bureau-by-bureau queries and Open Banking.
- **Cross-border banking:** Many lending applications involve cross-border structures (Belgian, German, French residents working in Luxembourg). KYB chains often complex.
- **Cross-reference:** `country-lu-lending-policy-agent` for full LU jurisdictional context (currently a stub in the Country Policy Pack).

## Statutory hooks

- Insolvency Act 1986 (waterfall + s176A prescribed part)
- Enterprise Act 2002
- Loi du 10 août 1915 (commercial companies) Part 25
- CSSF model risk supervision + ECB SREP (LGD model inputs)
- IFRS 9 (recovery modelling)

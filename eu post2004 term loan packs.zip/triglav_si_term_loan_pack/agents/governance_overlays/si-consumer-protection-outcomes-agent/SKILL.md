---
name: si-consumer-protection-outcomes-agent
description: |
  Cross-cutting Banka Slovenije consumer protection checks across the four outcomes: products + services, price + value, consumer understanding, consumer support. Runs continuously and writes a Banka Slovenije consumer protection audit trail to the case ledger. For business lending, the Duty applies to micro-enterprises (turnover <€2m + <10 employees).
---

# Banka Slovenije consumer protection Outcomes Agent

Continuous Banka Slovenije consumer protection oversight. Captures the audit trail Banka Slovenije inspections will ask for.

## Input contract

```yaml
duty_check_request:
  case_id: string
  case_state_snapshot: object               # current case state at this check
  trigger_event: enum                       # phase_completion | manual | scheduled
```

## Output contract

```yaml
duty_check_result:
  case_id: string
  outcomes_checked:
    products_and_services: enum             # pass | fail | not_applicable
    price_and_value: enum
    consumer_understanding: enum
    consumer_support: enum
  fair_value_check_passed: boolean
  understanding_check_passed: boolean
  audit_ledger_entry_id: string
  reason_codes: [string]
```

## Decision logic

```
For each outcome, check against rules:

products_and_services:
  - Product matches needs (cross-ref needs-discovery + purpose-validation)
  - No prohibited customer-product combinations

price_and_value:
  - Final rate within fair value band
  - Total cost transparent (incl. broker commission)
  - No hidden fees

consumer_understanding:
  - Key facts disclosed (rate, term, total cost, security implications)
  - Conditions clearly stated
  - Decline reasoning available (right to explanation)

consumer_support:
  - Channel-appropriate support available
  - Vulnerable customer flagged → enhanced support route

if all 4 outcomes pass → pass
else → fail with specific outcome flagged
```

## Worked example (Triglav Engineering d.o.o. case)

Input:
```yaml
duty_check_request:
  case_id: "TRI-2026-04-001"
  case_state_snapshot: {... full case state at decision time ...}
  trigger_event: phase_completion
```

Output:
```yaml
duty_check_result:
  case_id: "TRI-2026-04-001"
  outcomes_checked:
    products_and_services: pass             # term loan fits stated purpose
    price_and_value: pass                   # 8.4% within fair value band for B+ grade
    consumer_understanding: pass            # conditions clearly stated, decline reasons would be available
    consumer_support: pass                  # broker channel + lender support team available
  fair_value_check_passed: true
  understanding_check_passed: true
  audit_ledger_entry_id: "CD-2026-04-12-HE-001"
  reason_codes: ["UK_CONSUMER_DUTY_ALL_OUTCOMES_PASS"]
```

All four Banka Slovenije consumer protection outcomes pass for Triglav Engineering d.o.o.. Note: Highland is a limited company with turnover ~€850k and 6 employees — technically not a 'consumer' (>turnover threshold). The lender still applies Duty-equivalent standards as a matter of policy.

## Bright lines

- Fair value failure → escalate to product team; cannot proceed at quoted price
- Material information not disclosed pre-contract → cannot proceed

## Operational rules

- Duty applies to micro-enterprises in business lending (Banka Slovenije scope)
- Lender policy may extend Duty-equivalent standards to all business customers
- Audit trail is mandatory for Banka Slovenije inspection

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Case state snapshot incomplete | Defer check; re-run when complete |
| Fair value benchmark unavailable | Conservative interpretation; refer to product team |


## Slovenia-specific operational notes

Operates within the Slovenian framework — Banka Slovenije supervision, Consumer Credit Act, AML Act.

- **SISBON + SISBIZ dual registers:** Bank of Slovenia operates both the consumer (SISBON) and commercial (SISBIZ) credit registers — strong centralised visibility.
- **First post-2004 Eurozone member (2007):** EUR-denominated; no FX consideration.
- **EMŠO universal identifier:** Unique Master Citizen Number; restricted-use under GDPR.
- **AJPES:** Central registry agency for company + UBO data.
- **Cross-reference:** `country-si-lending-policy-agent` (Country Policy Pack stub).

## Statutory hooks

- Banka Slovenije Banka Slovenije consumer protection (PS22/9)
- Banka Slovenije regulations + Consumer Credit Act Banka Slovenije consumer outcomes (the Duty)
- Banka Slovenije Finalised Guidance FG22/5

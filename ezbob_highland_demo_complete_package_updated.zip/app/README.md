# ezbob Highland Engineering Agent Demo

This package contains a React/JavaScript internal demonstration UI for the Highland Engineering SME term-loan agent journey.

## Feedback update included

The front of the demo now starts from a deliberately small one-page UI seed instead of loading the full synthetic profile file:

- Company registration number
- Applicant name
- Applicant residential address
- Applicant date of birth

The Node adapter then shows how the company registration number is used to call Companies House and map the returned public company profile into KYB. After that enrichment step, the rest of the case remains synthetic replay data through the final offer.

## What is included

- `src/` — React application source.
- `server/` — Node.js live-adapter boundary with Companies House endpoint and replay fallback.
- `intake-one-page.html` — standalone one-page UI seed and Companies House lookup demo.
- `standalone-demo.html` — no-build browser replay used for the MP4 recording.
- `data/demo-data.json` — structured case, phase, skill, UI seed, Companies House and caption data.
- `data/case_state/HE-2026-04-001/` — representative JSON ledger outputs, including `ui_seed_payload.json` and `companies_house_profile.json`.
- `data/source/highland-demo/` — the supplied source case YAML, subagents and 36 skill definitions for traceability.
- `scripts/record-demo.js` and `scripts/record-demo.py` — regenerate the captioned MP4 from the standalone UI.

## Important demo truth

The supplied video and the default UI run in deterministic replay mode. No real customer, bureau, banking, HMRC or Land Registry data is gathered. The Companies House step is shown in two ways:

1. Replay mode: deterministic demo response for the MP4 and zero-config demos.
2. Live mode: server-side call to Companies House when `COMPANIES_HOUSE_API_KEY` or `CH_API_KEY` is configured.

The browser never receives the Companies House API key. Production use still needs proper credentials, security review, monitoring, permissioning, error handling and audit controls.

## Companies House adapter

Endpoint exposed by this demo server:

```bash
POST /api/company-profile
Content-Type: application/json

{
  "companyNumber": "10428671",
  "mode": "live"
}
```

Server-side outbound request when an API key is present:

```bash
GET https://api.company-information.service.gov.uk/company/10428671
Authorization: Basic base64(COMPANIES_HOUSE_API_KEY + ':')
Accept: application/json
```

Run live mode locally:

```bash
export COMPANIES_HOUSE_API_KEY="your_api_key"
npm install
npm run server
```

Then open:

- `http://localhost:4173/intake-one-page.html`
- `http://localhost:4173/standalone-demo.html`

Without an API key, the endpoint returns the deterministic Companies House replay response.

## Run the UI

### Zero-install replay

Open `standalone-demo.html` in a browser. Use left/right arrow keys to move through the full storyboard.

### One-page intake demo

Open `intake-one-page.html` directly for the static view, or run the Node server first to use `/api/company-profile`.

### React development mode

```bash
npm install
npm run dev
```

### Node adapter mode

```bash
npm install
npm run server
```

API endpoints:

- `GET /api/case`
- `GET /api/ui-seed`
- `POST /api/company-profile`
- `POST /api/start-application`
- `GET /api/demo-run?mode=replay`
- `GET /api/demo-run?mode=live`
- `POST /api/run-phase/:phaseId`

## Regenerate the video

```bash
npm install
npm run record
```

Or, in this container-style environment:

```bash
python scripts/record-demo.py
```

The generated file will be `ezbob_highland_demo_video.mp4`.

## Demo storyline

The demo shows the one-page UI seed, Companies House enrichment, all 36 specialist skills and 8 phase-level orchestrators across:

1. UI seed and Companies House profile
2. Intake
3. Consent + purpose
4. KYB + PSC
5. Parallel per-principal verification
6. Credit data assembly
7. Modelling + security valuation + PG feasibility
8. Decision + pricing
9. Governance overlays

Outcome: **ACCEPT WITH CONDITIONS** for a £150,000 / 60-month term loan, with prior charge release, Etridge/Boland process for Lachlan's PG, standard PG for Sarah, and equipment-security scheduling.

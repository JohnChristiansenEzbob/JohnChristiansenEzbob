---
name: de-sme-pricing-strategy-agent
description: |
  Apply risk-based pricing within commercial guardrails. Takes the decision-pricing-agent's indicative rate as base and applies pricing strategy overlays: competitive positioning, broker compensation, floor/ceiling checks, fair-value verification under BGB Verbraucherschutz framework.
---

# SME Pricing Strategy Agent

Final pricing. Same risk grade can warrant different pricing depending on competitive context, broker channel, and customer relationship history.

## Input contract

```yaml
pricing_request:
  case_id: string
  indicative_rate_pct: float                # base from decision-pricing-agent
  risk_rating: object
  facility_amount_eur: integer
  facility_term_months: integer
  channel: enum                             # broker | branch | online
  broker_commission_structure: object       # nullable
  competitive_context:
    peer_avg_rate_for_grade_pct: float
    market_position_target: enum            # match | above | below
```

## Output contract

```yaml
pricing_outcome:
  case_id: string
  final_rate_pct: float
  arrangement_fee_pct: float
  broker_commission_pct: float              # if broker channel
  effective_apr_pct: float
  within_commercial_band: boolean
  fair_value_check_passed: boolean
  adjustments_applied: [string]
  reason_codes: [string]
```

## Decision logic

```
final_rate = indicative_rate

Apply competitive adjustment:
  if market_position_target == match: final_rate = peer_avg_rate
  elif above: final_rate = max(indicative_rate, peer_avg_rate + 0.5)
  elif below: final_rate = min(indicative_rate, peer_avg_rate - 0.25)

Floor: final_rate >= product_floor (cost of funds + margin minimum)
Ceiling: final_rate <= grade_ceiling (consumer duty fair value)

Arrangement fee per product policy (typically 0.5-2.0%).
Broker commission per accreditation tier.

Effective APR computed (ECB methodology).

Fair value check:
  - APR vs peer benchmark
  - Total cost over term vs facility amount
  - Customer Duty 'price + value' outcome
```

## Worked example (Brandenburg Engineering GmbH case)

Input:
```yaml
pricing_request:
  case_id: "BRA-2026-04-001"
  indicative_rate_pct: 8.4
  risk_rating: {composite_grade: B+, pricing_tier: tier_1_prime}
  facility_amount_eur: 150000
  facility_term_months: 60
  channel: broker
  broker_commission_structure: {tier: accredited, base_pct: 1.5}
  competitive_context:
    peer_avg_rate_for_grade_pct: 8.6
    market_position_target: match
```

Output:
```yaml
pricing_outcome:
  case_id: "BRA-2026-04-001"
  final_rate_pct: 8.4
  arrangement_fee_pct: 1.0
  broker_commission_pct: 1.5
  effective_apr_pct: 9.5
  within_commercial_band: true
  fair_value_check_passed: true
  adjustments_applied: []
  reason_codes: ["UK_PRICING_TIER_1_PRIME_COMPETITIVE_MATCH"]
```

Final rate 8.4% — competitive match to peer benchmark of 8.6% (slight outperform). Arrangement fee 1.0%, broker commission 1.5% (standard accredited tier). Effective APR 9.5%. Fair value check passes.

## Bright lines

- Rate < product floor → AUTOMATIC REFER; unviable
- Rate > grade ceiling → fair value challenge under BGB Verbraucherschutz framework
- Broker commission > 3% → escalate (commission disclosure)

## Operational rules

- Final pricing is committee-approved policy not agent-discretionary above 0.5% deviation from indicative
- Broker channel pricing accounts for commission as part of customer-borne cost (transparency)
- Pricing reviewed monthly against market benchmark

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Competitive context data stale (>30 days) | Use cautiously; flag |
| Peer benchmark inversion (peer rate < cost of funds) | Refer; possible distressed market |


## Germany-specific operational notes

This agent operates within the German lending framework — BaFin supervisory perimeter (with Bundesbank joint prudential and ECB SSM for significant institutions), BGB §§ 491-505e for consumer credit, KWG (Kreditwesengesetz) for banking, GwG for AML.

- **SCHUFA monopoly:** SCHUFA holds the effective monopoly on consumer credit data. BDSG §29 consent (Einwilligung) is mandatory before any SCHUFA query — operational rigour matters; querying without consent is a data protection breach with material fines.
- **Notar requirement:** German property transfers require notarial certification (Notar). This is structural — mortgage origination must accommodate notarial step and cannot bypass it.
- **Cooperative + savings dominance:** Sparkassen and Volksbanken/Raiffeisenbanken collectively dominate German consumer + SME credit. Hausbank (house bank) culture means existing relationships are sticky.
- **Long-fixed-rate culture:** German mortgages commonly fixed for 10-30 years; affordability stress testing must reflect this product structure, not UK SVR conventions.
- **Transparenzregister:** UBO register (5AMLD-compliant). Threshold 25%+. Public access restricted post-CJEU ruling; financial institutions retain access via legitimate interest.
- **Cross-reference:** `country-de-lending-policy-agent` provides full DE jurisdictional context.

## Statutory hooks

- BaFin BGB Verbraucherschutz framework (price + value outcome)
- Financial Promotions regime (representative APR disclosure)
- Broker commission disclosure (LSB Standards)

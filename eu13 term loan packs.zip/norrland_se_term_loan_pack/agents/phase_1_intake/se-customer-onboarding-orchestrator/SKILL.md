---
name: se-customer-onboarding-orchestrator
description: |
  Case lifecycle coordinator for Sweden SME credit applications. Opens the case ledger, assigns the case_id, validates the inbound payload shape, dispatches downstream agents in correct phase order, and maintains case state across the journey. Control-flow primitive — does not perform external lookups or credit reasoning.
---

# Customer Onboarding Orchestrator

Every case starts here. The orchestrator owns the case_id, the phase pointer, and the right to dispatch downstream agents. It writes the canonical case ledger entries that the audit trail relies on.

## Input contract

```yaml
inbound_application:
  channel: enum                            # broker | branch | online | api
  applicant_name: string
  applicant_company_number: string
  facility_type: enum                      # term_loan | revolving_credit | invoice_finance | asset_finance
  facility_amount_sek: integer
  facility_term_months: integer            # nullable
  contact_name: string
  contact_email: string
  contact_phone: string
  application_date: date
  broker_firm: string                      # nullable (only if channel = broker)
  broker_fca_reference: string             # nullable
```

## Output contract

```yaml
case_state:
  case_id: string                          # e.g. NOR-2026-04-001
  status: enum                             # active | paused | terminated
  current_phase: integer                   # 1..7
  channel: enum
  case_type: enum                          # UK_term_loan | UK_revolving | ...
  audit_ledger_initialised: boolean
  next_phase_unlocked: boolean
  dispatched_agents: [string]              # what fires next
```

## Decision logic

```
if inbound_application.facility_type not in ALLOWED_PRODUCTS:
  status = terminated
  reason_codes = [UK_PRODUCT_NOT_OFFERED]
elif required_fields_missing(inbound_application):
  status = paused
  reason_codes = [UK_INTAKE_INCOMPLETE_PAYLOAD]
else:
  case_id = generate(applicant_company_number, application_date)
  initialise_ledger(case_id)
  status = active
  current_phase = 1
  dispatch([lead-qualification-agent, data-capture-agent])
```

## Worked example (Norrland Engineering AB case)

Input:
```yaml
inbound_application:
  channel: broker
  applicant_name: "Norrland Engineering AB Consultants Ltd"
  applicant_company_number: "556677-8899"
  facility_type: term_loan
  facility_amount_sek: 150000
  facility_term_months: 60
  contact_name: "Lachlan MacKenzie"
  contact_email: "lachlan@highlandeng.example.co.uk"
  contact_phone: "+44 141 555 0182"
  application_date: "2026-04-12"
  broker_firm: "Highland Capital Partners"
  broker_fca_reference: "555444"
```

Output:
```yaml
case_state:
  case_id: "NOR-2026-04-001"
  status: active
  current_phase: 1
  channel: broker
  case_type: UK_term_loan
  audit_ledger_initialised: true
  next_phase_unlocked: true
  dispatched_agents: ["lead-qualification-agent", "data-capture-agent"]
```

Standard happy-path intake. Broker channel with valid FI (Finansinspektionen) reference, facility within the term-loan product envelope, all required fields present. Case opened, ledger initialised, downstream agents dispatched.

## Bright lines

- Inbound payload missing required field (applicant_company_number, facility_amount_sek) → status=paused; cannot proceed
- Facility type not in the lender's product catalogue → status=terminated
- Duplicate case_id detected → status=terminated; existing case_id surfaced to broker

## Operational rules

- case_id is immutable once issued
- Audit ledger is append-only (WORM equivalent)
- All downstream agent dispatch goes through this orchestrator — no direct agent-to-agent calls
- Case state changes emit a ledger entry with timestamp + actor identity

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Required field missing | Pause case; surface specific missing field to broker via channel |
| Duplicate case detected | Terminate new case; return existing case_id |
| Ledger initialisation fails | Terminate; alarm to ops |
| Broker FI (Finansinspektionen) reference invalid | Pause; require broker accreditation check |


## Sweden-specific operational notes

This agent operates within the Swedish lending framework — Finansinspektionen (FI) as unified supervisor, Banking and Financing Business Act (2004:297), Konsumentkreditlag (2010:1846) for consumer credit, Lag 2017:630 for AML.

- **BankID universal:** Operationally critical. Every Swedish consumer financial interaction uses BankID for SCA. Without BankID integration, customer onboarding friction is material.
- **Swish dominance:** Swedish bank-cooperative mobile payment platform; near-universal adoption for P2P + retail payments. Significant cash displacement in Sweden.
- **UC AB near-monopoly:** Upplysningscentralen (UC AB) holds dominant position for consumer credit data. Operational relationship is essential — analogous to SCHUFA in Germany.
- **Outside Eurozone:** SEK is free-floating. Larger lending facilities may need FX hedging consideration.
- **Macroprudential amortisation requirements:** FI sets statutory amortisation requirements (amorteringskrav) for high-LTV mortgages — operationally significant for mortgage product structure.
- **High household debt:** Sweden has historically high household debt-to-income; FI macroprudential focus is operationally consequential.
- **Personnummer privacy:** Restricted-use identifier; over-collection is privacy breach.
- **Cross-reference:** `country-se-lending-policy-agent` for full SE jurisdictional context (currently a stub in the Country Policy Pack).

## Statutory hooks

- FI (Finansinspektionen) FI customer protection (case ownership + auditability)
- FI (Finansinspektionen) SYSC 3 (systems and controls)
- Sweden GDPR / DPA 2018 (lawful basis at intake)

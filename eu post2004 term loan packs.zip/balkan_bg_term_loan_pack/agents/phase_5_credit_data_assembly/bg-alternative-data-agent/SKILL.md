---
name: bg-alternative-data-agent
description: |
  Pull supplementary financial data from accounting platforms (Xero, QuickBooks, Sage) and trade-data providers. Returns recent management accounts, gross margin, overdue payables/receivables, and any other structured operational data the applicant has chosen to share.
---

# Alternative Data Agent

Closes the gap between filed accounts (9-12 months old) and NRA data. Management accounts give the most recent picture of operating performance.

## Input contract

```yaml
alt_data_request:
  case_id: string
  applicant_company_number: string
  platforms_connected: [enum]               # xero | quickbooks | sage
  consent_token: string
```

## Output contract

```yaml
alt_data_summary:
  case_id: string
  platforms_used: [enum]
  revenue_ttm_gbp: integer
  gross_margin_pct: float
  operating_profit_ttm_gbp: integer
  overdue_payables_gbp: integer
  overdue_receivables_gbp: integer
  days_sales_outstanding: integer
  inventory_value_gbp: integer              # nullable; goods-based businesses only
  ttm_end_period: date
  reason_codes: [string]
```

## Decision logic

```
For each connected platform:
  - pull last 12 months of P&L
  - pull aged debtors + creditors
  - pull inventory if applicable

Reconcile against bureau + OB:
  - revenue_ttm vs OB credits — should be close (within 15%)
  - if material divergence → flag for downstream cross-check
```

## Worked example (Balkan Engineering EOOD case)

Input:
```yaml
alt_data_request:
  case_id: "BAL-2026-04-001"
  applicant_company_number: "123456789"
  platforms_connected: [xero]
  consent_token: "TKN-alt-xero-2026-04-12"
```

Output:
```yaml
alt_data_summary:
  case_id: "BAL-2026-04-001"
  platforms_used: [xero]
  revenue_ttm_gbp: 854100
  gross_margin_pct: 41.2
  operating_profit_ttm_gbp: 118400
  overdue_payables_gbp: 4200
  overdue_receivables_gbp: 11800
  days_sales_outstanding: 38
  inventory_value_gbp: null
  ttm_end_period: "2026-03-31"
  reason_codes: ["UK_ALT_DATA_XERO_CURRENT_PERIOD_RETRIEVED"]
```

Xero gives the very recent picture: BGN 854k revenue TTM (matches NRA VAT BGN 851k and OB BGN 847k credits — excellent consistency), 41.2% gross margin, modest overdues. Strong operational picture.

## Bright lines

- (no statutory bright lines for this agent)

## Operational rules

- Cross-reference revenue against NRA VAT (where available) and OB credits — 15%+ delta is investigative
- Service businesses: gross margin proxied; inventory will be null
- Multiple platforms connected: aggregate consistently or flag discrepancy

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Platform connection broken (token expired) | Refer; user must reconnect |
| Data appears stale (last sync > 90 days) | Use but flag staleness |


## Bulgaria-specific operational notes

Operates within the Bulgarian framework — BNB + FSC supervision (ECB close cooperation since 2020), Consumer Credit Act, AML Act enforced via FID-SANS.

- **Eurozone accession imminent:** BGN runs a currency board pegged to EUR (1.95583 BGN/EUR). Eurozone accession targeted 1 January 2026 — operational EUR transition planning (dual display, conversion, system readiness) is a live consideration. Verify current accession status at time of use.
- **BNB Central Credit Register:** Mandatory central register; strong consumer + commercial visibility.
- **EGN universal identifier:** Unified civil number; restricted-use under GDPR.
- **Currency board stability:** Peg removes most FX risk vs EUR but is a fixed regime; redenomination on accession.
- **Cross-reference:** `country-bg-lending-policy-agent` (Country Policy Pack stub).

## Statutory hooks

- Bulgaria GDPR / DPA 2018
- BNB BNB consumer protection (use of accurate, recent data)

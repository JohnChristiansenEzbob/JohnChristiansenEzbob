---
name: es-lead-qualification-agent
description: |
  Policy-fit pre-screen for Spain SME credit applications. Tests the inbound case against the lender's credit policy envelope — product range, amount band, prohibited sectors, geographic restrictions, broker accreditation status. Returns qualification outcome before any external data is pulled.
---

# Lead Qualification Agent

Cheap, fast pre-screen. Filter out applications that cannot possibly succeed under current policy before spending money on bureau pulls or AEAT calls.

## Input contract

```yaml
qualification_request:
  case_id: string
  facility_type: enum
  facility_amount_eur: integer
  facility_term_months: integer
  applicant_company_number: string
  sic_codes: [string]                      # primary SIC code
  channel: enum
  broker_fca_reference: string             # nullable
  geographic_region: string                # GB-SCT, GB-ENG, GB-WLS, GB-NIR
```

## Output contract

```yaml
qualification_outcome:
  case_id: string
  outcome: enum                            # pass | refer | decline_policy
  product_match: string                    # specific product variant matched
  fail_reasons: [string]                   # populated if outcome != pass
  reason_codes: [string]
```

## Decision logic

```
if facility_amount_eur not in product.amount_band:
  outcome = decline_policy
  reason_codes += [UK_LEAD_AMOUNT_OUTSIDE_BAND]

if facility_term_months not in product.term_band:
  outcome = decline_policy
  reason_codes += [UK_LEAD_TERM_OUTSIDE_BAND]

if primary_sic_code in PROHIBITED_SECTORS:
  outcome = decline_policy
  reason_codes += [UK_LEAD_PROHIBITED_SECTOR]

if channel == "broker":
  if broker_fca_reference not in ACCREDITED_BROKERS:
    outcome = refer
    reason_codes += [UK_LEAD_BROKER_NOT_ACCREDITED]

if geographic_region not in COVERED_REGIONS:
  outcome = decline_policy
  reason_codes += [UK_LEAD_REGION_NOT_COVERED]

if outcome == None:
  outcome = pass
  product_match = match_product_variant(facility_type, amount, term)
```

## Worked example (Ibero Engineering S.L. case)

Input:
```yaml
qualification_request:
  case_id: "IBE-2026-04-001"
  facility_type: term_loan
  facility_amount_eur: 150000
  facility_term_months: 60
  applicant_company_number: "B-12345678"
  sic_codes: ["71121"]
  channel: broker
  broker_fca_reference: "555444"
  geographic_region: "GB-SCT"
```

Output:
```yaml
qualification_outcome:
  case_id: "IBE-2026-04-001"
  outcome: pass
  product_match: "UK_term_loan_v3"
  fail_reasons: []
  reason_codes: ["UK_LEAD_QUALIFICATION_PASS"]
```

Highland's €150k 5-year term loan is well within product band (€25k-€500k, 12-84 months). SIC 71121 (engineering consulting) is not prohibited. Broker Highland Capital Partners is CNMV + BdE-accredited. Scotland is covered. Clear pass.

## Bright lines

- Prohibited sectors (e.g. crypto exchanges, gambling, adult content) — automatic decline_policy
- Sanctioned regions / jurisdictions — automatic decline_policy
- Non-accredited broker — automatic refer (cannot auto-approve via unaccredited channel)

## Operational rules

- Policy data (prohibited sectors, accredited brokers, regions) is versioned and loaded from a controlled config
- Pre-screen is cheap and synchronous — must complete within 200ms
- Policy changes require named credit-policy committee sign-off; the agent does not have discretion to override

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Policy config unavailable | Fail-safe to refer (do not auto-approve) |
| SIC code missing | Refer; cannot apply sector policy without it |
| Region inferable from registered office | Use registered office region as default |


## Spain-specific operational notes

This agent operates within the Spanish lending framework — Banco de España + CNMV joint regulatory perimeter, Ley 10/2014 for banking supervision, LCC (Ley 16/2011) for consumer credit, LRCCI (Ley 5/2019) for mortgage credit.

- **CIRBE €9k threshold:** Banco de España central credit register. Commercial risks >€9,000 mandatory contribution. Small SME facilities frequently below threshold — limited CIRBE visibility for genuine SME risk.
- **ASNEF / BADEXCUG strict access:** Spanish consumer bureau access has the strictest legal review requirement in EU. Operational onboarding must include legal basis attestation. ASNEF for negative; BADEXCUG for comprehensive — separate access agreements required.
- **LRCCI notarial requirement (AGNCN):** Mortgage origination requires AGNCN (Acta de Información Notarial Previa) — notarial pre-contractual information act. Cannot bypass; significant operational integration with notary network.
- **Tarjeta revolving usury (2020 Supreme Court):** Revolving credit cards subject to enhanced disclosure post-2020 Supreme Court rulings on usury. APR materially above market average is voidable.
- **Bizum ubiquity:** Mobile P2P payment platform with near-universal Spanish adoption; PSD2 integration via participating banks.
- **NIE administrative complexity:** Foreign residents require NIE (Número de Identidad de Extranjero) — multiple issuing authorities, common source of onboarding friction.
- **Cross-reference:** `country-es-lending-policy-agent` provides full ES jurisdictional context.

## Statutory hooks

- CNMV + BdE LCC + BdE supervision (clear product-customer fit at first touch)
- Financial Promotions regime (lender must only offer products it advertises)

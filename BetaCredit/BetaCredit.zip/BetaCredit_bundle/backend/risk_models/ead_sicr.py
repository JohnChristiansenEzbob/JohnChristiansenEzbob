"""
risk_models.ead_sicr
BetaCredit — Exposure at Default (EAD) and SICR Staging Engine.

EADModelSuite: behavioural CCF-based EAD estimates.
SICREngine:    IFRS 9 three-stage classification with configurable thresholds
               per asset class (IFRS 9 §B5.5.14–B5.5.22).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List

import numpy as np

from .asset_classes import AssetClass, ASSET_CLASS_CONFIG


# ══════════════════════════════════════════════════════════════════════════════
# EAD
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class EADEstimate:
    ead: float                  # Total exposure at default (£)
    drawn_balance: float        # Currently drawn amount (£)
    undrawn_commitment: float   # Undrawn committed facility (£)
    ead_confidence_pct: float   # Model confidence in estimate (%)


# Typical drawn balances and undrawn commitments by asset class (£)
_EAD_PARAMS: dict[str, dict] = {
    "sme_unsecured":        dict(drawn_mean=85_000,  undrawn_mean=40_000,  conf=82.0),
    "sme_secured":          dict(drawn_mean=250_000, undrawn_mean=80_000,  conf=85.0),
    "consumer_unsecured":   dict(drawn_mean=12_000,  undrawn_mean=8_000,   conf=88.0),
    "residential_mortgage": dict(drawn_mean=220_000, undrawn_mean=0,       conf=92.0),
    "buy_to_let":           dict(drawn_mean=185_000, undrawn_mean=0,       conf=91.0),
    "motor_finance":        dict(drawn_mean=22_000,  undrawn_mean=0,       conf=87.0),
    "invoice_finance":      dict(drawn_mean=95_000,  undrawn_mean=55_000,  conf=78.0),
    "asset_finance":        dict(drawn_mean=140_000, undrawn_mean=20_000,  conf=84.0),
}


class EADModelSuite:
    """Behavioural CCF-based EAD model suite."""

    def __init__(self, seed: int = 99) -> None:
        self._rng = np.random.default_rng(seed)

    def estimate(self, ac: AssetClass) -> EADEstimate:
        ac_key = ac.value if isinstance(ac, AssetClass) else ac
        cfg = ASSET_CLASS_CONFIG[ac_key]
        p   = _EAD_PARAMS[ac_key]

        drawn    = float(np.clip(self._rng.lognormal(np.log(max(p["drawn_mean"], 1)), 0.4), 1_000, 5_000_000))
        undrawn  = float(np.clip(self._rng.lognormal(np.log(max(p["undrawn_mean"] + 1, 1)), 0.5), 0, 2_000_000)) \
                   if p["undrawn_mean"] > 0 else 0.0
        ead      = drawn + undrawn * cfg.ccf
        conf     = float(np.clip(p["conf"] + self._rng.normal(0, 2), 60, 99))

        return EADEstimate(
            ead=ead,
            drawn_balance=drawn,
            undrawn_commitment=undrawn,
            ead_confidence_pct=conf,
        )


# ══════════════════════════════════════════════════════════════════════════════
# SICR Engine
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class SICRAssessment:
    stage: str                          # "stage_1", "stage_2", "stage_3"
    triggers_fired: List[str]           # list of trigger names
    pd_increase_abs_bps: float          # absolute PD increase in basis points
    pd_increase_rel_pct: float          # relative PD increase in %


# SICR thresholds per asset class (absolute PD increase in bps)
_SICR_ABS_BPS: dict[str, float] = {
    "sme_unsecured":        200.0,
    "sme_secured":          150.0,
    "consumer_unsecured":   250.0,
    "residential_mortgage": 100.0,
    "buy_to_let":           100.0,
    "motor_finance":        175.0,
    "invoice_finance":      175.0,
    "asset_finance":        150.0,
}

# Relative threshold: all asset classes use >100% (doubling) per IFRS 9 B5.5.14
_SICR_REL_PCT = 100.0

# DPD backstop thresholds
_DPD_STAGE2 = 30   # IFRS 9 B5.5.19 rebuttable presumption
_DPD_STAGE3 = 90   # IFRS 9 B5.5.37 credit-impaired


class SICREngine:
    """
    IFRS 9 Significant Increase in Credit Risk (SICR) classification engine.

    Applies the following rule hierarchy:
      Stage 3: 90+ DPD  OR  default/credit-impaired flag
      Stage 2: abs PD increase > threshold  OR  rel PD increase > 100%
               OR  30+ DPD backstop  OR  forbearance flag
      Stage 1: none of the above
    """

    def assess(
        self,
        ac: AssetClass,
        pd_orig: float,
        pd_curr: float,
        flags: dict,
    ) -> SICRAssessment:
        """
        Parameters
        ----------
        ac       : AssetClass enum member
        pd_orig  : PD at origination (0–1)
        pd_curr  : Current PD (0–1)
        flags    : dict — optional keys:
                     'days_past_due'    (int, default 0)
                     'forbearance_flag' (bool, default False)
        """
        ac_key = ac.value if isinstance(ac, AssetClass) else ac

        dpd    = int(flags.get("days_past_due", 0))
        forb   = bool(flags.get("forbearance_flag", False))

        pd_delta_bps = (pd_curr - pd_orig) * 10_000
        pd_delta_rel = ((pd_curr / max(pd_orig, 1e-8)) - 1) * 100 if pd_orig > 0 else 0.0

        abs_thresh = _SICR_ABS_BPS.get(ac_key, 200.0)

        triggers: list[str] = []

        # ── Stage 3 checks ─────────────────────────────────────────────────────
        if dpd >= _DPD_STAGE3:
            triggers.append(f"dpd_{dpd}_stage3")
            return SICRAssessment(
                stage="stage_3",
                triggers_fired=triggers,
                pd_increase_abs_bps=pd_delta_bps,
                pd_increase_rel_pct=pd_delta_rel,
            )

        # ── Stage 2 checks ─────────────────────────────────────────────────────
        if pd_delta_bps >= abs_thresh:
            triggers.append(f"abs_pd_{pd_delta_bps:.0f}bps_gt_{abs_thresh:.0f}bps")
        if pd_delta_rel >= _SICR_REL_PCT:
            triggers.append(f"rel_pd_{pd_delta_rel:.0f}pct_gt_{_SICR_REL_PCT:.0f}pct")
        if dpd >= _DPD_STAGE2:
            triggers.append(f"dpd_{dpd}_backstop")
        if forb:
            triggers.append("forbearance_flag")

        if triggers:
            return SICRAssessment(
                stage="stage_2",
                triggers_fired=triggers,
                pd_increase_abs_bps=pd_delta_bps,
                pd_increase_rel_pct=pd_delta_rel,
            )

        # ── Stage 1 ────────────────────────────────────────────────────────────
        return SICRAssessment(
            stage="stage_1",
            triggers_fired=[],
            pd_increase_abs_bps=pd_delta_bps,
            pd_increase_rel_pct=pd_delta_rel,
        )

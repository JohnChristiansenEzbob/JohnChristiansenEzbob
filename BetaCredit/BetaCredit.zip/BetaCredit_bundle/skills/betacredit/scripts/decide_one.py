#!/usr/bin/env python3
"""
decide_one.py — produce a credit decision for a single loan from the CLI.

Usage:
    python decide_one.py --asset_class=sme_unsecured --bureau_score=620 \
                         --cashflow_coverage=1.3 --ltv=0 --loan_amount=50000 \
                         --loan_term_months=36 --default_flag=0

Optional fields: --dpd, --forbearance_flag, --borrower_id.
"""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path

# Locate the backend regardless of where this script is invoked from.
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent.parent  # scripts/ → betacredit/ → skills/ → bundle root
sys.path.insert(0, str(ROOT / "backend"))

from risk_models import CreditDecisionAgent


def parse_args() -> dict:
    """Parse --key=value pairs into a borrower dict. Coerces numbers."""
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--asset_class",       required=True)
    p.add_argument("--bureau_score",      required=True, type=int)
    p.add_argument("--cashflow_coverage", required=True, type=float)
    p.add_argument("--ltv",               required=True, type=float)
    p.add_argument("--loan_amount",       required=True, type=float)
    p.add_argument("--loan_term_months",  required=True, type=int)
    p.add_argument("--default_flag",      required=True, type=int, choices=[0, 1])
    p.add_argument("--dpd",               type=int,  default=0,
                   help="Days past due (drives Stage 2/3 staging)")
    p.add_argument("--forbearance_flag",  type=int,  default=0, choices=[0, 1])
    p.add_argument("--borrower_id",       type=str,  default=None)
    p.add_argument("--json",              action="store_true",
                   help="Emit JSON instead of the human-readable summary")
    return vars(p.parse_args())


def main() -> int:
    args = parse_args()
    json_mode = args.pop("json")
    borrower_id = args.pop("borrower_id")

    agent = CreditDecisionAgent()
    decision = agent.decide_one(args, borrower_id=borrower_id)

    if json_mode:
        print(json.dumps(decision.to_dict(), indent=2, default=str))
    else:
        print(decision.summary())
    return 0


if __name__ == "__main__":
    sys.exit(main())

# Consistency Check Matrix

The matrix of declared-vs-discoverable comparisons used by `application-fraud-agent`. Each declared field has zero, one, or several authoritative counterparts; mismatches generate weighted fraud signals.

## Reading the matrix

- **Declared field** — what the application form captures
- **Discoverable counterpart** — where the truth lives
- **Match logic** — how to compare (exact, fuzzy, range, derived)
- **Weight** — base contribution to the synthetic fraud score on mismatch (calibrated quarterly against bad-rate experience)
- **Hard?** — whether this mismatch alone can drive a `decline` recommendation

## Entity-level

| Declared | Discoverable | Match logic | Weight | Hard? |
|---|---|---|---|---|
| Trading name | Companies House registered name | exact OR known-trading-as variants | 0.20 | No |
| Trading address | CH registered office; OS Address Base; Royal Mail PAF | fuzzy with postcode-anchor | 0.10 | No |
| Trading address | Open banking transaction-cluster geocentroid | distance < 50km | 0.15 | No |
| Years trading | CH incorporation date | year diff ≤ 1 | 0.20 | No |
| Sector / business activity | CH filed SIC | semantic match (SIC ↔ free text) | 0.15 | No |
| Annual turnover | Filed accounts (latest) | declared within ±15% of latest filed (annualised if needed) | 0.30 | No |
| Annual turnover | Open banking 12m | declared within ±20% of OB-observed | 0.40 | No |
| Number of employees | HMRC PAYE outflow band; filed accounts headcount | derived band match | 0.20 | No |
| VAT registration | HMRC MTD VAT (with consent) | exact VRN match | 0.30 | Conditional |
| Bank account for disbursement | Open banking account-holder name | name match | 0.50 | Yes (combined with other signals) |

## Director / UBO-level

| Declared | Discoverable | Match logic | Weight | Hard? |
|---|---|---|---|---|
| Director name | CH active officers | exact / fuzzy with DOB partial | 0.40 | Yes |
| Director DOB (full) | CH DOB partial (year + month) | year+month match | 0.30 | Yes |
| Director home address | Bureau personal file address history | match in current or last 3 addresses | 0.20 | No |
| Director nationality | Bureau personal file | exact | 0.10 | No |
| Declared UBO | UBO graph from `ubo-mapper` | undisclosed UBOs / over-disclosed UBOs | 0.40 | No |

## Device / behavioural

| Signal | Description | Weight | Hard? |
|---|---|---|---|
| Datacentre / VPN IP | IP belongs to known VPN, Tor, or datacentre ASN | 0.15 | No |
| Geolocation vs trading address | IP geolocation > 500km from declared trading address with no plausible explanation | 0.10 | No |
| Device shared with prior decline | Same device fingerprint as a prior fraud-flagged or declined application | 0.40 | No |
| Application completion time anomaly | Completion time < 5th percentile or > 95th percentile of population | 0.05 | No |
| Copy-paste in free-text fields | Pasted (not typed) content in fields the form expects to be free-form | 0.10 | No |
| Autofill mismatch | Autofill suggests one identity, declared is another | 0.15 | No |
| Time-of-day anomaly | Submission at 3am for a customer-segment that doesn't typically operate then | 0.05 | No |

## Velocity (broker channel)

| Signal | Description | Weight |
|---|---|---|
| Broker submission rate | > 3× broker's 90-day baseline | 0.10 |
| Broker decline rate | > 2× book average over last 30 days | 0.15 |
| Template pattern | High lexical similarity in free-text across submissions from same broker | 0.20 |
| Common accountant / advisor | Same third-party advisor appearing on > N submissions in window | 0.05 |

## Combination rules

Some signals matter much more in combination than in isolation:

- `FRAUD_DEVICE_VPN_DATACENTRE` + `FRAUD_KYB_RECENTLY_INCORPORATED` + `FRAUD_GHOST_NO_OB_ACTIVITY` — classic synthetic / ghost combination, multiply combined weight by 1.5
- `FRAUD_IDT_DECLARED_DOB_MISMATCH_PSC` + `FRAUD_IDT_DEVICE_GEO_INCONSISTENT` — strong identity theft signal, multiply by 1.5
- `FRAUD_BROKER_VELOCITY_SPIKE` + `FRAUD_BROKER_TEMPLATE_PATTERN` + `FRAUD_BROKER_DECLINE_RATE_ELEVATED` — broker-channel investigation trigger, multiply by 1.5

## Calibration

Weights are calibrated quarterly against:
- Confirmed fraud cases (Cifas-filed, internal fraud team confirmed)
- False positives (cases flagged that turned out genuine)
- Performance of the resulting facilities (1- and 2-year vintages)

Calibration is a model-risk activity; the weights live in version-controlled policy files referenced by the agent at runtime.

## Notes

This matrix is a **screening** tool, not a decisioning tool. It produces signals; the agent combines those signals into a fraud risk score; the decision sits with `decision-pricing-agent` (and ultimately a human reviewer for any case the agent recommends `refer_to_fraud_team` or `decline` on).

---
name: betacredit
description: Use this skill whenever the user mentions BetaCredit, a credit decision, a loan application, IFRS 9 staging (Stage 1/2/3), expected credit loss (ECL), risk-weighted assets (RWA), Basel capital, SICR (significant increase in credit risk), loss given default (LGD), exposure at default (EAD), probability of default (PD), or asks Claude to analyse a book of UK loans. Also trigger when the user mentions any of the eight asset classes (SME unsecured/secured, consumer unsecured, residential mortgage, buy-to-let, motor finance, invoice finance, asset finance), when they provide a CSV/Excel/JSON/Parquet of borrower data, when they ask for a portfolio ECL run, a fairness analysis, or a credit-risk dashboard. Even if the user does not say "BetaCredit" by name — phrases like "decide on this loan", "what's the ECL for this book", "is this borrower risky", or "run IFRS 9 staging" should pull this skill in. Use the CreditDecisionAgent for single-loan or batch decisions; run the notebooks for full analytical packs.
---

# BetaCredit Skill

This skill lets Claude operate **BetaCredit**, a UK-lending credit-risk modelling suite. BetaCredit covers PD, LGD, EAD, IFRS 9 staging, fairness diagnostics, and portfolio ECL with Basel IV capital.

The skill has two execution paths. Pick the right one based on what the user is asking for:

| User wants … | Use the … |
|---|---|
| A decision on one loan, or a few loans they list in chat | `CreditDecisionAgent` directly (fast, no notebook) |
| Bulk decisions on a CSV / Parquet of loans | `scripts/decide_portfolio.py` (still no notebook) |
| To know whether the agent's policy is *any good* against a labelled book | `scripts/backtest.py` — runs precision/recall/AUC/profit at policy plus a threshold sweep, with cohort and asset-class breakdowns |
| The PD model retrained on the user's actual data (so absolute PDs and ECL reflect their book, not the benchmark calibration) | Run notebook 02 to the end — it now saves `pd_models.pkl`. The `CreditDecisionAgent` and notebook 07 will auto-load it on next run |
| A full analytical pack — PD model with SHAP, fairness charts, stress dashboard | The relevant Jupyter notebook(s) via `nbconvert` |
| To ingest a new data file (any format) | `scripts/ingest.py` or notebook 00 |
| To understand what the suite produces, or quote numbers from it | Read `references/` and explain |

## Step 1 — Set the working directory

BetaCredit is a folder containing the notebooks, a `backend/risk_models/` Python package, and (optionally) `example_data/` and `df_all.parquet`. Before doing anything, confirm the directory exists and that `backend/risk_models/credit_agent.py` is present. If the user has not given you the path, ask. Once located, `cd` into it for everything that follows; all paths in the scripts are relative.

## Step 2 — If the task is a credit decision, use the agent

The `CreditDecisionAgent` is the fastest path to a verdict on one or more loans. It takes a borrower row (a dict or a DataFrame row) with at minimum the seven required canonical fields:

- `asset_class` — one of the eight canonical strings (see `references/asset_classes.md`)
- `bureau_score` — int, 300-999
- `cashflow_coverage` — float, DSCR-equivalent
- `ltv` — float, 0-1.5 (use 0.0 for unsecured)
- `loan_amount` — float, in £
- `loan_term_months` — int
- `default_flag` — int, 0 or 1

Optional but useful: `dpd` (days past due, drives Stage 2/3), `forbearance_flag` (boolean), `borrower_id`.

**Optional LGD inputs (v1.2)** — any of these flow through to the LGD model. Either supply `lgd_observed` to override the model entirely, or supply one or more component inputs to engage the formula. Anything not supplied falls back to the asset-class default.

- `lgd_observed` — final pre-computed LGD (0-1). Overrides everything else.
- `collateral_value` — £ value of security at origination. Use 0 for genuinely unsecured.
- `cure_prob` — probability the loan cures without going to recovery (0-1).
- `recovery_costs` — workout costs as fraction of EAD (0-1).
- `time_to_resolution_months` — int. Drives recovery discounting.

The `CreditDecision` returned by the agent surfaces `lgd_source` ("observed" / "computed_from_components" / "asset_class_default") and `lgd_components` (the four-component breakdown when the formula path was used) so you can see *why* each LGD is what it is. See `references/lgd_components.md` for the formula.

### Single loan

```python
from risk_models import CreditDecisionAgent

agent = CreditDecisionAgent()
decision = agent.decide_one({
    "asset_class": "sme_unsecured",
    "bureau_score": 620,
    "cashflow_coverage": 1.3,
    "ltv": 0.0,
    "loan_amount": 50_000,
    "loan_term_months": 36,
    "default_flag": 0,
})
print(decision.summary())
```

A `CreditDecision` exposes: `recommendation` (APPROVE / REVIEW / DECLINE), `rationale` (one-line explanation), `confidence` (0-1), the full PD/LGD/EAD scores, IFRS 9 stage, four ECL measures (`ecl_12m`, `ecl_life`, `ecl_stress`, `rwa`), and `sicr_triggers`. Call `decision.summary()` for a human-readable block to drop into a reply; call `decision.to_dict()` for serialisation.

### Several loans listed in chat

Build a list of dicts, loop:

```python
decisions = [agent.decide_one(loan) for loan in loans]
for d in decisions:
    print(d.summary()); print()
```

### A CSV / Parquet of loans

Run `scripts/decide_portfolio.py` — it ingests the file (handling alias column names), scores every loan, and prints a summary table plus per-asset-class breakdown. Save the result to CSV for the user if they want it:

```bash
python scripts/decide_portfolio.py path/to/loans.csv --out decisions.csv
```

## Step 3 — If the task is an analytical pack, use the notebooks

When the user wants more than a verdict — SHAP explanations, calibration plots, fairness diagnostics, stress dashboards, an IFRS 9 staging migration chart — run the relevant notebook with `nbconvert`. The notebooks auto-detect `df_all.parquet`, so make sure it exists first (run notebook 00 if not).

| User asks for … | Run notebook |
|---|---|
| "Explore the data" / data quality check | `01_exploratory_data_analysis.ipynb` |
| PD model with explanations | `02_pd_models_shap_lime.ipynb` |
| LGD / EAD / stress curves | `03_lgd_ead_stress.ipynb` |
| IFRS 9 staging or SICR analysis | `04_sicr_staging.ipynb` |
| Fairness / Consumer Duty review | `05_fairness_responsible_ai.ipynb` |
| Model retraining via outcome feedback | `06_rl_reweighting.ipynb` |
| Portfolio ECL + Basel capital | `07_portfolio_ecl_capital.ipynb` |

Use `scripts/run_pipeline.py` to run the whole sequence, or invoke `nbconvert` directly for one notebook:

```bash
python -m nbconvert --to notebook --execute 04_sicr_staging.ipynb \
       --output _executed_04.ipynb --ExecutePreprocessor.timeout=600
```

After execution, tell the user where to find the file and which output plots / tables answer their question. If they want figures extracted as PNGs, the notebook already saves a few (look for files like `04_sicr_*.png` in the working directory).

## Step 4 — If the task is "is this policy any good?", back-test it

When a user asks whether the agent's APPROVE / REVIEW / DECLINE thresholds actually work on their book — "what fraction of declines were real defaulters?", "how many defaulters did we miss?", "would tighter thresholds be more profitable?" — run `scripts/backtest.py` against a labelled file (one with `default_flag` populated).

```bash
python scripts/backtest.py path/to/labelled_loans.parquet \
    --approval_profit 1500 --default_loss 12000
```

The back-tester produces six things to report back to the user, in this order of importance:

1. **Quality warnings** at the top of the output (low AUC, overfit, polarity error, no-DECLINE policy) — read these first. If they fire, surface them in the reply before the headline numbers.
2. **Confusion matrix** — APPROVE / REVIEW / DECLINE by good / default. Translate into plain English: "of the loans the agent declined, X% were genuine defaulters; of the actual defaulters, the agent caught Y%."
3. **AUC and Gini** of the underlying PD model. Compare against the saved CV AUC if a `pd_models.pkl` exists, to flag overfit.
4. **Profit at policy** using user-supplied or default economics. Most users won't have firm numbers; the defaults (£1,200 mean lifetime margin per good loan, £8,500 mean loss per defaulter) are reasonable UK SME starting points and worth flagging as overridable.
5. **Threshold sweep** — what happens at -50%, -25%, -10%, 0%, +10%, +25%, +50% shifts on the DECLINE ceiling. Use this to recommend the policy change that maximises profit while keeping default capture above some floor.
6. **Cohort breakdowns** — by `vintage_quarter` (when present) and by `asset_class`. Worst-performing vintages or asset classes are usually the actionable finding.

The back-tester does **not** decide whether the policy is "good" or "bad" for the user — its job is to surface the numbers and the warnings; the user's underwriting committee decides. Be explicit about that boundary.

## Step 5 — If the task is "retrain on my data", run notebook 02

The agent's default PD numbers are calibrated to UK lending benchmarks, not to the user's actual book. To produce PD / ECL / RWA figures that reflect their data, the user needs to run notebook 02 once. The notebook's final cell (Section 11) calls `PDModelSuite.fit_from_dataframe()` and saves `pd_models.pkl`.

After that:

- The `CreditDecisionAgent` auto-loads `pd_models.pkl` on construction. Confirm by checking `agent.pd_provenance['source']` — it should be `"real"` not `"synthetic"`.
- Notebook 07 picks it up via the same mechanism.
- To revert to the benchmark calibration, delete `pd_models.pkl`.

**Tell the user about the CV AUC vs in-sample AUC distinction.** A 5-fold cross-validated AUC is the honest one; an in-sample AUC of 1.0 with a CV AUC of 0.6 means the model is overfit and the back-tester will warn about it. This is a feature, not a bug — the suite is being honest about a real risk.

## Step 6 — Reporting back

When you reply to the user:

- **Lead with the decision** (APPROVE / REVIEW / DECLINE for a single loan; the portfolio summary table for a batch) before the supporting detail.
- **State the rationale.** The `CreditDecision.rationale` field already gives this in one sentence — quote it.
- **Cite the IFRS 9 stage and SICR triggers** when present — these are what regulators care about.
- **Be honest about calibration.** The PD/LGD/EAD/ECL/RWA numbers reflect BetaCredit's UK-lending calibration, not a fit to the user's data. If they're talking about a regulatory submission, point them at `references/calibration_and_trust.md`.
- **Don't fabricate numbers.** If you didn't run the agent or a notebook, say "I haven't run it yet — want me to?" and stop there.

## Critical things not to do

- **Do not invent borrower IDs or fields.** If a required canonical column is missing, ask. Do not guess `default_flag = 0`; pull it from the data or refuse.
- **Do not produce ECL totals or RWA without running the agent or notebook 07.** A pure narrative answer to "what's our RWA?" is wrong by construction; you must execute code.
- **Do not edit the modelling notebooks.** They are designed to auto-detect data through `df_all.parquet`; the right way to feed in real data is via notebook 00, never by patching cells in 01-07.
- **Do not claim the numbers are regulator-ready.** They are an analytical workbench. Surface this caveat when the conversation drifts toward submission.

## Reference files

Read these when the user asks for the specific detail:

- `references/schema.md` — the canonical schema, required vs optional, ranges and defaults (including the v1.1 origination/vintage columns and the v1.2 LGD-component columns)
- `references/asset_classes.md` — the eight asset classes with their typical default rates, LGDs, regulatory floors, and SICR thresholds
- `references/decision_policy.md` — how the agent's APPROVE / REVIEW / DECLINE thresholds work and when to override them
- `references/calibration_and_trust.md` — which numbers to trust directly, which are derived but defensible, and which need re-calibration before regulatory use
- `references/backtesting.md` — how to interpret the back-tester's outputs, what the quality warnings mean, and how to choose unit economics
- `references/lgd_components.md` — the v1.2 LGD decomposition formula, asset-class haircut and cure-rate calibration, when to use override vs component path

## Scripts available

- `scripts/decide_one.py` — CLI wrapper around `agent.decide_one()`. Pass borrower fields as `--field=value` pairs.
- `scripts/decide_portfolio.py` — ingest a file and score every loan; print summary; optionally save CSV.
- `scripts/backtest.py` — back-test the agent against a labelled book; print confusion matrix, AUC, profit at policy, threshold sweep, and cohort breakdowns; optionally save CSVs.
- `scripts/ingest.py` — wrap `data_ingestion.ingest()` to produce a canonical `df_all.parquet` from any supported file format.
- `scripts/run_pipeline.py` — run notebook 00 then one or more modelling notebooks via `nbconvert`, in order.

Each script has `--help`. Read the source if you need to compose them differently — they are short.

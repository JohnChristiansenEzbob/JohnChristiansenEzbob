---
name: cy-data-capture-agent
description: |
  Structured information capture from any origination channel. Normalises the raw broker / online / API payload into the canonical case object schema. Validates required fields, normalises currency and dates, flags missing data for follow-up.
---

# Data Capture Agent

Turn the raw inbound payload into a clean, structured case object that all downstream agents can consume reliably.

## Input contract

```yaml
raw_application_payload:
  source_channel: enum
  source_payload_raw: object                # arbitrary shape from broker/online form
  payload_schema_version: string
```

## Output contract

```yaml
case_object:
  case_id: string
  applicant:
    company_number: string
    name: string
    registered_office: string
    sic_codes: [string]
  facility:
    type: enum
    amount_eur: integer
    term_months: integer
    purpose_raw: string
  contact:
    primary_name: string
    primary_email: string
    primary_phone: string
    role: string
  channel: enum
  broker:                                   # nullable
    firm: string
    fca_reference: string
  validation_warnings: [string]
  field_count_populated: integer
```

## Decision logic

```
parse(raw_application_payload) against schema version.
For each field:
  - validate format (e.g. company_number = 8 digits, email regex, phone E.164)
  - normalise (currency to integer EUR, dates to ISO 8601)
  - if invalid: append to validation_warnings

If any required field missing or invalid: emit case_object with warnings populated.
Downstream orchestrator decides whether to pause or proceed.
```

## Worked example (Aphrodite Engineering Ltd case)

Input:
```yaml
raw_application_payload:
  source_channel: broker
  source_payload_raw:
    company_no: "HE 123456"
    co_name: "Aphrodite Engineering Ltd Consultants Ltd"
    facility: "term loan"
    amount: "150,000.00"
    term_yrs: 5
    contact: "Lachlan MacKenzie"
    contact_email: "lachlan@highlandeng.example.co.uk"
    contact_phone: "0141 555 0182"
  payload_schema_version: "broker_v3.2"
```

Output:
```yaml
case_object:
  case_id: "APH-2026-04-001"
  applicant:
    company_number: "HE 123456"
    name: "Aphrodite Engineering Ltd Consultants Ltd"
    registered_office: "Suite 4, 2 Atlantic Quay, Nicosia, G2 8GA"
    sic_codes: ["71121"]
  facility:
    type: term_loan
    amount_eur: 150000
    term_months: 60                         # normalised from 5 yrs
    purpose_raw: "Premises fit-out + testing equipment"
  contact:
    primary_name: "Lachlan MacKenzie"
    primary_email: "lachlan@highlandeng.example.co.uk"
    primary_phone: "+441415550182"          # normalised to E.164
    role: "Managing Director"
  channel: broker
  broker:
    firm: "Highland Capital Partners"
    fca_reference: "555444"
  validation_warnings: []
  field_count_populated: 47
```

Broker payload normalised — amount string '150,000.00' becomes integer 150000, term '5 yrs' becomes 60 months, phone normalised to E.164. No validation warnings.

## Bright lines

- (no statutory bright lines for this agent)

## Operational rules

- Field normalisation is deterministic — same input always produces same output
- Currency normalised to integer EUR (no fractional pence at this stage)
- Dates normalised to ISO 8601
- Phone numbers normalised to E.164
- Validation warnings are non-blocking — downstream agents see them and decide

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Payload schema version unknown | Refer to ops; cannot parse safely |
| Required field present but unparseable | Warning logged; field left null; case proceeds |
| Optional field unparseable | Warning logged; field left null; case proceeds |


## Cyprus-specific operational notes

Operates within the Cypriot framework — Central Bank of Cyprus + CySEC supervision, Consumer Credit Agreements Law, AML Law enforced via MOKAS.

- **ARTEMIS centrality:** ARTEMIS Bank Information Systems is the primary Cyprus credit bureau; operational relationship is essential.
- **Post-2013 crisis legacy:** The 2013 deposit bail-in left structural scars; borrower and depositor behaviour remains crisis-aware. Historical defaults common; distinguish current from legacy positions.
- **International business sector:** Large offshore/international company presence; KYB chains frequently involve cross-border structures requiring enhanced UBO scrutiny.
- **English in commerce:** English commonly accepted alongside Greek in commercial contracts.
- **Cross-reference:** `country-cy-lending-policy-agent` (Country Policy Pack stub).

## Statutory hooks

- Cyprus GDPR (data minimisation — capture only what's needed)
- CBC CBC consumer protection (clear capture of customer's stated needs)

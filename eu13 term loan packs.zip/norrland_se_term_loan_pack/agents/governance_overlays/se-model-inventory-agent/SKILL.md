---
name: se-model-inventory-agent
description: |
  Register every model invocation in the case — version, calibration date, input features, output, confidence. Satisfies FI model risk supervision model use governance and (where applicable) the Joint BoI/ISA AI Algorithmic Directive for high-impact use cases. Writes to the case audit trail.
---

# Model Inventory Agent

Audit trail for every model used. Regulators ask 'which model decided X' — this agent has the answer.

## Input contract

```yaml
model_invocation_record:
  case_id: string
  invoking_agent: string
  model_id: string
  model_version: string
  calibration_date: date
  feature_count: integer
  output_summary: object
  confidence: float
```

## Output contract

```yaml
model_inventory_entry:
  case_id: string
  inventory_record_id: string
  model_id: string
  model_version: string
  governance_classification: enum           # high_impact | medium_impact | low_impact
  ss1_23_classification: enum               # ai_use_case | non_ai_model | rule_based
  audit_ledger_entry_id: string
  reason_codes: [string]
```

## Decision logic

```
Record metadata for every model invocation:
  - PD scoring model
  - LGD model
  - Identity verification model (biometric)
  - Application fraud model
  - Fairness monitoring baseline
  - AML screening engine

Classify against FI model risk supervision:
  - Models with material customer impact → high_impact
  - Models supporting decisioning → medium_impact
  - Operational models → low_impact

Append to case-level model inventory.
At decision rendering, the inventory is attached to the case as audit evidence.
```

## Worked example (Norrland Engineering AB case)

Input:
```yaml
model_invocation_record:
  case_id: "NOR-2026-04-001"
  invoking_agent: pd-scoring-agent
  model_id: SME_TermLoan_PD
  model_version: v4.2
  calibration_date: "2026-01-15"
  feature_count: 47
  output_summary: {pd_12m: 0.018, portfolio_grade: "B+"}
  confidence: 0.91
```

Output:
```yaml
model_inventory_entry:
  case_id: "NOR-2026-04-001"
  inventory_record_id: "MI-2026-04-12-HE-001-006"
  model_id: SME_TermLoan_PD
  model_version: v4.2
  governance_classification: high_impact
  ss1_23_classification: ai_use_case
  audit_ledger_entry_id: "MI-LEDGER-001"
  reason_codes: ["UK_MODEL_INVENTORIED_HIGH_IMPACT_AI_USE_CASE"]
```

Highland's case will record 6+ model invocations: PD scoring (shown), LGD model, identity biometric, fraud model, fairness baseline, AML screening engine. All recorded in the case inventory for audit.

## Bright lines

- (no statutory bright lines for this agent)

## Operational rules

- Every model invocation is recorded — no silent inference
- Model versions are immutable once deployed; updates trigger new inventory entries
- Inventory survives the case (retained 7-25 years depending on facility class)
- Joint BoI/ISA AI Algorithmic Directive material change triggers re-registration

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Inventory store unavailable | Buffer and retry; alarm to ops |
| Model version unknown | Refuse invocation; cannot record without provenance |


## Sweden-specific operational notes

This agent operates within the Swedish lending framework — Finansinspektionen (FI) as unified supervisor, Banking and Financing Business Act (2004:297), Konsumentkreditlag (2010:1846) for consumer credit, Lag 2017:630 for AML.

- **BankID universal:** Operationally critical. Every Swedish consumer financial interaction uses BankID for SCA. Without BankID integration, customer onboarding friction is material.
- **Swish dominance:** Swedish bank-cooperative mobile payment platform; near-universal adoption for P2P + retail payments. Significant cash displacement in Sweden.
- **UC AB near-monopoly:** Upplysningscentralen (UC AB) holds dominant position for consumer credit data. Operational relationship is essential — analogous to SCHUFA in Germany.
- **Outside Eurozone:** SEK is free-floating. Larger lending facilities may need FX hedging consideration.
- **Macroprudential amortisation requirements:** FI sets statutory amortisation requirements (amorteringskrav) for high-LTV mortgages — operationally significant for mortgage product structure.
- **High household debt:** Sweden has historically high household debt-to-income; FI macroprudential focus is operationally consequential.
- **Personnummer privacy:** Restricted-use identifier; over-collection is privacy breach.
- **Cross-reference:** `country-se-lending-policy-agent` for full SE jurisdictional context (currently a stub in the Country Policy Pack).

## Statutory hooks

- FI model risk supervision (Model Risk Management)
- Joint BoI/ISA AI Algorithmic Directive 2024 (where applicable)
- EU AI Act (high-risk model inventory)
- FI (Finansinspektionen) FI customer protection (explainable models)

---
name: si-needs-discovery-agent
description: |
  Capture the structured needs profile — facility type, amount, term, drawdown pattern, urgency, dependencies. The 'what does the customer actually want' agent. Distinct from data-capture which normalises shape; needs-discovery captures intent.
---

# Needs Discovery Agent

Crystallise the customer's actual financing need into a structured profile that downstream agents (purpose-validation, decision-pricing) can reason against.

## Input contract

```yaml
needs_discovery_request:
  case_id: string
  declared_facility_type: enum
  declared_facility_amount_eur: integer
  declared_term_months: integer
  declared_drawdown_intent: enum            # single | phased | revolving
  urgency_band: enum                        # routine | <30d | <14d
  dependencies: [string]                    # e.g. ["equipment_delivery", "lease_completion"]
  alternative_options_considered: [string]  # nullable
```

## Output contract

```yaml
needs_profile:
  case_id: string
  facility_shape:
    type: enum
    amount_eur: integer
    term_months: integer
    drawdown: enum
  fit_assessment: enum                      # well_fitted | adequate | mismatch
  alternative_recommended: string           # nullable; if a different product would fit better
  urgency: enum
  dependencies: [string]
  reason_codes: [string]
```

## Decision logic

```
Compare declared shape against product fit heuristics:
  - Term loan + drawdown=revolving → mismatch (suggest revolving credit)
  - Term loan + amount < €25k → mismatch (suggest unsecured personal loan or revolving)
  - Term loan + term > 84 months → mismatch (refer to commercial mortgage)

If fit ≥ adequate: pass needs_profile through.
If mismatch: emit alternative_recommended and refer to broker for re-shape.
```

## Worked example (Triglav Engineering d.o.o. case)

Input:
```yaml
needs_discovery_request:
  case_id: "TRI-2026-04-001"
  declared_facility_type: term_loan
  declared_facility_amount_eur: 150000
  declared_term_months: 60
  declared_drawdown_intent: single
  urgency_band: routine
  dependencies: ["equipment_delivery", "lease_completion"]
  alternative_options_considered: ["asset_finance_for_equipment_only"]
```

Output:
```yaml
needs_profile:
  case_id: "TRI-2026-04-001"
  facility_shape:
    type: term_loan
    amount_eur: 150000
    term_months: 60
    drawdown: single
  fit_assessment: well_fitted
  alternative_recommended: null
  urgency: routine
  dependencies: ["equipment_delivery", "lease_completion"]
  reason_codes: ["UK_NEEDS_WELL_FITTED_TERM_LOAN"]
```

Term loan for capex with single drawdown, 5-year term, routine urgency, modest dependencies — classic well-fitted shape for this product.

## Bright lines

- (no statutory bright lines for this agent)

## Operational rules

- If applicant has considered asset finance for the equipment portion, surface that as an alternative even if the term loan fits — Banka Slovenije consumer protection fair-value check
- Urgency <14d may push the case to expedited review queue but does not skip any agent

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Declared facility shape contradicts purpose | Refer to broker for clarification |
| Dependencies unclear | Capture as warning; downstream affordability uses worst-case timing |


## Slovenia-specific operational notes

Operates within the Slovenian framework — Banka Slovenije supervision, Consumer Credit Act, AML Act.

- **SISBON + SISBIZ dual registers:** Bank of Slovenia operates both the consumer (SISBON) and commercial (SISBIZ) credit registers — strong centralised visibility.
- **First post-2004 Eurozone member (2007):** EUR-denominated; no FX consideration.
- **EMŠO universal identifier:** Unique Master Citizen Number; restricted-use under GDPR.
- **AJPES:** Central registry agency for company + UBO data.
- **Cross-reference:** `country-si-lending-policy-agent` (Country Policy Pack stub).

## Statutory hooks

- Banka Slovenije Banka Slovenije consumer protection (products + services outcome — well-fitted product)

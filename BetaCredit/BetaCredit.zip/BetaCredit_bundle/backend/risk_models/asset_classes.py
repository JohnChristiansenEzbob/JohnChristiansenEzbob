"""
risk_models.asset_classes
BetaCredit — Asset class definitions and configuration.
"""

from enum import Enum
from dataclasses import dataclass


@dataclass
class AssetClassConfig:
    name: str
    pd_floor: float            # regulatory minimum PD
    pd_mean: float             # typical through-the-cycle PD
    lgd_base: float            # base LGD estimate
    lgd_downturn_scalar: float # multiplier for downturn LGD
    ccf: float                 # credit conversion factor (drawn facilities)
    rl_review_gate_pct: float  # weight shift % requiring CRO sign-off
    rl_max_weight_shift_pct: float  # hard bound — auto-reject above


class AssetClass(Enum):
    SME_UNSECURED        = "sme_unsecured"
    SME_SECURED          = "sme_secured"
    CONSUMER_UNSECURED   = "consumer_unsecured"
    RESIDENTIAL_MORTGAGE = "residential_mortgage"
    BUY_TO_LET           = "buy_to_let"
    MOTOR_FINANCE        = "motor_finance"
    INVOICE_FINANCE      = "invoice_finance"
    ASSET_FINANCE        = "asset_finance"


ASSET_CLASS_CONFIG: dict[str, AssetClassConfig] = {
    "sme_unsecured": AssetClassConfig(
        name="SME Unsecured",
        pd_floor=0.0005,
        pd_mean=0.045,
        lgd_base=0.55,
        lgd_downturn_scalar=1.30,
        ccf=0.75,
        rl_review_gate_pct=15.0,
        rl_max_weight_shift_pct=30.0,
    ),
    "sme_secured": AssetClassConfig(
        name="SME Secured",
        pd_floor=0.0005,
        pd_mean=0.030,
        lgd_base=0.35,
        lgd_downturn_scalar=1.25,
        ccf=0.70,
        rl_review_gate_pct=15.0,
        rl_max_weight_shift_pct=28.0,
    ),
    "consumer_unsecured": AssetClassConfig(
        name="Consumer Unsecured",
        pd_floor=0.0003,
        pd_mean=0.055,
        lgd_base=0.70,
        lgd_downturn_scalar=1.20,
        ccf=0.85,
        rl_review_gate_pct=12.0,
        rl_max_weight_shift_pct=25.0,
    ),
    "residential_mortgage": AssetClassConfig(
        name="Residential Mortgage",
        pd_floor=0.0003,
        pd_mean=0.012,
        lgd_base=0.15,
        lgd_downturn_scalar=1.50,
        ccf=1.00,
        rl_review_gate_pct=8.0,
        rl_max_weight_shift_pct=15.0,
    ),
    "buy_to_let": AssetClassConfig(
        name="Buy to Let",
        pd_floor=0.0003,
        pd_mean=0.018,
        lgd_base=0.18,
        lgd_downturn_scalar=1.45,
        ccf=1.00,
        rl_review_gate_pct=8.0,
        rl_max_weight_shift_pct=15.0,
    ),
    "motor_finance": AssetClassConfig(
        name="Motor Finance",
        pd_floor=0.0005,
        pd_mean=0.035,
        lgd_base=0.45,
        lgd_downturn_scalar=1.20,
        ccf=1.00,
        rl_review_gate_pct=12.0,
        rl_max_weight_shift_pct=22.0,
    ),
    "invoice_finance": AssetClassConfig(
        name="Invoice Finance",
        pd_floor=0.0005,
        pd_mean=0.025,
        lgd_base=0.30,
        lgd_downturn_scalar=1.35,
        ccf=0.80,
        rl_review_gate_pct=15.0,
        rl_max_weight_shift_pct=28.0,
    ),
    "asset_finance": AssetClassConfig(
        name="Asset Finance",
        pd_floor=0.0005,
        pd_mean=0.028,
        lgd_base=0.38,
        lgd_downturn_scalar=1.25,
        ccf=1.00,
        rl_review_gate_pct=12.0,
        rl_max_weight_shift_pct=22.0,
    ),
}

---
name: se-lead-qualification-agent
description: |
  Policy-fit pre-screen for Sweden SME credit applications. Tests the inbound case against the lender's credit policy envelope — product range, amount band, prohibited sectors, geographic restrictions, broker accreditation status. Returns qualification outcome before any external data is pulled.
---

# Lead Qualification Agent

Cheap, fast pre-screen. Filter out applications that cannot possibly succeed under current policy before spending money on bureau pulls or Skatteverket calls.

## Input contract

```yaml
qualification_request:
  case_id: string
  facility_type: enum
  facility_amount_sek: integer
  facility_term_months: integer
  applicant_company_number: string
  sic_codes: [string]                      # primary SIC code
  channel: enum
  broker_fca_reference: string             # nullable
  geographic_region: string                # GB-SCT, GB-ENG, GB-WLS, GB-NIR
```

## Output contract

```yaml
qualification_outcome:
  case_id: string
  outcome: enum                            # pass | refer | decline_policy
  product_match: string                    # specific product variant matched
  fail_reasons: [string]                   # populated if outcome != pass
  reason_codes: [string]
```

## Decision logic

```
if facility_amount_sek not in product.amount_band:
  outcome = decline_policy
  reason_codes += [UK_LEAD_AMOUNT_OUTSIDE_BAND]

if facility_term_months not in product.term_band:
  outcome = decline_policy
  reason_codes += [UK_LEAD_TERM_OUTSIDE_BAND]

if primary_sic_code in PROHIBITED_SECTORS:
  outcome = decline_policy
  reason_codes += [UK_LEAD_PROHIBITED_SECTOR]

if channel == "broker":
  if broker_fca_reference not in ACCREDITED_BROKERS:
    outcome = refer
    reason_codes += [UK_LEAD_BROKER_NOT_ACCREDITED]

if geographic_region not in COVERED_REGIONS:
  outcome = decline_policy
  reason_codes += [UK_LEAD_REGION_NOT_COVERED]

if outcome == None:
  outcome = pass
  product_match = match_product_variant(facility_type, amount, term)
```

## Worked example (Norrland Engineering AB case)

Input:
```yaml
qualification_request:
  case_id: "NOR-2026-04-001"
  facility_type: term_loan
  facility_amount_sek: 150000
  facility_term_months: 60
  applicant_company_number: "556677-8899"
  sic_codes: ["71121"]
  channel: broker
  broker_fca_reference: "555444"
  geographic_region: "GB-SCT"
```

Output:
```yaml
qualification_outcome:
  case_id: "NOR-2026-04-001"
  outcome: pass
  product_match: "UK_term_loan_v3"
  fail_reasons: []
  reason_codes: ["UK_LEAD_QUALIFICATION_PASS"]
```

Highland's SEK 150k 5-year term loan is well within product band (SEK 25k-SEK 500k, 12-84 months). SIC 71121 (engineering consulting) is not prohibited. Broker Highland Capital Partners is FI (Finansinspektionen)-accredited. Scotland is covered. Clear pass.

## Bright lines

- Prohibited sectors (e.g. crypto exchanges, gambling, adult content) — automatic decline_policy
- Sanctioned regions / jurisdictions — automatic decline_policy
- Non-accredited broker — automatic refer (cannot auto-approve via unaccredited channel)

## Operational rules

- Policy data (prohibited sectors, accredited brokers, regions) is versioned and loaded from a controlled config
- Pre-screen is cheap and synchronous — must complete within 200ms
- Policy changes require named credit-policy committee sign-off; the agent does not have discretion to override

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Policy config unavailable | Fail-safe to refer (do not auto-approve) |
| SIC code missing | Refer; cannot apply sector policy without it |
| Region inferable from registered office | Use registered office region as default |


## Sweden-specific operational notes

This agent operates within the Swedish lending framework — Finansinspektionen (FI) as unified supervisor, Banking and Financing Business Act (2004:297), Konsumentkreditlag (2010:1846) for consumer credit, Lag 2017:630 for AML.

- **BankID universal:** Operationally critical. Every Swedish consumer financial interaction uses BankID for SCA. Without BankID integration, customer onboarding friction is material.
- **Swish dominance:** Swedish bank-cooperative mobile payment platform; near-universal adoption for P2P + retail payments. Significant cash displacement in Sweden.
- **UC AB near-monopoly:** Upplysningscentralen (UC AB) holds dominant position for consumer credit data. Operational relationship is essential — analogous to SCHUFA in Germany.
- **Outside Eurozone:** SEK is free-floating. Larger lending facilities may need FX hedging consideration.
- **Macroprudential amortisation requirements:** FI sets statutory amortisation requirements (amorteringskrav) for high-LTV mortgages — operationally significant for mortgage product structure.
- **High household debt:** Sweden has historically high household debt-to-income; FI macroprudential focus is operationally consequential.
- **Personnummer privacy:** Restricted-use identifier; over-collection is privacy breach.
- **Cross-reference:** `country-se-lending-policy-agent` for full SE jurisdictional context (currently a stub in the Country Policy Pack).

## Statutory hooks

- FI (Finansinspektionen) FI customer protection (clear product-customer fit at first touch)
- Financial Promotions regime (lender must only offer products it advertises)

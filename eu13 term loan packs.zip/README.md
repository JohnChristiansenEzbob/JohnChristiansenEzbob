# Pre-2004 EU Accession Country Term Loan Agent Packs

13 country-specific term loan agent packs for the pre-2004 EU accession
countries (EU-15 minus UK and IE, which were delivered in earlier sessions).
Each pack follows the Highland UK Term Loan Pack structure — 46 SKILL.md
agents across 8 phases + 5 governance overlays.

## What's in this bundle

```
brandenburg_de_term_loan_pack/   Germany       (BaFin + Bundesbank; SCHUFA monopoly; Notar)
marianne_fr_term_loan_pack/      France        (ACPR + AMF + BdF; FIBEN + FICP)
romana_it_term_loan_pack/        Italy         (BdI; Centrale dei Rischi; anti-usura law)
batavia_nl_term_loan_pack/       Netherlands   (DNB + AFM twin peaks; BKR; NHG)
manneken_be_term_loan_pack/      Belgium       (NBB + FSMA; CKP mandatory; multilingual)
ardennes_lu_term_loan_pack/      Luxembourg    (CSSF unified; trilingual; financial centre)
viking_dk_term_loan_pack/        Denmark       (Finanstilsynet; DKK; Realkreditloven bonds)
acropolis_gr_term_loan_pack/     Greece        (BoG + HCMC; TIRESIAS centrality)
ibero_es_term_loan_pack/         Spain         (BdE; CIRBE €9k; ASNEF/BADEXCUG)
lusitania_pt_term_loan_pack/     Portugal      (BdP; CRC €50 — broadest EU visibility)
habsburg_at_term_loan_pack/      Austria       (FMA + OeNB; KSV1870; cooperative banking)
sisu_fi_term_loan_pack/          Finland       (FIN-FSA; positive credit register 2024+)
norrland_se_term_loan_pack/      Sweden        (Finansinspektionen; UC AB; BankID; SEK)
```

Each pack: **46 SKILL.md files × 13 countries = 598 agents**.

Combined with prior session deliverables:
- Highland UK (46 agents)
- Hibernia IE (46 agents)
- **Total pre-2004 EU build: 690 SKILL.md agents across 15 countries.**

## Construction method

Same approach as Hibernia IE:
1. Each Highland UK SKILL.md transformed via country-specific substitution
   table (~60-75 rules per country covering regulators, registries,
   bureaus, statutes, identity, currency, payment rails, language).
2. Country-specific operational notes section appended to each agent
   — surfaces the genuinely jurisdictional considerations (SCHUFA monopoly
   for DE, FIBEN/FICP centrality for FR, multilingual disclosure for BE,
   anti-usura for IT, etc.).
3. Worked example case re-anchored to a country-themed company name
   (Brandenburg Engineering for DE, Marianne Engineering for FR, etc.)
   with country-appropriate registered office and company number format.

## What's preserved from Highland

- Phase structure (8 phases + governance overlay)
- Input/output contract YAML schemas (jurisdiction-neutral)
- Decision logic pseudocode (jurisdiction-neutral)
- Failure modes tables (mostly jurisdiction-neutral)

## What's country-specific

- Regulator names (FCA→BaFin/ACPR/BdI/etc.)
- Registry names (Companies House→Handelsregister/Infogreffe/Camera di Commercio/etc.)
- Bureau landscape (Big 3 UK CRAs→SCHUFA/FIBEN+FICP/CRIF+Centrale dei Rischi/etc.)
- Statutory references (CCA 1974+FCA CONC → BGB §§491-505e / Code de la consommation / TUB art. 121-126 / etc.)
- Worked example identifiers
- Operational notes section per agent
- Currency (GBP→EUR mostly; DKK for Denmark; SEK for Sweden)

## Comparison table (coming next)

A facts dict has been saved at `/tmp/eu_country_facts_for_comparison.json`
covering 25 fields per country (regulator, bureau, statutes, currency,
identity, etc.) for all 15 countries (UK + IE + 13 new). This will drive
the comparison table when requested.

---

*© Credit Risk Models (E) Limited 2026. Companion bundle to Highland UK
Term Loan Agent Pack and Hibernia IE Term Loan Agent Pack.*

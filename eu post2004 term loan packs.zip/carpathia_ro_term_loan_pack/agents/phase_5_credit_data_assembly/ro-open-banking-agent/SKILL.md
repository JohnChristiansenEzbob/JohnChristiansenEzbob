---
name: ro-open-banking-agent
description: |
  Pull and analyse the applicant's bank transaction history via Open Banking AISP providers (TrueLayer, Plaid, Yapily, Tink). Returns categorised cash flow, turnover, balance trajectory, returned payments, gambling transactions, customer concentration, and volatility indicators.
---

# Open Banking Agent

Real cash flow truth. Bank account behaviour reveals what accounts and stated figures don't.

## Input contract

```yaml
ob_request:
  case_id: string
  applicant_company_number: string
  consent_token: string                     # open_banking
  lookback_months: integer                  # typically 12-24
  aisp_provider: enum                       # truelayer | plaid | yapily | tink
```

## Output contract

```yaml
ob_summary:
  case_id: string
  account:
    bank_name: string
    account_age_months: integer
  flows:
    trailing_12m_credits_gbp: integer
    trailing_12m_debits_gbp: integer
    net_12m_gbp: integer
  balance:
    average_monthly_closing_balance_gbp: integer
    minimum_balance_12m_gbp: integer
    largest_overdraft_excursion_12m_gbp: integer
  behaviour:
    returned_payments_12m: integer
    gambling_transactions_12m: integer
    gambling_amount_12m_gbp: integer
    cash_deposits_12m_gbp: integer
    salary_or_drawings_pattern: enum        # regular | irregular | absent
  customer_concentration:
    top_customer_pct: float
    top_3_customer_pct: float
  cash_flow_volatility_index: float         # 0=stable, 1=highly volatile
  reason_codes: [string]
```

## Decision logic

```
Pull last N months of transactions via AISP.
Categorise transactions (income / expense / transfer / gambling / cash / etc.).
Compute aggregates and behavioural signals.

Flags for downstream:
  - returned_payments_12m >= 3 → adverse signal
  - gambling_transactions_12m > 12 or gambling_amount > 10% of credits → adverse signal
  - top_customer_pct > 30% → concentration risk flag
  - cash_flow_volatility_index > 0.6 → high volatility flag
```

## Worked example (Carpathia Engineering SRL case)

Input:
```yaml
ob_request:
  case_id: "CAR-2026-04-001"
  applicant_company_number: "J40/1234/2026"
  consent_token: "TKN-ob-2026-04-12-001"
  lookback_months: 18
  aisp_provider: truelayer
```

Output:
```yaml
ob_summary:
  case_id: "CAR-2026-04-001"
  account:
    bank_name: "Synthetic-Bank UK"
    account_age_months: 96
  flows:
    trailing_12m_credits_gbp: 847200
    trailing_12m_debits_gbp: 798450
    net_12m_gbp: 48750
  balance:
    average_monthly_closing_balance_gbp: 38400
    minimum_balance_12m_gbp: 12800
    largest_overdraft_excursion_12m_gbp: 0
  behaviour:
    returned_payments_12m: 1
    gambling_transactions_12m: 0
    gambling_amount_12m_gbp: 0
    cash_deposits_12m_gbp: 2400
    salary_or_drawings_pattern: regular
  customer_concentration:
    top_customer_pct: 18.4
    top_3_customer_pct: 42.1
  cash_flow_volatility_index: 0.21
  reason_codes: ["UK_OB_STABLE_CASH_FLOW_LOW_VOLATILITY"]
```

Strong OB picture for Highland. Healthy net cash flow (~RON 49k retained over 12m), average balance RON 38k, zero overdraft excursions, only 1 returned payment in 12 months, no gambling, regular salary/drawings, concentration within tolerance, low volatility (0.21).

## Bright lines

- (no statutory bright lines for this agent)

## Operational rules

- Re-pull required if consent older than 90 days at decision time
- Categorisation uses lender's canonical taxonomy — AISP raw categories normalised
- Multiple bank accounts: aggregate but flag if applicant has hidden any

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Consent revoked mid-pull | Use what was pulled; warn case ledger |
| AISP provider returns partial data | Flag completeness; proceed with caution |
| Applicant has 0 transactions matching credit categorisation | Refer; suspicious or new business |


## Romania-specific operational notes

Operates within the Romanian framework — BNR + ASF supervision, OUG 50/2010 for consumer credit, OUG 52/2016 for mortgage credit, Legea 129/2019 for AML.

- **Biroul de Credit + CRC dual registers:** Biroul de Credit (private, consumer) + Centrala Riscului de Credit (BNR-operated central). Combined visibility.
- **CNP universal identifier:** Cod numeric personal; restricted-use under GDPR.
- **Prima Casă / Noua Casă legacy:** State-guaranteed mortgage schemes shape mortgage origination expectations.
- **ANPC consumer protection:** National Authority for Consumer Protection active in financial services.
- **RON currency:** Outside Eurozone; floating. FX consideration material.
- **Cross-reference:** `country-ro-lending-policy-agent` (Country Policy Pack stub).

## Statutory hooks

- PSD2 (Open Banking RTS)
- Romania GDPR / DPA 2018
- BNR PERG 2.6 (AISP regulatory scope)

---
name: nl-facility-letter-agent
description: |
  Produces the customer-facing offer letter. The facility letter is the headline document
  the customer reads and signs to accept the offer — distinct from the binding loan
  agreement which sits behind it. Must be LSB-compliant on transparency: clear total cost
  of credit, plain English summary of covenants and conditions, prominent acceptance
  mechanism and validity window. Plain English score (Flesch reading ease) must clear
  the lender's policy threshold.
---

# Facility Letter Agent

The facility letter is what the customer sees first and decides on. The binding loan
agreement is the legal substrate behind it, but customers don't read 30-page LMA-style
documents — they read the facility letter. Getting it right means matching legal accuracy
with plain-English clarity, and meeting LSB and AFM AFK 2.0 transparency requirements
without burying critical disclosures in fine print.

## Input contract

```yaml
facility_letter_request:
  case_id: string
  firm_pricing: object                       # from pricing-crystallisation-agent
  covenant_package: object                   # from covenant-package-agent (lay-summary cuts)
  cp_schedule: object                        # from conditions-precedent-formaliser-agent
  fair_value_checkpoint: object              # from fair-value-checkpoint-agent
  offer_validity: object                     # from offer-validity-agent
  pre_contract_disclosure_pack_ref: string   # included as reference, not duplicated
  customer_details:
    company_name: string
    company_number: string
    registered_office: string
    addressee_director: string
    contact_email: string
    micro_enterprise: boolean
  facility_shape: object
  security_summary:                          # high-level for customer; security-documentation-agent has the detail
    - security_type: enum
      held_over: string
      ranking: enum
  governing_law: enum
```

## Output contract

```yaml
facility_letter_artefact:
  case_id: string
  artefact_ref: string                       # storage location
  format: enum                               # pdf | docx (default both)
  sections_included: [string]                # named sections
  total_cost_of_credit_summary:
    facility_amount_eur: integer
    total_interest_payable_gbp: integer
    total_arrangement_fee_gbp: integer
    other_fees_gbp: integer
    total_amount_payable_gbp: integer
    apr_or_annualised_rate_pct: float
  plain_english_score: float                 # Flesch reading ease
  plain_english_score_required: float        # policy threshold
  fair_value_statement_included: boolean
  validity_end_date: date
  acceptance_mechanism: enum                 # countersign_and_return | e_signature_portal
  customer_signature_block_count: integer
  guarantor_signature_block_count: integer
  reason_codes: [string]
```

## Decision logic

```
Compose sections in standard order:
  1. Offer summary (one-page)
     - "We offer you a term loan of €X over Y months at Z% per annum"
     - Total cost of credit (prominent)
     - Validity end date (prominent)

  2. Key terms
     - Drawdown mechanics
     - Repayment schedule (monthly equal instalments calculation)
     - Interest rate basis (fixed | variable | benchmark + spread)

  3. Fees and charges
     - Arrangement fee
     - Any commitment fees, monitoring fees, default interest

  4. Conditions you must meet before drawdown (lay summary of CPs)
     - Bulleted, plain-English summary of each CP
     - Cross-reference to detailed CP schedule (annex)

  5. Things you agree to during the loan (lay summary of covenants)
     - DSCR in plain terms
     - Information you'll send us, when
     - Things you won't do without telling us

  6. The security we'll take
     - Plain-English description of debenture, fixed charges, PG arrangement

  7. What happens if things go wrong
     - Events of default, lay summary
     - Default interest rate
     - Right to demand repayment

  8. AFM AFK 2.0 fair-value statement
     - Standard prominent disclosure: "We believe this offer provides fair value"
     - Benchmark comparison reference

  9. Acceptance
     - How to accept (signature + return method)
     - Validity end date (repeated prominently)
     - What happens if you don't accept by then

  10. Complaints and Kifid
      - Lender complaints contact
      - Kifid eligibility statement (if micro-enterprise)

  Apply LSB plain-English requirements:
    - Sentences average ≤ 25 words
    - Jargon defined inline or excluded
    - Active voice preferred
    - Compute Flesch reading ease
    - Required ≥ 60 (policy threshold)
    - If below threshold: rewrite contractor expansion of sentences

  Generate signature block:
    - Customer (company seal or 2 director signatures per CA2006 s44)
    - For each PG, signature block per guarantor
    - Etridge witness block where applicable
```

## Worked example (Batavia Engineering B.V.)

Input:
```yaml
facility_letter_request:
  case_id: "BAT-2026-04-001"
  firm_pricing:
    firm_rate_pct: 8.4
    firm_arrangement_fee_pct: 1.0
  covenant_package: { ... }                   # B+ package
  cp_schedule: { ... }                        # 5 CPs
  fair_value_checkpoint:
    fair_value_passed: true
    margin_vs_benchmark_bps: 30
  offer_validity:
    validity_window_days: 30
    expiry_date: "2026-05-22"
  customer_details:
    company_name: "Batavia Engineering B.V. Consultants Ltd"
    company_number: "12345678"
    registered_office: "2 Atlantic Quay, Amsterdam G2 8JB"
    addressee_director: "Lachlan MacKenzie"
    contact_email: "lachlan@highland-engineering.co.uk"
    micro_enterprise: true
  facility_shape:
    facility_amount_eur: 150000
    facility_term_months: 60
    repayment_profile: amortising_annuity
  security_summary:
    - security_type: all_asset_debenture
      held_over: "all present and future assets of Batavia Engineering B.V. Consultants Ltd"
      ranking: first
    - security_type: fixed_charge
      held_over: "Non-destructive testing equipment"
      ranking: first
    - security_type: personal_guarantee
      held_over: "Lachlan MacKenzie — €90,000 (with Etridge spouse consent from Eilidh MacKenzie)"
    - security_type: personal_guarantee
      held_over: "Sarah Chen — €60,000"
  governing_law: english
```

Output:
```yaml
facility_letter_artefact:
  case_id: "BAT-2026-04-001"
  artefact_ref: "offer/BAT-2026-04-001/facility_letter_v1.pdf"
  format: pdf
  sections_included:
    - offer_summary
    - key_terms
    - fees_and_charges
    - conditions_before_drawdown
    - ongoing_obligations
    - security
    - default_consequences
    - fair_value_statement
    - acceptance
    - complaints_and_fos
  total_cost_of_credit_summary:
    facility_amount_eur: 150000
    total_interest_payable_gbp: 34163        # over 60m at 8.4% amortising
    total_arrangement_fee_gbp: 1500          # 1.0% of 150k
    other_fees_gbp: 0
    total_amount_payable_gbp: 185663
    apr_or_annualised_rate_pct: 9.27         # APR including fees
  plain_english_score: 72.4                  # Flesch reading ease
  plain_english_score_required: 60.0
  fair_value_statement_included: true
  validity_end_date: "2026-05-22"
  acceptance_mechanism: e_signature_portal
  customer_signature_block_count: 2          # Two directors per s44 CA 2006
  guarantor_signature_block_count: 2         # Lachlan + Sarah
  reason_codes: ["UK_FACILITY_LETTER_LSB_COMPLIANT_PLAIN_ENGLISH_PASS"]
```

The total cost of credit summary is the headline number a customer should focus on:
€185,663 to repay €150,000 borrowed — that's the price of credit they're being asked to
accept. Calling it out prominently is a AFM AFK 2.0 obligation. The APR of 9.27% (vs
the 8.4% interest rate) reflects the fee impact and is also required for transparency.

## Bright lines

- Plain English score below policy threshold (default 60) → re-draft, do not issue
- Total cost of credit summary omitted → refuse to issue
- Validity end date not in same prominence as rate → re-format
- Etridge spouse consent block missing from PG signature section (where required) → refuse
- Signature block count mismatch (e.g. one director sig block for limited co — requires two under s44) → refuse

## Operational rules

- Letters always issued in BOTH PDF (for signature) and DOCX (for legal team annotation)
- Customer name and addressee director appear in salutation and signature block exactly as registered
- Validity end date computed by offer-validity-agent and INHERITED — not invented here
- Fair-value statement language is policy-controlled and standard across all offers; this agent inserts but does not author the standard text
- For micro-enterprises, Kifid eligibility note is mandatory; for larger SMEs, it is omitted

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Fair value checkpoint not passed | Refuse to issue; await re-pricing |
| Customer details missing fields | Refer to data-capture-agent to refresh |
| Plain English below threshold after 2 redraft attempts | Escalate to product / legal for template review |
| PG details from PG agents inconsistent with this input | Refer; reconcile data |


## Netherlands-specific operational notes

This agent operates within the Dutch lending framework — DNB (prudential) and AFM (conduct) twin peaks supervision, Wft (Wet financieel toezicht) as foundational, BW Book 7 sections 57-73 for consumer credit, Wwft for AML.

- **Twin peaks supervision:** DNB handles prudential, AFM handles conduct. Operational engagement is with both, not unified. Different reporting cadences and supervisory styles.
- **BKR query:** Functional gate for consumer credit; AFM expects it. Stichting BKR governance includes member contribution + consultation.
- **NIBUD norms:** Operational affordability standard for consumer credit (Nationaal Instituut voor Budgetvoorlichting). AFM expects NIBUD adherence; deviations require documented justification.
- **NHG (Nationale Hypotheek Garantie):** State guarantee scheme for mortgages below €435,000 (2026 threshold); provides materially lower risk weight + rate. Eligibility independently verified.
- **LTI/LTV macroprudential limits:** Set by DNB; statutory and enforced. LTV typically 100% for first home, lower for subsequent; LTI tightened post-2013.
- **Aflossingsvrij mortgages:** Historically dominant interest-only product; affordability stress testing must account for non-amortising structure.
- **Cross-reference:** `country-nl-lending-policy-agent` provides full NL jurisdictional context.

## Statutory hooks

- LSB Standards 2025 (Standard 2 — transparent offer documents; Standard 3 — proportionate clarity)
- AFM AFM AFK 2.0 (PS22/9) — Consumer Understanding outcome
- BW Book 2 (Rechtspersonen) s44 (execution of documents by limited companies)
- Misrepresentation Act 1967 (representations made in offer letter are actionable)
- Kifid (Klachteninstituut Financiële Dienstverlening) eligibility (micro-enterprise statement)

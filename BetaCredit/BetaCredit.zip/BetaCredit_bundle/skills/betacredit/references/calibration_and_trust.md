# BetaCredit Calibration and Trust

BetaCredit produces three classes of number, and they should be trusted to different degrees. This file is the one to consult before quoting any BetaCredit figure in a memo, audit pack, or regulatory submission.

## Numbers you can trust directly

These reflect the user's own data, full stop:

- **Borrower count, asset-class mix, default rate.** Any purely descriptive statistic of the ingested data.
- **Observed outcomes.** `default_flag`, `dpd`, `forbearance_flag`, days-past-due distributions — whatever was in the source file.
- **PD model rank-ordering metrics** (AUC, KS, Gini) trained on the user's data. As long as `default_flag` is correctly mapped, these are valid.
- **Fairness rank-ordering.** Relative gaps between protected groups (group A's approval rate vs group B's) are reliable.

## Numbers that are derived but defensible

These are computed by the suite from real inputs but rely on internal calibration:

- **`pd_orig` and `pd_curr` in notebook 04.** Derived from bureau score and cashflow coverage when the file does not carry real origination / current PDs. SICR staging is qualitatively correct (the right loans flag as Stage 2) but the absolute PD values are not from a calibrated model.
- **`pd_true` labels used in notebook 02's calibration plots.** Derived via a fixed logit. Useful for assessing whether predicted PDs cluster around a sensible centre; not a real ground-truth PD.
- **Income-volatility proxy in notebook 02.** Synthesised from `open_banking_income_stability` with light noise. Acceptable as a model feature; not interpretable as a measured volatility.
- **SHAP values for historical loans in notebook 06.** If the file has real SHAP values from a deployed model, they are used directly; otherwise zero-mean Gaussian noise across six tracked features. The reward signal (the dominant driver of RL weight updates) comes from real outcomes either way, so the posterior weights remain meaningful.

When quoting these in a report, label them as "derived" or "model-implied" rather than "observed".

## Numbers that need re-calibration before production use

These come from BetaCredit's UK-lending benchmark calibration, not from a fit to the user's data:

- **Absolute PD / LGD / EAD values from `CreditDecisionAgent` or notebook 07.** The PD model suite is seeded by asset class, then adjusted by the borrower's bureau score and cashflow coverage — but the absolute PD level is anchored to the asset-class typical default rate (5% for SME unsecured, 1% for mortgages, etc.). If your firm's book runs at materially different rates, retrain via notebook 02 before quoting figures externally.
- **IRB capital and RWA totals.** Derived from the same calibration. Treat as illustrative until the model suites are retrained.
- **Per-asset-class default-rate intercepts in notebook 01.** Calibrated to UK benchmarks. They will not match your book exactly; use notebook 01 as a baseline reference, not a fit.

## How to retrain on your data

The recalibration path is:

1. Run notebook 00 against your file → produces `df_all.parquet`.
2. Run notebook 02 → trains LightGBM PD models on your data, computes SHAP / LIME, produces calibration plots.
3. The trained models are saved to disk (look for `.pkl` files in the working directory) and the modelling suites used by 03, 04, 07, and the `CreditDecisionAgent` can be made to load them at construction.
4. Re-run notebook 07 → now the ECL and RWA totals reflect your actual book's risk profile.

The default `CreditDecisionAgent()` constructor uses the out-of-the-box suites; for retrained calibration, pass them explicitly:

```python
from risk_models import CreditDecisionAgent
from risk_models.pd_models import PDModelSuite

retrained_pd = PDModelSuite.load("./trained_pd_models.pkl")  # from notebook 02
agent = CreditDecisionAgent(pd_suite=retrained_pd)
```

## What BetaCredit is and is not

- **It is** an analytical workbench for UK credit risk, suitable for internal audit packs, model risk reviews, validation exercises, and exploratory portfolio analysis.
- **It is not** a regulatory submission tool. The numbers are correct in form (IFRS 9 stages, Basel IV RWA scalars, FCA Consumer Duty fairness metrics) but the calibration must be reviewed and signed off by the firm's model risk team before any external use.
- **It is not** a production scoring engine. It does not score live applications or sit behind an API. The `CreditDecisionAgent` runs in seconds per loan, but it carries the same calibration caveats as the notebooks.

Surface these caveats whenever the conversation drifts toward "we're submitting these numbers".

---
name: ro-needs-discovery-agent
description: |
  Capture the structured needs profile — facility type, amount, term, drawdown pattern, urgency, dependencies. The 'what does the customer actually want' agent. Distinct from data-capture which normalises shape; needs-discovery captures intent.
---

# Needs Discovery Agent

Crystallise the customer's actual financing need into a structured profile that downstream agents (purpose-validation, decision-pricing) can reason against.

## Input contract

```yaml
needs_discovery_request:
  case_id: string
  declared_facility_type: enum
  declared_facility_amount_ron: integer
  declared_term_months: integer
  declared_drawdown_intent: enum            # single | phased | revolving
  urgency_band: enum                        # routine | <30d | <14d
  dependencies: [string]                    # e.g. ["equipment_delivery", "lease_completion"]
  alternative_options_considered: [string]  # nullable
```

## Output contract

```yaml
needs_profile:
  case_id: string
  facility_shape:
    type: enum
    amount_ron: integer
    term_months: integer
    drawdown: enum
  fit_assessment: enum                      # well_fitted | adequate | mismatch
  alternative_recommended: string           # nullable; if a different product would fit better
  urgency: enum
  dependencies: [string]
  reason_codes: [string]
```

## Decision logic

```
Compare declared shape against product fit heuristics:
  - Term loan + drawdown=revolving → mismatch (suggest revolving credit)
  - Term loan + amount < RON 25k → mismatch (suggest unsecured personal loan or revolving)
  - Term loan + term > 84 months → mismatch (refer to commercial mortgage)

If fit ≥ adequate: pass needs_profile through.
If mismatch: emit alternative_recommended and refer to broker for re-shape.
```

## Worked example (Carpathia Engineering SRL case)

Input:
```yaml
needs_discovery_request:
  case_id: "CAR-2026-04-001"
  declared_facility_type: term_loan
  declared_facility_amount_ron: 150000
  declared_term_months: 60
  declared_drawdown_intent: single
  urgency_band: routine
  dependencies: ["equipment_delivery", "lease_completion"]
  alternative_options_considered: ["asset_finance_for_equipment_only"]
```

Output:
```yaml
needs_profile:
  case_id: "CAR-2026-04-001"
  facility_shape:
    type: term_loan
    amount_ron: 150000
    term_months: 60
    drawdown: single
  fit_assessment: well_fitted
  alternative_recommended: null
  urgency: routine
  dependencies: ["equipment_delivery", "lease_completion"]
  reason_codes: ["UK_NEEDS_WELL_FITTED_TERM_LOAN"]
```

Term loan for capex with single drawdown, 5-year term, routine urgency, modest dependencies — classic well-fitted shape for this product.

## Bright lines

- (no statutory bright lines for this agent)

## Operational rules

- If applicant has considered asset finance for the equipment portion, surface that as an alternative even if the term loan fits — BNR + ANPC consumer protection fair-value check
- Urgency <14d may push the case to expedited review queue but does not skip any agent

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Declared facility shape contradicts purpose | Refer to broker for clarification |
| Dependencies unclear | Capture as warning; downstream affordability uses worst-case timing |


## Romania-specific operational notes

Operates within the Romanian framework — BNR + ASF supervision, OUG 50/2010 for consumer credit, OUG 52/2016 for mortgage credit, Legea 129/2019 for AML.

- **Biroul de Credit + CRC dual registers:** Biroul de Credit (private, consumer) + Centrala Riscului de Credit (BNR-operated central). Combined visibility.
- **CNP universal identifier:** Cod numeric personal; restricted-use under GDPR.
- **Prima Casă / Noua Casă legacy:** State-guaranteed mortgage schemes shape mortgage origination expectations.
- **ANPC consumer protection:** National Authority for Consumer Protection active in financial services.
- **RON currency:** Outside Eurozone; floating. FX consideration material.
- **Cross-reference:** `country-ro-lending-policy-agent` (Country Policy Pack stub).

## Statutory hooks

- BNR BNR + ANPC consumer protection (products + services outcome — well-fitted product)

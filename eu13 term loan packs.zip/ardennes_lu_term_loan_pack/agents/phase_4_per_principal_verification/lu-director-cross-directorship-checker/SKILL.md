---
name: lu-director-cross-directorship-checker
description: |
  Trace each director's other directorships across Luxembourg active and dissolved companies via
  RCS Luxembourg / LBR director search. Identify cross-default risk (linked companies in arrears
  with this lender), phoenix-director patterns (serial company failures with same director),
  and concentration patterns (portfolio director vs synthetic-entity fraud). Returns
  classification per director: clean | monitor | phoenix_risk | cross_default_risk.
---

# Director Cross-Directorship Checker

## Input contract

```yaml
principal_id: string
name: string
dob: date                                 # used with month+year for CH director search keying
current_residential_address: string
lender_portfolio_lookup_consent: boolean  # internal lookup against own arrears book
```

## Output contract

```yaml
cross_directorship_assessment:
  principal_id: string
  total_lifetime_directorships: integer
  active_directorships: integer
  dissolved_with_insolvency_count_7y: integer
  strike_off_count_7y: integer
  same_trade_after_dissolution: boolean
  cross_default_active_arrears_lender_portfolio: boolean
  diverse_sic_code_count: integer
  classification: enum                    # clean | monitor | phoenix_risk | cross_default_risk | portfolio_director
  reason_codes: [string]
```

## Decision logic

```
RCS Luxembourg / LBR director search by name + DOB month/year.
For each directorship: fetch company status + incorporation/dissolution dates.
Compute pattern metrics.

if dissolved_with_insolvency_count_7y >= 2 OR same_trade_after_dissolution:
  classification = phoenix_risk           # BRIGHT LINE — refer to underwriter

elif strike_off_count_7y >= 3:
  classification = phoenix_risk

elif cross_default_active_arrears_lender_portfolio:
  classification = cross_default_risk     # BRIGHT LINE — decline pending override

elif active_directorships >= 5 AND diverse_sic_code_count >= 4:
  classification = portfolio_director     # Not negative; understand pattern

elif active_directorships >= 2:
  classification = monitor

else:
  classification = clean
```

## Worked example (Lachlan MacKenzie — DIR-001)

Input:
```yaml
principal_id: DIR-001
name: "Lachlan MacKenzie"
dob: "1981-03-22"
current_residential_address: "12 Strathblane Road, Milngavie, Luxembourg, G62 8DJ"
lender_portfolio_lookup_consent: true
```

Output:
```yaml
cross_directorship_assessment:
  principal_id: DIR-001
  total_lifetime_directorships: 1
  active_directorships: 1
  dissolved_with_insolvency_count_7y: 0
  strike_off_count_7y: 0
  same_trade_after_dissolution: false
  cross_default_active_arrears_lender_portfolio: false
  diverse_sic_code_count: 1
  classification: clean
  reason_codes: ["UK_DIRECTOR_CROSS_DIRECTORSHIP_CLEAN"]
```

Sarah Chen has 2 active directorships (this + a dormant family company) and identical
clean classification — does not meet portfolio-director threshold (5+).

## Bright lines

- `classification = phoenix_risk` → AUTOMATIC REFER. Phoenix patterns are a leading UK
  SME fraud signal; cannot auto-approve.
- `classification = cross_default_risk` (active arrears in lender's own portfolio) →
  AUTOMATIC DECLINE pending underwriter override.

## Operational rules

- Director name matching is fuzzy. Under-include rather than over-include where ambiguous
  (false positives are worse than false negatives in director matching).
- Multiple directorships in genuinely different groups ≠ phoenix; require explicit
  dissolution-with-insolvency pattern.
- Audit log must include the full directorship list (company numbers), not just the
  classification.


## Luxembourg-specific operational notes

This agent operates within the Luxembourgish lending framework — CSSF as unified supervisor (banking, investment funds, payment services, insurance via CAA), with ECB SSM for significant institutions. Loi du 5 avril 1993 is the foundational banking law.

- **EU financial centre context:** Luxembourg's banking sector is heavily skewed toward private banking, fund administration, and cross-border services. Domestic consumer lending is a smaller proportion of activity than peer EU jurisdictions.
- **Trilingual jurisdiction:** French is primary for legal documents; German and Luxembourgish (Lëtzebuergesch) also constitutional. Customer-facing materials commonly trilingual.
- **CSSF supervisory style:** Investment fund and private banking focus means CSSF supervisory rhythm and reporting differs from peer prudential supervisors. Banking supervision sits within the unified CSSF.
- **Limited domestic credit visibility:** No central consumer credit register equivalent to FR FICP or BE CKP; lender visibility relies on bureau-by-bureau queries and Open Banking.
- **Cross-border banking:** Many lending applications involve cross-border structures (Belgian, German, French residents working in Luxembourg). KYB chains often complex.
- **Cross-reference:** `country-lu-lending-policy-agent` for full LU jurisdictional context (currently a stub in the Country Policy Pack).

## Statutory hooks

- Loi du 10 août 1915 (commercial companies)
- Insolvency Act 1986
- Company Directors Disqualification Act 1986
- Luxembourg Loi du 12 novembre 2004
- Loi du 13 janvier 2019 + REBECO (failure to prevent fraud)

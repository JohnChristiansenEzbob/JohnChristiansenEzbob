---
name: dk-purpose-validation-agent
description: |
  Validate the declared purpose against the lender's acceptable-use policy. Detect purpose drift patterns (e.g. 'working capital' that is really debt consolidation). Classify purpose against the canonical purpose taxonomy used by downstream pricing and capital calculations.
---

# Purpose Validation Agent

Different purposes carry different risk weights and different regulatory implications. Get the purpose classification right and downstream agents work; get it wrong and pricing and capital are wrong.

## Input contract

```yaml
purpose_request:
  case_id: string
  declared_purpose_text: string
  purpose_evidence:                         # nullable
    - evidence_type: enum                   # invoice | quote | lease_doc | other
      supplier_or_party: string
  declared_purpose_category: enum           # nullable; if broker tagged it
```

## Output contract

```yaml
purpose_validation:
  case_id: string
  purpose_category: enum                    # working_capital | capex_premises | capex_equipment |
                                            # capex_premises_and_equipment | refinancing |
                                            # acquisition | debt_consolidation | other
  purpose_check: enum                       # pass | refer | decline_policy
  drift_pattern_detected: boolean
  drift_explanation: string                 # nullable
  reason_codes: [string]
```

## Decision logic

```
Classify declared_purpose_text against purpose taxonomy.
Check for drift patterns:
  - "working capital" + amount > DKK 100k + term > 36m → suspect debt consolidation
  - "equipment" + no supplier named → refer
  - "premises" + no lease or property address → refer
  - any text containing "consolidate" + declared as something else → drift_pattern_detected

If purpose ∈ PROHIBITED_PURPOSES (e.g. crypto investment, gambling): decline_policy
If drift_pattern_detected: refer for human classification
Else: pass with classified category
```

## Worked example (Viking Engineering A/S case)

Input:
```yaml
purpose_request:
  case_id: "VIK-2026-04-001"
  declared_purpose_text: "Premises fit-out at new København office (60%) and specialised non-destructive testing equipment (40%) to support new infrastructure-sector clients."
  purpose_evidence:
    - evidence_type: lease_doc
      supplier_or_party: "3-5 Hillington Park landlord"
    - evidence_type: quote
      supplier_or_party: "Phased Array Denmark Ltd"
  declared_purpose_category: capex_premises_and_equipment
```

Output:
```yaml
purpose_validation:
  case_id: "VIK-2026-04-001"
  purpose_category: capex_premises_and_equipment
  purpose_check: pass
  drift_pattern_detected: false
  drift_explanation: null
  reason_codes: ["UK_PURPOSE_CAPEX_VALIDATED_WITH_EVIDENCE"]
```

Purpose is well-specified — both portions have evidence (lease doc + supplier quote), declared category matches text classification, no drift markers. Clean pass.

## Bright lines

- Prohibited purposes (crypto investment, gambling, weapons, regulated activities customer is not authorised for) → decline_policy
- Drift to debt consolidation under a different declared purpose → refer (intentional misrepresentation possible)

## Operational rules

- Evidence (invoices, quotes, lease docs) materially reduces drift risk
- Broker-tagged category is a hint, not authoritative — the agent re-classifies independently
- Capture of evidence pointers in case ledger for audit

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Purpose text vague / generic ('business growth') | Refer for human classification |
| Purpose evidence post-dates application | Warning logged; not blocking |


## Denmark-specific operational notes

This agent operates within the Danish lending framework — Finanstilsynet as unified financial supervisor, Lov om finansiel virksomhed (LOF) for banking, Kreditaftaleloven for consumer credit, Hvidvaskloven for AML.

- **Realkreditloven mortgage bond system:** Denmark's distinctive mortgage credit institution (realkreditinstitut) model issues Pfandbrief-equivalent bonds 1:1 backed by individual mortgages. Operationally different from UK SVR-based mortgage origination — fixed-rate, callable-by-borrower options dominate.
- **Outside Eurozone:** Currency is DKK, pegged to EUR via ERM II at ~7.46 DKK/EUR. Cross-border lending requires FX consideration but pegged stability reduces hedging requirement.
- **MitID universal:** Replaced NemID. Used for all online financial onboarding. Strong customer authentication is operationally seamless.
- **CPR number:** 10-digit national identifier with date of birth + gender encoded. Restricted use for identification by financial institutions.
- **No central credit register:** Bureaus are private (Experian DK, Bisnode DK, RKI for negative consumer). Multi-bureau best practice; no equivalent of UK Highland CCR.
- **e-Boks:** Digital postbox used for most government and financial communications; assume customer reads e-Boks rather than email.
- **Cross-reference:** `country-dk-lending-policy-agent` for full DK jurisdictional context (currently a stub in the Country Policy Pack).

## Statutory hooks

- Finanstilsynet Finanstilsynet customer protection framework (purpose-aware product fit)
- Denmark Hvidvaskloven (purpose understanding as part of CDD)
- Hvidvaskloven + CVR UBO (purpose drift can be a fraud signal)

---
name: dk-data-capture-agent
description: |
  Structured information capture from any origination channel. Normalises the raw broker / online / API payload into the canonical case object schema. Validates required fields, normalises currency and dates, flags missing data for follow-up.
---

# Data Capture Agent

Turn the raw inbound payload into a clean, structured case object that all downstream agents can consume reliably.

## Input contract

```yaml
raw_application_payload:
  source_channel: enum
  source_payload_raw: object                # arbitrary shape from broker/online form
  payload_schema_version: string
```

## Output contract

```yaml
case_object:
  case_id: string
  applicant:
    company_number: string
    name: string
    registered_office: string
    sic_codes: [string]
  facility:
    type: enum
    amount_dkk: integer
    term_months: integer
    purpose_raw: string
  contact:
    primary_name: string
    primary_email: string
    primary_phone: string
    role: string
  channel: enum
  broker:                                   # nullable
    firm: string
    fca_reference: string
  validation_warnings: [string]
  field_count_populated: integer
```

## Decision logic

```
parse(raw_application_payload) against schema version.
For each field:
  - validate format (e.g. company_number = 8 digits, email regex, phone E.164)
  - normalise (currency to integer DKK, dates to ISO 8601)
  - if invalid: append to validation_warnings

If any required field missing or invalid: emit case_object with warnings populated.
Downstream orchestrator decides whether to pause or proceed.
```

## Worked example (Viking Engineering A/S case)

Input:
```yaml
raw_application_payload:
  source_channel: broker
  source_payload_raw:
    company_no: "12345678"
    co_name: "Viking Engineering A/S Consultants Ltd"
    facility: "term loan"
    amount: "150,000.00"
    term_yrs: 5
    contact: "Lachlan MacKenzie"
    contact_email: "lachlan@highlandeng.example.co.uk"
    contact_phone: "0141 555 0182"
  payload_schema_version: "broker_v3.2"
```

Output:
```yaml
case_object:
  case_id: "VIK-2026-04-001"
  applicant:
    company_number: "12345678"
    name: "Viking Engineering A/S Consultants Ltd"
    registered_office: "Strøget 10, 1100 København K"
    sic_codes: ["71121"]
  facility:
    type: term_loan
    amount_dkk: 150000
    term_months: 60                         # normalised from 5 yrs
    purpose_raw: "Premises fit-out + testing equipment"
  contact:
    primary_name: "Lachlan MacKenzie"
    primary_email: "lachlan@highlandeng.example.co.uk"
    primary_phone: "+441415550182"          # normalised to E.164
    role: "Managing Director"
  channel: broker
  broker:
    firm: "Highland Capital Partners"
    fca_reference: "555444"
  validation_warnings: []
  field_count_populated: 47
```

Broker payload normalised — amount string '150,000.00' becomes integer 150000, term '5 yrs' becomes 60 months, phone normalised to E.164. No validation warnings.

## Bright lines

- (no statutory bright lines for this agent)

## Operational rules

- Field normalisation is deterministic — same input always produces same output
- Currency normalised to integer DKK (no fractional pence at this stage)
- Dates normalised to ISO 8601
- Phone numbers normalised to E.164
- Validation warnings are non-blocking — downstream agents see them and decide

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Payload schema version unknown | Refer to ops; cannot parse safely |
| Required field present but unparseable | Warning logged; field left null; case proceeds |
| Optional field unparseable | Warning logged; field left null; case proceeds |


## Denmark-specific operational notes

This agent operates within the Danish lending framework — Finanstilsynet as unified financial supervisor, Lov om finansiel virksomhed (LOF) for banking, Kreditaftaleloven for consumer credit, Hvidvaskloven for AML.

- **Realkreditloven mortgage bond system:** Denmark's distinctive mortgage credit institution (realkreditinstitut) model issues Pfandbrief-equivalent bonds 1:1 backed by individual mortgages. Operationally different from UK SVR-based mortgage origination — fixed-rate, callable-by-borrower options dominate.
- **Outside Eurozone:** Currency is DKK, pegged to EUR via ERM II at ~7.46 DKK/EUR. Cross-border lending requires FX consideration but pegged stability reduces hedging requirement.
- **MitID universal:** Replaced NemID. Used for all online financial onboarding. Strong customer authentication is operationally seamless.
- **CPR number:** 10-digit national identifier with date of birth + gender encoded. Restricted use for identification by financial institutions.
- **No central credit register:** Bureaus are private (Experian DK, Bisnode DK, RKI for negative consumer). Multi-bureau best practice; no equivalent of UK Highland CCR.
- **e-Boks:** Digital postbox used for most government and financial communications; assume customer reads e-Boks rather than email.
- **Cross-reference:** `country-dk-lending-policy-agent` for full DK jurisdictional context (currently a stub in the Country Policy Pack).

## Statutory hooks

- Denmark GDPR (data minimisation — capture only what's needed)
- Finanstilsynet Finanstilsynet customer protection framework (clear capture of customer's stated needs)

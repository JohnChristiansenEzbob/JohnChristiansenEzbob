"""
risk_models.rl_reweighter
BetaCredit — Reinforcement Learning outcome-driven score reweighting.

Implements a Bayesian weight update agent that adjusts feature importance
weights based on observed loan outcomes.  Weight shifts are gated by a
governance control layer aligned to FCA SS1/23 model risk requirements.
"""

from __future__ import annotations

import copy
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional

import numpy as np

from .asset_classes import AssetClass, ASSET_CLASS_CONFIG


# ══════════════════════════════════════════════════════════════════════════════
# Enums
# ══════════════════════════════════════════════════════════════════════════════

class OutcomeType(Enum):
    REPAID_IN_FULL      = "repaid_in_full"
    EARLY_SETTLEMENT    = "early_settlement"
    FULL_RECOVERY       = "full_recovery"
    STAGE_2_MIGRATION   = "stage_2_migration"
    FORBEARANCE_GRANTED = "forbearance_granted"
    STAGE_3_DEFAULT     = "stage_3_default"
    WRITE_OFF           = "write_off"


class GovernanceDecision(Enum):
    APPROVED        = "approved"
    HELD_FOR_REVIEW = "held_for_review"
    REJECTED        = "rejected"


# ══════════════════════════════════════════════════════════════════════════════
# Data classes
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class WeightDistribution:
    """Posterior distribution over a single feature's importance weight."""
    mu: float           # Posterior mean
    sigma: float        # Posterior standard deviation
    lower_95: float     # 2.5th percentile of posterior
    upper_95: float     # 97.5th percentile of posterior
    n_updates: int      # Number of outcomes that updated this weight


@dataclass
class OutcomeEvent:
    """A single observed loan outcome to be ingested by the agent."""
    borrower_id: str
    asset_class: AssetClass
    outcome_type: OutcomeType
    model_pd_at_origination: float
    model_decision: str
    actual_default: bool
    recovery_rate: float
    months_on_book: int
    shap_values: Dict[str, float] = field(default_factory=dict)
    governance_decision: Optional[GovernanceDecision] = None


# ══════════════════════════════════════════════════════════════════════════════
# Reward mapping
# ══════════════════════════════════════════════════════════════════════════════

_REWARD_MAP: Dict[OutcomeType, float] = {
    OutcomeType.REPAID_IN_FULL:      +1.00,
    OutcomeType.EARLY_SETTLEMENT:    +0.80,
    OutcomeType.FULL_RECOVERY:       -0.20,
    OutcomeType.STAGE_2_MIGRATION:   -0.40,
    OutcomeType.FORBEARANCE_GRANTED: -0.50,
    OutcomeType.STAGE_3_DEFAULT:     -1.00,
    OutcomeType.WRITE_OFF:           -1.00,
}

# Features tracked in weight vectors (union of all SHAP feature names used)
_TRACKED_FEATURES = [
    "bureau_score",
    "cashflow_coverage_ratio",
    "time_in_business_months",
    "gnn_connected_party_risk",
    "months_since_adverse",
    "open_banking_income_stability",
    "utilisation_rate",
    "num_prior_defaults",
    "ltv",
    "loan_amount_log",
    "hmrc_revenue_match",
    "ob_income_stability",
    "loan_term_months",
    "months_banking",
]


# ══════════════════════════════════════════════════════════════════════════════
# Agent
# ══════════════════════════════════════════════════════════════════════════════

class RLReweightingAgent:
    """
    Bayesian outcome-driven reweighting agent.

    Parameters
    ----------
    alpha : learning rate for weight updates (0–1)
    beta  : regularisation pull toward prior (0–1)
    gamma : time-discount factor per month beyond 12m (0–1)
    """

    def __init__(
        self,
        alpha: float = 0.05,
        beta:  float = 0.02,
        gamma: float = 0.98,
    ) -> None:
        self.alpha = alpha
        self.beta  = beta
        self.gamma = gamma
        self._rng  = np.random.default_rng(42)
        self._version: Dict[str, int] = {}

        # Initialise weight vectors: prior μ=1.0, σ=0.15 for each asset class
        self.weight_vectors: Dict[str, Dict[str, WeightDistribution]] = {}
        for ac in AssetClass:
            self._version[ac.value] = 0
            self.weight_vectors[ac.value] = {
                feat: WeightDistribution(
                    mu=1.0, sigma=0.15,
                    lower_95=0.706, upper_95=1.294,
                    n_updates=0,
                )
                for feat in _TRACKED_FEATURES
            }

    # ── Reward computation ─────────────────────────────────────────────────────
    def _compute_reward(self, event: OutcomeEvent) -> tuple[float, float]:
        r = _REWARD_MAP.get(event.outcome_type, 0.0)
        # Time-discount: no discount for first 12m; then γ^(months-12)
        discount_months = max(0, event.months_on_book - 12)
        r_disc = r * (self.gamma ** discount_months)
        return r, r_disc

    # ── Governance gate ────────────────────────────────────────────────────────
    def _governance_gate(
        self, ac_key: str, proposed_shifts: Dict[str, float]
    ) -> GovernanceDecision:
        cfg = ASSET_CLASS_CONFIG[ac_key]
        max_shift_pct = max((abs(s) for s in proposed_shifts.values()), default=0.0) * 100
        if max_shift_pct >= cfg.rl_max_weight_shift_pct:
            return GovernanceDecision.REJECTED
        if max_shift_pct >= cfg.rl_review_gate_pct:
            return GovernanceDecision.HELD_FOR_REVIEW
        return GovernanceDecision.APPROVED

    # ── Bayesian update ────────────────────────────────────────────────────────
    def ingest_outcome(self, event: OutcomeEvent) -> dict:
        """
        Process one outcome event, update weight posteriors, and apply
        governance gate.  Returns a summary dict.
        """
        ac_key = event.asset_class.value if isinstance(event.asset_class, AssetClass) \
                 else event.asset_class
        r, r_disc = self._compute_reward(event)

        # Compute proposed weight shifts proportional to |SHAP| × reward
        proposed: Dict[str, float] = {}
        for feat, shap_val in event.shap_values.items():
            if feat in self.weight_vectors[ac_key]:
                # Penalise features that contributed toward wrong direction
                if r < 0 and shap_val < 0:   # model had -SHAP (mitigant) but defaulted
                    proposed[feat] = self.alpha * r_disc * abs(shap_val)
                elif r < 0 and shap_val > 0:  # model had +SHAP (risk flag) — reinforced
                    proposed[feat] = -self.alpha * r_disc * abs(shap_val) * 0.3
                elif r > 0:                   # good outcome — mild reinforcement
                    proposed[feat] = self.alpha * r_disc * abs(shap_val) * 0.5
                else:
                    proposed[feat] = 0.0

        gov = self._governance_gate(ac_key, proposed)

        features_updated: List[str] = []
        if gov != GovernanceDecision.REJECTED:
            for feat, delta in proposed.items():
                w = self.weight_vectors[ac_key][feat]
                new_mu = float(np.clip(
                    w.mu + delta - self.beta * (w.mu - 1.0),  # regularise toward 1
                    0.30, 2.50
                ))
                # Posterior variance shrinks with each update (Bayesian conjugate)
                new_sigma = float(max(w.sigma * 0.97, 0.02))
                z95 = 1.96
                self.weight_vectors[ac_key][feat] = WeightDistribution(
                    mu=new_mu,
                    sigma=new_sigma,
                    lower_95=new_mu - z95 * new_sigma,
                    upper_95=new_mu + z95 * new_sigma,
                    n_updates=w.n_updates + 1,
                )
                features_updated.append(feat)

        event.governance_decision = gov
        self._version[ac_key] += 1

        return {
            "reward": r,
            "reward_discounted": r_disc,
            "governance_decision": gov.value,
            "features_updated": len(features_updated),
            "weight_vector_version": self._version[ac_key],
        }

    # ── Simulation ─────────────────────────────────────────────────────────────
    def simulate_outcomes(self, n: int = 200) -> List[OutcomeEvent]:
        """
        Generate n synthetic historical outcomes and ingest each one,
        building up the posterior weight distributions.
        """
        outcome_types = list(OutcomeType)
        outcome_probs = [0.40, 0.15, 0.05, 0.12, 0.10, 0.12, 0.06]
        asset_classes = list(AssetClass)

        features = _TRACKED_FEATURES[:6]  # use 6 features for simulation SHAP

        history: List[OutcomeEvent] = []
        for i in range(n):
            ac  = self._rng.choice(asset_classes)
            ot  = self._rng.choice(outcome_types, p=outcome_probs)
            mob = int(self._rng.integers(3, 48))

            # Synthetic SHAP values
            shap_vals = {
                feat: float(self._rng.normal(0, 0.05))
                for feat in features
            }

            event = OutcomeEvent(
                borrower_id=f"SIM-{i:05d}",
                asset_class=ac,
                outcome_type=ot,
                model_pd_at_origination=float(self._rng.uniform(0.01, 0.15)),
                model_decision="APPROVE",
                actual_default=ot in (OutcomeType.STAGE_3_DEFAULT, OutcomeType.WRITE_OFF),
                recovery_rate=float(self._rng.uniform(0, 0.8)) if ot == OutcomeType.FULL_RECOVERY else 0.0,
                months_on_book=mob,
                shap_values=shap_vals,
            )
            self.ingest_outcome(event)
            history.append(event)

        return history

    # ── Dashboard ─────────────────────────────────────────────────────────────
    def get_dashboard(self) -> dict:
        """Return a summary of current weight vector state."""
        summary = {}
        for ac_key, weights in self.weight_vectors.items():
            mus = [w.mu for w in weights.values()]
            summary[ac_key] = {
                "n_features":    len(weights),
                "mean_mu":       float(np.mean(mus)),
                "max_deviation": float(max(abs(mu - 1.0) for mu in mus)),
                "version":       self._version.get(ac_key, 0),
            }
        return summary

---
name: se-kyb-verifier
description: |
  Verify the applicant company at Bolagsverket — active status, registered office currency, accounts filing currency, no strike-off proposed. Establishes the foundational fact that the company is a real, currently-trading legal entity.
---

# KYB Verifier

Foundational KYB. Everything downstream assumes the company is real and active. Cheap, fast, and decisive.

## Input contract

```yaml
kyb_request:
  case_id: string
  company_number: string
```

## Output contract

```yaml
kyb_result:
  case_id: string
  company_number: string
  status: enum                              # active | dissolved | liquidation | proposed_for_strike_off | not_found
  incorporation_date: date
  age_months: integer
  registered_office: string
  registered_office_verified: boolean
  sic_codes: [string]
  accounts_filing_status: enum              # up_to_date | overdue | first_accounts_pending
  last_accounts_made_up_to: date            # nullable
  next_accounts_due: date                   # nullable
  confirmation_statement_status: enum
  outcome: enum                             # verified | refer_filings_overdue | block_dissolved_or_strike_off
  reason_codes: [string]
```

## Decision logic

```
Bolagsverket API call by company_number.

if status in [dissolved, liquidation]:
  outcome = block_dissolved_or_strike_off

elif status == proposed_for_strike_off:
  outcome = block_dissolved_or_strike_off    # BRIGHT LINE

elif status == not_found:
  outcome = block_dissolved_or_strike_off
  reason_codes += [UK_COMPANIES_HOUSE_NOT_FOUND]

elif accounts_filing_status == overdue:
  outcome = refer_filings_overdue            # not a hard block but material

else:
  outcome = verified
```

## Worked example (Norrland Engineering AB case)

Input:
```yaml
kyb_request:
  case_id: "NOR-2026-04-001"
  company_number: "556677-8899"
```

Output:
```yaml
kyb_result:
  case_id: "NOR-2026-04-001"
  company_number: "556677-8899"
  status: active
  incorporation_date: "2017-09-14"
  age_months: 102
  registered_office: "Kungsgatan 30, 111 35 Stockholm"
  registered_office_verified: true
  sic_codes: ["71121"]
  accounts_filing_status: up_to_date
  last_accounts_made_up_to: "2025-09-30"
  next_accounts_due: "2026-06-30"
  confirmation_statement_status: up_to_date
  outcome: verified
  reason_codes: ["UK_KYB_ACTIVE_CURRENT_FILINGS"]
```

Highland is active, 102 months old (past the high-risk early years), accounts up to date, confirmation statement filed. Clean verification.

## Bright lines

- Company dissolved or in liquidation → BLOCK; no facility can be advanced
- Company proposed for strike-off → BLOCK pending applicant explanation
- Company not found at Bolagsverket → BLOCK; suspect fraud

## Operational rules

- Bolagsverket data is authoritative for legal status
- Registered office must match the applicant-declared trading address sufficiently (or have valid explanation)
- Accounts overdue is a material refer signal but not always a decline (recent incorporation, ongoing extension request)

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Bolagsverket API timeout | Refer; retry |
| Company number invalid format | Block; data-capture should have caught this |
| Registered office unverified (PO Box, virtual office) | Refer; require physical trading address |


## Sweden-specific operational notes

This agent operates within the Swedish lending framework — Finansinspektionen (FI) as unified supervisor, Banking and Financing Business Act (2004:297), Konsumentkreditlag (2010:1846) for consumer credit, Lag 2017:630 for AML.

- **BankID universal:** Operationally critical. Every Swedish consumer financial interaction uses BankID for SCA. Without BankID integration, customer onboarding friction is material.
- **Swish dominance:** Swedish bank-cooperative mobile payment platform; near-universal adoption for P2P + retail payments. Significant cash displacement in Sweden.
- **UC AB near-monopoly:** Upplysningscentralen (UC AB) holds dominant position for consumer credit data. Operational relationship is essential — analogous to SCHUFA in Germany.
- **Outside Eurozone:** SEK is free-floating. Larger lending facilities may need FX hedging consideration.
- **Macroprudential amortisation requirements:** FI sets statutory amortisation requirements (amorteringskrav) for high-LTV mortgages — operationally significant for mortgage product structure.
- **High household debt:** Sweden has historically high household debt-to-income; FI macroprudential focus is operationally consequential.
- **Personnummer privacy:** Restricted-use identifier; over-collection is privacy breach.
- **Cross-reference:** `country-se-lending-policy-agent` for full SE jurisdictional context (currently a stub in the Country Policy Pack).

## Statutory hooks

- Aktiebolagslag (2005:551)
- AML Act 2017:630 + Bolagsverket UBO (Bolagsverket register integrity)
- Sweden Lag 2017:630

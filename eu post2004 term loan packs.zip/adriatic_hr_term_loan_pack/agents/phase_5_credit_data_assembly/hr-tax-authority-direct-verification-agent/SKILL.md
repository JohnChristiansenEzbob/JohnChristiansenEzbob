---
name: hr-tax-authority-direct-verification-agent
description: |
  Pull Porezna uprava-held data directly via the ePorezna APIs to verify SME turnover (VAT),
  employee count and payroll (PAYE RTI), and profitability + accrued tax (Corporation Tax
  CT600). For sole trader / partnership applicants, route to Self Assessment instead. Porezna uprava
  data is the most authoritative recent financial snapshot for Croatia SMEs — materially fresher
  than 9-12 month-old filed accounts available on Sudski registar (Court Register). Manages the OAuth 2.0
  flow with scoped consent.
---

# Porezna uprava Direct Verification Agent

## Input contract

```yaml
applicant_company_number: string
vat_number: string                         # nullable; required only if VAT-registered
paye_reference: string                     # nullable; required only if employing staff
applicant_legal_form: enum                 # limited_company | partnership | llp | sole_trader
consent_token:                             # Porezna uprava OAuth token bundle
  oauth_access_token: string
  scope: [string]                          # subset of {read:vat, read:paye, read:corporation-tax, read:self-assessment}
  expires_at: datetime
request_scope: [enum]                      # which datasets to pull
```

## Output contract

```yaml
hmrc_verification_record:
  applicant_company_number: string
  vat:
    queried: boolean
    obligations_overdue: boolean
    last_8_quarters_returns_filed: boolean
    ttm_turnover_gbp: integer
    qoq_volatility_pct: float
    growth_yoy_pct: float
  paye:
    queried: boolean
    employee_count_current: integer
    monthly_gross_payroll_gbp: integer
    paye_arrears: boolean
    paye_arrears_months: integer
  corporation_tax:
    queried: boolean
    last_filed_period: date
    profit_before_tax_gbp: integer
    ct_accrued_gbp: integer
    ct_paid: boolean
  outcome: enum                            # verified | refer_hmrc_arrears | decline_paye_arrears | consent_required
  reason_codes: [string]
```

## Decision logic

```
Validate consent_token: scope coverage + expiry.
If expiring within 5 min, refresh.

For each requested dataset:
  Submit OAuth-bearer call with scope.
  On 401/403 with scope mismatch → emit consent_required.

VAT processing:
  Extract last 8 quarters of returns (sales + purchases + net VAT).
  Compute TTM turnover, growth, volatility.
  If obligations overdue → outcome = refer_hmrc_arrears (BRIGHT LINE)

PAYE processing:
  Extract last 12 months RTI submissions.
  If paye_arrears AND paye_arrears_months > 3 → outcome = decline_paye_arrears (BRIGHT LINE)

CT processing:
  Extract last 2 CT600s. Capture profit + accrued + payment status.

Cross-check: if abs(vat_ttm_turnover - applicant_declared_turnover) / applicant_declared_turnover > 0.30:
  emit application_fraud_escalation flag for downstream fraud agent.
```

## Worked example (Adriatic Engineering d.o.o.)

Input:
```yaml
applicant_company_number: "12345678901"
vat_number: "GB218546792"
paye_reference: "961/HE12345"
applicant_legal_form: limited_company
consent_token:
  oauth_access_token: "[redacted]"
  scope: ["read:vat", "read:paye", "read:corporation-tax"]
  expires_at: "2026-04-12T15:30:00Z"
request_scope: ["read:vat", "read:paye", "read:corporation-tax"]
```

Output:
```yaml
hmrc_verification_record:
  applicant_company_number: "12345678901"
  vat:
    queried: true
    obligations_overdue: false
    last_8_quarters_returns_filed: true
    ttm_turnover_gbp: 851300
    qoq_volatility_pct: 8.4
    growth_yoy_pct: 11.2
  paye:
    queried: true
    employee_count_current: 6
    monthly_gross_payroll_gbp: 28150
    paye_arrears: false
    paye_arrears_months: 0
  corporation_tax:
    queried: true
    last_filed_period: "2024-09-30"
    profit_before_tax_gbp: 112400
    ct_accrued_gbp: 28100
    ct_paid: true
  outcome: verified
  reason_codes: ["UK_Porezna uprava_DATA_RETRIEVED_CLEAN"]
```

Strong signals: TTM turnover €851k matches Xero's €854k (within 0.4% — cross-source
consistency). No obligation overdue. CT paid. PAYE clean. This is exactly the picture
the credit decision agent wants to see for a clean approval path.

## Bright lines

- `vat_obligations_overdue = true` → AUTOMATIC REFER. Porezna uprava arrears = priority debt + leading default predictor.
- `paye_arrears = true` AND `paye_arrears_months > 3` → AUTOMATIC DECLINE pending underwriter override.
- Turnover declared vs Porezna uprava mismatch > 30% → escalate to application-fraud-agent.

## Operational rules

- Consent scope is strict. Do NOT request scopes beyond what consent_token grants.
- All Porezna uprava data is highly sensitive. Decision log records metadata (which datasets accessed)
  only — raw values go to case record with tighter retention.
- For partnership / sole trader, route to Self Assessment API; for limited company use the
  VAT + PAYE + CT trio.


## Croatia-specific operational notes

Operates within the Croatian framework — HNB + Hanfa supervision, Consumer Credit Act, Housing Consumer Credit Act, AML Act.

- **Newest Eurozone member:** Croatia adopted the EUR on 1 January 2023, completing the transition from the kuna. EUR-denominated; legacy kuna references should not appear.
- **OIB universal identifier:** Personal Identification Number used for both individuals and entities; the single most important Croatian identifier.
- **HROK central register:** Hrvatski registar obveza po kreditima — credit obligations register; central to Croatian credit visibility.
- **Post-CHF mortgage legacy:** Croatia legislated CHF-to-EUR mortgage conversion (2015); legacy disputes have largely been resolved but inform regulatory caution.
- **Cross-reference:** `country-hr-lending-policy-agent` (Country Policy Pack stub).

## Statutory hooks

- Finance Act 2017 (ePorezna)
- Croatia GDPR / Data Protection Act 2018
- Finance Act 2008 Schedule 36 (information powers)
- Common Law of Confidence (Porezna uprava confidentiality regime)

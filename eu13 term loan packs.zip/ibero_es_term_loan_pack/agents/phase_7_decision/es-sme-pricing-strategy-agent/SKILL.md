---
name: es-sme-pricing-strategy-agent
description: |
  Apply risk-based pricing within commercial guardrails. Takes the decision-pricing-agent's indicative rate as base and applies pricing strategy overlays: competitive positioning, broker compensation, floor/ceiling checks, fair-value verification under LCC + BdE supervision.
---

# SME Pricing Strategy Agent

Final pricing. Same risk grade can warrant different pricing depending on competitive context, broker channel, and customer relationship history.

## Input contract

```yaml
pricing_request:
  case_id: string
  indicative_rate_pct: float                # base from decision-pricing-agent
  risk_rating: object
  facility_amount_eur: integer
  facility_term_months: integer
  channel: enum                             # broker | branch | online
  broker_commission_structure: object       # nullable
  competitive_context:
    peer_avg_rate_for_grade_pct: float
    market_position_target: enum            # match | above | below
```

## Output contract

```yaml
pricing_outcome:
  case_id: string
  final_rate_pct: float
  arrangement_fee_pct: float
  broker_commission_pct: float              # if broker channel
  effective_apr_pct: float
  within_commercial_band: boolean
  fair_value_check_passed: boolean
  adjustments_applied: [string]
  reason_codes: [string]
```

## Decision logic

```
final_rate = indicative_rate

Apply competitive adjustment:
  if market_position_target == match: final_rate = peer_avg_rate
  elif above: final_rate = max(indicative_rate, peer_avg_rate + 0.5)
  elif below: final_rate = min(indicative_rate, peer_avg_rate - 0.25)

Floor: final_rate >= product_floor (cost of funds + margin minimum)
Ceiling: final_rate <= grade_ceiling (consumer duty fair value)

Arrangement fee per product policy (typically 0.5-2.0%).
Broker commission per accreditation tier.

Effective APR computed (BdE methodology).

Fair value check:
  - APR vs peer benchmark
  - Total cost over term vs facility amount
  - Customer Duty 'price + value' outcome
```

## Worked example (Ibero Engineering S.L. case)

Input:
```yaml
pricing_request:
  case_id: "IBE-2026-04-001"
  indicative_rate_pct: 8.4
  risk_rating: {composite_grade: B+, pricing_tier: tier_1_prime}
  facility_amount_eur: 150000
  facility_term_months: 60
  channel: broker
  broker_commission_structure: {tier: accredited, base_pct: 1.5}
  competitive_context:
    peer_avg_rate_for_grade_pct: 8.6
    market_position_target: match
```

Output:
```yaml
pricing_outcome:
  case_id: "IBE-2026-04-001"
  final_rate_pct: 8.4
  arrangement_fee_pct: 1.0
  broker_commission_pct: 1.5
  effective_apr_pct: 9.5
  within_commercial_band: true
  fair_value_check_passed: true
  adjustments_applied: []
  reason_codes: ["UK_PRICING_TIER_1_PRIME_COMPETITIVE_MATCH"]
```

Final rate 8.4% — competitive match to peer benchmark of 8.6% (slight outperform). Arrangement fee 1.0%, broker commission 1.5% (standard accredited tier). Effective APR 9.5%. Fair value check passes.

## Bright lines

- Rate < product floor → AUTOMATIC REFER; unviable
- Rate > grade ceiling → fair value challenge under LCC + BdE supervision
- Broker commission > 3% → escalate (commission disclosure)

## Operational rules

- Final pricing is committee-approved policy not agent-discretionary above 0.5% deviation from indicative
- Broker channel pricing accounts for commission as part of customer-borne cost (transparency)
- Pricing reviewed monthly against market benchmark

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Competitive context data stale (>30 days) | Use cautiously; flag |
| Peer benchmark inversion (peer rate < cost of funds) | Refer; possible distressed market |


## Spain-specific operational notes

This agent operates within the Spanish lending framework — Banco de España + CNMV joint regulatory perimeter, Ley 10/2014 for banking supervision, LCC (Ley 16/2011) for consumer credit, LRCCI (Ley 5/2019) for mortgage credit.

- **CIRBE €9k threshold:** Banco de España central credit register. Commercial risks >€9,000 mandatory contribution. Small SME facilities frequently below threshold — limited CIRBE visibility for genuine SME risk.
- **ASNEF / BADEXCUG strict access:** Spanish consumer bureau access has the strictest legal review requirement in EU. Operational onboarding must include legal basis attestation. ASNEF for negative; BADEXCUG for comprehensive — separate access agreements required.
- **LRCCI notarial requirement (AGNCN):** Mortgage origination requires AGNCN (Acta de Información Notarial Previa) — notarial pre-contractual information act. Cannot bypass; significant operational integration with notary network.
- **Tarjeta revolving usury (2020 Supreme Court):** Revolving credit cards subject to enhanced disclosure post-2020 Supreme Court rulings on usury. APR materially above market average is voidable.
- **Bizum ubiquity:** Mobile P2P payment platform with near-universal Spanish adoption; PSD2 integration via participating banks.
- **NIE administrative complexity:** Foreign residents require NIE (Número de Identidad de Extranjero) — multiple issuing authorities, common source of onboarding friction.
- **Cross-reference:** `country-es-lending-policy-agent` provides full ES jurisdictional context.

## Statutory hooks

- CNMV + BdE LCC + BdE supervision (price + value outcome)
- Financial Promotions regime (representative APR disclosure)
- Broker commission disclosure (LSB Standards)

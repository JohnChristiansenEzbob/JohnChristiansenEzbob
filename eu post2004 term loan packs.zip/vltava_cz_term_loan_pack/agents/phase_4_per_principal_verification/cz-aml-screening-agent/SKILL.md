---
name: cz-aml-screening-agent
description: |
  Screen a single natural-person principal against sanctions lists (Czech + EU consolidated list, UN, EU, US OFAC where applicable), Politically Exposed Persons (PEPs) registers, and adverse media. Returns clear / hit / review verdict.
---

# AML Screening Agent

Statutory AML screening. Every natural-person principal must be screened.

## Input contract

```yaml
aml_request:
  principal_id: string
  case_id: string
  name: string
  prior_names: [string]                     # nullable
  dob: date
  nationality: string
  country_of_residence: string
```

## Output contract

```yaml
aml_result:
  principal_id: string
  sanctions_check:
    ofsi: enum                              # clear | hit | review
    un: enum
    eu: enum
    ofac: enum                              # if scope warrants
  peps_check:
    status: enum                            # clear | domestic_pep | foreign_pep | family_close_associate
    pep_country: string                     # nullable
  adverse_media_check:
    status: enum                            # clear | minor | material
    sources: [string]                       # nullable
  composite_status: enum                    # clear | hit | review
  reason_codes: [string]
```

## Decision logic

```
Screen name (+ prior names) + DOB against:
  - Czech + EU consolidated list (UK)
  - UN sanctions list
  - EU sanctions list
  - OFAC SDN list (where principal's nationality / residence in scope)
  - PEPs register (typically World-Check or similar)
  - Adverse media (last 5 years)

if ANY sanctions list returns a confirmed hit:
  composite_status = hit                     # BRIGHT LINE

elif PEPs status in [foreign_pep, family_close_associate]:
  composite_status = review                  # mandatory EDD

elif adverse_media_check.status == material:
  composite_status = review

else:
  composite_status = clear
```

## Worked example (Vltava Engineering s.r.o. case)

Input:
```yaml
aml_request:
  principal_id: DIR-001
  case_id: "VLT-2026-04-001"
  name: "Lachlan MacKenzie"
  dob: "1981-03-22"
  nationality: "British"
  country_of_residence: "Scotland, Czech Republic"
```

Output:
```yaml
aml_result:
  principal_id: DIR-001
  sanctions_check:
    ofsi: clear
    un: clear
    eu: clear
    ofac: clear
  peps_check:
    status: clear
    pep_country: null
  adverse_media_check:
    status: clear
    sources: []
  composite_status: clear
  reason_codes: ["UK_AML_CLEAR_ALL_LISTS"]
```

Clean AML screen. Both principals return clear across all lists. If a sanctions hit had appeared, the multi-principal-fan-out-orchestrator would aggregate to block_and_sar (bright line).

## Bright lines

- Czech + EU consolidated list hit → BLOCK (mandatory under Czechia financial sanctions regime)
- UN / EU / OFAC hit (within applicable jurisdictional scope) → BLOCK
- Tipping-off rule: customer-facing communication must not reveal the underlying reason

## Operational rules

- Fuzzy matching with name variations + transliteration handled by the screening engine
- Confirmed hits require MLRO sign-off before any case action
- False positives recorded with disposition for future model tuning
- PEPs status is not a decline trigger per se but mandates enhanced due diligence (EDD)

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Screening engine unavailable | Refer; cannot proceed without screening |
| Match returned with low confidence | Manual review by MLRO; do not auto-block or auto-clear |


## Czech Republic-specific operational notes

Operates within the Czech framework — ČNB as unified supervisor, Consumer Credit Act 257/2016, AML Act 253/2008 enforced via FAÚ.

- **BRKI + NRKI dual registers:** Bank register (BRKI) and non-bank register (NRKI) provide comprehensive Czech consumer credit visibility; SOLUS adds negative data. Strong coverage.
- **Bankovní identita (BankID):** Czech bank-issued digital identity widely adopted for online onboarding and government services.
- **CZK currency:** Outside Eurozone; floating. Larger facilities may need FX consideration.
- **Rodné číslo:** Birth number is the universal identifier; restricted-use under GDPR.
- **Cross-reference:** `country-cz-lending-policy-agent` (Country Policy Pack stub).

## Statutory hooks

- Czechia Zákon č. 253/2008 Sb. (AML Act)
- Czechia Sanctions and Anti-Money Laundering Act 2018
- Financial Sanctions Notice (Czech + EU)
- ČNB SYSC 6.3
- Proceeds of Crime Act 2002 (POCA) — tipping-off and SAR obligations

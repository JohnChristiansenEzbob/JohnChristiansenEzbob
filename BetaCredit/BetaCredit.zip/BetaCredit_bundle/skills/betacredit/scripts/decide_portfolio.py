#!/usr/bin/env python3
"""
decide_portfolio.py — score every loan in a CSV / Parquet / Excel / JSON file
and print a portfolio summary table.

Usage:
    python decide_portfolio.py path/to/loans.csv
    python decide_portfolio.py path/to/loans.csv --out decisions.csv
    python decide_portfolio.py df_all.parquet --json summary.json

Reads via risk_models.data_ingestion.ingest() so it handles aliased column
names automatically (experian_score → bureau_score, etc.). For an already-
clean Parquet (i.e. df_all.parquet from notebook 00), it reads directly
without re-ingesting.
"""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent.parent
sys.path.insert(0, str(ROOT / "backend"))

import pandas as pd

from risk_models import CreditDecisionAgent
from risk_models.data_ingestion import ingest


def load_loans(path: str) -> pd.DataFrame:
    """Load loan data. Parquet files are read directly; everything else
    goes through the canonical ingester."""
    p = Path(path)
    if p.suffix.lower() == ".parquet":
        return pd.read_parquet(p)
    result = ingest(path)
    return result.dataframe


def main() -> int:
    ap = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ap.add_argument("path", help="Path to the loan file")
    ap.add_argument("--out",  help="Optional CSV path to save per-loan decisions")
    ap.add_argument("--json", help="Optional JSON path to save the summary")
    ap.add_argument("--quiet", action="store_true",
                    help="Suppress the summary table (only useful with --out / --json)")
    args = ap.parse_args()

    df = load_loans(args.path)
    if not args.quiet:
        print(f"Loaded {len(df):,} loans from {args.path}")
        print("Scoring...")

    agent = CreditDecisionAgent()
    result = agent.decide_portfolio(df)

    if not args.quiet:
        print()
        print(result.summary_table())
        print()
        print("By asset class:")
        print(result.by_asset_class.to_string(index=False))

    if args.out:
        result.to_dataframe().to_csv(args.out, index=False)
        print(f"\nPer-loan decisions saved → {args.out}")

    if args.json:
        with open(args.json, "w") as f:
            json.dump({
                "n_loans":          result.n_loans,
                "n_approve":        result.n_approve,
                "n_review":         result.n_review,
                "n_decline":        result.n_decline,
                "total_ead":        result.total_ead,
                "total_ecl_12m":    result.total_ecl_12m,
                "total_ecl_life":   result.total_ecl_life,
                "total_ecl_stress": result.total_ecl_stress,
                "total_rwa":        result.total_rwa,
                "stage_counts":     result.stage_counts,
                "by_asset_class":   result.by_asset_class.to_dict(orient="records"),
            }, f, indent=2, default=str)
        print(f"Portfolio summary saved → {args.json}")

    return 0


if __name__ == "__main__":
    sys.exit(main())

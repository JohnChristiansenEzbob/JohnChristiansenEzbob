---
name: be-adverse-action-agent
description: |
  Generate decline / refer reason codes in both regulatory taxonomy and customer-facing language. Triggered when decision-pricing-agent renders a decline or refer outcome. Ensures the right-to-explanation under Belgium GDPR Article 22 is fulfilled and the LSB-compliant decline notice is prepared.
---

# Adverse Action Agent

When the answer is no, the customer (and any future ombudsman / Ombudsfin review) is entitled to know why. Adverse-action handles the why.

## Input contract

```yaml
adverse_action_request:
  case_id: string
  decision_outcome: enum                    # refer | decline
  decline_reasons: [string]                 # regulatory taxonomy reason codes
  decline_reasons_evidence:                 # which upstream agents raised each reason
    - reason_code: string
      origin_agent: string
      evidence_pointer: string
```

## Output contract

```yaml
adverse_action_output:
  case_id: string
  customer_facing_decline_letter_text: string
  reason_codes_internal: [string]
  reason_codes_customer: [string]           # plain-English translations
  right_to_explanation_text: string
  appeal_route_text: string
  bank_referral_scheme_eligibility: boolean # if declined & lender is designated
  audit_ledger_entry_id: string
  reason_codes: [string]
```

## Decision logic

```
For each regulatory reason_code:
  Look up canonical customer-facing translation.

Compose decline letter:
  - Outcome statement (clear, plain English)
  - Reasons (top 3-5, prioritised by materiality)
  - Right to explanation + request channel
  - Appeal route
  - Bank Referral Scheme notice if applicable
  - Vulnerability-aware language adjustments

Set bank_referral_scheme_eligibility based on lender designation + outcome.
```

## Worked example (Manneken Engineering NV/SA case)

Input:
```yaml
(not triggered for Highland — accept outcome.
This agent would fire if outcome had been refer or decline.)
```

Output:
```yaml
(not triggered for Highland — accept outcome.
Example shape for a hypothetical decline:

adverse_action_output:
  case_id: "MAN-2026-04-001"
  customer_facing_decline_letter_text: "..."
  reason_codes_customer:
    - "Your business's recent trading performance does not currently meet our affordability requirements."
    - "There is an existing charge on the company that would need to be released before we could provide new funding."
  right_to_explanation_text: "..."
  appeal_route_text: "..."
  bank_referral_scheme_eligibility: true)
```

Not triggered for Highland (accept outcome). Documented here for completeness — would fire on refer / decline path.

## Bright lines

- Tipping-off cases: decline letter must NOT reveal underlying suspicion
- Customer-facing reasons cannot be more specific than regulatory codes allow

## Operational rules

- Plain English required (Flesch Reading Ease >= 60)
- Reasons prioritised by materiality, not first-discovered
- Vulnerability-aware language for flagged principals
- Appeal route must be a real working channel, not a black hole

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Reason code with no customer translation | Generic + escalate translation to product |
| Decline reasons inconsistent | Refer to compliance |


## Belgium-specific operational notes

This agent operates within the Belgian lending framework — NBB (prudential, including CKP operation) and FSMA (conduct) twin peaks, Code de droit économique Books VII (consumer) + VIII (KBO), Loi du 18 septembre 2017 for AML.

- **Regional language obligation:** SECCI and contract MUST be in the customer's regional language — French (Wallonie), Dutch (Flanders), German (Eastern Cantons), or bilingual (Brussels Capital). This is statutory and contracts in the wrong language are invalid.
- **CKP mandatory consumer query:** Statutory mandatory before consumer credit decision; non-query invalidates agreement. NBB-operated central consumer credit register.
- **Statutory rate caps:** Code de droit économique Book VII sets statutory rate caps per consumer credit category — exceeding is contract invalidity.
- **itsme universal:** Belgian mobile identity platform widely adopted; integrates with PSD2 SCA. Most consumer onboarding uses itsme.
- **Cooperative + commercial bank mix:** Belfius (state-related cooperative legacy), KBC (cooperative origin), BNP Paribas Fortis (commercial), ING Belgium — diverse market structure.
- **Cross-reference:** `country-be-lending-policy-agent` provides full BE jurisdictional context.

## Statutory hooks

- Belgium GDPR Article 22 (right to explanation for automated decisions)
- FSMA Code de droit économique Book VII (consumer understanding outcome)
- Febelfin Code of Conduct for Business Customers
- SBEE Act 2015 (Bank Referral Scheme on decline)

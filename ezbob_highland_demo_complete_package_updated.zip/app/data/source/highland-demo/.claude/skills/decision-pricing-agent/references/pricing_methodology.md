# Pricing Methodology

How the decision-pricing-agent constructs the APR offered to an SME applicant. Risk-based, calibrated, and Consumer Duty fair-value tested.

## The pricing curve

```
APR = expected_loss + cost_of_funds + operational_cost + capital_charge + margin
```

Each component is a percentage. The numbers are calibrated centrally and refreshed at the cadence shown.

## Components

### Expected loss

```
expected_loss_pct = PD_12m × LGD × EAD_factor
```

- **PD_12m** — 12-month probability of default from AlphaCredit, calibrated to the firm's bad-rate experience
- **LGD** — loss given default for the proposed product/security profile, from the firm's LGD model
- **EAD_factor** — expressed relative to facility size; for amortising term loans this is approximately 0.6 (average exposure over the life is roughly 60% of original); for RCFs use the firm's CCF assumption

For longer-dated facilities, multiply by the term factor (PD over the full life rather than 12-month, or a multi-year cumulative-default approximation).

### Cost of funds

The current internal funding cost passed in by treasury. Sensitive to:
- Source mix (deposits, securitisation, warehouse, equity)
- Tenor of the facility (matched-funding assumption)
- Hedging cost where applicable

For UK SME term loans in current conditions, this is typically a positive spread to gilts of broadly the facility tenor. Treasury maintains the curve and feeds it into the policy snapshot consumed by the decision agent.

### Operational cost

Direct origination + servicing cost amortised over the facility life. Includes:
- Origination cost (verification, underwriting, decisioning, document generation)
- Ongoing servicing cost (collections, reporting, compliance monitoring)
- Bureau and data costs allocated per facility

For a £50k 36-month term loan, operational cost is in the order of 200–250bps APR. Smaller facilities carry proportionally higher operational cost APR; very small facilities may not be economic at acceptable APR levels — Consumer Duty fair-value pressure point.

### Capital charge

Cost of the regulatory and economic capital tied up by the facility. Drives off:
- The risk weight under the firm's capital regime (standardised vs IRB; SME supporting factor where applicable)
- The firm's cost of equity
- The capital ratio target

Approximate computation: `capital_charge_pct = risk_weight × leverage_ratio × cost_of_equity_premium`.

### Margin

The residual after all above. Set by:
- Risk appetite for the segment
- Competitive position
- Strategic priority for the segment

Margin can vary across segments and is the lever the firm uses to compete or to pull back. It is **not** a function of the individual customer's likely sensitivity to price (price discrimination at customer level on non-risk-related factors raises Consumer Duty fair-value flags).

## Worked example

A medium-risk SME (PD 2.5%, blended bureau B grade) requests a £50k 36-month term loan, with debenture and a £25k limited director PG.

| Component | Value | Notes |
|---|---|---|
| Expected loss | 1.0% | 0.025 × 0.40 (LGD with security) × 1.0 (term factor short) |
| Cost of funds | 5.5% | 3y fixed; current treasury rate |
| Operational cost | 2.5% | Standard term loan origination + servicing |
| Capital charge | 2.0% | Standardised risk weight × cost of equity |
| Margin | 2.2% | Standard SME term loan segment margin |
| **Total APR** | **13.2%** | |

The agent emits this breakdown so the underwriter (and, for material amendments, the customer's adverse-action explanation) can see how the price was constructed.

## Risk-based pricing tiers

The firm operates approximate APR tiers by ezbob blended grade, which the agent treats as guard-rails:

| Grade | APR floor | APR ceiling |
|---|---|---|
| A | 7.0% | 11.0% |
| B | 10.0% | 14.0% |
| C | 13.0% | 17.0% |
| D | 16.0% | 21.0% |
| E | not eligible for unsecured term | — |

The component build above produces a candidate APR; if that candidate falls outside the tier band, the agent emits a flag and refers — material APR misalignment usually indicates a calibration drift somewhere upstream (PD model, LGD model, treasury curve).

## Consumer Duty fair value

Every approved offer carries a fair-value check:

1. **Distributional check** — does this customer's APR fall within the expected distribution for similar-risk customers in this segment? Three-sigma outliers are flagged.
2. **Benefit-to-price check** — for the segment, is the facility delivering value commensurate with price? Driven from outcomes data: switching rates, complaint rates, satisfaction scores, hardship rates.
3. **Vulnerability cross-check** — if the customer profile carries any vulnerability signal, the firm's vulnerability framework requires additional scrutiny (e.g. is this customer in a segment where high APR is correlated with worse outcomes?).

Failed fair-value check does not auto-block the offer; it routes to a human reviewer with the failure reason. The agent never silently passes a failed fair-value check.

## Calibration cadence

| Component | Refresh cadence |
|---|---|
| PD/LGD/EAD models | Quarterly performance review; full recalibration at least annually |
| Cost of funds | Daily (treasury feed) |
| Operational cost | Annual review of cost allocation |
| Capital charge | Quarterly review (post-ICAAP) |
| Margin tiers | Annual strategic review; ad-hoc on material competitive shifts |
| Fair value distributional thresholds | Quarterly recalculation against the previous quarter's book |

Each calibration is versioned. The audit trail on every decision records which version of every input was used, so historical decisions can be replayed.

## What the agent does not do

- It does not apply individual-customer price discrimination on non-risk-related factors (e.g. brand loyalty, perceived sensitivity)
- It does not change pricing based on the customer's competitor quotes (those are inputs to a sales / RM decision, not an automated decision-pricing decision)
- It does not auto-discount to win business — discount authority sits with sales / underwriter roles, not the agent

---
name: cz-ead-modelling-agent
description: |
  Estimate Exposure at Default. For Czechia term loans, this is largely deterministic — principal at drawdown amortising over term. For revolving credit or committed lines, includes credit conversion factor for undrawn portions. Term loans get a simple EAD profile.
---

# EAD Modelling Agent

EAD is the exposure metric for capital and ECL. For term loans it's near-trivial; kept as a separate agent for consistency and to handle non-term products.

## Input contract

```yaml
ead_request:
  case_id: string
  facility_type: enum
  facility_amount_czk: integer
  facility_term_months: integer
  drawdown_pattern: enum                    # single | phased | revolving
  undrawn_commitment_gbp: integer           # for revolving / committed
```

## Output contract

```yaml
ead_estimate:
  case_id: string
  ead_at_completion_gbp: integer
  ead_profile_over_term:                    # amortising schedule
    - month: integer
      outstanding_gbp: integer
  ead_avg_over_term_gbp: integer
  credit_conversion_factor: float           # 1.0 for term loans
  reason_codes: [string]
```

## Decision logic

```
For term_loan:
  ead_at_completion = facility_amount (fully drawn at completion)
  ead_profile = annuity_amortisation_schedule(facility_amount, term, rate)
  ead_avg = mean(ead_profile)
  credit_conversion_factor = 1.0

For revolving_credit:
  ead = drawn_estimate + (undrawn * CCF)  # CCF typically 40-75%

For asset_finance / invoice_finance:
  agent-specific logic
```

## Worked example (Vltava Engineering s.r.o. case)

Input:
```yaml
ead_request:
  case_id: "VLT-2026-04-001"
  facility_type: term_loan
  facility_amount_czk: 150000
  facility_term_months: 60
  drawdown_pattern: single
  undrawn_commitment_gbp: 0
```

Output:
```yaml
ead_estimate:
  case_id: "VLT-2026-04-001"
  ead_at_completion_gbp: 150000
  ead_profile_over_term:
    - month: 0
      outstanding_gbp: 150000
    - month: 12
      outstanding_gbp: 124800
    - month: 24
      outstanding_gbp: 97200
    - month: 36
      outstanding_gbp: 67100
    - month: 48
      outstanding_gbp: 34200
    - month: 60
      outstanding_gbp: 0
  ead_avg_over_term_gbp: 78600
  credit_conversion_factor: 1.0
  reason_codes: ["UK_EAD_TERM_LOAN_AMORTISING_PROFILE"]
```

Simple amortising profile for a CZK 150k 60-month term loan. CZK 150k at completion, ~CZK 0 at maturity, time-weighted average CZK 78.6k. Used as input to ECL (in combination with PD and LGD).

## Bright lines

- (no statutory bright lines for this agent)

## Operational rules

- Term loans: EAD profile is deterministic; no model risk in this calculation
- Revolving: CCF is portfolio-calibrated; updated quarterly

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Phased drawdown: unclear timing | Use worst-case (all drawn at once); flag |
| Asset finance: depreciation profile not provided | Refer |


## Czech Republic-specific operational notes

Operates within the Czech framework — ČNB as unified supervisor, Consumer Credit Act 257/2016, AML Act 253/2008 enforced via FAÚ.

- **BRKI + NRKI dual registers:** Bank register (BRKI) and non-bank register (NRKI) provide comprehensive Czech consumer credit visibility; SOLUS adds negative data. Strong coverage.
- **Bankovní identita (BankID):** Czech bank-issued digital identity widely adopted for online onboarding and government services.
- **CZK currency:** Outside Eurozone; floating. Larger facilities may need FX consideration.
- **Rodné číslo:** Birth number is the universal identifier; restricted-use under GDPR.
- **Cross-reference:** `country-cz-lending-policy-agent` (Country Policy Pack stub).

## Statutory hooks

- Basel III/IV (EAD for capital)
- IFRS 9 (ECL inputs)

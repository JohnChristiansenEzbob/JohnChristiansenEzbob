# BetaCredit Decision Policy

The `CreditDecisionAgent.decide_one()` method produces an APPROVE / REVIEW / DECLINE recommendation by applying five rules in strict priority order. This file documents the rules and explains how to override them for a specific firm's underwriting policy.

## The rules (applied top to bottom; first match wins)

1. **IFRS 9 Stage 3 → DECLINE.** A loan flagged as credit-impaired (90+ DPD or default flag set) is rejected regardless of every other signal. The agent stamps the SICR trigger that fired as the rationale (`dpd_92_stage3`, `default_flag_stage3`, etc.).

2. **Bureau score below 400 → DECLINE.** UK bureau scores below 400 indicate severe credit distress and fall outside the agent's calibrated range. No underwriting policy should approve at this level without strong compensating factors that the agent does not see.

3. **PD above asset-class ceiling → DECLINE.** Each asset class has a ceiling (e.g. 12% for SME unsecured, 4% for residential mortgage). A loan whose 12-month PD exceeds the ceiling is rejected with confidence proportional to how far over the ceiling it sits, measured in log-odds.

4. **PD below asset-class floor AND Stage 1 → APPROVE.** A loan comfortably below the asset-class approve threshold (e.g. 3% for SME unsecured, 0.8% for residential mortgage) AND in Stage 1 is auto-approved.

5. **Anything else → REVIEW.** PDs in the middle band, or Stage 2 (SICR triggered) loans regardless of PD, are routed to a human underwriter with a rationale explaining why.

## Default thresholds

See `asset_classes.md` for the per-asset-class APPROVE-below and DECLINE-above thresholds. They reflect a moderately-conservative UK lender; your firm's risk appetite may differ.

## Overriding the thresholds

The agent accepts a `thresholds` dict on construction. Each entry is `(approve_below, decline_above)` in 12-month PD space, e.g. `(0.03, 0.12)` for SME unsecured. You only need to specify the classes you want to override; unspecified classes fall back to defaults.

```python
from risk_models import CreditDecisionAgent

# Tighten mortgage thresholds for a low-risk-appetite lender
agent = CreditDecisionAgent(thresholds={
    "residential_mortgage": (0.005, 0.025),  # was (0.008, 0.040)
    "buy_to_let":           (0.008, 0.040),  # was (0.012, 0.060)
})
```

## Confidence

Every decision carries a confidence between 0 and 1. The heuristic is:

- **Stage 3 DECLINE** → 0.98 (no ambiguity)
- **Bureau < 400 DECLINE** → 0.95
- **PD-based DECLINE or APPROVE** → distance from threshold on a log-odds scale, capped at 0.98. A loan whose PD is well below the approve floor (say 0.5% vs 3%) gets a high confidence; one just below the floor (say 2.9% vs 3%) gets a low confidence and a REVIEW-like rationale even though formally classified APPROVE.
- **Stage 2 REVIEW** → 0.70 (the SICR engine is confident the loan is at elevated risk, but the underwriter must decide)
- **Mid-band REVIEW** → 0.55 (the model itself is uncertain)

When reporting to a user, quote the confidence alongside the recommendation. A 55%-confidence APPROVE should not be acted on the same way as a 95%-confidence APPROVE.

## What the policy does not consider

The agent does not look at:

- **Counterparty concentration.** Two large loans to the same parent group both count as independent decisions.
- **Internal credit limits.** A loan that fits the agent's PD policy may still breach a single-name or sector limit.
- **Macro outlook.** PD is computed point-in-time using the model suite's current calibration; forward-looking adjustments (PRA SS3/18 base/adverse/severe scenarios) live in notebook 07, not in the agent.
- **Customer affordability beyond DSCR.** Cashflow coverage is one of the inputs but the agent does not consult disposable-income or stress-affordability calculations.

For these, the analytical notebooks (especially 04 SICR, 05 Fairness, and 07 Portfolio ECL) are the right tools. The agent is a per-loan triage step; the notebooks are the full diligence pack.

---
name: fi-multi-principal-fan-out-orchestrator
description: |
  Coordinate parallel verification across all natural-person principals of a Finland SME applicant —
  directors, named Persons of Significant Control (PSCs), and applicant signatory. Spawn
  parallel subcases for identity, AML, application fraud, individual financial difficulty,
  and cross-directorship checks. Reconcile partial failures and aggregate per-principal
  outcomes into a composite case-level KYC/AML/fraud assessment that downstream credit
  decisioning can consume. Trigger whenever the assembled principals list contains more
  than one entry, OR whenever the PSC structure recursor has surfaced additional natural-
  person controllers beyond the named applicant. This agent is a control-flow primitive —
  it does not call external APIs; it composes other agents.
---

# Multi-Principal Fan-Out Orchestrator

Most Finland SME applications have multiple directors (typically 2-4) and one or more named
PSCs (often overlapping with directors). A naïve flow that only verifies the applicant
signatory misses material risk on co-directors who will become co-guarantors. This
orchestrator removes that gap.

## Input contract

```yaml
principals:                            # list — required, length >= 1
  - principal_id: string               # case-unique identifier
    kind: enum                         # director | psc | applicant_signatory | shareholder
    name: string
    dob: date                          # may be partial (YYYY-MM) for PSC entries
    address: string                    # current residential
    nationality: string
    source_record: enum                # companies_house_director | companies_house_psc | applicant_declaration
    is_proposed_pg_bearer: boolean
    proposed_pg_amount_eur: integer    # nullable; required if is_proposed_pg_bearer = true
case_id: string                        # parent case identifier
```

## Output contract

```yaml
principal_aggregate_assessment:
  case_id: string
  principal_count: integer
  per_principal_outcomes:
    - principal_id: string
      identity_verified: boolean
      identity_confidence: float       # 0.0 - 1.0
      sanctions_pep_status: enum       # clear | hit | review
      application_fraud_score: integer # 0-100
      financial_difficulty_status: enum # clear | refer | decline
      cross_directorship_status: enum  # clean | monitor | phoenix_risk | cross_default_risk
      subcase_completed: boolean
  aggregate_outcome: enum              # clear | refer | block_and_sar | block_phoenix | block_pg_bearer_difficulty
  aggregate_reason_codes: [string]
  hardest_blocker_principal_id: string # nullable
```

## Decision logic

```
For each principal (in parallel):
  spawn subcase → identity-orchestration-agent → aml-screening-agent →
                  application-fraud-agent → director-financial-difficulty-checker →
                  director-cross-directorship-checker

Aggregate:
  if ANY principal.sanctions_pep_status == "hit":
    aggregate_outcome = block_and_sar             # bright line
  elif ANY principal.financial_difficulty_status == "decline" AND principal.is_proposed_pg_bearer:
    aggregate_outcome = block_pg_bearer_difficulty
  elif ANY principal.cross_directorship_status == "phoenix_risk":
    aggregate_outcome = block_phoenix
  elif ALL principals.identity_verified AND ALL principals.financial_difficulty_status == "clear":
    aggregate_outcome = clear
  else:
    aggregate_outcome = refer
```

## Worked example (Sisu Engineering Oy)

Input:
```yaml
principals:
  - principal_id: DIR-001
    kind: director
    name: "Lachlan MacKenzie"
    is_proposed_pg_bearer: true
    proposed_pg_amount_eur: 90000
  - principal_id: DIR-002
    kind: director
    name: "Sarah Chen"
    is_proposed_pg_bearer: true
    proposed_pg_amount_eur: 60000
```

Output:
```yaml
principal_aggregate_assessment:
  case_id: SIS-2026-04-001
  principal_count: 2
  per_principal_outcomes:
    - principal_id: DIR-001
      identity_verified: true
      identity_confidence: 0.97
      sanctions_pep_status: clear
      application_fraud_score: 12
      financial_difficulty_status: clear  # 1 historic satisfied CCJ; not a blocker
      cross_directorship_status: clean
      subcase_completed: true
    - principal_id: DIR-002
      identity_verified: true
      identity_confidence: 0.98
      sanctions_pep_status: clear
      application_fraud_score: 8
      financial_difficulty_status: clear
      cross_directorship_status: clean
      subcase_completed: true
  aggregate_outcome: clear
  aggregate_reason_codes: ["UK_PRINCIPAL_AGGREGATE_CLEAR"]
  hardest_blocker_principal_id: null
```

## Bright lines

- Sanctions hit on ANY principal → `block_and_sar`. No agent discretion. Engage tipping-off wall.
- Undischarged bankruptcy on a director where `is_proposed_pg_bearer = true` → `block_pg_bearer_difficulty`.
- Identity verification hard failure on any principal → case held; cannot progress.

## Operational rules

- Per-principal subcases run in parallel. Sequential execution is a performance bug.
- Each subcase emits its own decision-log entry; aggregate does not collapse individual evidence.
- Partial failure: if any subcase times out, aggregate emits `refer` (not block).

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| `principals` list empty | Return error; case cannot proceed |
| Single principal | Run subcase synchronously (no parallelism needed) |
| Subcase exception | Mark `subcase_completed: false`; aggregate → `refer` |
| All subcases timeout | Aggregate → `refer`; alarm to ops |


## Finland-specific operational notes

This agent operates within the Finnish lending framework — FIN-FSA (Finanssivalvonta) as unified supervisor, Credit Institutions Act for banking, Consumer Protection Act ch 7 for consumer credit, AML Act 444/2017 for AML.

- **FIN-FSA positive credit register (2024+):** Operational positive credit data register at the supervisor — uncommon in EU. Materially raises lender visibility.
- **Suomen Asiakastieto positive data:** Even before FIN-FSA register, Asiakastieto offered positive credit data — Finland was atypical for EU in this regard.
- **Bilingual constitutional requirement:** Finnish + Swedish; Swedish-speaking minority has constitutional rights to financial services in Swedish. Operational disclosure in Swedish for Swedish-speaking customers.
- **Bank-issued e-ID universal:** Finnish banks issue universal e-ID credentials used across financial services and government interactions. PSD2 SCA operationally seamless.
- **Suomi.fi authentication:** Government identity hub. Strong integration.
- **HETU privacy:** Henkilötunnus is restricted-use; over-collection or unnecessary retention is privacy breach under GDPR + Finnish Data Protection Act.
- **Cross-reference:** `country-fi-lending-policy-agent` for full FI jurisdictional context (currently a stub in the Country Policy Pack).

## Statutory hooks

- Finland Law on the Prevention of Money Laundering 444/2017 (as amended)
- AML Act 444/2017 + PRH UBO Register (PRH UBO Register)
- FIN-FSA SYSC 6.3
- FIN-FSA FIN-FSA customer protection

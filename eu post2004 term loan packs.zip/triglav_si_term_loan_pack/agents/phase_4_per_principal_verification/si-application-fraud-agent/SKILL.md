---
name: si-application-fraud-agent
description: |
  Detect application-stage fraud indicators per principal — synthetic identity patterns, document tampering signals, velocity rules (repeated applications), SISBON / SISBIZ negative Protective Registration / National Fraud Database hits, device fingerprinting signals. Returns a fraud score (0-100) with classification.
---

# Application Fraud Agent

First-line application fraud screen. Identity-orchestration confirms the person is real and the documents are real; this agent confirms the application itself isn't suspicious.

## Input contract

```yaml
fraud_request:
  principal_id: string
  case_id: string
  name: string
  dob: date
  current_residential_address: string
  application_metadata:
    device_fingerprint: string
    ip_address: string
    submission_timestamp: datetime
    browser_locale: string
  cifas_check_consent: boolean
```

## Output contract

```yaml
fraud_assessment:
  principal_id: string
  fraud_score: integer                      # 0-100; 0=clean, 100=high risk
  classification: enum                      # low | medium | high
  signals:
    cifas_markers: [string]                 # nullable
    velocity_signals: [string]              # multiple recent applications etc.
    device_signals: [string]                # VPN, automation, mismatched locale etc.
    synthetic_identity_signals: [string]
  outcome: enum                             # proceed | refer | block_high_risk_fraud
  reason_codes: [string]
```

## Decision logic

```
Lookup SISBON / SISBIZ negative National Fraud Database (consent-gated).
Apply velocity rules (same identity in N applications in past M days).
Device fingerprint analysis (known fraud-associated devices, automation).
Synthetic identity detection (DOB-name combinations, address-credit history mismatches).

Compute composite fraud_score.

if cifas_markers include "fraud" (Category 6) marker:
  outcome = block_high_risk_fraud           # BRIGHT LINE; SISBON / SISBIZ negative fraud marker is decline

elif fraud_score >= 70:
  outcome = block_high_risk_fraud

elif fraud_score >= 40:
  outcome = refer

else:
  outcome = proceed
```

## Worked example (Triglav Engineering d.o.o. case)

Input:
```yaml
fraud_request:
  principal_id: DIR-001
  case_id: "TRI-2026-04-001"
  name: "Lachlan MacKenzie"
  dob: "1981-03-22"
  current_residential_address: "12 Strathblane Road, Milngavie, Ljubljana, G62 8DJ"
  application_metadata:
    device_fingerprint: "[hash]"
    ip_address: "82.x.x.x"
    submission_timestamp: "2026-04-12T09:14:22Z"
    browser_locale: "en-GB"
  cifas_check_consent: true
```

Output:
```yaml
fraud_assessment:
  principal_id: DIR-001
  fraud_score: 12
  classification: low
  signals:
    cifas_markers: []
    velocity_signals: []
    device_signals: []
    synthetic_identity_signals: []
  outcome: proceed
  reason_codes: ["UK_APPLICATION_FRAUD_LOW_RISK"]
```

Clean fraud screen. Slovenia IP, en-GB locale matching declared residence, no SISBON / SISBIZ negative markers, no velocity issues. Sarah Chen returns similar low-risk shape.

## Bright lines

- SISBON / SISBIZ negative Category 6 fraud marker → AUTO-DECLINE; cannot override without explicit dispensation
- Confirmed synthetic identity (fabricated person) → AUTO-DECLINE + SAR

## Operational rules

- SISBON / SISBIZ negative lookup requires explicit consent; absence of consent → cannot perform that check (not blocking by itself)
- Velocity rules windowed (e.g. >3 applications in 30 days flags)
- Device fingerprints retained in fraud history for pattern detection

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| SISBON / SISBIZ negative unavailable | Refer; cannot make decision without check (over a critical limit) |
| Device fingerprint missing | Score conservatively; some signals unusable |


## Slovenia-specific operational notes

Operates within the Slovenian framework — Banka Slovenije supervision, Consumer Credit Act, AML Act.

- **SISBON + SISBIZ dual registers:** Bank of Slovenia operates both the consumer (SISBON) and commercial (SISBIZ) credit registers — strong centralised visibility.
- **First post-2004 Eurozone member (2007):** EUR-denominated; no FX consideration.
- **EMŠO universal identifier:** Unique Master Citizen Number; restricted-use under GDPR.
- **AJPES:** Central registry agency for company + UBO data.
- **Cross-reference:** `country-si-lending-policy-agent` (Country Policy Pack stub).

## Statutory hooks

- Fraud Act 2006
- RDL (Register dejanskih lastnikov) (failure to prevent fraud — must have reasonable procedures)
- Slovenia AML Act (transaction monitoring + identity)
- SISBON / SISBIZ negative Code of Practice

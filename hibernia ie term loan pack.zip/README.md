# Hibernia IE Term Loan Agent Pack

46 SKILL.md agents for Irish SME term lending. Companion to the Highland UK
Term Loan Agent Pack — replicates the same 8-phase + governance-overlay
structure with Ireland-specific regulatory, registry, bureau, and statutory
context.

## Structure

```
ie_term_loan_pack/
├── agents/
│   ├── phase_1_intake/                      3 agents
│   ├── phase_2_consent_and_purpose/         3 agents
│   ├── phase_3_kyb_and_psc/                 3 agents (CRO + RBO)
│   ├── phase_4_per_principal_verification/  6 agents
│   ├── phase_5_credit_data_assembly/        5 agents (CCR + Revenue + IE bureaus)
│   ├── phase_6_modelling_and_pg_feasibility/ 9 agents
│   ├── phase_7_decision/                    2 agents
│   ├── phase_8_offer_construction/         10 agents (CCA-IE + CPC 2026 disclosure)
│   └── governance_overlays/                 5 agents (CPC 2026 outcomes)
└── README.md                                              Total: 46 agents
```

## Key differences from Highland UK

The pack inherits Highland's agent skeleton but the operational reality is
materially different in Ireland on several axes:

| Domain | UK (Highland) | Ireland (Hibernia) |
|---|---|---|
| Primary regulator | FCA + PRA | CBI (unified) |
| Corporate registry | Companies House (8-digit) | CRO (6-digit) |
| Beneficial ownership | PSC register + ECCTA 2023 | RBO + SI 110/2019 + CEA |
| Tax authority | HMRC + Making Tax Digital | Revenue Commissioners + ROS + PAYE Modernisation |
| Credit register | Multi-bureau (best practice) | **CCR mandatory** for consumer >€500 + ALL business |
| Consumer credit | CCA 1974 + FCA CONC | Consumer Credit Act 1995 + CPC 2026 |
| Mortgage | MCOB + MMR | Mortgage Credit Regulations 2016 + CCMA |
| Sanctions | OFSI + UN + EU + OFAC | EU consolidated + UN + DFA Ireland |
| AML | MLR 2017 | CJMLA 2010 (as amended) |
| Ombudsman | FOS | FSPO |
| Outcomes framework | Consumer Duty (PRIN 12) | Consumer Protection Code 2026 |
| Property registry | HM Land Registry | Tailte Éireann (formerly PRAI) |
| Identity | NI number + driving licence | PPS number + MyGovID + Eircode |
| Currency | GBP | EUR |
| Payment rails | Faster Payments / BACS / CHAPS | SCT Inst (SEPA Instant) + SEPA Direct Debit |
| Fraud database | CIFAS | InfoTrack IE / GardaCheck |

## The Hibernia Engineering case study

Hibernia Engineering Limited (CRO 654321) is the IE-equivalent of Highland
Engineering. Worked examples in each agent use this case — a Dublin-based
SME (IFSC registered office), incorporated 2017, currently trading with
filings current, applying for a €500,000 term loan for plant + working
capital. The case study runs across all 46 agents and provides a complete
end-to-end Irish lending decision narrative.

## Agent naming

All agents are prefixed `ie-` to distinguish from Highland (UK) equivalents.
A few agents are renamed where the IE concept differs structurally:

- `kyb-companies-house-agent` → `ie-kyb-cro-agent` (under-the-hood
  rename via substitution; agent files use `ie-kyb-verifier` for the canonical
  KYB agent)
- `psc-complex-structure-recursor` → `ie-rbo-complex-structure-recursor`
- `hmrc-direct-verification-agent` → `ie-revenue-direct-verification-agent`
- `consumer-duty-outcomes-agent` → `ie-cpc-2026-outcomes-agent`

## What's deliberately preserved from Highland

- Phase structure (8 phases + governance overlay)
- Input / output contract YAML schemas (jurisdiction-neutral)
- Decision logic pseudocode (jurisdiction-neutral)
- Failure modes tables (mostly jurisdiction-neutral)
- Worked example structure (re-anchored to Hibernia Engineering)

## Ireland-specific operational notes

Each agent SKILL.md now ends with an **Ireland-specific operational notes**
section that surfaces the genuine IE-distinct considerations — including
CCR mandatory query (statutory), CPC 2026 outcomes (effective March 2026),
Tailte Éireann property registry (formerly PRAI), and the Equal Status Acts
2000-2018 protected characteristics (different list from UK Equality Act
2010).

## Pre-2004 EU accession countries — completion roadmap

This is the 2nd pack of 14 in the pre-2004 EU build. Status:

| # | Country | Status |
|---|---|---|
| 1 | United Kingdom | ✓ Highland (46 agents) |
| 2 | Ireland | ✓ Hibernia (46 agents) — THIS PACK |
| 3 | Germany | Pending (next-session priority) |
| 4 | France | Pending |
| 5 | Italy | Pending |
| 6 | Netherlands | Pending |
| 7 | Belgium | Pending |
| 8 | Luxembourg | Pending |
| 9 | Denmark | Pending |
| 10 | Spain | Pending |
| 11 | Portugal | Pending |
| 12 | Greece | Pending |
| 13 | Austria | Pending |
| 14 | Finland | Pending |
| 15 | Sweden | Pending |

Each subsequent country pack will follow the Hibernia approach — substitution
table for the routine fact-replacement, custom rewrites for the agents where
the jurisdiction differs structurally (e.g. Germany's SCHUFA monopoly,
France's FIBEN central commercial register, Italy's anti-usura law caps,
Belgium's multilingual disclosure requirements, Denmark/Sweden/Finland
post-2025 PSD2 implementations, Greece's TIRESIAS bureau).

## Cross-references

- `Highland UK Term Loan Agent Pack` — the source pattern (46 agents).
- `country-ie-lending-policy-agent` (in the Country Policy Agents Pack) —
  fully-built jurisdictional context for Ireland. Provides the complete
  regulatory framework that these workflow agents operate within.

---

*© Credit Risk Models (E) Limited 2026. Hibernia IE Term Loan Agent Pack
is the Irish operational companion to the Highland UK Term Loan Agent Pack.*

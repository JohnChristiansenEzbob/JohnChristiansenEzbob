# DSCR and ICR Methodology

The firm's conventions for computing Debt Service Coverage Ratio and Interest Cover Ratio in SME credit assessment. These ratios are the operational core of CONC 5.2A creditworthiness; the conventions here are stable and version-controlled because audit replay depends on it.

## DSCR

### Formula

```
DSCR = (operating cashflow available for debt service) / (total debt service obligations)
```

Both numerator and denominator are annualised. DSCR > 1 means the business covers its debt service; the firm's policy minimum for SME term loans is **1.25x** baseline and **1.00x** under severe stress.

### Numerator: operating cashflow available for debt service

Computed in priority order, with a reconciliation step:

1. **Filed-accounts EBITDA** (preferred where current and reliable)
   - Operating profit + depreciation + amortisation
   - Adjustments: add back any one-off items disclosed in the directors' report; subtract any non-recurring revenue
   - Use only if year-end < 9 months old

2. **Open banking proxy EBITDA** (preferred where filed accounts are stale)
   - 12-month net cashflow + observable interest paid + tax paid
   - Less: an essential capex deduction (sector-typical, from the firm's policy table)
   - Less: a normalised owner drawings figure where actual drawings exceed sector norms

3. **Management accounts** (used to bridge filed accounts and current period when both available)

If filed and OB diverge by > 15%, take the **lower** of the two and emit `AFF_INCOME_BASIS_RECONCILIATION_MATERIAL`.

### Denominator: total debt service

Sum of:
- **Existing facilities' annual servicing** — interest plus principal on amortising loans, interest plus expected fees on RCFs and overdrafts at policy-stressed utilisation, expected lease payments
- **Proposed facility's annual servicing** — same logic, applied to the requested terms

Sources:
- Bureau file (existing facilities and balances)
- Open banking (observed monthly servicing outflows — useful for confirmation and for catching off-bureau debts)
- Application disclosure (intercompany, related-party, BNPL not on bureau)

Take the **union**, deduplicated by counterparty. Where bureau says a facility exists but no servicing outflow is observed, investigate.

### Treatment of structures

| Facility type | Servicing component |
|---|---|
| Amortising term loan | Contractual annual P+I |
| Bullet / interest-only | Annual interest, plus a sinking-fund-equivalent toward bullet maturity |
| RCF / overdraft | Interest at firm's stressed utilisation (typically 75% of committed limit) |
| Invoice finance | Fees + interest at expected drawn-down level |
| Asset finance / lease | Annual rentals |
| Trade credit | Generally excluded unless terms exceed 90 days (then treated as facility) |

## ICR

### Formula

```
ICR = EBITDA / total interest expense (existing + proposed)
```

Same numerator as DSCR; denominator is interest only, no principal.

ICR is informative for businesses with high principal repayment loads where DSCR alone might mask a healthy interest-coverage profile — for example, a business close to retiring a significant amortising loan whose principal component falls away in the near term.

Policy minimum for ICR is **3.0x** baseline, **2.0x** stressed.

## Free cashflow after all debt

```
FCF_after_debt = operating cashflow − total debt service − tax − essential capex
```

Useful as a sanity check and for the underwriter's narrative. Negative FCF after debt under severe stress is a strong `AFF_FCF_NEGATIVE_UNDER_STRESS` signal even if DSCR remains above 1.0x — the difference is what's available for the unforeseen.

## Stress application

The DSCR / ICR / FCF figures in the agent's output are computed across the firm's standard scenario set:

| Scenario | Turnover delta | Margin delta | APR delta |
|---|---|---|---|
| Baseline | 0% | 0bps | 0bps |
| Mild downturn | -10% | -100bps | 0bps |
| Severe downturn | -25% | -200bps | +100bps |
| Customer concentration shock | top customer removed | margin held | 0bps |
| Sector-specific | per sector library | per sector library | 0bps |

Scenarios are applied to the numerator side; the denominator side is held at proposed terms (with the APR delta affecting the proposed facility's servicing).

## Owner drawings

For owner-managed SMEs, the line between salary, dividends, and drawings is fluid. Treatment:
- **Below sector-typical** — leave as observed; the business is being modest and that's a reasonable affordability cushion
- **At sector-typical** — leave as observed
- **Above sector-typical** — normalise down to typical level and flag `AFF_OWNER_DRAWINGS_HIGH`

Sector-typical levels are from the firm's policy table (`sector_drawings_norms.md`).

The reason this matters: if a sole director is taking £80k/year of drawings out of a £100k EBITDA business, the business looks unaffordable on observed cashflow but might be affordable if the director chose to draw less. The agent shouldn't decide that for them, but it should make the trade-off visible.

## Worked example

A retail SME requests £50,000 over 36 months at indicative 12.5% APR (£1,672 monthly, £20,065 annualised).

Income basis:
- FY2024 filed accounts: £580k turnover, £67k EBITDA
- Open banking 12m: £585k turnover, £71k net cashflow + £4k interest = £75k EBITDA proxy
- Reconciliation: aligned (within 15%); take lower as conservative → £67k

Existing servicing:
- Bureau shows existing £30k term loan, £1,400/mo = £16,800 annualised
- Open banking confirms £1,400/mo to that lender

Proposed servicing: £20,065

Total debt service: £36,865

DSCR baseline: 67,000 / 36,865 = **1.82x** ✓ (> 1.25)
DSCR mild stress: turnover -10% → margin scale → EBITDA ≈ £53k. Same servicing. = **1.44x** ✓
DSCR severe stress: EBITDA ≈ £37k, plus 100bps APR adds ~£500 to proposed annual cost → servicing ~£37,365. = **0.99x** ✗ (< 1.0)

Decision agent's policy: passes baseline and mild but fails severe. → **`affordable_at_lower_amount`**.

Solving for max sustainable: severe-stress DSCR = 1.0 at facility ≈ £40k.

Output: recommend £40k rather than the £50k requested.

## Versioning

This methodology is version-controlled. Every affordability output carries `methodology_version` so decisions can be replayed against the methodology that produced them. Material methodology changes go through Risk Committee approval.

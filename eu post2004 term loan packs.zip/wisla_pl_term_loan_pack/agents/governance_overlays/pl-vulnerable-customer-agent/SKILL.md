---
name: pl-vulnerable-customer-agent
description: |
  Detect indicators of customer vulnerability — financial, health, life events, capability — and flag for enhanced support. For SME lending the principals can be vulnerable even where the company is not. Sole traders are particularly in scope.
---

# Vulnerable Customer Agent

Vulnerability is a KNF consumer protection cross-cutting requirement. Many vulnerability signals are subtle; this agent looks across all signals consistently.

## Input contract

```yaml
vulnerability_check_request:
  case_id: string
  applicant_legal_form: enum                # limited_company | partnership | sole_trader
  principal_signals_per_director:
    - principal_id: string
      bureau_signals: [string]              # recent defaults, multiple credit applications, etc.
      application_signals: [string]         # life-event indicators in application text
      stated_vulnerabilities: [string]      # explicitly declared
```

## Output contract

```yaml
vulnerability_assessment:
  case_id: string
  vulnerability_flags:
    - principal_id: string
      flag_type: enum                       # financial | health | life_event | capability | digital_capability
      severity: enum                        # low | medium | high
      source: enum                          # bureau | application | declared | inferred
      treatment_marker: enum                # enhanced_support | clear_communication | extended_timeframe
  enhanced_support_required: boolean
  audit_ledger_entry_id: string
  reason_codes: [string]
```

## Decision logic

```
For each principal:
  Check bureau signals (recent defaults, multiple applications, etc.)
  Check application signals (life events in stated purpose, contact patterns)
  Check declared vulnerabilities

Sole traders + micro-businesses: principals' personal vulnerability is materially relevant.

If any flag at medium/high severity: enhanced_support_required = true.
```

## Worked example (Wisła Engineering Sp. z o.o. case)

Input:
```yaml
vulnerability_check_request:
  case_id: "WIS-2026-04-001"
  applicant_legal_form: limited_company
  principal_signals_per_director:
    - principal_id: DIR-001
      bureau_signals: []
      application_signals: []
      stated_vulnerabilities: []
    - principal_id: DIR-002
      bureau_signals: []
      application_signals: []
      stated_vulnerabilities: []
```

Output:
```yaml
vulnerability_assessment:
  case_id: "WIS-2026-04-001"
  vulnerability_flags: []
  enhanced_support_required: false
  audit_ledger_entry_id: "VC-2026-04-12-HE-001"
  reason_codes: ["UK_VULNERABILITY_NO_FLAGS_STANDARD_HANDLING"]
```

No vulnerability flags for Highland's directors. Standard handling. Both directors are stable, well-established, no adverse signals.

## Bright lines

- (no statutory bright lines for this agent)

## Operational rules

- Vulnerability is a sensitive attribute — handle in line with DPA 2018 + KNF guidance
- Treatment markers are advisory to channel staff, not blocking
- Declared vulnerabilities are first-class — never override applicant's own statement

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Vulnerability signal but principal disputes | Record dispute; treat per applicant's preference |


## Poland-specific operational notes

Operates within the Polish framework — KNF + NBP supervision, Consumer Credit Act, Mortgage Credit Act, AML Act enforced via GIIF.

- **BIK centrality:** Biuro Informacji Kredytowej is the largest CEE credit bureau and central to Polish consumer + SME lending. Comprehensive coverage; operational relationship essential.
- **CHF mortgage litigation legacy:** Poland's Swiss-franc mortgage saga has produced a massive ongoing court caseload (borrower-favourable CJEU + Supreme Court rulings). FX lending to unhedged retail borrowers carries litigation tail risk; legacy CHF books remain contentious.
- **Express Elixir instant payments:** Operational instant settlement; widely used.
- **profil zaufany / mojeID:** Polish e-government identity used for online onboarding.
- **PLN currency:** Outside Eurozone; floating. FX consideration material for larger facilities.
- **Cross-reference:** `country-pl-lending-policy-agent` (Country Policy Pack stub).

## Statutory hooks

- KNF FG21/1 (Vulnerable Customers)
- KNF KNF consumer protection
- Equality Act 2010 (disability)
- Poland GDPR (special category data — health)

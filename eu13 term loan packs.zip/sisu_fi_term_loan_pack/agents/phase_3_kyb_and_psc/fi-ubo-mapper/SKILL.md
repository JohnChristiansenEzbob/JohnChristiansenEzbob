---
name: fi-ubo-mapper
description: |
  Map the standard 25%+ Person of Significant Control (PSC) chain via the PRH (Trade Register) PSC register. Identifies whether further recursion is needed (corporate PSC, trust-as-PSC, overseas entity) and hands off to psc-complex-structure-recursor if so.
---

# UBO Mapper

First-pass UBO mapping. Handles the simple case (direct natural-person PSCs) and flags the complex case for the recursor.

## Input contract

```yaml
ubo_request:
  case_id: string
  company_number: string
```

## Output contract

```yaml
ubo_mapping:
  case_id: string
  company_number: string
  psc_list:
    - psc_id: string
      natural_person: boolean
      name: string
      nature_of_control: [enum]
      ownership_band: enum                  # 25-50 | 50-75 | 75-100
      notified_on: date
      country_of_residence: string
  psc_count: integer
  natural_person_pscs: integer
  non_natural_person_pscs: integer
  requires_recursion: boolean
  outcome: enum                             # mapped | recursion_required
  reason_codes: [string]
```

## Decision logic

```
Pull PSC register from PRH (Trade Register).

For each PSC entry:
  classify as natural_person or non_natural_person.

if any non_natural_person_pscs > 0:
  requires_recursion = true
  outcome = recursion_required               # hand off to psc-complex-structure-recursor
else:
  requires_recursion = false
  outcome = mapped
```

## Worked example (Sisu Engineering Oy case)

Input:
```yaml
ubo_request:
  case_id: "SIS-2026-04-001"
  company_number: "1234567-8"
```

Output:
```yaml
ubo_mapping:
  case_id: "SIS-2026-04-001"
  company_number: "1234567-8"
  psc_list:
    - psc_id: PSC-001
      natural_person: true
      name: "Lachlan MacKenzie"
      nature_of_control: ["ownership_of_shares_50_to_75_percent", "voting_rights_50_to_75_percent"]
      ownership_band: "50-75"
      notified_on: "2017-09-14"
      country_of_residence: "Scotland, Finland"
    - psc_id: PSC-002
      natural_person: true
      name: "Sarah Chen"
      nature_of_control: ["ownership_of_shares_25_to_50_percent", "voting_rights_25_to_50_percent"]
      ownership_band: "25-50"
      notified_on: "2020-04-01"
      country_of_residence: "Scotland, Finland"
  psc_count: 2
  natural_person_pscs: 2
  non_natural_person_pscs: 0
  requires_recursion: false
  outcome: mapped
  reason_codes: ["UK_UBO_MAPPED_DIRECT_NATURAL_PERSONS"]
```

Both PSCs are natural persons — no recursion needed. Maps directly to the two natural-person beneficial owners. PSC recursor will short-circuit in phase 3.

## Bright lines

- PSC register marked 'super-secure' (extremely rare; person at risk) — handle via senior compliance, do not bypass
- PSC register empty for an active company — flag for EDD (companies must declare PSCs)

## Operational rules

- If any non-natural-person PSC present, automatic handoff to psc-complex-structure-recursor
- Nature-of-control codes are taxonomic; preserve original codes alongside categorisation

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| PSC register empty | Flag; require EDD on applicant declaration of PSCs |
| PSC register internally inconsistent | Refer; require PRH (Trade Register) data quality review |


## Finland-specific operational notes

This agent operates within the Finnish lending framework — FIN-FSA (Finanssivalvonta) as unified supervisor, Credit Institutions Act for banking, Consumer Protection Act ch 7 for consumer credit, AML Act 444/2017 for AML.

- **FIN-FSA positive credit register (2024+):** Operational positive credit data register at the supervisor — uncommon in EU. Materially raises lender visibility.
- **Suomen Asiakastieto positive data:** Even before FIN-FSA register, Asiakastieto offered positive credit data — Finland was atypical for EU in this regard.
- **Bilingual constitutional requirement:** Finnish + Swedish; Swedish-speaking minority has constitutional rights to financial services in Swedish. Operational disclosure in Swedish for Swedish-speaking customers.
- **Bank-issued e-ID universal:** Finnish banks issue universal e-ID credentials used across financial services and government interactions. PSD2 SCA operationally seamless.
- **Suomi.fi authentication:** Government identity hub. Strong integration.
- **HETU privacy:** Henkilötunnus is restricted-use; over-collection or unnecessary retention is privacy breach under GDPR + Finnish Data Protection Act.
- **Cross-reference:** `country-fi-lending-policy-agent` for full FI jurisdictional context (currently a stub in the Country Policy Pack).

## Statutory hooks

- Osakeyhtiölaki (Limited Liability Companies Act) Part 21A (PSC regime)
- PRH UBO Register
- Finland AML Act 444/2017

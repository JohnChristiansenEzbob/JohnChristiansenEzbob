---
name: dk-consent-management-agent
description: |
  Capture, validate, and issue scoped consent tokens for all downstream data pulls — commercial bureau, consumer bureau (per director), Open Banking, Skattestyrelsen MTD APIs, Tingbogen. Records consent provenance and provides a revocation handle.
---

# Consent Management Agent

Without valid scoped consent, downstream agents cannot pull external data lawfully. This agent is the consent gatekeeper.

## Input contract

```yaml
consent_request:
  case_id: string
  applicant_company_number: string
  director_principal_ids: [string]
  scopes_requested:
    - bureau_commercial
    - bureau_consumer_per_director
    - open_banking
    - hmrc_mtd_vat
    - hmrc_mtd_paye
    - hmrc_mtd_ct
    - land_registry_named_directors
  consent_capture_evidence:                 # signed forms or e-sign payloads
    - scope: string
      evidence_type: enum                   # signed_form | esign | api_callback
      timestamp: datetime
      ip_address: string                    # for online consent
      signature_hash: string
```

## Output contract

```yaml
consent_token_bundle:
  case_id: string
  tokens:
    - scope: string
      token_id: string
      issued_at: datetime
      expires_at: datetime
      revocation_handle: string
      evidence_pointer: string              # link to audit evidence
  scopes_granted: [string]
  scopes_refused: [string]
  outcome: enum                             # complete | partial | consent_required
```

## Decision logic

```
For each scope_requested:
  Find matching consent_capture_evidence entry.
  Validate evidence (signature, timestamp recency, IP if online).
  If valid:
    Issue scoped token with appropriate expiry (24h to 90 days depending on scope).
    Append to tokens list.
  Else:
    Append to scopes_refused.

if all requested scopes granted: outcome = complete
elif some granted: outcome = partial
else: outcome = consent_required
```

## Worked example (Viking Engineering A/S case)

Input:
```yaml
consent_request:
  case_id: "VIK-2026-04-001"
  applicant_company_number: "12345678"
  director_principal_ids: ["DIR-001", "DIR-002"]
  scopes_requested:
    - bureau_commercial
    - bureau_consumer_per_director
    - open_banking
    - hmrc_mtd_vat
    - hmrc_mtd_paye
    - hmrc_mtd_ct
    - land_registry_named_directors
  consent_capture_evidence:
    - scope: bureau_commercial
      evidence_type: esign
      timestamp: "2026-04-12T09:14:22Z"
      ip_address: "82.x.x.x"
      signature_hash: "[hash]"
    # (similar entries for other 6 scopes)
```

Output:
```yaml
consent_token_bundle:
  case_id: "VIK-2026-04-001"
  tokens:
    - scope: bureau_commercial
      token_id: "TKN-bureau-com-2026-04-12-001"
      issued_at: "2026-04-12T09:14:30Z"
      expires_at: "2026-07-11T09:14:30Z"
      revocation_handle: "REV-001"
    # (similar entries for other 6 tokens)
  scopes_granted: [bureau_commercial, bureau_consumer_per_director, open_banking,
                   hmrc_mtd_vat, hmrc_mtd_paye, hmrc_mtd_ct, land_registry_named_directors]
  scopes_refused: []
  outcome: complete
```

All 7 scopes granted with e-signed evidence. Tokens issued with scope-appropriate expiries (bureau 90d; Skattestyrelsen ties to MTD OAuth lifecycle; Tingbogen per-query).

## Bright lines

- Consent without evidence (no signed form, no e-sign hash) — cannot issue token; refused
- Consent older than scope-specific staleness threshold — refused; require refresh

## Operational rules

- Tokens are scope-specific — never issue a single token covering multiple scopes
- Revocation handles are issued at token issuance; revocation propagates within 60 seconds
- Consent evidence is retained for 6 years post-relationship (DPA 2018 + Finanstilsynet record-keeping)
- IP-based fraud signals (unusual location, VPN exit nodes) flagged but not blocking

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| No evidence for requested scope | Refuse that scope only; other scopes unaffected |
| Evidence signature invalid | Refuse; alert to fraud agent |
| Evidence timestamp in future | Refuse; clock-skew investigation |


## Denmark-specific operational notes

This agent operates within the Danish lending framework — Finanstilsynet as unified financial supervisor, Lov om finansiel virksomhed (LOF) for banking, Kreditaftaleloven for consumer credit, Hvidvaskloven for AML.

- **Realkreditloven mortgage bond system:** Denmark's distinctive mortgage credit institution (realkreditinstitut) model issues Pfandbrief-equivalent bonds 1:1 backed by individual mortgages. Operationally different from UK SVR-based mortgage origination — fixed-rate, callable-by-borrower options dominate.
- **Outside Eurozone:** Currency is DKK, pegged to EUR via ERM II at ~7.46 DKK/EUR. Cross-border lending requires FX consideration but pegged stability reduces hedging requirement.
- **MitID universal:** Replaced NemID. Used for all online financial onboarding. Strong customer authentication is operationally seamless.
- **CPR number:** 10-digit national identifier with date of birth + gender encoded. Restricted use for identification by financial institutions.
- **No central credit register:** Bureaus are private (Experian DK, Bisnode DK, RKI for negative consumer). Multi-bureau best practice; no equivalent of UK Highland CCR.
- **e-Boks:** Digital postbox used for most government and financial communications; assume customer reads e-Boks rather than email.
- **Cross-reference:** `country-dk-lending-policy-agent` for full DK jurisdictional context (currently a stub in the Country Policy Pack).

## Statutory hooks

- Denmark GDPR Article 6 (lawful basis) + Article 7 (consent conditions)
- Data Protection Act 2018
- PSD2 / Open Banking RTS (consent requirements for account access)
- Finance Act 2017 (Skattestyrelsen MTD consent scope)


import { chromium } from 'playwright';
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '..');
const data = JSON.parse(fs.readFileSync(path.join(root, 'data', 'demo-data.json'), 'utf8'));
const framesDir = path.join(root, 'video_frames');
fs.rmSync(framesDir, { recursive: true, force: true });
fs.mkdirSync(framesDir, { recursive: true });
const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || '/usr/bin/chromium', args: ['--no-sandbox'] });
const page = await browser.newPage({ viewport: { width: 1280, height: 720 }, deviceScaleFactor: 1 });
for (let i = 0; i < data.steps.length; i++) {
  const url = pathToFileURL(path.join(root, 'standalone-demo.html')).href + '?step=' + i;
  await page.goto(url);
  await page.screenshot({ path: path.join(framesDir, `frame_${String(i).padStart(3,'0')}.png`), fullPage: false });
}
await browser.close();
const concat = data.steps.map((s,i)=>`file '${path.join(framesDir, `frame_${String(i).padStart(3,'0')}.png`).replace(/'/g,"'\\''")}'\nduration ${s.duration || 5.5}`).join('\n') + `\nfile '${path.join(framesDir, `frame_${String(data.steps.length-1).padStart(3,'0')}.png`).replace(/'/g,"'\\''")}'\n`;
fs.writeFileSync(path.join(framesDir, 'concat.txt'), concat);
const out = path.join(root, 'ezbob_highland_demo_video.mp4');
const ff = spawnSync('ffmpeg', ['-y', '-f', 'concat', '-safe', '0', '-i', path.join(framesDir, 'concat.txt'), '-vf', 'fps=8,format=yuv420p', '-c:v', 'libx264', '-preset', 'ultrafast', '-crf', '30', '-movflags', '+faststart', out], { stdio: 'inherit' });
if (ff.status !== 0) process.exit(ff.status);
console.log(out);

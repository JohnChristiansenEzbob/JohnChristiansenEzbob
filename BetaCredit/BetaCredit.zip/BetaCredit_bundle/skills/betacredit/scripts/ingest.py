#!/usr/bin/env python3
"""
ingest.py — wrap risk_models.data_ingestion.ingest() to read one or more
loan files and save a canonical df_all.parquet that notebooks 01-07 will
auto-detect.

Usage:
    # Single file → df_all.parquet
    python ingest.py path/to/loans.csv

    # Multiple files concatenated into one df_all.parquet
    python ingest.py sme.csv consumer.tsv mortgage.xlsx btl.jsonl

    # Custom output path
    python ingest.py loans.csv --out my_book.parquet

    # Force an asset class label when the file does not contain one
    python ingest.py sme.csv --asset_class sme_unsecured

Prints the IngestionResult.report for each file ingested so the user
can verify column mappings and rejections before the data flows
downstream.
"""
from __future__ import annotations
import argparse
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent.parent
sys.path.insert(0, str(ROOT / "backend"))

import pandas as pd

from risk_models.data_ingestion import ingest


def main() -> int:
    ap = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ap.add_argument("paths", nargs="+", help="One or more loan files to ingest")
    ap.add_argument("--out", default="df_all.parquet",
                    help="Output Parquet path (default: df_all.parquet)")
    ap.add_argument("--asset_class",
                    help="Apply this canonical asset_class to all input files "
                         "(useful when the files do not name it themselves)")
    args = ap.parse_args()

    frames = []
    for path in args.paths:
        print(f"\nIngesting {path} ...")
        result = ingest(path, asset_class=args.asset_class)
        print(result.report)
        frames.append(result.dataframe)

    df_all = pd.concat(frames, ignore_index=True) if len(frames) > 1 else frames[0]

    df_all.to_parquet(args.out, index=False)
    print(f"\n{'='*60}")
    print(f"Saved {len(df_all):,} rows × {df_all.shape[1]} columns → {args.out}")
    print(f"Asset class breakdown:")
    print(df_all["asset_class"].value_counts().to_string())
    print(f"\nNotebooks 01-07 will pick this up automatically on next run.")
    return 0


if __name__ == "__main__":
    sys.exit(main())

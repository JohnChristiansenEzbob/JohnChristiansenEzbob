# Reason Code Translations

Approved customer-facing translations for every reason code that can drive a decline or material amendment. Compliance-reviewed; version-controlled. The adverse-action-agent never invents customer-facing language — it slots in from this catalogue.

## Format

Each entry has:
- **Code** — the stable reason code emitted upstream
- **Customer phrase** — the plain-English translation; reading age 12
- **Counterfactual template** — what would change the outcome (substitute the customer's specifics)
- **Data sources to cite** — which sources to mention so the customer can request specifics under DSAR

## Affordability codes

### `AFF_DSCR_FAILS_BASELINE`

> Based on the financial information available to us, the regular cash available to service this loan after your existing commitments is lower than the level our policy requires.

Counterfactual: *A facility of around £{max_sustainable_amount} would be within our affordability range based on what we currently see.*

Sources to cite: filed accounts, open banking data, existing facilities visible to credit reference agencies.

### `AFF_DSCR_FAILS_SEVERE`

> The application meets our affordability checks under normal conditions, but we also test how loans would perform under tougher conditions. Under a more stressed scenario, the regular cash available to service the loan would be tight.

Counterfactual: *A smaller facility, around £{max_sustainable_amount}, would meet our stressed affordability test.*

### `AFF_INCOME_BASIS_STALE`

> Your most recent filed accounts are over nine months old, and we don't currently have other recent financial information that would let us assess affordability with confidence.

Counterfactual: *If you can share recent management accounts or connect your business bank account so we can review the last twelve months of activity, we'll be happy to reassess.*

### `AFF_OWNER_DRAWINGS_HIGH`

> Owner drawings from the business are higher than the level the business can sustainably support alongside this loan.

Counterfactual: *The picture would be different if drawings were closer to {sector_typical} for businesses of this size and sector. We can also reconsider if you can demonstrate this is a one-off rather than a normal pattern.*

## Bureau / credit history codes

### `BUREAU_CCJ_UNSATISFIED_PRESENT`

> Credit reference data shows an unsatisfied county court judgment against the business.

Counterfactual: *If the judgment has been satisfied or set aside, please ask the credit reference agency to update their records and we'll be happy to reconsider.*

Sources: Experian / Equifax / CreditSafe (specify whichever reported it).

### `BUREAU_DIRECTOR_BANKRUPTCY_HISTORICAL`

> A director's personal credit history shows a previous bankruptcy.

Counterfactual: *We may be able to reconsider some time after the bankruptcy is fully discharged. The exact criteria depend on the recency and circumstances. If you'd like to discuss, please reply to this email.*

Note: Use cautiously. Bankruptcy is a sensitive subject; the language above is deliberate to avoid implying the customer is permanently excluded.

### `BUREAU_TRADE_LINES_IN_ARREARS`

> The business has one or more existing credit accounts that are currently in arrears, according to credit reference data.

Counterfactual: *If those accounts are brought up to date and the credit reference agencies' records reflect the change, we'd be happy to reassess. If you believe the data is incorrect, the credit reference agency is the right place to challenge it; we'll reconsider once their records are corrected.*

### `BUREAU_FILED_ACCOUNTS_STALE`

> The business's accounts at Companies House are overdue.

Counterfactual: *Filing the overdue accounts would resolve this. We can reassess once Companies House shows them as current.*

## KYB codes

### `KYB_INSOLVENCY_HISTORICAL`

> Records show a previous insolvency event in the business's history.

Counterfactual: *We may be able to revisit this depending on the circumstances and how long ago it was. Please reply if you'd like to discuss the specifics.*

### `KYB_RECENTLY_INCORPORATED`

> The business was incorporated recently, and we're not yet able to assess how it's performing over a meaningful period.

Counterfactual: *Once the business has trading history and at least one set of accounts (or a meaningful period of bank account activity), we'd be happy to reconsider. In the meantime, you may have more options through start-up-focused finance providers — see the signposting at the end of this email.*

### `KYB_DECLARED_DIRECTOR_MISMATCH`

> The director(s) named on your application don't match the directors currently registered for the company at Companies House.

Counterfactual: *Please update either the application or the Companies House record so they're consistent, and we'll happily reconsider.*

Note: This is one of those flags where the explanation is usually mundane (recent director change not yet filed; clerical error). Tone should be neutral, not accusatory.

## AML / fraud codes

### `AML_PEP_FOREIGN` (where used as a contributing factor in a refer/decline)

Note: Direct disclosure of "we identified you as a politically exposed person" is sensitive and may itself trigger tipping-off concerns. Use only with compliance approval and only where the customer has made the disclosure themselves first.

> We're not able to proceed with the application at this time.

When the binding factor is genuinely AML-driven, the firm's standard practice is to be deliberately vague about the specific reason; the appropriate route for the customer to challenge is the firm's complaints procedure and (if applicable) the Information Commissioner's Office.

### `FRAUD_*`

Where any fraud-tier code is binding, use the standard generic phrasing:

> We're not able to proceed with the application at this time.

with no further detail. Disclosure of fraud signals to the applicant defeats the purpose of fraud screening. The appropriate routes are the firm's complaints procedure, DSAR, and (for filings) the Cifas Subject Access process.

## Pre-decisional gate codes

### `DEC_PRE_GATE_AML` (sanctions)

Standard generic phrasing only:

> We're not able to proceed with the application at this time.

There are reporting and freezing obligations under sanctions law that override normal explanation rights. Compliance / MLRO handles the regulatory steps.

### `DEC_PRE_GATE_KYB` (entity dissolved / in liquidation)

> Companies House records show that the company is currently {dissolved | in liquidation | in administration}.

Counterfactual: *We're unable to lend to a company in this status. If this is an error in the Companies House record, please contact Companies House to correct it.*

## Pricing / amendment codes

### `DEC_AFFORDABILITY_BINDING` (used for amendments)

> Based on our affordability assessment, we're not able to offer the full {requested_amount} you applied for, but we can offer {amount_offered}.

Counterfactual: *If a smaller facility works for you, please reply and we'll progress at {amount_offered}. If you can share additional financial information that wasn't visible to us in the assessment (recent contracts, planned revenue changes), we may be able to reconsider at a higher amount.*

## Boilerplate sections (always included)

### Right to human review

> You have the right to ask for this decision to be reviewed by a member of our team rather than relying on the automated assessment we used. To request a human review, reply to this email or call 0xxx xxx xxxx within 30 days.

### Right to access data

> You have the right to ask us for a copy of the data we used to make this decision. To request that, reply to this email and write "Data subject access request" in the subject line. We'll respond within one calendar month.

### Complaints

> If you're unhappy with how we've handled your application, our complaints procedure is here: {link}. {if FOS_eligible}: If we don't resolve your complaint to your satisfaction, you may also be able to refer it to the Financial Ombudsman Service. The FOS is a free, independent service. Their details are at financial-ombudsman.org.uk.{endif}

### Free advice signposting

> If you'd like free, independent advice on business finance options or business debt, the following services are free to use:
> - Business Debtline: businessdebtline.org / 0800 197 6026
> - Money Helper (formerly the Money Advice Service): moneyhelper.org.uk
> - Federation of Small Businesses (members): fsb.org.uk

## Versioning and update process

This catalogue is owned by Compliance with input from Risk and Customer Experience. Changes go through:
1. Drafting (proposed by anyone — Risk, CX, Compliance, Customer Operations, regulator feedback)
2. Plain English review (Crystal Mark equivalent)
3. Compliance sign-off
4. Customer testing where material change to a high-volume code
5. Version bump and rollout

Every adverse-action letter records which version of this catalogue was used. The audit trail allows replaying historical decisions against the language version that was actually applied.

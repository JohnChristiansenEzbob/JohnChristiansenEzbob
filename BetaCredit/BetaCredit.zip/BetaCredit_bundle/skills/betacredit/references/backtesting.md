# Back-Testing in BetaCredit

`CreditDecisionAgent.backtest(df)` runs the agent across a labelled DataFrame and produces a `BackTestResult` with confusion matrix, precision/recall/AUC, profit at policy, threshold sweep, and cohort breakdowns. This file explains how to read each output and what counts as a problem.

## What you need

- A DataFrame conforming to the canonical schema (notebook 00 output) **with a populated `default_flag` column**. The back-tester cannot work without realised outcomes.
- Optional but useful: `vintage_quarter` (drives cohort breakdown) and `asset_class` (drives asset-class breakdown).

## Quick start

```python
import pandas as pd
from risk_models import CreditDecisionAgent, BackTestEconomics

df = pd.read_parquet("df_all.parquet")
agent = CreditDecisionAgent()

# Defaults: £1,200 profit per good loan; £8,500 loss per defaulter
result = agent.backtest(df)
print(result.summary())

# Or with custom economics
eco = BackTestEconomics(
    approval_profit=1500,
    default_loss_per_loan=12_000,
)
result = agent.backtest(df, economics=eco)
```

## The `BackTestResult` fields

| Field | Meaning |
|---|---|
| `n_loans`, `n_actual_defaults`, `actual_default_rate` | Headline descriptive stats of the test set |
| `cm` | Confusion matrix: `{recommendation: {good: N, default: N}}` |
| `auc`, `gini` | AUC of `pd_pit_1y` against `default_flag`; Gini = 2·AUC − 1 |
| `precision_decline`, `recall_decline`, `fpr_decline`, `fnr_decline` | DECLINE policy treated as a binary classifier of defaulters |
| `precision_approve`, `recall_approve` | APPROVE policy treated as a binary classifier of goods |
| `total_profit`, `avg_profit_per_loan` | Under the supplied economics |
| `by_threshold` | DataFrame of shift_pct → (declined, approved, default_capture, profit) |
| `by_vintage` | DataFrame of vintage_quarter → (n, default_rate, approve/review/decline, mean_pd) |
| `by_asset_class` | Same shape, grouped by asset_class |
| `pd_provenance` | Where the PD model came from (synthetic vs real fit) |

## How to read the headline metrics

### AUC and Gini

The PD model's discriminative power on this dataset. Rules of thumb for UK credit:

| AUC | Interpretation |
|---|---|
| > 0.80 | Strong — production-grade |
| 0.70 – 0.80 | Acceptable for retail / SME lending |
| 0.60 – 0.70 | Weak — usable for triage but not for capital |
| 0.55 – 0.60 | Marginal — worth investigating before using |
| < 0.55 | The back-tester emits a quality warning (AUC barely above random) |

### Precision and recall of DECLINE

- **Precision** — of all loans you DECLINED, what fraction were actual defaulters? Low precision = lots of false-positive declines (good business turned away).
- **Recall** — of all actual defaulters, what fraction did you DECLINE? Low recall = lots of false-negative approvals (defaulters that got through).

In credit, recall matters more than precision because the cost of missing a defaulter (£8,500 default loss in the default economics) is much higher than the cost of turning away a good (£1,200 missed margin). A 70% recall + 30% precision policy is usually better than a 30% recall + 70% precision policy.

### Profit at policy

`total_profit = sum over loans of value_per_decision(rec, defaulted)`, where:

- APPROVE + good loan → `+approval_profit`
- APPROVE + defaulter → `-default_loss_per_loan`
- REVIEW → ~half of the approve outcomes (50/50 approximation, configurable)
- DECLINE → `decline_profit` (zero by default)

If the back-tester's profit is negative, your decline policy is too loose or your default loss assumption is too high. Negative profit on a real book is a serious signal — flag it loudly in any report.

## How to read the threshold sweep

`by_threshold` shows what happens if you shift the per-asset-class DECLINE ceiling by ±10/25/50%. Columns:

- `declined`, `approved` — what would happen to the volume mix
- `default_capture` — what fraction of actual defaulters would be caught at the new threshold
- `defaults_approved` — the corollary
- `profit` — total profit at the new threshold

Look for the threshold where profit is maximised. Often it is **looser** than the default (the default policy may decline too aggressively). When the optimum sits at one of the extremes of the sweep (-50% or +50%), the user should expand the grid.

## How to read the cohort breakdowns

`by_vintage` (when `vintage_quarter` is in the input data) shows whether the policy holds up across origination cohorts. The columns are the same per-cohort: n, default_rate, approve/review/decline counts and rates, mean_pd.

**The diagnostic move:** sort by `default_rate` descending. The worst few cohorts are where the user should drill in — what changed in underwriting, in the macro, in the customer mix? This is the question every credit committee asks.

`by_asset_class` is the same shape grouped by asset class. Use to confirm the per-asset-class default rates match the user's understanding of their book — if SME unsecured is suddenly 15% default rate, something is wrong with the data, not the model.

## The quality warning system

`result.warnings()` returns a list of human-readable warnings. They fire on:

| Warning | Trigger | What to do |
|---|---|---|
| **AUC barely above random** | `auc < 0.55` | Inspect feature distributions and default_flag polarity. The PD model may be guessing |
| **Strong overfit** | `in_sample_auc − cv_auc > 0.20` | Reduce `n_estimators` (currently 300) or add regularisation in `fit_from_dataframe()` |
| **Default rate looks inverted** | `default_rate > 0.6` | Almost certainly a polarity error (1=good, 0=bad). Flip the column before re-running |
| **Default rate near 50%** | `0.4 < default_rate < 0.6` | Possible polarity confusion; verify the column meaning |
| **Policy never DECLINES** | All loans are APPROVE or REVIEW | Thresholds too loose; use the `by_threshold` sweep to find tighter values |

When any warning fires, surface it before the headline numbers. The point of the warning system is that it would be irresponsible to quote a £profit figure that came from a model with AUC = 0.51 — the model isn't actually discriminating, the recommendations are essentially random, and the profit figure is meaningless.

## Choosing economics

The default `BackTestEconomics` (£1,200 approval profit, £8,500 default loss) is calibrated to UK SME unsecured lending. For other contexts:

| Asset class | Approval profit (£) | Default loss (£) |
|---|---|---|
| SME unsecured | 1,200 | 8,500 |
| SME secured | 3,500 | 12,000 |
| Consumer unsecured | 600 | 4,200 |
| Residential mortgage | 8,000 | 25,000 |
| Buy to let | 6,500 | 20,000 |
| Motor finance | 800 | 6,500 |
| Invoice finance | 1,500 | 5,500 |
| Asset finance | 2,800 | 11,000 |

These are order-of-magnitude figures, not a calibrated lifetime-value model. A real firm should pass its own figures based on its own historical lifetime margins and loss-given-default observations. The back-tester is most useful when the economics are calibrated to the firm's actual book — at that point the profit-at-policy number becomes a real decision aid rather than illustrative.

## What back-testing does *not* tell you

- **Whether the policy is good for the customer.** Fairness analysis is notebook 05's job; the back-tester evaluates the lender's economics.
- **Whether the model will hold up out-of-time.** Vintage breakdown reveals historical drift; it doesn't predict the future. PSI on a forward-out-of-time sample is the right diagnostic for that (notebook 02 covers it).
- **Whether the threshold sweep's "optimum" is robust.** It's the best point in a single sweep on one labelled dataset. Re-run on a held-out sample before locking in any change.

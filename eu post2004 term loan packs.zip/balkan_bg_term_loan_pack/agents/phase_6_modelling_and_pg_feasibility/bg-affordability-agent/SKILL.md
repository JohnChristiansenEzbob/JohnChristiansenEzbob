---
name: bg-affordability-agent
description: |
  Compute BNB-compliant affordability: monthly repayment burden against free cash flow, debt service coverage ratio (DSCR), surplus income after commitments. For term loans, uses TTM cash flow from NRA + OB + alt data as the base. Returns a compliant / non-compliant verdict with the calculation evidence.
---

# Affordability Agent

Statutory affordability test. The decision-pricing-agent cannot proceed to accept without an affordability pass.

## Input contract

```yaml
affordability_request:
  case_id: string
  facility_amount_bgn: integer
  facility_term_months: integer
  indicative_rate_pct: float                # tentative; will be refined post-decision
  ob_summary: object                        # from open-banking-agent
  hmrc_record: object                       # from hmrc-direct-verification-agent
  alt_data_summary: object                  # from alternative-data-agent
  existing_facility_burden_gbp_per_month: integer
  proposed_repayment_structure: enum        # capital_and_interest | interest_only_then_bullet | bullet
```

## Output contract

```yaml
affordability_assessment:
  case_id: string
  monthly_repayment_gbp: integer
  ttm_revenue_gbp: integer
  ttm_operating_cash_flow_gbp: integer
  ttm_existing_debt_service_gbp: integer
  ttm_free_cash_flow_gbp: integer
  dscr: float
  surplus_after_repayment_gbp_per_month: integer
  fca_compliant: boolean
  outcome: enum                             # affordable | marginal | unaffordable
  stress_test_passed: boolean               # at rate +200bps
  reason_codes: [string]
```

## Decision logic

```
monthly_repayment = annuity(facility_amount, term, indicative_rate)
ttm_operating_cash_flow = best estimate from NRA profit + OB net + alt data operating profit
ttm_free_cash_flow = ttm_operating_cash_flow - ttm_existing_debt_service
dscr = ttm_free_cash_flow / (12 * monthly_repayment)

stress_rate = indicative_rate + 2.0%
stress_monthly = annuity(facility_amount, term, stress_rate)
stress_dscr = ttm_free_cash_flow / (12 * stress_monthly)

if dscr >= 1.25 AND stress_dscr >= 1.10:
  outcome = affordable; fca_compliant = true
elif dscr >= 1.10 AND stress_dscr >= 1.00:
  outcome = marginal; fca_compliant = true
else:
  outcome = unaffordable; fca_compliant = false
```

## Worked example (Balkan Engineering EOOD case)

Input:
```yaml
affordability_request:
  case_id: "BAL-2026-04-001"
  facility_amount_bgn: 150000
  facility_term_months: 60
  indicative_rate_pct: 8.4
  existing_facility_burden_gbp_per_month: 1100  # for the BGN 38k existing facility to be cleared
  proposed_repayment_structure: capital_and_interest
```

Output:
```yaml
affordability_assessment:
  case_id: "BAL-2026-04-001"
  monthly_repayment_gbp: 3070
  ttm_revenue_gbp: 851300
  ttm_operating_cash_flow_gbp: 92700
  ttm_existing_debt_service_gbp: 13200
  ttm_free_cash_flow_gbp: 74400              # net of existing facility being cleared at drawdown
  dscr: 2.02
  surplus_after_repayment_gbp_per_month: 3130
  fca_compliant: true
  outcome: affordable
  stress_test_passed: true
  reason_codes: ["UK_AFFORDABILITY_AFFORDABLE_DSCR_2_02"]
```

Strong affordability. DSCR 2.02x — twice the cover. Stress test at 10.4% still passes. Existing facility cleared at drawdown so debt service decreases net.

## Bright lines

- dscr < 1.0 stressed → AUTOMATIC DECLINE (cannot demonstrate affordability under stress)
- Free cash flow negative or zero → AUTOMATIC DECLINE
- BNB-compliant calculation methodology must be documented in audit log

## Operational rules

- Use the LOWER of NRA profit + OB cash flow + alt data — conservatism
- Stress test at +200bps minimum (some lenders use +300bps for term > 60m)
- If facility has phased drawdown, model based on full-drawn position

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Cash flow data inconsistent across NRA/OB/alt | Refer; manual reconciliation needed |
| No NRA data available (recently incorporated) | Refer; cannot rely on OB alone for affordability |
| Existing debt service unverifiable | Conservative estimate; flag for verification |


## Bulgaria-specific operational notes

Operates within the Bulgarian framework — BNB + FSC supervision (ECB close cooperation since 2020), Consumer Credit Act, AML Act enforced via FID-SANS.

- **Eurozone accession imminent:** BGN runs a currency board pegged to EUR (1.95583 BGN/EUR). Eurozone accession targeted 1 January 2026 — operational EUR transition planning (dual display, conversion, system readiness) is a live consideration. Verify current accession status at time of use.
- **BNB Central Credit Register:** Mandatory central register; strong consumer + commercial visibility.
- **EGN universal identifier:** Unified civil number; restricted-use under GDPR.
- **Currency board stability:** Peg removes most FX risk vs EUR but is a fixed regime; redenomination on accession.
- **Cross-reference:** `country-bg-lending-policy-agent` (Country Policy Pack stub).

## Statutory hooks

- Consumer Credit Act (BG) 5.2A (responsible lending — consumer credit)
- BNB BNB consumer protection
- Association of Banks in Bulgaria standards for Business Customers

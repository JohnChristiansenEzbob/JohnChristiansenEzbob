---
name: dk-open-banking-agent
description: |
  Pull and analyse the applicant's bank transaction history via Open Banking AISP providers (TrueLayer, Plaid, Yapily, Tink). Returns categorised cash flow, turnover, balance trajectory, returned payments, gambling transactions, customer concentration, and volatility indicators.
---

# Open Banking Agent

Real cash flow truth. Bank account behaviour reveals what accounts and stated figures don't.

## Input contract

```yaml
ob_request:
  case_id: string
  applicant_company_number: string
  consent_token: string                     # open_banking
  lookback_months: integer                  # typically 12-24
  aisp_provider: enum                       # truelayer | plaid | yapily | tink
```

## Output contract

```yaml
ob_summary:
  case_id: string
  account:
    bank_name: string
    account_age_months: integer
  flows:
    trailing_12m_credits_gbp: integer
    trailing_12m_debits_gbp: integer
    net_12m_gbp: integer
  balance:
    average_monthly_closing_balance_gbp: integer
    minimum_balance_12m_gbp: integer
    largest_overdraft_excursion_12m_gbp: integer
  behaviour:
    returned_payments_12m: integer
    gambling_transactions_12m: integer
    gambling_amount_12m_gbp: integer
    cash_deposits_12m_gbp: integer
    salary_or_drawings_pattern: enum        # regular | irregular | absent
  customer_concentration:
    top_customer_pct: float
    top_3_customer_pct: float
  cash_flow_volatility_index: float         # 0=stable, 1=highly volatile
  reason_codes: [string]
```

## Decision logic

```
Pull last N months of transactions via AISP.
Categorise transactions (income / expense / transfer / gambling / cash / etc.).
Compute aggregates and behavioural signals.

Flags for downstream:
  - returned_payments_12m >= 3 → adverse signal
  - gambling_transactions_12m > 12 or gambling_amount > 10% of credits → adverse signal
  - top_customer_pct > 30% → concentration risk flag
  - cash_flow_volatility_index > 0.6 → high volatility flag
```

## Worked example (Viking Engineering A/S case)

Input:
```yaml
ob_request:
  case_id: "VIK-2026-04-001"
  applicant_company_number: "12345678"
  consent_token: "TKN-ob-2026-04-12-001"
  lookback_months: 18
  aisp_provider: truelayer
```

Output:
```yaml
ob_summary:
  case_id: "VIK-2026-04-001"
  account:
    bank_name: "Synthetic-Bank UK"
    account_age_months: 96
  flows:
    trailing_12m_credits_gbp: 847200
    trailing_12m_debits_gbp: 798450
    net_12m_gbp: 48750
  balance:
    average_monthly_closing_balance_gbp: 38400
    minimum_balance_12m_gbp: 12800
    largest_overdraft_excursion_12m_gbp: 0
  behaviour:
    returned_payments_12m: 1
    gambling_transactions_12m: 0
    gambling_amount_12m_gbp: 0
    cash_deposits_12m_gbp: 2400
    salary_or_drawings_pattern: regular
  customer_concentration:
    top_customer_pct: 18.4
    top_3_customer_pct: 42.1
  cash_flow_volatility_index: 0.21
  reason_codes: ["UK_OB_STABLE_CASH_FLOW_LOW_VOLATILITY"]
```

Strong OB picture for Highland. Healthy net cash flow (~DKK 49k retained over 12m), average balance DKK 38k, zero overdraft excursions, only 1 returned payment in 12 months, no gambling, regular salary/drawings, concentration within tolerance, low volatility (0.21).

## Bright lines

- (no statutory bright lines for this agent)

## Operational rules

- Re-pull required if consent older than 90 days at decision time
- Categorisation uses lender's canonical taxonomy — AISP raw categories normalised
- Multiple bank accounts: aggregate but flag if applicant has hidden any

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Consent revoked mid-pull | Use what was pulled; warn case ledger |
| AISP provider returns partial data | Flag completeness; proceed with caution |
| Applicant has 0 transactions matching credit categorisation | Refer; suspicious or new business |


## Denmark-specific operational notes

This agent operates within the Danish lending framework — Finanstilsynet as unified financial supervisor, Lov om finansiel virksomhed (LOF) for banking, Kreditaftaleloven for consumer credit, Hvidvaskloven for AML.

- **Realkreditloven mortgage bond system:** Denmark's distinctive mortgage credit institution (realkreditinstitut) model issues Pfandbrief-equivalent bonds 1:1 backed by individual mortgages. Operationally different from UK SVR-based mortgage origination — fixed-rate, callable-by-borrower options dominate.
- **Outside Eurozone:** Currency is DKK, pegged to EUR via ERM II at ~7.46 DKK/EUR. Cross-border lending requires FX consideration but pegged stability reduces hedging requirement.
- **MitID universal:** Replaced NemID. Used for all online financial onboarding. Strong customer authentication is operationally seamless.
- **CPR number:** 10-digit national identifier with date of birth + gender encoded. Restricted use for identification by financial institutions.
- **No central credit register:** Bureaus are private (Experian DK, Bisnode DK, RKI for negative consumer). Multi-bureau best practice; no equivalent of UK Highland CCR.
- **e-Boks:** Digital postbox used for most government and financial communications; assume customer reads e-Boks rather than email.
- **Cross-reference:** `country-dk-lending-policy-agent` for full DK jurisdictional context (currently a stub in the Country Policy Pack).

## Statutory hooks

- PSD2 (Open Banking RTS)
- Denmark GDPR / DPA 2018
- Finanstilsynet PERG 2.6 (AISP regulatory scope)

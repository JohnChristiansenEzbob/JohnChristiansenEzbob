---
name: ee-ubo-mapper
description: |
  Map the standard 25%+ Person of Significant Control (PSC) chain via the Äriregister (e-Business Register) PSC register. Identifies whether further recursion is needed (corporate PSC, trust-as-PSC, overseas entity) and hands off to psc-complex-structure-recursor if so.
---

# UBO Mapper

First-pass UBO mapping. Handles the simple case (direct natural-person PSCs) and flags the complex case for the recursor.

## Input contract

```yaml
ubo_request:
  case_id: string
  company_number: string
```

## Output contract

```yaml
ubo_mapping:
  case_id: string
  company_number: string
  psc_list:
    - psc_id: string
      natural_person: boolean
      name: string
      nature_of_control: [enum]
      ownership_band: enum                  # 25-50 | 50-75 | 75-100
      notified_on: date
      country_of_residence: string
  psc_count: integer
  natural_person_pscs: integer
  non_natural_person_pscs: integer
  requires_recursion: boolean
  outcome: enum                             # mapped | recursion_required
  reason_codes: [string]
```

## Decision logic

```
Pull PSC register from Äriregister (e-Business Register).

For each PSC entry:
  classify as natural_person or non_natural_person.

if any non_natural_person_pscs > 0:
  requires_recursion = true
  outcome = recursion_required               # hand off to psc-complex-structure-recursor
else:
  requires_recursion = false
  outcome = mapped
```

## Worked example (Kalev Engineering OÜ case)

Input:
```yaml
ubo_request:
  case_id: "KAL-2026-04-001"
  company_number: "12345678"
```

Output:
```yaml
ubo_mapping:
  case_id: "KAL-2026-04-001"
  company_number: "12345678"
  psc_list:
    - psc_id: PSC-001
      natural_person: true
      name: "Lachlan MacKenzie"
      nature_of_control: ["ownership_of_shares_50_to_75_percent", "voting_rights_50_to_75_percent"]
      ownership_band: "50-75"
      notified_on: "2017-09-14"
      country_of_residence: "Scotland, Estonia"
    - psc_id: PSC-002
      natural_person: true
      name: "Sarah Chen"
      nature_of_control: ["ownership_of_shares_25_to_50_percent", "voting_rights_25_to_50_percent"]
      ownership_band: "25-50"
      notified_on: "2020-04-01"
      country_of_residence: "Scotland, Estonia"
  psc_count: 2
  natural_person_pscs: 2
  non_natural_person_pscs: 0
  requires_recursion: false
  outcome: mapped
  reason_codes: ["UK_UBO_MAPPED_DIRECT_NATURAL_PERSONS"]
```

Both PSCs are natural persons — no recursion needed. Maps directly to the two natural-person beneficial owners. PSC recursor will short-circuit in phase 3.

## Bright lines

- PSC register marked 'super-secure' (extremely rare; person at risk) — handle via senior compliance, do not bypass
- PSC register empty for an active company — flag for EDD (companies must declare PSCs)

## Operational rules

- If any non-natural-person PSC present, automatic handoff to psc-complex-structure-recursor
- Nature-of-control codes are taxonomic; preserve original codes alongside categorisation

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| PSC register empty | Flag; require EDD on applicant declaration of PSCs |
| PSC register internally inconsistent | Refer; require Äriregister (e-Business Register) data quality review |


## Estonia-specific operational notes

Operates within the Estonian framework — Finantsinspektsioon supervision, Võlaõigusseadus for consumer credit, X-Road digital government infrastructure enabling real-time data access.

- **X-Road real-time access:** Most government data (registry, tax, land) is API-accessible in real-time; Estonian lending operations are faster than any other EU jurisdiction.
- **e-Residency scrutiny:** e-Resident-formed companies require enhanced UBO scrutiny — cannot default-trust as resident companies.
- **Mobile-ID / Smart-ID universal:** Strong customer authentication is operationally seamless.
- **High foreign bank penetration:** Swedbank + SEB (Swedish-owned) dominate; parent-group risk policies may overlay.
- **Cross-reference:** `country-ee-lending-policy-agent` (Country Policy Pack — fully populated).

## Statutory hooks

- Companies Act 2006 Part 21A (PSC regime)
- Äriregister beneficial owner data
- Estonia Rahapesu seadus

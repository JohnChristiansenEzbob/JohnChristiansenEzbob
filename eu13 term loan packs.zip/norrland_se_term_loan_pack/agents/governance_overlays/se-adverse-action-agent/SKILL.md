---
name: se-adverse-action-agent
description: |
  Generate decline / refer reason codes in both regulatory taxonomy and customer-facing language. Triggered when decision-pricing-agent renders a decline or refer outcome. Ensures the right-to-explanation under Sweden GDPR Article 22 is fulfilled and the LSB-compliant decline notice is prepared.
---

# Adverse Action Agent

When the answer is no, the customer (and any future ombudsman / ARN review) is entitled to know why. Adverse-action handles the why.

## Input contract

```yaml
adverse_action_request:
  case_id: string
  decision_outcome: enum                    # refer | decline
  decline_reasons: [string]                 # regulatory taxonomy reason codes
  decline_reasons_evidence:                 # which upstream agents raised each reason
    - reason_code: string
      origin_agent: string
      evidence_pointer: string
```

## Output contract

```yaml
adverse_action_output:
  case_id: string
  customer_facing_decline_letter_text: string
  reason_codes_internal: [string]
  reason_codes_customer: [string]           # plain-English translations
  right_to_explanation_text: string
  appeal_route_text: string
  bank_referral_scheme_eligibility: boolean # if declined & lender is designated
  audit_ledger_entry_id: string
  reason_codes: [string]
```

## Decision logic

```
For each regulatory reason_code:
  Look up canonical customer-facing translation.

Compose decline letter:
  - Outcome statement (clear, plain English)
  - Reasons (top 3-5, prioritised by materiality)
  - Right to explanation + request channel
  - Appeal route
  - Bank Referral Scheme notice if applicable
  - Vulnerability-aware language adjustments

Set bank_referral_scheme_eligibility based on lender designation + outcome.
```

## Worked example (Norrland Engineering AB case)

Input:
```yaml
(not triggered for Highland — accept outcome.
This agent would fire if outcome had been refer or decline.)
```

Output:
```yaml
(not triggered for Highland — accept outcome.
Example shape for a hypothetical decline:

adverse_action_output:
  case_id: "NOR-2026-04-001"
  customer_facing_decline_letter_text: "..."
  reason_codes_customer:
    - "Your business's recent trading performance does not currently meet our affordability requirements."
    - "There is an existing charge on the company that would need to be released before we could provide new funding."
  right_to_explanation_text: "..."
  appeal_route_text: "..."
  bank_referral_scheme_eligibility: true)
```

Not triggered for Highland (accept outcome). Documented here for completeness — would fire on refer / decline path.

## Bright lines

- Tipping-off cases: decline letter must NOT reveal underlying suspicion
- Customer-facing reasons cannot be more specific than regulatory codes allow

## Operational rules

- Plain English required (Flesch Reading Ease >= 60)
- Reasons prioritised by materiality, not first-discovered
- Vulnerability-aware language for flagged principals
- Appeal route must be a real working channel, not a black hole

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Reason code with no customer translation | Generic + escalate translation to product |
| Decline reasons inconsistent | Refer to compliance |


## Sweden-specific operational notes

This agent operates within the Swedish lending framework — Finansinspektionen (FI) as unified supervisor, Banking and Financing Business Act (2004:297), Konsumentkreditlag (2010:1846) for consumer credit, Lag 2017:630 for AML.

- **BankID universal:** Operationally critical. Every Swedish consumer financial interaction uses BankID for SCA. Without BankID integration, customer onboarding friction is material.
- **Swish dominance:** Swedish bank-cooperative mobile payment platform; near-universal adoption for P2P + retail payments. Significant cash displacement in Sweden.
- **UC AB near-monopoly:** Upplysningscentralen (UC AB) holds dominant position for consumer credit data. Operational relationship is essential — analogous to SCHUFA in Germany.
- **Outside Eurozone:** SEK is free-floating. Larger lending facilities may need FX hedging consideration.
- **Macroprudential amortisation requirements:** FI sets statutory amortisation requirements (amorteringskrav) for high-LTV mortgages — operationally significant for mortgage product structure.
- **High household debt:** Sweden has historically high household debt-to-income; FI macroprudential focus is operationally consequential.
- **Personnummer privacy:** Restricted-use identifier; over-collection is privacy breach.
- **Cross-reference:** `country-se-lending-policy-agent` for full SE jurisdictional context (currently a stub in the Country Policy Pack).

## Statutory hooks

- Sweden GDPR Article 22 (right to explanation for automated decisions)
- FI (Finansinspektionen) FI customer protection (consumer understanding outcome)
- Bankföreningen banking standards for Business Customers
- SBEE Act 2015 (Bank Referral Scheme on decline)

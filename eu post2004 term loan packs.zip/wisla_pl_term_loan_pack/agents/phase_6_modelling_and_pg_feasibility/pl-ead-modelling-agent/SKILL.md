---
name: pl-ead-modelling-agent
description: |
  Estimate Exposure at Default. For Poland term loans, this is largely deterministic — principal at drawdown amortising over term. For revolving credit or committed lines, includes credit conversion factor for undrawn portions. Term loans get a simple EAD profile.
---

# EAD Modelling Agent

EAD is the exposure metric for capital and ECL. For term loans it's near-trivial; kept as a separate agent for consistency and to handle non-term products.

## Input contract

```yaml
ead_request:
  case_id: string
  facility_type: enum
  facility_amount_pln: integer
  facility_term_months: integer
  drawdown_pattern: enum                    # single | phased | revolving
  undrawn_commitment_gbp: integer           # for revolving / committed
```

## Output contract

```yaml
ead_estimate:
  case_id: string
  ead_at_completion_gbp: integer
  ead_profile_over_term:                    # amortising schedule
    - month: integer
      outstanding_gbp: integer
  ead_avg_over_term_gbp: integer
  credit_conversion_factor: float           # 1.0 for term loans
  reason_codes: [string]
```

## Decision logic

```
For term_loan:
  ead_at_completion = facility_amount (fully drawn at completion)
  ead_profile = annuity_amortisation_schedule(facility_amount, term, rate)
  ead_avg = mean(ead_profile)
  credit_conversion_factor = 1.0

For revolving_credit:
  ead = drawn_estimate + (undrawn * CCF)  # CCF typically 40-75%

For asset_finance / invoice_finance:
  agent-specific logic
```

## Worked example (Wisła Engineering Sp. z o.o. case)

Input:
```yaml
ead_request:
  case_id: "WIS-2026-04-001"
  facility_type: term_loan
  facility_amount_pln: 150000
  facility_term_months: 60
  drawdown_pattern: single
  undrawn_commitment_gbp: 0
```

Output:
```yaml
ead_estimate:
  case_id: "WIS-2026-04-001"
  ead_at_completion_gbp: 150000
  ead_profile_over_term:
    - month: 0
      outstanding_gbp: 150000
    - month: 12
      outstanding_gbp: 124800
    - month: 24
      outstanding_gbp: 97200
    - month: 36
      outstanding_gbp: 67100
    - month: 48
      outstanding_gbp: 34200
    - month: 60
      outstanding_gbp: 0
  ead_avg_over_term_gbp: 78600
  credit_conversion_factor: 1.0
  reason_codes: ["UK_EAD_TERM_LOAN_AMORTISING_PROFILE"]
```

Simple amortising profile for a PLN 150k 60-month term loan. PLN 150k at completion, ~PLN 0 at maturity, time-weighted average PLN 78.6k. Used as input to ECL (in combination with PD and LGD).

## Bright lines

- (no statutory bright lines for this agent)

## Operational rules

- Term loans: EAD profile is deterministic; no model risk in this calculation
- Revolving: CCF is portfolio-calibrated; updated quarterly

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Phased drawdown: unclear timing | Use worst-case (all drawn at once); flag |
| Asset finance: depreciation profile not provided | Refer |


## Poland-specific operational notes

Operates within the Polish framework — KNF + NBP supervision, Consumer Credit Act, Mortgage Credit Act, AML Act enforced via GIIF.

- **BIK centrality:** Biuro Informacji Kredytowej is the largest CEE credit bureau and central to Polish consumer + SME lending. Comprehensive coverage; operational relationship essential.
- **CHF mortgage litigation legacy:** Poland's Swiss-franc mortgage saga has produced a massive ongoing court caseload (borrower-favourable CJEU + Supreme Court rulings). FX lending to unhedged retail borrowers carries litigation tail risk; legacy CHF books remain contentious.
- **Express Elixir instant payments:** Operational instant settlement; widely used.
- **profil zaufany / mojeID:** Polish e-government identity used for online onboarding.
- **PLN currency:** Outside Eurozone; floating. FX consideration material for larger facilities.
- **Cross-reference:** `country-pl-lending-policy-agent` (Country Policy Pack stub).

## Statutory hooks

- Basel III/IV (EAD for capital)
- IFRS 9 (ECL inputs)

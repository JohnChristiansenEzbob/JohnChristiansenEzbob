---
name: fr-ubo-mapper
description: |
  Map the standard 25%+ Person of Significant Control (PSC) chain via the Infogreffe (RCS) / INPI PSC register. Identifies whether further recursion is needed (corporate PSC, trust-as-PSC, overseas entity) and hands off to psc-complex-structure-recursor if so.
---

# UBO Mapper

First-pass UBO mapping. Handles the simple case (direct natural-person PSCs) and flags the complex case for the recursor.

## Input contract

```yaml
ubo_request:
  case_id: string
  company_number: string
```

## Output contract

```yaml
ubo_mapping:
  case_id: string
  company_number: string
  psc_list:
    - psc_id: string
      natural_person: boolean
      name: string
      nature_of_control: [enum]
      ownership_band: enum                  # 25-50 | 50-75 | 75-100
      notified_on: date
      country_of_residence: string
  psc_count: integer
  natural_person_pscs: integer
  non_natural_person_pscs: integer
  requires_recursion: boolean
  outcome: enum                             # mapped | recursion_required
  reason_codes: [string]
```

## Decision logic

```
Pull PSC register from Infogreffe (RCS) / INPI.

For each PSC entry:
  classify as natural_person or non_natural_person.

if any non_natural_person_pscs > 0:
  requires_recursion = true
  outcome = recursion_required               # hand off to psc-complex-structure-recursor
else:
  requires_recursion = false
  outcome = mapped
```

## Worked example (Marianne Engineering SAS case)

Input:
```yaml
ubo_request:
  case_id: "MAR-2026-04-001"
  company_number: "552 100 554"
```

Output:
```yaml
ubo_mapping:
  case_id: "MAR-2026-04-001"
  company_number: "552 100 554"
  psc_list:
    - psc_id: PSC-001
      natural_person: true
      name: "Lachlan MacKenzie"
      nature_of_control: ["ownership_of_shares_50_to_75_percent", "voting_rights_50_to_75_percent"]
      ownership_band: "50-75"
      notified_on: "2017-09-14"
      country_of_residence: "Scotland, France"
    - psc_id: PSC-002
      natural_person: true
      name: "Sarah Chen"
      nature_of_control: ["ownership_of_shares_25_to_50_percent", "voting_rights_25_to_50_percent"]
      ownership_band: "25-50"
      notified_on: "2020-04-01"
      country_of_residence: "Scotland, France"
  psc_count: 2
  natural_person_pscs: 2
  non_natural_person_pscs: 0
  requires_recursion: false
  outcome: mapped
  reason_codes: ["UK_UBO_MAPPED_DIRECT_NATURAL_PERSONS"]
```

Both PSCs are natural persons — no recursion needed. Maps directly to the two natural-person beneficial owners. PSC recursor will short-circuit in phase 3.

## Bright lines

- PSC register marked 'super-secure' (extremely rare; person at risk) — handle via senior compliance, do not bypass
- PSC register empty for an active company — flag for EDD (companies must declare PSCs)

## Operational rules

- If any non-natural-person PSC present, automatic handoff to psc-complex-structure-recursor
- Nature-of-control codes are taxonomic; preserve original codes alongside categorisation

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| PSC register empty | Flag; require EDD on applicant declaration of PSCs |
| PSC register internally inconsistent | Refer; require Infogreffe (RCS) / INPI data quality review |


## France-specific operational notes

This agent operates within the French lending framework — ACPR + AMF supervisory perimeter, Banque de France operating both FIBEN (commercial credit register) and FICP (consumer credit incidents register), Code monétaire et financier for banking, Code de la consommation for consumer credit (with Loi Lagarde 2010 reforms still operationally consequential).

- **FIBEN central commercial register:** Operated by Banque de France itself, not a commercial bureau. Banks contribute and consult; FIBEN gives French banks unusually rich commercial credit visibility relative to most EU peers. Reciprocity requirement applies for full query depth.
- **FICP mandatory consumer query:** Statutory mandatory before consumer credit decision; no FICP query = invalid decision.
- **Toubon Law:** Commercial contracts and consumer disclosures must be in French. Foreign-language versions can supplement but the French version is the legally operative text.
- **TAEG (APR) statutory rigour:** Code de la consommation TAEG calculation rules are statutory; mis-statement >0.2pp is material. Quarterly Banque de France usury rate ceilings (taux d'usure) per consumer credit category — exceeding is voidable contract.
- **Assurance emprunteur:** Loi Lemoine 2022 reformed mortgage insurance — borrower has right to substitute insurer; insurer commission disclosure required.
- **Cross-reference:** `country-fr-lending-policy-agent` provides full FR jurisdictional context.

## Statutory hooks

- Code de commerce + Code civil Part 21A (PSC regime)
- RBE + Loi Sapin II
- France CMF Livre V

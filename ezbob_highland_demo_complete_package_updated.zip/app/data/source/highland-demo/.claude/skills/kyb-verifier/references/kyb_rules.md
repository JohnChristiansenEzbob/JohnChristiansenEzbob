# KYB Rule Catalogue

Rules applied by `kyb-verifier`. Each rule has a code, condition, severity, and regulatory anchor.

## Severity levels

- **HARD** — emits `decision: "failed"`. Cannot proceed without manual review.
- **FLAG** — emits `decision: "verified_with_flags"`. Application proceeds; downstream agents weigh the flag.
- **INFO** — recorded in evidence; not surfaced as a flag.

## Rules

### Trading status

| Code | Condition | Severity | Anchor |
|---|---|---|---|
| `KYB_TRADING_ACTIVE` | `company_status == "active"` | INFO (positive) | MLR 2017 Reg 28 |
| `KYB_TRADING_DISSOLVED` | `company_status == "dissolved"` | HARD | MLR 2017 Reg 28 |
| `KYB_TRADING_LIQUIDATION` | `company_status in ("liquidation","receivership","administration")` | HARD | MLR 2017 Reg 28 |
| `KYB_TRADING_DORMANT` | `company_status == "dormant"` | FLAG | FCA CONC 5.2A creditworthiness |

### Filing currency

| Code | Condition | Severity | Anchor |
|---|---|---|---|
| `KYB_ACCOUNTS_CURRENT` | accounts not overdue | INFO | CA 2006 s441 |
| `KYB_ACCOUNTS_OVERDUE` | accounts past due | FLAG | CA 2006 s441 |
| `KYB_ACCOUNTS_NEVER_FILED` | incorporated > 21 months, no accounts | FLAG | CA 2006 s442 |
| `KYB_CONFIRMATION_CURRENT` | CS01 not overdue | INFO | CA 2006 s853A |
| `KYB_CONFIRMATION_OVERDUE` | CS01 overdue | FLAG | CA 2006 s853A |

### Insolvency & charges

| Code | Condition | Severity | Anchor |
|---|---|---|---|
| `KYB_INSOLVENCY_ACTIVE` | active insolvency event | HARD | Insolvency Act 1986 |
| `KYB_INSOLVENCY_HISTORICAL` | resolved insolvency in last 6 years | FLAG | FCA CONC 5.2A |
| `KYB_CHARGES_OUTSTANDING` | one or more outstanding charges | INFO | CA 2006 Pt 25 |
| `KYB_CHARGES_NONE` | no outstanding charges | INFO | — |

### SIC and sector

| Code | Condition | Severity | Anchor |
|---|---|---|---|
| `KYB_SIC_PRESENT` | at least one SIC filed | INFO | CA 2006 s853A |
| `KYB_SIC_MISSING` | no SIC filed | FLAG | MLR 2017 Reg 28 |
| `KYB_SIC_HIGH_RISK_SECTOR` | SIC matches high-risk list | FLAG | MLR 2017 Reg 33 (EDD) |

### Address & structure

| Code | Condition | Severity | Anchor |
|---|---|---|---|
| `KYB_MASS_REGISTRATION_ADDRESS` | registered office on mass-reg list | FLAG | MLR 2017 Reg 28 |
| `KYB_RECENTLY_INCORPORATED` | incorporated < 6 months ago | FLAG | FCA CONC 5.2A |
| `KYB_NAME_CHANGE_RECENT` | name changed in last 12 months | FLAG | MLR 2017 Reg 28 |
| `KYB_FOREIGN_PARENT` | parent in non-UK jurisdiction | INFO | MLR 2017 Reg 33 |

### Declared vs filed mismatches

| Code | Condition | Severity |
|---|---|---|
| `KYB_DECLARED_ADDRESS_MISMATCH` | applicant's stated trading address ≠ registered office, with no plausible explanation | FLAG |
| `KYB_DECLARED_DIRECTOR_MISMATCH` | applicant declared a director not currently appointed | FLAG |
| `KYB_DECLARED_SIC_MISMATCH` | applicant's stated activity ≠ filed SIC sector | INFO |

Note: address mismatch is common (registered office often a formation agent's address). Treat as FLAG, not HARD — and `decision-pricing-agent` should give little weight unless combined with other signals.

## Regulatory rationale

The MLR 2017 Reg 28 customer due diligence requirement is the primary anchor — banks must verify the customer's identity and the nature/purpose of the business relationship. Companies House data is the canonical source for UK-incorporated entities. Reg 33 EDD applies to higher-risk relationships, including some sectors and foreign parent structures.

FCA CONC 5.2A creditworthiness assessment requires consideration of the customer's financial situation, which begins with confirming the entity exists and trades.

Consumer Duty (PS22/9) Products and Services outcome requires that the firm understand the target market — entity verification is a precondition.

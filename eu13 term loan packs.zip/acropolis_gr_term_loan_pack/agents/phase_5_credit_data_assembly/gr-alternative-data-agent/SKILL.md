---
name: gr-alternative-data-agent
description: |
  Pull supplementary financial data from accounting platforms (Xero, QuickBooks, Sage) and trade-data providers. Returns recent management accounts, gross margin, overdue payables/receivables, and any other structured operational data the applicant has chosen to share.
---

# Alternative Data Agent

Closes the gap between filed accounts (9-12 months old) and AADE data. Management accounts give the most recent picture of operating performance.

## Input contract

```yaml
alt_data_request:
  case_id: string
  applicant_company_number: string
  platforms_connected: [enum]               # xero | quickbooks | sage
  consent_token: string
```

## Output contract

```yaml
alt_data_summary:
  case_id: string
  platforms_used: [enum]
  revenue_ttm_gbp: integer
  gross_margin_pct: float
  operating_profit_ttm_gbp: integer
  overdue_payables_gbp: integer
  overdue_receivables_gbp: integer
  days_sales_outstanding: integer
  inventory_value_gbp: integer              # nullable; goods-based businesses only
  ttm_end_period: date
  reason_codes: [string]
```

## Decision logic

```
For each connected platform:
  - pull last 12 months of P&L
  - pull aged debtors + creditors
  - pull inventory if applicable

Reconcile against bureau + OB:
  - revenue_ttm vs OB credits — should be close (within 15%)
  - if material divergence → flag for downstream cross-check
```

## Worked example (Acropolis Engineering AE case)

Input:
```yaml
alt_data_request:
  case_id: "ACR-2026-04-001"
  applicant_company_number: "1234567"
  platforms_connected: [xero]
  consent_token: "TKN-alt-xero-2026-04-12"
```

Output:
```yaml
alt_data_summary:
  case_id: "ACR-2026-04-001"
  platforms_used: [xero]
  revenue_ttm_gbp: 854100
  gross_margin_pct: 41.2
  operating_profit_ttm_gbp: 118400
  overdue_payables_gbp: 4200
  overdue_receivables_gbp: 11800
  days_sales_outstanding: 38
  inventory_value_gbp: null
  ttm_end_period: "2026-03-31"
  reason_codes: ["UK_ALT_DATA_XERO_CURRENT_PERIOD_RETRIEVED"]
```

Xero gives the very recent picture: €854k revenue TTM (matches AADE VAT €851k and OB €847k credits — excellent consistency), 41.2% gross margin, modest overdues. Strong operational picture.

## Bright lines

- (no statutory bright lines for this agent)

## Operational rules

- Cross-reference revenue against AADE VAT (where available) and OB credits — 15%+ delta is investigative
- Service businesses: gross margin proxied; inventory will be null
- Multiple platforms connected: aggregate consistently or flag discrepancy

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Platform connection broken (token expired) | Refer; user must reconnect |
| Data appears stale (last sync > 90 days) | Use but flag staleness |


## Greece-specific operational notes

This agent operates within the Greek lending framework — Bank of Greece supervisory perimeter, Banking Law 5021/2023, Law 4557/2018 for AML, post-2010 crisis NPL legacy materially shaping market structure.

- **TIRESIAS centrality:** Both consumer and commercial credit bureau roles operationally consolidated in TIRESIAS. Operational relationship is essential — no Greek consumer credit decision is meaningful without TIRESIAS visibility.
- **Post-crisis NPL legacy:** Substantial Greek NPL portfolio sold to specialist servicers (intrum, Cepal, doValue, Quant Servicer). Borrowers may have historical defaults; current creditworthiness assessment must distinguish current from historical positions.
- **Katseli Law (3869/2010):** Over-indebted households framework allowing court-supervised debt restructuring. Operationally consequential — borrowers with Katseli filings have specific protections; lending decisions must account.
- **AFM ubiquity:** Tax Registration Number (AFM) is the universal Greek financial identifier; required for any account-opening, lending, or property transaction.
- **Tax clearance certificate:** Operational must-have for business credit — proof of current tax compliance with AADE.
- **Cross-reference:** `country-gr-lending-policy-agent` for full GR jurisdictional context (currently a stub in the Country Policy Pack).

## Statutory hooks

- Greece GDPR / DPA 2018
- BoG BoG consumer protection (use of accurate, recent data)

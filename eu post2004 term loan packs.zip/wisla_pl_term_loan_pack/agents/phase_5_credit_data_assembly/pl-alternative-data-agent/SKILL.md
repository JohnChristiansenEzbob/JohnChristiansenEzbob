---
name: pl-alternative-data-agent
description: |
  Pull supplementary financial data from accounting platforms (Xero, QuickBooks, Sage) and trade-data providers. Returns recent management accounts, gross margin, overdue payables/receivables, and any other structured operational data the applicant has chosen to share.
---

# Alternative Data Agent

Closes the gap between filed accounts (9-12 months old) and KAS data. Management accounts give the most recent picture of operating performance.

## Input contract

```yaml
alt_data_request:
  case_id: string
  applicant_company_number: string
  platforms_connected: [enum]               # xero | quickbooks | sage
  consent_token: string
```

## Output contract

```yaml
alt_data_summary:
  case_id: string
  platforms_used: [enum]
  revenue_ttm_gbp: integer
  gross_margin_pct: float
  operating_profit_ttm_gbp: integer
  overdue_payables_gbp: integer
  overdue_receivables_gbp: integer
  days_sales_outstanding: integer
  inventory_value_gbp: integer              # nullable; goods-based businesses only
  ttm_end_period: date
  reason_codes: [string]
```

## Decision logic

```
For each connected platform:
  - pull last 12 months of P&L
  - pull aged debtors + creditors
  - pull inventory if applicable

Reconcile against bureau + OB:
  - revenue_ttm vs OB credits — should be close (within 15%)
  - if material divergence → flag for downstream cross-check
```

## Worked example (Wisła Engineering Sp. z o.o. case)

Input:
```yaml
alt_data_request:
  case_id: "WIS-2026-04-001"
  applicant_company_number: "KRS 0000123456"
  platforms_connected: [xero]
  consent_token: "TKN-alt-xero-2026-04-12"
```

Output:
```yaml
alt_data_summary:
  case_id: "WIS-2026-04-001"
  platforms_used: [xero]
  revenue_ttm_gbp: 854100
  gross_margin_pct: 41.2
  operating_profit_ttm_gbp: 118400
  overdue_payables_gbp: 4200
  overdue_receivables_gbp: 11800
  days_sales_outstanding: 38
  inventory_value_gbp: null
  ttm_end_period: "2026-03-31"
  reason_codes: ["UK_ALT_DATA_XERO_CURRENT_PERIOD_RETRIEVED"]
```

Xero gives the very recent picture: PLN 854k revenue TTM (matches KAS VAT PLN 851k and OB PLN 847k credits — excellent consistency), 41.2% gross margin, modest overdues. Strong operational picture.

## Bright lines

- (no statutory bright lines for this agent)

## Operational rules

- Cross-reference revenue against KAS VAT (where available) and OB credits — 15%+ delta is investigative
- Service businesses: gross margin proxied; inventory will be null
- Multiple platforms connected: aggregate consistently or flag discrepancy

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Platform connection broken (token expired) | Refer; user must reconnect |
| Data appears stale (last sync > 90 days) | Use but flag staleness |


## Poland-specific operational notes

Operates within the Polish framework — KNF + NBP supervision, Consumer Credit Act, Mortgage Credit Act, AML Act enforced via GIIF.

- **BIK centrality:** Biuro Informacji Kredytowej is the largest CEE credit bureau and central to Polish consumer + SME lending. Comprehensive coverage; operational relationship essential.
- **CHF mortgage litigation legacy:** Poland's Swiss-franc mortgage saga has produced a massive ongoing court caseload (borrower-favourable CJEU + Supreme Court rulings). FX lending to unhedged retail borrowers carries litigation tail risk; legacy CHF books remain contentious.
- **Express Elixir instant payments:** Operational instant settlement; widely used.
- **profil zaufany / mojeID:** Polish e-government identity used for online onboarding.
- **PLN currency:** Outside Eurozone; floating. FX consideration material for larger facilities.
- **Cross-reference:** `country-pl-lending-policy-agent` (Country Policy Pack stub).

## Statutory hooks

- Poland GDPR / DPA 2018
- KNF KNF consumer protection (use of accurate, recent data)

---
name: cy-kyb-verifier
description: |
  Verify the applicant company at DRCIP (Registrar of Companies) — active status, registered office currency, accounts filing currency, no strike-off proposed. Establishes the foundational fact that the company is a real, currently-trading legal entity.
---

# KYB Verifier

Foundational KYB. Everything downstream assumes the company is real and active. Cheap, fast, and decisive.

## Input contract

```yaml
kyb_request:
  case_id: string
  company_number: string
```

## Output contract

```yaml
kyb_result:
  case_id: string
  company_number: string
  status: enum                              # active | dissolved | liquidation | proposed_for_strike_off | not_found
  incorporation_date: date
  age_months: integer
  registered_office: string
  registered_office_verified: boolean
  sic_codes: [string]
  accounts_filing_status: enum              # up_to_date | overdue | first_accounts_pending
  last_accounts_made_up_to: date            # nullable
  next_accounts_due: date                   # nullable
  confirmation_statement_status: enum
  outcome: enum                             # verified | refer_filings_overdue | block_dissolved_or_strike_off
  reason_codes: [string]
```

## Decision logic

```
DRCIP (Registrar of Companies) API call by company_number.

if status in [dissolved, liquidation]:
  outcome = block_dissolved_or_strike_off

elif status == proposed_for_strike_off:
  outcome = block_dissolved_or_strike_off    # BRIGHT LINE

elif status == not_found:
  outcome = block_dissolved_or_strike_off
  reason_codes += [UK_COMPANIES_HOUSE_NOT_FOUND]

elif accounts_filing_status == overdue:
  outcome = refer_filings_overdue            # not a hard block but material

else:
  outcome = verified
```

## Worked example (Aphrodite Engineering Ltd case)

Input:
```yaml
kyb_request:
  case_id: "APH-2026-04-001"
  company_number: "HE 123456"
```

Output:
```yaml
kyb_result:
  case_id: "APH-2026-04-001"
  company_number: "HE 123456"
  status: active
  incorporation_date: "2017-09-14"
  age_months: 102
  registered_office: "Suite 4, 2 Atlantic Quay, Nicosia, G2 8GA"
  registered_office_verified: true
  sic_codes: ["71121"]
  accounts_filing_status: up_to_date
  last_accounts_made_up_to: "2025-09-30"
  next_accounts_due: "2026-06-30"
  confirmation_statement_status: up_to_date
  outcome: verified
  reason_codes: ["UK_KYB_ACTIVE_CURRENT_FILINGS"]
```

Highland is active, 102 months old (past the high-risk early years), accounts up to date, confirmation statement filed. Clean verification.

## Bright lines

- Company dissolved or in liquidation → BLOCK; no facility can be advanced
- Company proposed for strike-off → BLOCK pending applicant explanation
- Company not found at DRCIP (Registrar of Companies) → BLOCK; suspect fraud

## Operational rules

- DRCIP (Registrar of Companies) data is authoritative for legal status
- Registered office must match the applicant-declared trading address sufficiently (or have valid explanation)
- Accounts overdue is a material refer signal but not always a decline (recent incorporation, ongoing extension request)

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| DRCIP (Registrar of Companies) API timeout | Refer; retry |
| Company number invalid format | Block; data-capture should have caught this |
| Registered office unverified (PO Box, virtual office) | Refer; require physical trading address |


## Cyprus-specific operational notes

Operates within the Cypriot framework — Central Bank of Cyprus + CySEC supervision, Consumer Credit Agreements Law, AML Law enforced via MOKAS.

- **ARTEMIS centrality:** ARTEMIS Bank Information Systems is the primary Cyprus credit bureau; operational relationship is essential.
- **Post-2013 crisis legacy:** The 2013 deposit bail-in left structural scars; borrower and depositor behaviour remains crisis-aware. Historical defaults common; distinguish current from legacy positions.
- **International business sector:** Large offshore/international company presence; KYB chains frequently involve cross-border structures requiring enhanced UBO scrutiny.
- **English in commerce:** English commonly accepted alongside Greek in commercial contracts.
- **Cross-reference:** `country-cy-lending-policy-agent` (Country Policy Pack stub).

## Statutory hooks

- Companies Act 2006
- UBO Register (DRCIP) (DRCIP (Registrar of Companies) register integrity)
- Cyprus AML Law

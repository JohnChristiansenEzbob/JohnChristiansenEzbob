---
name: se-ubo-mapper
description: |
  Map the standard 25%+ Person of Significant Control (PSC) chain via the Bolagsverket PSC register. Identifies whether further recursion is needed (corporate PSC, trust-as-PSC, overseas entity) and hands off to psc-complex-structure-recursor if so.
---

# UBO Mapper

First-pass UBO mapping. Handles the simple case (direct natural-person PSCs) and flags the complex case for the recursor.

## Input contract

```yaml
ubo_request:
  case_id: string
  company_number: string
```

## Output contract

```yaml
ubo_mapping:
  case_id: string
  company_number: string
  psc_list:
    - psc_id: string
      natural_person: boolean
      name: string
      nature_of_control: [enum]
      ownership_band: enum                  # 25-50 | 50-75 | 75-100
      notified_on: date
      country_of_residence: string
  psc_count: integer
  natural_person_pscs: integer
  non_natural_person_pscs: integer
  requires_recursion: boolean
  outcome: enum                             # mapped | recursion_required
  reason_codes: [string]
```

## Decision logic

```
Pull PSC register from Bolagsverket.

For each PSC entry:
  classify as natural_person or non_natural_person.

if any non_natural_person_pscs > 0:
  requires_recursion = true
  outcome = recursion_required               # hand off to psc-complex-structure-recursor
else:
  requires_recursion = false
  outcome = mapped
```

## Worked example (Norrland Engineering AB case)

Input:
```yaml
ubo_request:
  case_id: "NOR-2026-04-001"
  company_number: "556677-8899"
```

Output:
```yaml
ubo_mapping:
  case_id: "NOR-2026-04-001"
  company_number: "556677-8899"
  psc_list:
    - psc_id: PSC-001
      natural_person: true
      name: "Lachlan MacKenzie"
      nature_of_control: ["ownership_of_shares_50_to_75_percent", "voting_rights_50_to_75_percent"]
      ownership_band: "50-75"
      notified_on: "2017-09-14"
      country_of_residence: "Scotland, Sweden"
    - psc_id: PSC-002
      natural_person: true
      name: "Sarah Chen"
      nature_of_control: ["ownership_of_shares_25_to_50_percent", "voting_rights_25_to_50_percent"]
      ownership_band: "25-50"
      notified_on: "2020-04-01"
      country_of_residence: "Scotland, Sweden"
  psc_count: 2
  natural_person_pscs: 2
  non_natural_person_pscs: 0
  requires_recursion: false
  outcome: mapped
  reason_codes: ["UK_UBO_MAPPED_DIRECT_NATURAL_PERSONS"]
```

Both PSCs are natural persons — no recursion needed. Maps directly to the two natural-person beneficial owners. PSC recursor will short-circuit in phase 3.

## Bright lines

- PSC register marked 'super-secure' (extremely rare; person at risk) — handle via senior compliance, do not bypass
- PSC register empty for an active company — flag for EDD (companies must declare PSCs)

## Operational rules

- If any non-natural-person PSC present, automatic handoff to psc-complex-structure-recursor
- Nature-of-control codes are taxonomic; preserve original codes alongside categorisation

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| PSC register empty | Flag; require EDD on applicant declaration of PSCs |
| PSC register internally inconsistent | Refer; require Bolagsverket data quality review |


## Sweden-specific operational notes

This agent operates within the Swedish lending framework — Finansinspektionen (FI) as unified supervisor, Banking and Financing Business Act (2004:297), Konsumentkreditlag (2010:1846) for consumer credit, Lag 2017:630 for AML.

- **BankID universal:** Operationally critical. Every Swedish consumer financial interaction uses BankID for SCA. Without BankID integration, customer onboarding friction is material.
- **Swish dominance:** Swedish bank-cooperative mobile payment platform; near-universal adoption for P2P + retail payments. Significant cash displacement in Sweden.
- **UC AB near-monopoly:** Upplysningscentralen (UC AB) holds dominant position for consumer credit data. Operational relationship is essential — analogous to SCHUFA in Germany.
- **Outside Eurozone:** SEK is free-floating. Larger lending facilities may need FX hedging consideration.
- **Macroprudential amortisation requirements:** FI sets statutory amortisation requirements (amorteringskrav) for high-LTV mortgages — operationally significant for mortgage product structure.
- **High household debt:** Sweden has historically high household debt-to-income; FI macroprudential focus is operationally consequential.
- **Personnummer privacy:** Restricted-use identifier; over-collection is privacy breach.
- **Cross-reference:** `country-se-lending-policy-agent` for full SE jurisdictional context (currently a stub in the Country Policy Pack).

## Statutory hooks

- Aktiebolagslag (2005:551) Part 21A (PSC regime)
- AML Act 2017:630 + Bolagsverket UBO
- Sweden Lag 2017:630

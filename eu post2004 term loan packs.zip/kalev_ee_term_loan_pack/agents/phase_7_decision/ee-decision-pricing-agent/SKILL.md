---
name: ee-decision-pricing-agent
description: |
  The credit decision engine. Synthesises every upstream output into an accept / refer / decline outcome with base pricing. Captures conditions raised upstream (existing charge clearance, Etridge process, equipment specification) as drawdown conditions. Generates the reason-code set for adverse-action handling if applicable.
---

# Decision and Base Pricing Agent

The decision. Everything upstream feeds here, and this agent's output is the answer.

## Input contract

```yaml
decision_request:
  case_id: string
  principal_aggregate_assessment: object    # from multi-principal-fan-out-orchestrator
  kyb_result: object
  psc_resolved_structure: object
  hmrc_verification_record: object
  open_banking_summary: object
  bureau_composite: object
  alt_data_summary: object
  prior_security_schedule: object           # from charges-register
  affordability_assessment: object
  pd_score: object
  lgd_estimate: object
  ead_estimate: object
  risk_rating: object
  pg_feasibility_outcomes: [object]         # per principal
```

## Output contract

```yaml
credit_decision:
  case_id: string
  outcome: enum                             # accept | accept_with_conditions | refer | decline
  approved_amount_eur: integer              # nullable on decline
  approved_term_months: integer             # nullable on decline
  indicative_rate_pct: float                # nullable on decline; base rate from risk grade
  conditions:                               # accept_with_conditions populates this
    - condition_id: string
      condition_text: string
      origin_agent: string                  # which upstream agent raised it
      timing: enum                          # pre_drawdown | at_drawdown | post_drawdown
  reason_codes: [string]
  decline_reasons: [string]                 # populated on refer/decline; feeds adverse-action-agent
  next_phase: enum                          # phase_8_offer_construction | refer_review | decline_dispatch
```

## Decision logic

```
Check for any hard blockers in upstream output:
  - principal_aggregate.aggregate_outcome in [block_and_sar, block_pg_bearer_difficulty, block_phoenix] → decline
  - kyb_result.outcome == block_dissolved_or_strike_off → decline
  - psc_resolved_structure.outcome == eccta_non_compliance_block → decline
  - hmrc.outcome == decline_paye_arrears → decline
  - affordability.fca_compliant == false → decline

Check for refer signals (cumulative):
  - principal_aggregate.aggregate_outcome == refer → refer
  - hmrc.outcome == refer_hmrc_arrears → refer
  - charges_register.outcome contains refer_subordination → refer if no committed clearance
  - bureau.composite_rating == weak → refer
  - risk_rating.pricing_tier == tier_3_subprime → refer (typical policy)

If no blockers and no refers:
  outcome = accept_with_conditions (if any conditions raised) OR accept
  approved_amount = facility_amount
  approved_term = facility_term
  indicative_rate = base_rate(risk_rating.composite_grade) + small_adjustments

Collect all conditions from upstream:
  - existing_floating_charge to clear → charges-register raised it
  - Etridge process → pg-feasibility raised it
  - equipment specification → purpose-validation raised it
```

## Worked example (Kalev Engineering OÜ case)

Input:
```yaml
(see all upstream agent outputs — assembled into decision_request)
```

Output:
```yaml
credit_decision:
  case_id: "KAL-2026-04-001"
  outcome: accept_with_conditions
  approved_amount_eur: 150000
  approved_term_months: 60
  indicative_rate_pct: 8.4
  conditions:
    - condition_id: COND-001
      condition_text: "Existing floating charge to First-Bank Plc (€38,000) to be released at drawdown; satisfaction letter from First-Bank Plc required."
      origin_agent: charges-register-and-prior-security-agent
      timing: at_drawdown
    - condition_id: COND-002
      condition_text: "Personal guarantee from Lachlan MacKenzie (€90,000): Etridge process required — independent legal advice to spouse Eilidh MacKenzie from a solicitor not acting for the bank, certified in writing, BEFORE PG signing."
      origin_agent: personal-guarantee-feasibility-agent
      timing: pre_drawdown
    - condition_id: COND-003
      condition_text: "Personal guarantee from Sarah Chen (€60,000): standard process — sole property, no Etridge requirement."
      origin_agent: personal-guarantee-feasibility-agent
      timing: pre_drawdown
    - condition_id: COND-004
      condition_text: "Equipment specification (Phased Array Estonia Ltd quote) to be finalised before drawdown for inclusion in security schedule."
      origin_agent: purpose-validation-agent
      timing: pre_drawdown
  reason_codes:
    - UK_CREDIT_DECISION_ACCEPT_WITHIN_POLICY
    - UK_PG_ETRIDGE_BOLAND_PROCESS_REQUIRED_DIR_001
    - UK_EXISTING_FLOATING_CHARGE_TO_BE_RELEASED_AT_DRAWDOWN
    - UK_EQUIPMENT_SPECIFICATION_PENDING
  decline_reasons: []
  next_phase: phase_8_offer_construction
```

Accept with 4 conditions. Two of the conditions (Etridge process, existing charge clearance) are MATERIAL — they go to the LSB Standards guarantee transparency requirement and the Boland case law. Without these conditions surfaced pre-decision, the application would either have been auto-accepted with hidden risk OR discovered at signing.

## Bright lines

- Any upstream block_ outcome → AUTOMATIC DECLINE
- Finantsinspektsioon-non-compliant affordability → AUTOMATIC DECLINE
- Reason codes are the authoritative basis for adverse-action notices
- Approved amount cannot exceed requested amount (cannot 'top up' against customer's interest)

## Operational rules

- Indicative rate is base + small adjustments; sme-pricing-strategy-agent finalises pricing within commercial guardrails
- Conditions are immutable once decision rendered (changes require new decision cycle)
- Reason codes are taxonomic — drawn from a controlled vocabulary, not freeform
- Decline path triggers adverse-action-agent for customer notice + Bank Referral Scheme dispatch

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Any upstream agent failed to return | Refer; cannot decide on partial information |
| Conditions list internally inconsistent | Refer; manual reconciliation |
| Risk-adjusted return < threshold | Refer; not commercially viable |


## Estonia-specific operational notes

Operates within the Estonian framework — Finantsinspektsioon supervision, Võlaõigusseadus for consumer credit, X-Road digital government infrastructure enabling real-time data access.

- **X-Road real-time access:** Most government data (registry, tax, land) is API-accessible in real-time; Estonian lending operations are faster than any other EU jurisdiction.
- **e-Residency scrutiny:** e-Resident-formed companies require enhanced UBO scrutiny — cannot default-trust as resident companies.
- **Mobile-ID / Smart-ID universal:** Strong customer authentication is operationally seamless.
- **High foreign bank penetration:** Swedbank + SEB (Swedish-owned) dominate; parent-group risk policies may overlay.
- **Cross-reference:** `country-ee-lending-policy-agent` (Country Policy Pack — fully populated).

## Statutory hooks

- Finantsinspektsioon Finantsinspektsioon consumer protection (4 outcomes)
- Estonian Banking Association standards for Business Customers
- Krediidiandjate seadus + Võlaõigusseadus ch 22 (where applicable — sole traders, small partnerships)
- Estonia GDPR Article 22 (automated decision-making)
- Finantsinspektsioon model risk supervision (model use governance)

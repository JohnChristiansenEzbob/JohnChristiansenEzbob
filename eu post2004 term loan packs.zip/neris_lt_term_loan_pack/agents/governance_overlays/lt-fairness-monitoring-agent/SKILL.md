---
name: lt-fairness-monitoring-agent
description: |
  Monitor decision outcomes for fairness across protected attribute proxies (region, deprivation index, SIC code where it correlates with protected attributes). Returns demographic parity statistics, drift indicators, and any breach signals. Operates per-case (current decision vs portfolio baseline) and aggregate (rolling portfolio statistics).
---

# Fairness Monitoring Agent

Continuous fairness oversight. EU AI Act + Lietuvos Bankas Lietuvos Bankas consumer protection + (where applicable) Equality Act 2010 require demonstrable fairness in automated credit decisioning.

## Input contract

```yaml
fairness_check_request:
  case_id: string
  decision_outcome: enum                    # accept | refer | decline
  applicant_attributes_proxy:
    region: string
    deprivation_quintile: integer           # IMD 1-5
    sic_code: string
  portfolio_baseline_ref: string            # reference to current baseline snapshot
```

## Output contract

```yaml
fairness_check_result:
  case_id: string
  this_case_in_distribution: boolean
  demographic_parity_delta: float           # vs baseline
  drift_indicators:
    region_drift: boolean
    deprivation_drift: boolean
    sic_drift: boolean
  within_tolerance: boolean
  alert_required: boolean
  audit_ledger_entry_id: string
  reason_codes: [string]
```

## Decision logic

```
Compare this case's outcome distribution against portfolio baseline.
Compute demographic parity delta on each protected attribute proxy.

Tolerance thresholds (configurable):
  - region parity delta <= 0.05 (5%)
  - deprivation parity delta <= 0.05
  - sic parity delta <= 0.05

if any delta > tolerance: drift_indicator = true

Rolling alerts:
  - Sustained drift >4 weeks → alert + reportable under AI Directive 2024
  - Single case in extreme outlier → flag for manual review
```

## Worked example (Neris Engineering UAB case)

Input:
```yaml
fairness_check_request:
  case_id: "NER-2026-04-001"
  decision_outcome: accept
  applicant_attributes_proxy:
    region: "GB-SCT"
    deprivation_quintile: 4                # mid-upper (Milngavie postcode)
    sic_code: "71121"
  portfolio_baseline_ref: "fairness_baseline_2026Q1"
```

Output:
```yaml
fairness_check_result:
  case_id: "NER-2026-04-001"
  this_case_in_distribution: true
  demographic_parity_delta: 0.03
  drift_indicators:
    region_drift: false
    deprivation_drift: false
    sic_drift: false
  within_tolerance: true
  alert_required: false
  audit_ledger_entry_id: "FM-2026-04-12-HE-001"
  reason_codes: ["UK_FAIRNESS_WITHIN_TOLERANCE"]
```

This single case is within distribution and consistent with baseline. No drift signals. No alert required. Audit ledger updated.

## Bright lines

- Sustained breach >4 weeks → MUST notify Lietuvos Bankas + reportable under (where applicable) AI Algorithmic Directive

## Operational rules

- Protected attribute proxies, not protected attributes themselves (cannot collect race/ethnicity for credit)
- Baseline refreshed quarterly
- Per-case alerts are advisory; portfolio alerts are mandatory action

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Baseline data stale | Use cautiously; flag refresh required |
| Outlier case but no clear protected attribute correlation | Flag for human review |


## Lithuania-specific operational notes

Operates within the Lithuanian framework — Lietuvos Bankas as unified supervisor, Vartojimo kredito įstatymas for consumer credit, fintech-friendly regulatory posture.

- **Fintech sandbox:** Fast-track EMI/PI licensing, English-language regulator engagement. Lithuania is the preferred EU base for many fintechs — but supervision is correspondingly rigorous.
- **CENTROlink:** Bank of Lithuania's SEPA gateway gives non-bank PSPs direct SCT Inst access — unique-in-EU advantage.
- **Fintech-licensed counterparties:** Verify Lietuvos Bankas registration; ~80+ EMI/PI licences issued.
- **Rate caps:** Post-2016 statutory APR caps tightened significantly; market consolidation followed.
- **Cross-reference:** `country-lt-lending-policy-agent` (Country Policy Pack — fully populated).

## Statutory hooks

- Equality Act 2010 (indirect discrimination via correlated attributes)
- Lietuvos Bankas Lietuvos Bankas consumer protection
- EU AI Act (high-risk classification — credit scoring) where applicable
- Lietuvos Bankas model risk supervision

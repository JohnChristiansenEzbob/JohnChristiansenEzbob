---
name: ro-aml-screening-agent
description: |
  Screen a single natural-person principal against sanctions lists (Romanian + EU consolidated list, UN, EU, US OFAC where applicable), Politically Exposed Persons (PEPs) registers, and adverse media. Returns clear / hit / review verdict.
---

# AML Screening Agent

Statutory AML screening. Every natural-person principal must be screened.

## Input contract

```yaml
aml_request:
  principal_id: string
  case_id: string
  name: string
  prior_names: [string]                     # nullable
  dob: date
  nationality: string
  country_of_residence: string
```

## Output contract

```yaml
aml_result:
  principal_id: string
  sanctions_check:
    ofsi: enum                              # clear | hit | review
    un: enum
    eu: enum
    ofac: enum                              # if scope warrants
  peps_check:
    status: enum                            # clear | domestic_pep | foreign_pep | family_close_associate
    pep_country: string                     # nullable
  adverse_media_check:
    status: enum                            # clear | minor | material
    sources: [string]                       # nullable
  composite_status: enum                    # clear | hit | review
  reason_codes: [string]
```

## Decision logic

```
Screen name (+ prior names) + DOB against:
  - Romanian + EU consolidated list (UK)
  - UN sanctions list
  - EU sanctions list
  - OFAC SDN list (where principal's nationality / residence in scope)
  - PEPs register (typically World-Check or similar)
  - Adverse media (last 5 years)

if ANY sanctions list returns a confirmed hit:
  composite_status = hit                     # BRIGHT LINE

elif PEPs status in [foreign_pep, family_close_associate]:
  composite_status = review                  # mandatory EDD

elif adverse_media_check.status == material:
  composite_status = review

else:
  composite_status = clear
```

## Worked example (Carpathia Engineering SRL case)

Input:
```yaml
aml_request:
  principal_id: DIR-001
  case_id: "CAR-2026-04-001"
  name: "Lachlan MacKenzie"
  dob: "1981-03-22"
  nationality: "British"
  country_of_residence: "Scotland, Romania"
```

Output:
```yaml
aml_result:
  principal_id: DIR-001
  sanctions_check:
    ofsi: clear
    un: clear
    eu: clear
    ofac: clear
  peps_check:
    status: clear
    pep_country: null
  adverse_media_check:
    status: clear
    sources: []
  composite_status: clear
  reason_codes: ["UK_AML_CLEAR_ALL_LISTS"]
```

Clean AML screen. Both principals return clear across all lists. If a sanctions hit had appeared, the multi-principal-fan-out-orchestrator would aggregate to block_and_sar (bright line).

## Bright lines

- Romanian + EU consolidated list hit → BLOCK (mandatory under Romania financial sanctions regime)
- UN / EU / OFAC hit (within applicable jurisdictional scope) → BLOCK
- Tipping-off rule: customer-facing communication must not reveal the underlying reason

## Operational rules

- Fuzzy matching with name variations + transliteration handled by the screening engine
- Confirmed hits require MLRO sign-off before any case action
- False positives recorded with disposition for future model tuning
- PEPs status is not a decline trigger per se but mandates enhanced due diligence (EDD)

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Screening engine unavailable | Refer; cannot proceed without screening |
| Match returned with low confidence | Manual review by MLRO; do not auto-block or auto-clear |


## Romania-specific operational notes

Operates within the Romanian framework — BNR + ASF supervision, OUG 50/2010 for consumer credit, OUG 52/2016 for mortgage credit, Legea 129/2019 for AML.

- **Biroul de Credit + CRC dual registers:** Biroul de Credit (private, consumer) + Centrala Riscului de Credit (BNR-operated central). Combined visibility.
- **CNP universal identifier:** Cod numeric personal; restricted-use under GDPR.
- **Prima Casă / Noua Casă legacy:** State-guaranteed mortgage schemes shape mortgage origination expectations.
- **ANPC consumer protection:** National Authority for Consumer Protection active in financial services.
- **RON currency:** Outside Eurozone; floating. FX consideration material.
- **Cross-reference:** `country-ro-lending-policy-agent` (Country Policy Pack stub).

## Statutory hooks

- Romania Legea 129/2019 (AML Law)
- Romania Sanctions and Anti-Money Laundering Act 2018
- Financial Sanctions Notice (Romanian + EU)
- BNR SYSC 6.3
- Proceeds of Crime Act 2002 (POCA) — tipping-off and SAR obligations

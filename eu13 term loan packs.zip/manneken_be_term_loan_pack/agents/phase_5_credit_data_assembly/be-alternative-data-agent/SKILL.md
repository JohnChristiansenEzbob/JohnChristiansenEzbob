---
name: be-alternative-data-agent
description: |
  Pull supplementary financial data from accounting platforms (Xero, QuickBooks, Sage) and trade-data providers. Returns recent management accounts, gross margin, overdue payables/receivables, and any other structured operational data the applicant has chosen to share.
---

# Alternative Data Agent

Closes the gap between filed accounts (9-12 months old) and SPF Finances / FOD Financiën data. Management accounts give the most recent picture of operating performance.

## Input contract

```yaml
alt_data_request:
  case_id: string
  applicant_company_number: string
  platforms_connected: [enum]               # xero | quickbooks | sage
  consent_token: string
```

## Output contract

```yaml
alt_data_summary:
  case_id: string
  platforms_used: [enum]
  revenue_ttm_gbp: integer
  gross_margin_pct: float
  operating_profit_ttm_gbp: integer
  overdue_payables_gbp: integer
  overdue_receivables_gbp: integer
  days_sales_outstanding: integer
  inventory_value_gbp: integer              # nullable; goods-based businesses only
  ttm_end_period: date
  reason_codes: [string]
```

## Decision logic

```
For each connected platform:
  - pull last 12 months of P&L
  - pull aged debtors + creditors
  - pull inventory if applicable

Reconcile against bureau + OB:
  - revenue_ttm vs OB credits — should be close (within 15%)
  - if material divergence → flag for downstream cross-check
```

## Worked example (Manneken Engineering NV/SA case)

Input:
```yaml
alt_data_request:
  case_id: "MAN-2026-04-001"
  applicant_company_number: "0123.456.789"
  platforms_connected: [xero]
  consent_token: "TKN-alt-xero-2026-04-12"
```

Output:
```yaml
alt_data_summary:
  case_id: "MAN-2026-04-001"
  platforms_used: [xero]
  revenue_ttm_gbp: 854100
  gross_margin_pct: 41.2
  operating_profit_ttm_gbp: 118400
  overdue_payables_gbp: 4200
  overdue_receivables_gbp: 11800
  days_sales_outstanding: 38
  inventory_value_gbp: null
  ttm_end_period: "2026-03-31"
  reason_codes: ["UK_ALT_DATA_XERO_CURRENT_PERIOD_RETRIEVED"]
```

Xero gives the very recent picture: €854k revenue TTM (matches SPF Finances / FOD Financiën VAT €851k and OB €847k credits — excellent consistency), 41.2% gross margin, modest overdues. Strong operational picture.

## Bright lines

- (no statutory bright lines for this agent)

## Operational rules

- Cross-reference revenue against SPF Finances / FOD Financiën VAT (where available) and OB credits — 15%+ delta is investigative
- Service businesses: gross margin proxied; inventory will be null
- Multiple platforms connected: aggregate consistently or flag discrepancy

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Platform connection broken (token expired) | Refer; user must reconnect |
| Data appears stale (last sync > 90 days) | Use but flag staleness |


## Belgium-specific operational notes

This agent operates within the Belgian lending framework — NBB (prudential, including CKP operation) and FSMA (conduct) twin peaks, Code de droit économique Books VII (consumer) + VIII (KBO), Loi du 18 septembre 2017 for AML.

- **Regional language obligation:** SECCI and contract MUST be in the customer's regional language — French (Wallonie), Dutch (Flanders), German (Eastern Cantons), or bilingual (Brussels Capital). This is statutory and contracts in the wrong language are invalid.
- **CKP mandatory consumer query:** Statutory mandatory before consumer credit decision; non-query invalidates agreement. NBB-operated central consumer credit register.
- **Statutory rate caps:** Code de droit économique Book VII sets statutory rate caps per consumer credit category — exceeding is contract invalidity.
- **itsme universal:** Belgian mobile identity platform widely adopted; integrates with PSD2 SCA. Most consumer onboarding uses itsme.
- **Cooperative + commercial bank mix:** Belfius (state-related cooperative legacy), KBC (cooperative origin), BNP Paribas Fortis (commercial), ING Belgium — diverse market structure.
- **Cross-reference:** `country-be-lending-policy-agent` provides full BE jurisdictional context.

## Statutory hooks

- Belgium GDPR / DPA 2018
- FSMA Code de droit économique Book VII (use of accurate, recent data)

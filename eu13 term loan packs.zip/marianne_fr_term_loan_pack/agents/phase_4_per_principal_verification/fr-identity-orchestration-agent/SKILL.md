---
name: fr-identity-orchestration-agent
description: |
  Verify the identity of a single natural-person principal — typically via document verification, biometric liveness, and database cross-checks (electoral roll, credit header). Returns a verification verdict plus a confidence score. Invoked by multi-principal-fan-out-orchestrator for each director / PSC.
---

# Identity Orchestration Agent

Foundational per-principal check. Get identity wrong and the whole AML/KYC chain is compromised.

## Input contract

```yaml
identity_request:
  principal_id: string
  case_id: string
  name: string
  prior_names: [string]                     # nullable
  dob: date
  current_residential_address: string
  prior_addresses_3y: [string]              # nullable
  nationality: string
  document_evidence:                        # provided by applicant at intake
    - doc_type: enum                        # passport | driving_licence | brp | residence_permit
      doc_number: string
      expiry: date
      front_image_pointer: string
      back_image_pointer: string            # nullable for passports
  biometric_evidence: string                # selfie image pointer
  consent_token: string                     # bureau header consent
```

## Output contract

```yaml
identity_verification:
  principal_id: string
  identity_verified: boolean
  confidence: float                         # 0.0 - 1.0
  document_check:
    doc_type: enum
    authenticity_score: float
    tampering_signals: [string]
  biometric_check:
    liveness_passed: boolean
    facial_match_score: float
  database_check:
    electoral_roll_match: boolean
    credit_header_match: boolean
    name_match: boolean
    address_match: boolean
    dob_match: boolean
  outcome: enum                             # verified | refer | hard_fail
  reason_codes: [string]
```

## Decision logic

```
Document check: authenticity + tampering signals.
Biometric check: liveness + facial match to document photo.
Database check: cross-reference against electoral roll and credit header.

if document_check.authenticity_score < 0.5 OR len(tampering_signals) > 0:
  outcome = hard_fail
elif biometric_check.liveness_passed == false:
  outcome = hard_fail
elif biometric_check.facial_match_score < 0.7:
  outcome = refer
elif database_check.name_match AND database_check.address_match AND database_check.dob_match:
  outcome = verified
  confidence = composite_score(all_checks)
else:
  outcome = refer
```

## Worked example (Marianne Engineering SAS case)

Input:
```yaml
identity_request:
  principal_id: DIR-001
  case_id: "MAR-2026-04-001"
  name: "Lachlan MacKenzie"
  dob: "1981-03-22"
  current_residential_address: "12 Strathblane Road, Milngavie, Paris, G62 8DJ"
  nationality: "British"
  document_evidence:
    - doc_type: passport
      doc_number: "[redacted]"
      expiry: "2028-06-14"
      front_image_pointer: "doc_evidence://DIR-001/passport/front.jpg"
  biometric_evidence: "biometric_evidence://DIR-001/selfie.jpg"
  consent_token: "TKN-bureau-con-2026-04-12-DIR-001"
```

Output:
```yaml
identity_verification:
  principal_id: DIR-001
  identity_verified: true
  confidence: 0.97
  document_check:
    doc_type: passport
    authenticity_score: 0.98
    tampering_signals: []
  biometric_check:
    liveness_passed: true
    facial_match_score: 0.94
  database_check:
    electoral_roll_match: true
    credit_header_match: true
    name_match: true
    address_match: true
    dob_match: true
  outcome: verified
  reason_codes: ["UK_IDENTITY_VERIFIED_HIGH_CONFIDENCE"]
```

Strong identity verification: authentic passport, high biometric match, all database checks corroborate. Composite confidence 0.97. Sarah Chen (DIR-002) returns similar shape with confidence 0.98.

## Bright lines

- Document tampering signals present → hard_fail; case held
- Liveness check failed (static image, replay) → hard_fail
- Name/DOB on document does not match application → hard_fail

## Operational rules

- Image evidence retained per DPA 2018 for as long as relationship plus 6 years
- Failed verifications are auditable — must record reason, not just outcome
- Where applicant has changed name (marriage etc.), verify both names

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Document image quality too poor | Refer; request reupload |
| Database lookups all return no match | Refer; could be valid (new resident) but needs human |
| Address declared mismatches all databases | Refer to fraud agent |


## France-specific operational notes

This agent operates within the French lending framework — ACPR + AMF supervisory perimeter, Banque de France operating both FIBEN (commercial credit register) and FICP (consumer credit incidents register), Code monétaire et financier for banking, Code de la consommation for consumer credit (with Loi Lagarde 2010 reforms still operationally consequential).

- **FIBEN central commercial register:** Operated by Banque de France itself, not a commercial bureau. Banks contribute and consult; FIBEN gives French banks unusually rich commercial credit visibility relative to most EU peers. Reciprocity requirement applies for full query depth.
- **FICP mandatory consumer query:** Statutory mandatory before consumer credit decision; no FICP query = invalid decision.
- **Toubon Law:** Commercial contracts and consumer disclosures must be in French. Foreign-language versions can supplement but the French version is the legally operative text.
- **TAEG (APR) statutory rigour:** Code de la consommation TAEG calculation rules are statutory; mis-statement >0.2pp is material. Quarterly Banque de France usury rate ceilings (taux d'usure) per consumer credit category — exceeding is voidable contract.
- **Assurance emprunteur:** Loi Lemoine 2022 reformed mortgage insurance — borrower has right to substitute insurer; insurer commission disclosure required.
- **Cross-reference:** `country-fr-lending-policy-agent` provides full FR jurisdictional context.

## Statutory hooks

- France CMF Livre V (customer due diligence — identity verification)
- RBE + Loi Sapin II (director identity verification)
- France GDPR (biometric data is special category — explicit consent + minimisation)

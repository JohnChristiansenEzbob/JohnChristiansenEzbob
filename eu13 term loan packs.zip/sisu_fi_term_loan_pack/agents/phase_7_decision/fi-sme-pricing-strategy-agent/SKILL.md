---
name: fi-sme-pricing-strategy-agent
description: |
  Apply risk-based pricing within commercial guardrails. Takes the decision-pricing-agent's indicative rate as base and applies pricing strategy overlays: competitive positioning, broker compensation, floor/ceiling checks, fair-value verification under FIN-FSA customer protection.
---

# SME Pricing Strategy Agent

Final pricing. Same risk grade can warrant different pricing depending on competitive context, broker channel, and customer relationship history.

## Input contract

```yaml
pricing_request:
  case_id: string
  indicative_rate_pct: float                # base from decision-pricing-agent
  risk_rating: object
  facility_amount_eur: integer
  facility_term_months: integer
  channel: enum                             # broker | branch | online
  broker_commission_structure: object       # nullable
  competitive_context:
    peer_avg_rate_for_grade_pct: float
    market_position_target: enum            # match | above | below
```

## Output contract

```yaml
pricing_outcome:
  case_id: string
  final_rate_pct: float
  arrangement_fee_pct: float
  broker_commission_pct: float              # if broker channel
  effective_apr_pct: float
  within_commercial_band: boolean
  fair_value_check_passed: boolean
  adjustments_applied: [string]
  reason_codes: [string]
```

## Decision logic

```
final_rate = indicative_rate

Apply competitive adjustment:
  if market_position_target == match: final_rate = peer_avg_rate
  elif above: final_rate = max(indicative_rate, peer_avg_rate + 0.5)
  elif below: final_rate = min(indicative_rate, peer_avg_rate - 0.25)

Floor: final_rate >= product_floor (cost of funds + margin minimum)
Ceiling: final_rate <= grade_ceiling (consumer duty fair value)

Arrangement fee per product policy (typically 0.5-2.0%).
Broker commission per accreditation tier.

Effective APR computed (Suomen Pankki methodology).

Fair value check:
  - APR vs peer benchmark
  - Total cost over term vs facility amount
  - Customer Duty 'price + value' outcome
```

## Worked example (Sisu Engineering Oy case)

Input:
```yaml
pricing_request:
  case_id: "SIS-2026-04-001"
  indicative_rate_pct: 8.4
  risk_rating: {composite_grade: B+, pricing_tier: tier_1_prime}
  facility_amount_eur: 150000
  facility_term_months: 60
  channel: broker
  broker_commission_structure: {tier: accredited, base_pct: 1.5}
  competitive_context:
    peer_avg_rate_for_grade_pct: 8.6
    market_position_target: match
```

Output:
```yaml
pricing_outcome:
  case_id: "SIS-2026-04-001"
  final_rate_pct: 8.4
  arrangement_fee_pct: 1.0
  broker_commission_pct: 1.5
  effective_apr_pct: 9.5
  within_commercial_band: true
  fair_value_check_passed: true
  adjustments_applied: []
  reason_codes: ["UK_PRICING_TIER_1_PRIME_COMPETITIVE_MATCH"]
```

Final rate 8.4% — competitive match to peer benchmark of 8.6% (slight outperform). Arrangement fee 1.0%, broker commission 1.5% (standard accredited tier). Effective APR 9.5%. Fair value check passes.

## Bright lines

- Rate < product floor → AUTOMATIC REFER; unviable
- Rate > grade ceiling → fair value challenge under FIN-FSA customer protection
- Broker commission > 3% → escalate (commission disclosure)

## Operational rules

- Final pricing is committee-approved policy not agent-discretionary above 0.5% deviation from indicative
- Broker channel pricing accounts for commission as part of customer-borne cost (transparency)
- Pricing reviewed monthly against market benchmark

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Competitive context data stale (>30 days) | Use cautiously; flag |
| Peer benchmark inversion (peer rate < cost of funds) | Refer; possible distressed market |


## Finland-specific operational notes

This agent operates within the Finnish lending framework — FIN-FSA (Finanssivalvonta) as unified supervisor, Credit Institutions Act for banking, Consumer Protection Act ch 7 for consumer credit, AML Act 444/2017 for AML.

- **FIN-FSA positive credit register (2024+):** Operational positive credit data register at the supervisor — uncommon in EU. Materially raises lender visibility.
- **Suomen Asiakastieto positive data:** Even before FIN-FSA register, Asiakastieto offered positive credit data — Finland was atypical for EU in this regard.
- **Bilingual constitutional requirement:** Finnish + Swedish; Swedish-speaking minority has constitutional rights to financial services in Swedish. Operational disclosure in Swedish for Swedish-speaking customers.
- **Bank-issued e-ID universal:** Finnish banks issue universal e-ID credentials used across financial services and government interactions. PSD2 SCA operationally seamless.
- **Suomi.fi authentication:** Government identity hub. Strong integration.
- **HETU privacy:** Henkilötunnus is restricted-use; over-collection or unnecessary retention is privacy breach under GDPR + Finnish Data Protection Act.
- **Cross-reference:** `country-fi-lending-policy-agent` for full FI jurisdictional context (currently a stub in the Country Policy Pack).

## Statutory hooks

- FIN-FSA FIN-FSA customer protection (price + value outcome)
- Financial Promotions regime (representative APR disclosure)
- Broker commission disclosure (LSB Standards)

# Post-2004 EU Accession Country Term Loan Agent Packs

13 country-specific term loan agent packs for the post-2004 EU accession
countries, each following the Highland UK structure (46 agents, 8 phases +
governance overlays).

## Packs

- 2004 enlargement (10): Cyprus (Aphrodite), Czech Republic (Vltava),
  Estonia (Kalev), Hungary (Danube), Latvia (Daugava), Lithuania (Neris),
  Malta (Melita), Poland (Wisła), Slovakia (Tatra), Slovenia (Triglav)
- 2007 enlargement (2): Bulgaria (Balkan), Romania (Carpathia)
- 2013 enlargement (1): Croatia (Adriatic)

46 agents x 13 countries = 598 agents.

## Currency split
- Eurozone: CY, EE, LV, LT, MT, SK, SI, HR (EUR)
- Own currency: CZ (CZK), HU (HUF), PL (PLN), RO (RON)
- Currency board peg / accession imminent: BG (BGN -> EUR targeted 1 Jan 2026)

## Combined EU programme status
- Pre-2004 EU-15: UK (Highland) + IE (Hibernia) + 13 more = 15 packs
- Post-2004: 13 packs (this bundle)
- TOTAL: 28 country packs = 1,288 SKILL.md agents across all EU/EEA jurisdictions + UK

A 28-jurisdiction comparison facts dict is included (_country_facts_28.json).

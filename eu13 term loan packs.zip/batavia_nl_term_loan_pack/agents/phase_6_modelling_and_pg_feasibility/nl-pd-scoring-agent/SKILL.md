---
name: nl-pd-scoring-agent
description: |
  Produce a Probability of Default (PD) score for the applicant company over a 12-month horizon. Uses a calibrated portfolio model — typically a gradient-boosted classifier or logistic regression — combining bureau, OB, Belastingdienst, alt data, and company features. Output is calibrated to portfolio default rates.
---

# PD Scoring Agent

The probabilistic backbone of the credit decision. PD drives pricing, capital, and the policy thresholds.

## Input contract

```yaml
pd_request:
  case_id: string
  company_features:
    age_months: integer
    sic_code_primary: string
    region: string
  bureau_composite: object                  # from bureau-orchestration-agent
  ob_summary: object                        # from open-banking-agent
  hmrc_record: object                       # from hmrc-direct-verification-agent
  alt_data_summary: object                  # from alternative-data-agent
  macro_overlay_period: string              # e.g. "2026Q2" — affects calibration
```

## Output contract

```yaml
pd_score:
  case_id: string
  pd_12m: float                             # 0.0 - 1.0
  pd_percentile_portfolio: integer          # 0-100
  portfolio_grade: enum                     # A | B+ | B | C+ | C | D | E
  model_version: string                     # e.g. "SME_TermLoan_PD_v4.2"
  top_5_drivers:                            # SHAP-style attribution
    - feature: string
      contribution_pct: float
  model_assumptions:
    macro_overlay_period: string
    calibration_date: date
  reason_codes: [string]
```

## Decision logic

```
Assemble feature vector from all inputs.
Apply model_version against feature vector.
Return calibrated PD + grade based on portfolio thresholds.
Generate top-5 SHAP attributions for explainability.

Portfolio grade mapping (example):
  PD < 1.0%: A
  PD 1.0-2.5%: B+
  PD 2.5-5%: B
  PD 5-10%: C+
  PD 10-20%: C
  PD 20-40%: D
  PD > 40%: E
```

## Worked example (Batavia Engineering B.V. case)

Input:
```yaml
pd_request:
  case_id: "BAT-2026-04-001"
  company_features:
    age_months: 102
    sic_code_primary: "71121"
    region: "GB-SCT"
  bureau_composite: {composite_rating: solid, ...}
  ob_summary: {cash_flow_volatility_index: 0.21, ...}
  hmrc_record: {ttm_turnover_gbp: 851300, ...}
  alt_data_summary: {gross_margin_pct: 41.2, ...}
  macro_overlay_period: "2026Q2"
```

Output:
```yaml
pd_score:
  case_id: "BAT-2026-04-001"
  pd_12m: 0.018
  pd_percentile_portfolio: 68               # better than 68% of portfolio
  portfolio_grade: B+
  model_version: "SME_TermLoan_PD_v4.2"
  top_5_drivers:
    - feature: bureau_composite_rating
      contribution_pct: 22.4
    - feature: hmrc_ttm_turnover_consistency
      contribution_pct: 18.1
    - feature: company_age_months
      contribution_pct: 14.6
    - feature: cash_flow_volatility_index
      contribution_pct: 11.8
    - feature: receivables_concentration_ratio
      contribution_pct: 9.2
  model_assumptions:
    macro_overlay_period: "2026Q2"
    calibration_date: "2026-01-15"
  reason_codes: ["UK_PD_12M_1_8_PCT_GRADE_B_PLUS"]
```

PD 1.8% maps to portfolio grade B+. Top drivers: solid bureau composite, consistent Belastingdienst turnover, mature company age, low cash flow volatility, strong trade references. Standard pricing band.

## Bright lines

- (no statutory bright lines for this agent)

## Operational rules

- Model versions are governed under SR 11-7 / DNB model risk supervision + ECB SREP + Joint BoI/ISA AI Directive (where applicable)
- Top-5 drivers must be returned for explainability and adverse action notices
- Macro overlay refreshed quarterly by the model risk team
- PD output capped at 99.9% (no 100% predictions)

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Feature vector incomplete (>10% missing) | Refer; model not reliable with high missingness |
| Model version stale (>6 months since refresh) | Use but flag; ops to refresh |
| Macro overlay unavailable | Use prior period; flag |


## Netherlands-specific operational notes

This agent operates within the Dutch lending framework — DNB (prudential) and AFM (conduct) twin peaks supervision, Wft (Wet financieel toezicht) as foundational, BW Book 7 sections 57-73 for consumer credit, Wwft for AML.

- **Twin peaks supervision:** DNB handles prudential, AFM handles conduct. Operational engagement is with both, not unified. Different reporting cadences and supervisory styles.
- **BKR query:** Functional gate for consumer credit; AFM expects it. Stichting BKR governance includes member contribution + consultation.
- **NIBUD norms:** Operational affordability standard for consumer credit (Nationaal Instituut voor Budgetvoorlichting). AFM expects NIBUD adherence; deviations require documented justification.
- **NHG (Nationale Hypotheek Garantie):** State guarantee scheme for mortgages below €435,000 (2026 threshold); provides materially lower risk weight + rate. Eligibility independently verified.
- **LTI/LTV macroprudential limits:** Set by DNB; statutory and enforced. LTV typically 100% for first home, lower for subsequent; LTI tightened post-2013.
- **Aflossingsvrij mortgages:** Historically dominant interest-only product; affordability stress testing must account for non-amortising structure.
- **Cross-reference:** `country-nl-lending-policy-agent` provides full NL jurisdictional context.

## Statutory hooks

- DNB model risk supervision + ECB SREP (model risk management)
- AFM AFM AFK 2.0 (use of accurate models)
- EU AI Act (high-risk classification — credit scoring) — relevant for EU customer scope
- Netherlands GDPR Article 22 (right to explanation for automated decisions)

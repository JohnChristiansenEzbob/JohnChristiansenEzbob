---
name: nl-ead-modelling-agent
description: |
  Estimate Exposure at Default. For Netherlands term loans, this is largely deterministic — principal at drawdown amortising over term. For revolving credit or committed lines, includes credit conversion factor for undrawn portions. Term loans get a simple EAD profile.
---

# EAD Modelling Agent

EAD is the exposure metric for capital and ECL. For term loans it's near-trivial; kept as a separate agent for consistency and to handle non-term products.

## Input contract

```yaml
ead_request:
  case_id: string
  facility_type: enum
  facility_amount_eur: integer
  facility_term_months: integer
  drawdown_pattern: enum                    # single | phased | revolving
  undrawn_commitment_gbp: integer           # for revolving / committed
```

## Output contract

```yaml
ead_estimate:
  case_id: string
  ead_at_completion_gbp: integer
  ead_profile_over_term:                    # amortising schedule
    - month: integer
      outstanding_gbp: integer
  ead_avg_over_term_gbp: integer
  credit_conversion_factor: float           # 1.0 for term loans
  reason_codes: [string]
```

## Decision logic

```
For term_loan:
  ead_at_completion = facility_amount (fully drawn at completion)
  ead_profile = annuity_amortisation_schedule(facility_amount, term, rate)
  ead_avg = mean(ead_profile)
  credit_conversion_factor = 1.0

For revolving_credit:
  ead = drawn_estimate + (undrawn * CCF)  # CCF typically 40-75%

For asset_finance / invoice_finance:
  agent-specific logic
```

## Worked example (Batavia Engineering B.V. case)

Input:
```yaml
ead_request:
  case_id: "BAT-2026-04-001"
  facility_type: term_loan
  facility_amount_eur: 150000
  facility_term_months: 60
  drawdown_pattern: single
  undrawn_commitment_gbp: 0
```

Output:
```yaml
ead_estimate:
  case_id: "BAT-2026-04-001"
  ead_at_completion_gbp: 150000
  ead_profile_over_term:
    - month: 0
      outstanding_gbp: 150000
    - month: 12
      outstanding_gbp: 124800
    - month: 24
      outstanding_gbp: 97200
    - month: 36
      outstanding_gbp: 67100
    - month: 48
      outstanding_gbp: 34200
    - month: 60
      outstanding_gbp: 0
  ead_avg_over_term_gbp: 78600
  credit_conversion_factor: 1.0
  reason_codes: ["UK_EAD_TERM_LOAN_AMORTISING_PROFILE"]
```

Simple amortising profile for a €150k 60-month term loan. €150k at completion, ~€0 at maturity, time-weighted average €78.6k. Used as input to ECL (in combination with PD and LGD).

## Bright lines

- (no statutory bright lines for this agent)

## Operational rules

- Term loans: EAD profile is deterministic; no model risk in this calculation
- Revolving: CCF is portfolio-calibrated; updated quarterly

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Phased drawdown: unclear timing | Use worst-case (all drawn at once); flag |
| Asset finance: depreciation profile not provided | Refer |


## Netherlands-specific operational notes

This agent operates within the Dutch lending framework — DNB (prudential) and AFM (conduct) twin peaks supervision, Wft (Wet financieel toezicht) as foundational, BW Book 7 sections 57-73 for consumer credit, Wwft for AML.

- **Twin peaks supervision:** DNB handles prudential, AFM handles conduct. Operational engagement is with both, not unified. Different reporting cadences and supervisory styles.
- **BKR query:** Functional gate for consumer credit; AFM expects it. Stichting BKR governance includes member contribution + consultation.
- **NIBUD norms:** Operational affordability standard for consumer credit (Nationaal Instituut voor Budgetvoorlichting). AFM expects NIBUD adherence; deviations require documented justification.
- **NHG (Nationale Hypotheek Garantie):** State guarantee scheme for mortgages below €435,000 (2026 threshold); provides materially lower risk weight + rate. Eligibility independently verified.
- **LTI/LTV macroprudential limits:** Set by DNB; statutory and enforced. LTV typically 100% for first home, lower for subsequent; LTI tightened post-2013.
- **Aflossingsvrij mortgages:** Historically dominant interest-only product; affordability stress testing must account for non-amortising structure.
- **Cross-reference:** `country-nl-lending-policy-agent` provides full NL jurisdictional context.

## Statutory hooks

- Basel III/IV (EAD for capital)
- IFRS 9 (ECL inputs)

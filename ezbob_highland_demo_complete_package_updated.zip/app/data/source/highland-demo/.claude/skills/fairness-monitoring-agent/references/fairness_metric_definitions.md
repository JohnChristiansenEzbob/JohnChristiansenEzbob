# Fairness Metric Definitions

Formal definitions, computation, and interpretation of the group-fairness metrics used by `fairness-monitoring-agent`. These are the metrics with operational thresholds in the firm's policy.

## Notation

For a binary classification (approve / decline):
- `Y` ∈ {0, 1}: true outcome (1 = would have repaid, 0 = would have defaulted) — observable only for vintaged cohorts
- `Ŷ` ∈ {0, 1}: predicted outcome / decision (1 = approve, 0 = decline)
- `A` ∈ groups: the protected or policy segment

## Statistical Parity Difference (SPD)

```
SPD = P(Ŷ = 1 | A = a) − P(Ŷ = 1 | A = b)
```

The difference in approval rates between groups. Range −1 to 1.

**Tests:** equality of acceptance.

**Threshold (firm policy):** |SPD| < 0.05 between any two groups in the same protected dimension.

**Limitation:** Does not account for any underlying difference in base rates between groups. If group A genuinely has a higher repayment rate than group B (e.g. due to wealth, sector concentration, or structural factors entirely outside any individual customer's control), enforcing equal SPD would mean lending to higher-risk applicants in group B than group A — which can itself be a form of harm. SPD is a screening signal, not a target.

## Disparate Impact Ratio (DIR)

```
DIR = P(Ŷ = 1 | A = a) / P(Ŷ = 1 | A = b)
```

The ratio of approval rates. Convention: numerator is the group with the lower rate, so DIR ∈ [0, 1]. The "four-fifths rule" (DIR < 0.8) comes from US EEOC guidance and is widely cited but has no formal status in UK law.

**Tests:** same as SPD, on a ratio scale rather than difference scale.

**Threshold (firm policy):** DIR > 0.80 between any two groups in the same protected dimension.

**Limitation:** Same as SPD plus the ratio scale can be misleading when overall approval rates are low (a 1pp gap on a 5% base is a DIR of 0.80, which sounds like the threshold but represents a tiny absolute gap).

## Equal Opportunity Difference (EOD)

```
EOD = TPR(A = a) − TPR(A = b)
where TPR(A = g) = P(Ŷ = 1 | Y = 1, A = g)
```

The difference in true-positive rate (approval rate among customers who would have repaid) between groups. Range −1 to 1.

**Tests:** equality of treatment for those who deserve approval.

**Threshold (firm policy):** |EOD| < 0.05 between any two groups in the same protected dimension.

**Requires:** observed outcomes (vintaged cohort). For new model deployments, this is unavailable until vintages mature; rely on SPD and DIR initially with EOD added at vintage maturity (typically 12–18 months).

**Why often preferred to SPD:** EOD is consistent with the firm legitimately declining higher-risk applicants — the metric only compares people who in fact repaid. A gap on EOD is harder to explain away as "different base rates" because the conditioning is already on the same outcome.

## Predictive Parity (calibration parity)

```
For each predicted-PD bucket b:
  observed default rate(A = a, b) ≈ observed default rate(A = b, b) ≈ predicted PD(b)
```

Tests whether the model's predicted PDs are equally accurate across groups.

**Threshold (firm policy):** for each PD bucket, |observed default rate by group − predicted PD| / predicted PD < 0.20, and the per-group observed rates within a bucket are within ±20% of each other.

**Important property:** when base rates differ across groups, predictive parity is mathematically incompatible with EOD parity (Chouldechova 2017; Kleinberg-Mullainathan-Raghavan 2016). The firm cannot satisfy both simultaneously; choose intentionally and document the choice.

## Treatment Equality

```
TE = (FN/FP)(A = a) − (FN/FP)(A = b)
```

The ratio of false negatives to false positives, by group. A group with a high FN/FP ratio is being declined unnecessarily relative to a group with a low FN/FP ratio.

**Tests:** equality of error trade-off.

**Threshold:** the firm doesn't run a hard threshold here; tracks for trend.

## Fair value (Consumer Duty angle)

```
For each risk-grade bucket b and group:
  median(APR | grade = b, A = g)
```

Compare the median APR offered to similar-risk customers across groups. Material gaps (> 50bps for the same internal grade) are flagged as Consumer Duty fair-value concerns.

**Threshold:** median APR difference < 50bps for same internal grade and same product/term.

## Counterfactual fairness (sample-based)

For a sampled set of approved and declined cases:
- Generate a counterfactual where only the protected-characteristic-correlated features are changed
- Re-run the decision pipeline
- Record any decision flips

**Threshold:** flip rate against any protected group < 2% on a sample of ≥ 200.

**Limitation:** Counterfactuals leak through correlations — changing "inferred sex" while leaving "name" unchanged is not a clean counterfactual. The agent's counterfactual sample is informative as a corroborating signal, not a single source of truth.

## Confidence intervals

For each metric, compute a 95% CI:
- For SPD and DIR: Wilson or Wald interval on the underlying proportions, propagated
- For EOD: same, conditioned on Y = 1
- For predictive parity: Hosmer-Lemeshow or expected-vs-observed CIs

**Operational rule:** a metric is only reported as "failed" if the threshold breach is statistically significant at the 95% level. Borderline cases (point estimate breaches threshold but CI crosses it) are reported as `marginal` with a recommendation to extend the observation window.

## Sample size requirements

Group sizes < 50 produce noisy metrics. Operational guidance:
- < 30 per group: do not report metric for that segment in that period; note "insufficient sample size" in the report
- 30–100: report with widened CIs; flag as `low_confidence`
- 100–500: standard reporting
- 500+: full statistical power

## Multi-period rolling windows

For small protected-characteristic groups, operational stability is improved by reporting a 3-month or 6-month rolling window rather than month-by-month. The agent's report explicitly states the window used.

## What to do with a failed metric

A failed metric is not by itself a finding of discrimination. Investigate:

1. **Is the conditioning variable properly captured?** Inferred sex from title is noisy; postcode IMD decile is noisy across multiple dimensions.
2. **Is there a legitimate underlying driver?** A sector with high default rates may be over-represented among one group; the gap reflects the sector, not the group.
3. **Is the driver, in turn, a proxy for the protected characteristic?** Postcode is correlated with ethnicity in the UK; bureau thin-file rates differ by socio-economic status. If a "neutral" feature is doing the work of a protected characteristic, the legal test under Equality Act 2010 indirect discrimination is whether the criterion is a proportionate means of achieving a legitimate aim.
4. **Document the determination and the actions.** Either: continue monitoring (gap is statistically reliable but legitimate); or remediate (gap is driven by an unfair proxy or unjustifiable model behaviour).

The agent surfaces the gap. The investigation is a human task. The firm's Risk Committee and the second-line MRM function are the canonical forum for the determination.

## References

- Chouldechova, A. (2017). Fair prediction with disparate impact. *Big Data*, 5(2).
- Kleinberg, J., Mullainathan, S., Raghavan, M. (2016). Inherent trade-offs in the fair determination of risk scores.
- ICO (UK): Guidance on AI and data protection.
- FCA Discussion Paper 22/4 on AI.
- EU AI Act Article 15 (high-risk AI systems: accuracy, robustness, cybersecurity).
- Equality Act 2010, sections 13 (direct discrimination) and 19 (indirect discrimination).

---
name: se-floating-charge-valuation-agent
description: |
  Value a proposed floating charge over the applicant company's asset base. Takes the
  company's working assets (inventory, receivables, plant & machinery, intangibles, cash)
  and applies liquidation-scenario haircuts to produce a realistic recoverable estimate
  for the lender at the prospective security rank. Distinct from charges-register-and-
  prior-security-agent which discovers EXISTING charges; this agent values the NEW
  floating charge the lender is taking.
---

# Floating Charge Valuation Agent

In Sweden SME term lending, an all-asset debenture (giving a floating charge plus fixed
charges where possible) is the most common security beyond personal guarantees. Its
value depends critically on what the company actually owns and what those assets would
realise in a liquidation scenario, NOT on book value.

## Input contract

```yaml
floating_charge_valuation_request:
  case_id: string
  applicant_company_number: string
  asset_base:
    cash_and_equivalents_gbp: integer
    receivables_book_gbp: integer
    receivables_aged_60_plus_pct: float       # >60d ageing as fraction
    inventory_book_gbp: integer               # nullable for services businesses
    inventory_type: enum                      # raw_materials | wip | finished_goods | not_applicable
    plant_and_machinery_nbv_gbp: integer
    plant_and_machinery_age_years: float
    intangibles_book_gbp: integer             # goodwill, IP, brand
    investment_property_gbp: integer          # nullable
  prospective_rank: enum                      # first | second | third | unsecured_in_practice
  industry_sic_primary: string
  geographic_region: string                   # GB-SCT, GB-ENG, etc.
```

## Output contract

```yaml
floating_charge_valuation:
  case_id: string
  asset_realisations:
    cash_realisable_gbp: integer              # ~100% subject to existing claims
    receivables_realisable_gbp: integer       # post-collection-haircut
    inventory_realisable_gbp: integer         # post-liquidation-haircut
    plant_realisable_gbp: integer             # secondary market value
    intangibles_realisable_gbp: integer       # typically minimal
    investment_property_realisable_gbp: integer
  gross_realisable_gbp: integer
  realisation_costs_gbp: integer              # liquidator fees, legal, sale costs
  prescribed_part_carve_out_gbp: integer      # unsecured creditor share (s176A Insolvency Act 1986)
  net_realisable_floating_gbp: integer        # final value for this lender at this rank
  recovery_ratio_to_facility: float
  reason_codes: [string]
```

## Decision logic

```
For each asset class, apply liquidation haircut:
  cash:           realisable = book × 0.95     (minor reconciliation losses)
  receivables:    realisable = book × (1 - aged_60_plus_pct) × 0.65
                  (collection in liquidation is hard; aged debt rarely recovers)
  inventory:      realisable = book × inventory_haircut[type]
                  raw_materials: 0.30 | wip: 0.15 | finished_goods: 0.45
                  not_applicable (services): 0
  plant:          realisable = nbv × age_haircut(age_years)
                  age 0-2y: 0.55 | 2-5y: 0.40 | 5-10y: 0.25 | >10y: 0.15
  intangibles:    realisable = book × 0.05     (goodwill rarely transfers)
  inv_property:   realisable = book × 0.85 (RICS forced sale ~85%)

Sum gross_realisable.
realisation_costs = max(SEK 15,000, gross_realisable × 0.10)   (liquidator + legal + sale)

Prescribed part carve-out (Enterprise Act 2002 / s176A IA 1986):
  if net floating > SEK 10,000:
    prescribed_part = min(SEK 800,000, 50% of first SEK 10k + 20% of next SEK 2,990,000)
  set aside for unsecured creditors

if prospective_rank == "first":
  net_realisable = gross_realisable - realisation_costs - prescribed_part
elif prospective_rank == "second":
  net_realisable = max(0, gross_realisable - realisation_costs - prescribed_part - prior_charge_outstanding)
else:
  net_realisable = 0 (deeply subordinated → unsecured in practice)
```

## Worked example (Norrland Engineering AB)

Input (post-drawdown position, with existing First-Bank floating charge cleared):
```yaml
floating_charge_valuation_request:
  case_id: "NOR-2026-04-001"
  applicant_company_number: "556677-8899"
  asset_base:
    cash_and_equivalents_gbp: 38400               # OB avg balance
    receivables_book_gbp: 88900                   # ~38 DSO × monthly revenue
    receivables_aged_60_plus_pct: 0.08
    inventory_book_gbp: 0                         # services business
    inventory_type: not_applicable
    plant_and_machinery_nbv_gbp: 60000            # testing equipment to be acquired
    plant_and_machinery_age_years: 0.0            # newly acquired at drawdown
    intangibles_book_gbp: 12000                   # capitalised dev costs
    investment_property_gbp: 0
  prospective_rank: first                          # after existing charge cleared
  industry_sic_primary: "71121"
  geographic_region: "GB-SCT"
```

Output:
```yaml
floating_charge_valuation:
  case_id: "NOR-2026-04-001"
  asset_realisations:
    cash_realisable_gbp: 36500                    # 38400 × 0.95
    receivables_realisable_gbp: 53200             # 88900 × 0.92 × 0.65
    inventory_realisable_gbp: 0
    plant_realisable_gbp: 33000                   # 60000 × 0.55 (new equipment)
    intangibles_realisable_gbp: 600
    investment_property_realisable_gbp: 0
  gross_realisable_gbp: 123300
  realisation_costs_gbp: 15000                    # minimum
  prescribed_part_carve_out_gbp: 27660            # ~22% effective on net
  net_realisable_floating_gbp: 80640
  recovery_ratio_to_facility: 0.54                # vs SEK 150k facility
  reason_codes: ["UK_FLOATING_CHARGE_FIRST_RANK_AFTER_PRIOR_CLEARANCE"]
```

The floating charge would realise approximately SEK 80k net to the lender — about 54% of
the SEK 150k facility. Note the prescribed-part carve-out: under s176A IA 1986 (Enterprise
Act 2002), 50% of the first SEK 10k + 20% of the next SEK 2.99m of floating-charge realisations
is set aside for unsecured creditors. Lenders forget this; the agent does not.

## Bright lines

- Prospective rank ≠ first AND no committed clearance of prior charge → realisable = 0; security is symbolic
- Goodwill / brand IP claimed at book — apply 95% haircut by default unless RICS valuation in evidence
- Inventory in regulated / perishable categories (food, pharma, fashion) — apply additional 30% haircut

## Operational rules

- Liquidation haircuts are policy-controlled and refreshed annually from portfolio actuals
- Prescribed-part calculation MUST be included; otherwise the lender systematically over-counts
- For services businesses (zero inventory), the floating charge value sits in receivables + plant — communicate this transparently
- Cross-check with charges-register-and-prior-security-agent for existing rank; recovery on subordinated positions is materially lower

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Asset base data not in alt_data or accounts | Refer; cannot value floating charge without asset detail |
| Plant & machinery age unknown | Use conservative bucket (>10y haircut) |
| Receivables ageing not available | Use industry default (12% aged 60+) and flag |
| Inventory present but type unspecified | Use the most punitive (wip) bucket |


## Sweden-specific operational notes

This agent operates within the Swedish lending framework — Finansinspektionen (FI) as unified supervisor, Banking and Financing Business Act (2004:297), Konsumentkreditlag (2010:1846) for consumer credit, Lag 2017:630 for AML.

- **BankID universal:** Operationally critical. Every Swedish consumer financial interaction uses BankID for SCA. Without BankID integration, customer onboarding friction is material.
- **Swish dominance:** Swedish bank-cooperative mobile payment platform; near-universal adoption for P2P + retail payments. Significant cash displacement in Sweden.
- **UC AB near-monopoly:** Upplysningscentralen (UC AB) holds dominant position for consumer credit data. Operational relationship is essential — analogous to SCHUFA in Germany.
- **Outside Eurozone:** SEK is free-floating. Larger lending facilities may need FX hedging consideration.
- **Macroprudential amortisation requirements:** FI sets statutory amortisation requirements (amorteringskrav) for high-LTV mortgages — operationally significant for mortgage product structure.
- **High household debt:** Sweden has historically high household debt-to-income; FI macroprudential focus is operationally consequential.
- **Personnummer privacy:** Restricted-use identifier; over-collection is privacy breach.
- **Cross-reference:** `country-se-lending-policy-agent` for full SE jurisdictional context (currently a stub in the Country Policy Pack).

## Statutory hooks

- Aktiebolagslag (2005:551) Part 25 (registration of charges)
- Insolvency Act 1986 s176A (prescribed-part carve-out)
- Enterprise Act 2002 (prescribed-part introduction)
- Law of Property Act 1925
- FI model risk supervision (model use governance for LGD inputs)

"""
risk_models.lgd_models
BetaCredit — Loss Given Default model suite with component decomposition (v1.2).

LGD is computed as a four-component economic-loss formula:

    LGD = (1 − cure_prob)
        × max(0, 1 − [collateral_recovery + unsecured_recovery − costs] × discount / EAD)

Where each component has an asset-class default but can be overridden per-loan
by columns supplied in df_all:

    lgd_observed             — if present, used directly (skips the formula)
    collateral_value         — £ value of collateral at origination
    cure_prob                — probability the loan cures without recovery
    recovery_costs           — workout costs as a fraction of EAD
    time_to_resolution_months — for discounting recoveries to present value

Two entry paths:

1. **Override path** — borrower row has lgd_observed → used as-is.
2. **Component path** — borrower row has any subset of the four component
   inputs → formula assembles LGD; missing inputs are filled from the
   asset-class defaults.

The asset-class defaults are the v1.0 calibration figures (5.5% TTC default for
SME unsecured, 14% LGD for mortgage, etc.), preserved here so existing notebooks
that pass only an asset class still get the same numbers.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np

from .asset_classes import AssetClass


# ─── LGDEstimate ─────────────────────────────────────────────────────────
@dataclass
class LGDEstimate:
    """
    The output of LGDModelSuite.estimate(). Backwards-compatible: the
    headline four fields (lgd_best_estimate, lgd_downturn, recovery_rate,
    collateral_value, time_to_recovery_months) are unchanged from v1.0.
    v1.2 adds the components dict so notebook 03 and the agent can show
    *why* each LGD is what it is.
    """
    lgd_best_estimate: float                      # Expected LGD under base
    lgd_downturn: float                           # Downturn LGD (Basel IV)
    recovery_rate: float                          # 1 - lgd_best_estimate
    collateral_value: float                       # £ collateral at origination
    time_to_recovery_months: int                  # Expected workout period

    # v1.2 component decomposition.
    # components.keys() is always:
    #   {'cure_prob', 'collateral_recovery', 'unsecured_recovery',
    #    'recovery_costs', 'discount_factor', 'lgd_workout'}
    # source ∈ {'observed', 'computed_from_components', 'asset_class_default'}
    components: dict = field(default_factory=dict)
    source: str = "asset_class_default"


# ─── Asset-class calibration ─────────────────────────────────────────────
# Numbers chosen to reproduce the v1.0 headline LGDs (55% / 35% / 72% / 14% /
# 16% / 44% / 28% / 38%) when no component overrides are supplied. Source:
# published UK lending benchmarks; equivalents can be found in Basel IV
# Article 181 supervisory tables and FCA Consumer Duty model risk papers.
_LGD_PARAMS: dict[str, dict] = {
    # cure_prob values calibrated so the component formula reproduces the
    # v1.0 headline LGDs when no per-loan overrides are supplied.
    "sme_unsecured": dict(
        lgd_be=0.55, dt_scalar=1.30, recovery_months=24,
        collateral_base=0,        haircut=0.0,    typical_ead=85_000,
        cure_prob=0.395, unsecured_recovery_rate=0.20,
        recovery_costs_pct=0.10,
    ),
    "sme_secured": dict(
        lgd_be=0.35, dt_scalar=1.25, recovery_months=18,
        collateral_base=120_000,  haircut=0.75,   typical_ead=250_000,
        cure_prob=0.491, unsecured_recovery_rate=0.15,
        recovery_costs_pct=0.12,
    ),
    "consumer_unsecured": dict(
        lgd_be=0.72, dt_scalar=1.18, recovery_months=18,
        collateral_base=0,        haircut=0.0,    typical_ead=12_000,
        cure_prob=0.206, unsecured_recovery_rate=0.18,
        recovery_costs_pct=0.08,
    ),
    "residential_mortgage": dict(
        lgd_be=0.14, dt_scalar=1.55, recovery_months=30,
        collateral_base=280_000,  haircut=0.85,   typical_ead=220_000,
        cure_prob=0.246, unsecured_recovery_rate=0.05,
        recovery_costs_pct=0.08,
    ),
    "buy_to_let": dict(
        lgd_be=0.16, dt_scalar=1.48, recovery_months=28,
        collateral_base=240_000,  haircut=0.80,   typical_ead=185_000,
        cure_prob=0.149, unsecured_recovery_rate=0.05,
        recovery_costs_pct=0.09,
    ),
    "motor_finance": dict(
        lgd_be=0.44, dt_scalar=1.22, recovery_months=12,
        collateral_base=18_000,   haircut=0.65,   typical_ead=22_000,
        cure_prob=0.147, unsecured_recovery_rate=0.10,
        recovery_costs_pct=0.07,
    ),
    "invoice_finance": dict(
        lgd_be=0.28, dt_scalar=1.38, recovery_months=9,
        collateral_base=45_000,   haircut=0.90,   typical_ead=95_000,
        cure_prob=0.478, unsecured_recovery_rate=0.20,
        recovery_costs_pct=0.06,
    ),
    "asset_finance": dict(
        lgd_be=0.38, dt_scalar=1.28, recovery_months=15,
        collateral_base=65_000,   haircut=0.70,   typical_ead=140_000,
        cure_prob=0.466, unsecured_recovery_rate=0.12,
        recovery_costs_pct=0.10,
    ),
}

# Risk-free rate used to discount recoveries to present value. The Basel IV
# Article 181 default is 5% nominal; UK firms commonly use Bank Rate + 100bps.
_DISCOUNT_RATE = 0.05


# ─── LGDModelSuite ───────────────────────────────────────────────────────
class LGDModelSuite:
    """
    Workout LGD model suite with component decomposition.

    Backwards-compatible with v1.0: calling .estimate(ac) with only an asset
    class reproduces the v1.0 headline LGDs exactly. Pass a borrower row
    (dict) as the second argument to engage the component path, or include
    lgd_observed in that row to engage the override path.
    """

    def __init__(self, seed: int = 42) -> None:
        self._rng = np.random.default_rng(seed)

    def estimate(
        self,
        ac: AssetClass,
        row: Optional[dict] = None,
        ead: Optional[float] = None,
    ) -> LGDEstimate:
        """
        Return an LGDEstimate for the asset class.

        Parameters
        ----------
        ac
            The borrower's asset class (AssetClass enum or canonical string).
        row
            Optional borrower row (dict) carrying any of:
              lgd_observed, collateral_value, cure_prob, recovery_costs,
              time_to_resolution_months
            Anything not present falls back to the asset-class default.
        ead
            Optional exposure at default in £. Defaults to the borrower row's
            loan_amount (or the asset-class typical EAD if absent).
        """
        ac_key = ac.value if isinstance(ac, AssetClass) else ac
        p = _LGD_PARAMS[ac_key]
        row = row or {}

        # Resolve EAD — needed to scale collateral recovery to LGD.
        # When no per-loan EAD is supplied we fall back to the asset-class
        # typical_ead, which is the EAD value the cure_prob calibration
        # was tuned against. This is what makes the asset-class-default
        # path reproduce the v1.0 headline LGDs exactly.
        ead_value = float(ead if ead is not None
                          else row.get("loan_amount")
                          or p["typical_ead"])

        # ─── Path 1: observed override ─────────────────────────────────
        # User-supplied LGD takes precedence over everything. We still
        # compute components for the dashboard but flag the source.
        lgd_obs = row.get("lgd_observed")
        if lgd_obs is not None and not (isinstance(lgd_obs, float)
                                        and np.isnan(lgd_obs)):
            lgd_be = float(np.clip(lgd_obs, 0.0, 1.0))
            lgd_dt = float(np.clip(lgd_be * p["dt_scalar"], 0.0, 1.0))
            return LGDEstimate(
                lgd_best_estimate=lgd_be,
                lgd_downturn=lgd_dt,
                recovery_rate=max(0.0, 1.0 - lgd_be),
                collateral_value=float(row.get("collateral_value",
                                               p["collateral_base"])),
                time_to_recovery_months=int(row.get(
                    "time_to_resolution_months", p["recovery_months"])),
                components={
                    "cure_prob":            float(row.get("cure_prob",
                                                          p["cure_prob"])),
                    "collateral_recovery":  None,
                    "unsecured_recovery":   None,
                    "recovery_costs":       None,
                    "discount_factor":      None,
                    "lgd_workout":          None,
                },
                source="observed",
            )

        # ─── Path 2: component formula ─────────────────────────────────
        cure_prob       = float(row.get("cure_prob",        p["cure_prob"]))
        collateral_val  = float(row.get("collateral_value", p["collateral_base"]))
        costs_pct       = float(row.get("recovery_costs",   p["recovery_costs_pct"]))
        ttr_months      = int(  row.get("time_to_resolution_months",
                                        p["recovery_months"]))

        # Asset-class jitter — apply ±10% to the collateral haircut and
        # ±20% to the collateral value so per-loan variation is preserved.
        # Skip jitter entirely when no borrower row is supplied so the
        # asset-class-default path reproduces v1.0 numbers exactly.
        if row:
            haircut_eff = p["haircut"] * float(self._rng.uniform(0.90, 1.10)) \
                          if p["haircut"] > 0 else 0.0
            # Only jitter collateral if the borrower didn't explicitly supply one
            if "collateral_value" not in row:
                collateral_val *= float(self._rng.uniform(0.80, 1.20))
        else:
            haircut_eff = p["haircut"]

        # ─── Decomposition ────────────────────────────────────────────
        # 1. Collateral recovery — what we get from realising security,
        #    capped at EAD (can't recover more than was lent).
        collateral_recovery = min(collateral_val * haircut_eff, ead_value)

        # 2. Unsecured recovery — what we get from the unsecured remainder
        #    (debt collection, salary garnish, etc.).
        unsecured_remaining = max(0.0, ead_value - collateral_recovery)
        unsecured_recovery  = unsecured_remaining * p["unsecured_recovery_rate"]

        # 3. Workout costs — legal, admin, asset management, all expressed
        #    as a fraction of EAD per Basel IV economic-loss definition.
        costs = ead_value * costs_pct

        # 4. Discount factor — recoveries arrive in the future and are
        #    discounted to present value at _DISCOUNT_RATE. Mortgages and
        #    BTL feel this most (long workout periods).
        discount_factor = (1 + _DISCOUNT_RATE) ** (-ttr_months / 12.0)

        # Net recovery and workout LGD before cure
        gross_recovery = collateral_recovery + unsecured_recovery
        net_recovery   = max(0.0, (gross_recovery - costs) * discount_factor)
        lgd_workout    = max(0.0, min(1.0, 1.0 - net_recovery / ead_value))

        # Final LGD applies cure probability: cured loans contribute ~zero
        # loss, only the (1 - cure_prob) fraction reaches workout.
        lgd_be = float(np.clip((1.0 - cure_prob) * lgd_workout, 0.0, 1.0))
        lgd_dt = float(np.clip(lgd_be * p["dt_scalar"], 0.0, 1.0))

        # Decide whether to report "computed_from_components" or
        # "asset_class_default" based on whether any per-loan override
        # was actually provided.
        provided = {k for k in ("collateral_value", "cure_prob",
                                "recovery_costs", "time_to_resolution_months")
                    if k in row and row.get(k) is not None}
        source = "computed_from_components" if provided else "asset_class_default"

        return LGDEstimate(
            lgd_best_estimate=lgd_be,
            lgd_downturn=lgd_dt,
            recovery_rate=max(0.0, 1.0 - lgd_be),
            collateral_value=collateral_val,
            time_to_recovery_months=ttr_months,
            components={
                "cure_prob":           cure_prob,
                "collateral_recovery": collateral_recovery,
                "unsecured_recovery":  unsecured_recovery,
                "recovery_costs":      costs,
                "discount_factor":     discount_factor,
                "lgd_workout":         lgd_workout,
            },
            source=source,
        )

    # ── Sensitivity helper for notebook 03 ──────────────────────────────
    def sensitivity(self, ac: AssetClass, ead: float = 100_000) -> dict:
        """
        Return a dict mapping each component → the LGD impact in basis
        points of an adverse one-standard-deviation shift in that component.

        "Adverse" means: lower cure rate, lower collateral value, higher
        costs, longer time to resolution. So the sign of every entry
        should be ≥ 0 (each adverse shift increases LGD).

        For asset classes with collateral, the test EAD is set just
        above the collateral haircut value so a 20% drop in collateral
        translates into a visible LGD increase — this is the standard
        "HPI stress" use case from notebook 03's waterfall chart.
        """
        ac_key = ac.value if isinstance(ac, AssetClass) else ac
        params = _LGD_PARAMS[ac_key]

        # For secured asset classes, set EAD just above the haircut-adjusted
        # collateral so a 20% drop in collateral_value translates into a
        # real LGD impact. For unsecured, this is moot.
        if params["collateral_base"] > 0:
            ead = max(ead, params["collateral_base"] * params["haircut"] * 1.05)

        base = self.estimate(ac, ead=ead)
        base_lgd = base.lgd_best_estimate

        # Adverse shifts: each one moves the parameter in the direction
        # that increases LGD (lower cure, lower collateral, higher costs,
        # longer workout).
        shifts = {
            "cure_prob":                 -0.10,   # -10pp cure → more workout
            "collateral_value":          -0.20,   # -20% collateral (HPI shock)
            "recovery_costs":            +0.05,   # +5pp costs
            "time_to_resolution_months": +12,     # +12 months workout
        }
        result = {}
        for key, delta in shifts.items():
            row = {"loan_amount": ead}
            if key == "collateral_value":
                row[key] = params["collateral_base"] * (1.0 + delta)
            elif key == "time_to_resolution_months":
                row[key] = params["recovery_months"] + delta
            elif key == "cure_prob":
                row[key] = max(0.0, params["cure_prob"] + delta)
            else:
                row[key] = params["recovery_costs_pct"] + delta
            shifted = self.estimate(ac, row=row, ead=ead)
            result[key] = (shifted.lgd_best_estimate - base_lgd) * 10_000  # bps
        return result

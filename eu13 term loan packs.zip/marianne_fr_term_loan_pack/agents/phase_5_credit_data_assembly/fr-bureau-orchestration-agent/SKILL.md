---
name: fr-bureau-orchestration-agent
description: |
  Orchestrate commercial credit bureau pulls (FIBEN + Altares D&B FR, Equifax Commercial, CreditSafe, optionally Dun & Bradstreet). Aggregate into a composite credit picture. Handles bureau-specific scoring quirks and returns a consolidated view consumable by downstream affordability and PD agents.
---

# Bureau Orchestration Agent

Authoritative credit picture from the bureaux. Each bureau has its own model and scoring; the orchestrator presents them as one consistent set of facts.

## Input contract

```yaml
bureau_request:
  case_id: string
  company_number: string
  consent_token: string                     # bureau_commercial
  bureaux_requested: [enum]                 # subset of {experian, equifax, creditsafe, dnb}
```

## Output contract

```yaml
bureau_composite:
  case_id: string
  company_number: string
  experian:
    delphi_score: integer                   # 0-100
    band: enum                              # 1=high risk, 6=very low risk (or similar)
    age_at_companies_house: integer
  equifax:
    score: string                           # alphabetic A/B/C/D...
    arrears_indicator: boolean
  creditsafe:
    score: integer                          # 0-100
    international_score: integer
  dnb:                                      # nullable; not always pulled
    paydex: integer
    failure_score: integer
  consolidated:
    composite_rating: enum                  # solid | adequate | weak
    cumulative_ccj_count_company: integer
    current_charges_outstanding: integer
    current_arrears_with_any_lender: boolean
    discrepancies_across_bureaux: [string]
  reason_codes: [string]
```

## Decision logic

```
Parallel pulls of all bureaux_requested.
For each bureau response:
  - record raw score + band
  - normalise key facts (CCJs, charges, arrears)
Cross-check key facts across bureaux:
  - if bureaux disagree on CCJ count: flag discrepancy
  - if one bureau reports arrears the others don't: flag discrepancy

Composite rating:
  - solid: all bureaux above their respective "low risk" thresholds
  - adequate: at least 2 of 3 above thresholds
  - weak: majority below thresholds OR any bureau reports arrears
```

## Worked example (Marianne Engineering SAS case)

Input:
```yaml
bureau_request:
  case_id: "MAR-2026-04-001"
  company_number: "552 100 554"
  consent_token: "TKN-bureau-com-2026-04-12-001"
  bureaux_requested: [experian, equifax, creditsafe]
```

Output:
```yaml
bureau_composite:
  case_id: "MAR-2026-04-001"
  company_number: "552 100 554"
  experian:
    delphi_score: 78
    band: 4                                # low-medium risk
    age_at_companies_house: 102
  equifax:
    score: "B+"
    arrears_indicator: false
  creditsafe:
    score: 72
    international_score: 70
  consolidated:
    composite_rating: solid
    cumulative_ccj_count_company: 0
    current_charges_outstanding: 1
    current_arrears_with_any_lender: false
    discrepancies_across_bureaux: []
  reason_codes: ["UK_BUREAU_COMPOSITE_SOLID_NO_DISCREPANCIES"]
```

All three bureaux agree on the substantive facts (no CCJs, 1 outstanding charge, no current arrears). Scores cluster in the solid mid-tier (Delphi 78, Equifax B+, CreditSafe 72). Composite rating: solid.

## Bright lines

- Bureau flags 'do not lend' marker (rare; reserved for confirmed serious adverse) → BLOCK
- Active arrears with any reported lender → AUTOMATIC REFER

## Operational rules

- Discrepancies across bureaux are NOT automatically resolved — they're flagged for review
- Different bureau scales are preserved in raw; only the composite is normalised
- Bureau costs: aim for 2 bureaux minimum, 3 for cases >€100k
- Bureau data is point-in-time — re-pull if case takes >30 days

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| One bureau unavailable | Proceed with other two; flag completeness < ideal |
| All bureaux unavailable | Refer; cannot make data-driven decision |
| Bureaux disagree materially on key facts | Refer for manual reconciliation |


## France-specific operational notes

This agent operates within the French lending framework — ACPR + AMF supervisory perimeter, Banque de France operating both FIBEN (commercial credit register) and FICP (consumer credit incidents register), Code monétaire et financier for banking, Code de la consommation for consumer credit (with Loi Lagarde 2010 reforms still operationally consequential).

- **FIBEN central commercial register:** Operated by Banque de France itself, not a commercial bureau. Banks contribute and consult; FIBEN gives French banks unusually rich commercial credit visibility relative to most EU peers. Reciprocity requirement applies for full query depth.
- **FICP mandatory consumer query:** Statutory mandatory before consumer credit decision; no FICP query = invalid decision.
- **Toubon Law:** Commercial contracts and consumer disclosures must be in French. Foreign-language versions can supplement but the French version is the legally operative text.
- **TAEG (APR) statutory rigour:** Code de la consommation TAEG calculation rules are statutory; mis-statement >0.2pp is material. Quarterly Banque de France usury rate ceilings (taux d'usure) per consumer credit category — exceeding is voidable contract.
- **Assurance emprunteur:** Loi Lemoine 2022 reformed mortgage insurance — borrower has right to substitute insurer; insurer commission disclosure required.
- **Cross-reference:** `country-fr-lending-policy-agent` provides full FR jurisdictional context.

## Statutory hooks

- Code de la consommation (Loi Lagarde 2010) (where applicable — sole traders, small partnerships)
- France GDPR / DPA 2018
- ACPR ACPR Recommandation + Code de la consommation

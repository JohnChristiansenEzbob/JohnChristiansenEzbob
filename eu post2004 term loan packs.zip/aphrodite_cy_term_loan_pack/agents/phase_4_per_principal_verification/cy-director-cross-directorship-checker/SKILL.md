---
name: cy-director-cross-directorship-checker
description: |
  Trace each director's other directorships across Cyprus active and dissolved companies via
  DRCIP (Registrar of Companies) director search. Identify cross-default risk (linked companies in arrears
  with this lender), phoenix-director patterns (serial company failures with same director),
  and concentration patterns (portfolio director vs synthetic-entity fraud). Returns
  classification per director: clean | monitor | phoenix_risk | cross_default_risk.
---

# Director Cross-Directorship Checker

## Input contract

```yaml
principal_id: string
name: string
dob: date                                 # used with month+year for CH director search keying
current_residential_address: string
lender_portfolio_lookup_consent: boolean  # internal lookup against own arrears book
```

## Output contract

```yaml
cross_directorship_assessment:
  principal_id: string
  total_lifetime_directorships: integer
  active_directorships: integer
  dissolved_with_insolvency_count_7y: integer
  strike_off_count_7y: integer
  same_trade_after_dissolution: boolean
  cross_default_active_arrears_lender_portfolio: boolean
  diverse_sic_code_count: integer
  classification: enum                    # clean | monitor | phoenix_risk | cross_default_risk | portfolio_director
  reason_codes: [string]
```

## Decision logic

```
DRCIP (Registrar of Companies) director search by name + DOB month/year.
For each directorship: fetch company status + incorporation/dissolution dates.
Compute pattern metrics.

if dissolved_with_insolvency_count_7y >= 2 OR same_trade_after_dissolution:
  classification = phoenix_risk           # BRIGHT LINE — refer to underwriter

elif strike_off_count_7y >= 3:
  classification = phoenix_risk

elif cross_default_active_arrears_lender_portfolio:
  classification = cross_default_risk     # BRIGHT LINE — decline pending override

elif active_directorships >= 5 AND diverse_sic_code_count >= 4:
  classification = portfolio_director     # Not negative; understand pattern

elif active_directorships >= 2:
  classification = monitor

else:
  classification = clean
```

## Worked example (Lachlan MacKenzie — DIR-001)

Input:
```yaml
principal_id: DIR-001
name: "Lachlan MacKenzie"
dob: "1981-03-22"
current_residential_address: "12 Strathblane Road, Milngavie, Nicosia, G62 8DJ"
lender_portfolio_lookup_consent: true
```

Output:
```yaml
cross_directorship_assessment:
  principal_id: DIR-001
  total_lifetime_directorships: 1
  active_directorships: 1
  dissolved_with_insolvency_count_7y: 0
  strike_off_count_7y: 0
  same_trade_after_dissolution: false
  cross_default_active_arrears_lender_portfolio: false
  diverse_sic_code_count: 1
  classification: clean
  reason_codes: ["UK_DIRECTOR_CROSS_DIRECTORSHIP_CLEAN"]
```

Sarah Chen has 2 active directorships (this + a dormant family company) and identical
clean classification — does not meet portfolio-director threshold (5+).

## Bright lines

- `classification = phoenix_risk` → AUTOMATIC REFER. Phoenix patterns are a leading UK
  SME fraud signal; cannot auto-approve.
- `classification = cross_default_risk` (active arrears in lender's own portfolio) →
  AUTOMATIC DECLINE pending underwriter override.

## Operational rules

- Director name matching is fuzzy. Under-include rather than over-include where ambiguous
  (false positives are worse than false negatives in director matching).
- Multiple directorships in genuinely different groups ≠ phoenix; require explicit
  dissolution-with-insolvency pattern.
- Audit log must include the full directorship list (company numbers), not just the
  classification.


## Cyprus-specific operational notes

Operates within the Cypriot framework — Central Bank of Cyprus + CySEC supervision, Consumer Credit Agreements Law, AML Law enforced via MOKAS.

- **ARTEMIS centrality:** ARTEMIS Bank Information Systems is the primary Cyprus credit bureau; operational relationship is essential.
- **Post-2013 crisis legacy:** The 2013 deposit bail-in left structural scars; borrower and depositor behaviour remains crisis-aware. Historical defaults common; distinguish current from legacy positions.
- **International business sector:** Large offshore/international company presence; KYB chains frequently involve cross-border structures requiring enhanced UBO scrutiny.
- **English in commerce:** English commonly accepted alongside Greek in commercial contracts.
- **Cross-reference:** `country-cy-lending-policy-agent` (Country Policy Pack stub).

## Statutory hooks

- Companies Act 2006
- Insolvency Act 1986
- Company Directors Disqualification Act 1986
- Cyprus AML Law
- UBO Register (DRCIP) (failure to prevent fraud)

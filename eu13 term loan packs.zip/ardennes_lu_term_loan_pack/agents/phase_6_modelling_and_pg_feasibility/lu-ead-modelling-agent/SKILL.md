---
name: lu-ead-modelling-agent
description: |
  Estimate Exposure at Default. For Luxembourg term loans, this is largely deterministic — principal at drawdown amortising over term. For revolving credit or committed lines, includes credit conversion factor for undrawn portions. Term loans get a simple EAD profile.
---

# EAD Modelling Agent

EAD is the exposure metric for capital and ECL. For term loans it's near-trivial; kept as a separate agent for consistency and to handle non-term products.

## Input contract

```yaml
ead_request:
  case_id: string
  facility_type: enum
  facility_amount_eur: integer
  facility_term_months: integer
  drawdown_pattern: enum                    # single | phased | revolving
  undrawn_commitment_gbp: integer           # for revolving / committed
```

## Output contract

```yaml
ead_estimate:
  case_id: string
  ead_at_completion_gbp: integer
  ead_profile_over_term:                    # amortising schedule
    - month: integer
      outstanding_gbp: integer
  ead_avg_over_term_gbp: integer
  credit_conversion_factor: float           # 1.0 for term loans
  reason_codes: [string]
```

## Decision logic

```
For term_loan:
  ead_at_completion = facility_amount (fully drawn at completion)
  ead_profile = annuity_amortisation_schedule(facility_amount, term, rate)
  ead_avg = mean(ead_profile)
  credit_conversion_factor = 1.0

For revolving_credit:
  ead = drawn_estimate + (undrawn * CCF)  # CCF typically 40-75%

For asset_finance / invoice_finance:
  agent-specific logic
```

## Worked example (Ardennes Engineering S.à r.l. case)

Input:
```yaml
ead_request:
  case_id: "ARD-2026-04-001"
  facility_type: term_loan
  facility_amount_eur: 150000
  facility_term_months: 60
  drawdown_pattern: single
  undrawn_commitment_gbp: 0
```

Output:
```yaml
ead_estimate:
  case_id: "ARD-2026-04-001"
  ead_at_completion_gbp: 150000
  ead_profile_over_term:
    - month: 0
      outstanding_gbp: 150000
    - month: 12
      outstanding_gbp: 124800
    - month: 24
      outstanding_gbp: 97200
    - month: 36
      outstanding_gbp: 67100
    - month: 48
      outstanding_gbp: 34200
    - month: 60
      outstanding_gbp: 0
  ead_avg_over_term_gbp: 78600
  credit_conversion_factor: 1.0
  reason_codes: ["UK_EAD_TERM_LOAN_AMORTISING_PROFILE"]
```

Simple amortising profile for a €150k 60-month term loan. €150k at completion, ~€0 at maturity, time-weighted average €78.6k. Used as input to ECL (in combination with PD and LGD).

## Bright lines

- (no statutory bright lines for this agent)

## Operational rules

- Term loans: EAD profile is deterministic; no model risk in this calculation
- Revolving: CCF is portfolio-calibrated; updated quarterly

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| Phased drawdown: unclear timing | Use worst-case (all drawn at once); flag |
| Asset finance: depreciation profile not provided | Refer |


## Luxembourg-specific operational notes

This agent operates within the Luxembourgish lending framework — CSSF as unified supervisor (banking, investment funds, payment services, insurance via CAA), with ECB SSM for significant institutions. Loi du 5 avril 1993 is the foundational banking law.

- **EU financial centre context:** Luxembourg's banking sector is heavily skewed toward private banking, fund administration, and cross-border services. Domestic consumer lending is a smaller proportion of activity than peer EU jurisdictions.
- **Trilingual jurisdiction:** French is primary for legal documents; German and Luxembourgish (Lëtzebuergesch) also constitutional. Customer-facing materials commonly trilingual.
- **CSSF supervisory style:** Investment fund and private banking focus means CSSF supervisory rhythm and reporting differs from peer prudential supervisors. Banking supervision sits within the unified CSSF.
- **Limited domestic credit visibility:** No central consumer credit register equivalent to FR FICP or BE CKP; lender visibility relies on bureau-by-bureau queries and Open Banking.
- **Cross-border banking:** Many lending applications involve cross-border structures (Belgian, German, French residents working in Luxembourg). KYB chains often complex.
- **Cross-reference:** `country-lu-lending-policy-agent` for full LU jurisdictional context (currently a stub in the Country Policy Pack).

## Statutory hooks

- Basel III/IV (EAD for capital)
- IFRS 9 (ECL inputs)

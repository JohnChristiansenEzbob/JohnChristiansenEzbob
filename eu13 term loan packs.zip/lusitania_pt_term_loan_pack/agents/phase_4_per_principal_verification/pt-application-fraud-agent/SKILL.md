---
name: pt-application-fraud-agent
description: |
  Detect application-stage fraud indicators per principal — synthetic identity patterns, document tampering signals, velocity rules (repeated applications), CRC negative + e-fatura cross-check Protective Registration / National Fraud Database hits, device fingerprinting signals. Returns a fraud score (0-100) with classification.
---

# Application Fraud Agent

First-line application fraud screen. Identity-orchestration confirms the person is real and the documents are real; this agent confirms the application itself isn't suspicious.

## Input contract

```yaml
fraud_request:
  principal_id: string
  case_id: string
  name: string
  dob: date
  current_residential_address: string
  application_metadata:
    device_fingerprint: string
    ip_address: string
    submission_timestamp: datetime
    browser_locale: string
  cifas_check_consent: boolean
```

## Output contract

```yaml
fraud_assessment:
  principal_id: string
  fraud_score: integer                      # 0-100; 0=clean, 100=high risk
  classification: enum                      # low | medium | high
  signals:
    cifas_markers: [string]                 # nullable
    velocity_signals: [string]              # multiple recent applications etc.
    device_signals: [string]                # VPN, automation, mismatched locale etc.
    synthetic_identity_signals: [string]
  outcome: enum                             # proceed | refer | block_high_risk_fraud
  reason_codes: [string]
```

## Decision logic

```
Lookup CRC negative + e-fatura cross-check National Fraud Database (consent-gated).
Apply velocity rules (same identity in N applications in past M days).
Device fingerprint analysis (known fraud-associated devices, automation).
Synthetic identity detection (DOB-name combinations, address-credit history mismatches).

Compute composite fraud_score.

if cifas_markers include "fraud" (Category 6) marker:
  outcome = block_high_risk_fraud           # BRIGHT LINE; CRC negative + e-fatura cross-check fraud marker is decline

elif fraud_score >= 70:
  outcome = block_high_risk_fraud

elif fraud_score >= 40:
  outcome = refer

else:
  outcome = proceed
```

## Worked example (Lusitânia Engineering Lda. case)

Input:
```yaml
fraud_request:
  principal_id: DIR-001
  case_id: "LUS-2026-04-001"
  name: "Lachlan MacKenzie"
  dob: "1981-03-22"
  current_residential_address: "12 Strathblane Road, Milngavie, Lisboa, G62 8DJ"
  application_metadata:
    device_fingerprint: "[hash]"
    ip_address: "82.x.x.x"
    submission_timestamp: "2026-04-12T09:14:22Z"
    browser_locale: "en-GB"
  cifas_check_consent: true
```

Output:
```yaml
fraud_assessment:
  principal_id: DIR-001
  fraud_score: 12
  classification: low
  signals:
    cifas_markers: []
    velocity_signals: []
    device_signals: []
    synthetic_identity_signals: []
  outcome: proceed
  reason_codes: ["UK_APPLICATION_FRAUD_LOW_RISK"]
```

Clean fraud screen. Portugal IP, en-GB locale matching declared residence, no CRC negative + e-fatura cross-check markers, no velocity issues. Sarah Chen returns similar low-risk shape.

## Bright lines

- CRC negative + e-fatura cross-check Category 6 fraud marker → AUTO-DECLINE; cannot override without explicit dispensation
- Confirmed synthetic identity (fabricated person) → AUTO-DECLINE + SAR

## Operational rules

- CRC negative + e-fatura cross-check lookup requires explicit consent; absence of consent → cannot perform that check (not blocking by itself)
- Velocity rules windowed (e.g. >3 applications in 30 days flags)
- Device fingerprints retained in fraud history for pattern detection

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| CRC negative + e-fatura cross-check unavailable | Refer; cannot make decision without check (over a critical limit) |
| Device fingerprint missing | Score conservatively; some signals unusable |


## Portugal-specific operational notes

This agent operates within the Portuguese lending framework — BdP and CMVM joint regulatory perimeter, Decreto-Lei 298/92 (Regime Geral das Instituições de Crédito) for banking, Decreto-Lei 133/2009 for consumer credit, Lei 83/2017 for AML.

- **CRC €50 threshold:** Banco de Portugal central credit register has the broadest visibility threshold in the EU — effectively covers all consumer credit and almost all commercial credit. Mandatory contribution + consultation. Operationally raises the visibility floor significantly above Spanish CIRBE (€9k), Italian Centrale dei Rischi (€30k).
- **Statutory TAEG ceiling:** BdP publishes quarterly TAEG (APR) caps per consumer credit category. Exceeding is contract invalidity — not just disclosure issue.
- **Cartão de Cidadão integration:** Portuguese citizen card is the operational gold standard for EU national ID — integrates national ID + tax + social security + electoral + health on one card. Strong eID infrastructure.
- **e-fatura mandatory e-invoicing:** Creates rich verification source for SME turnover. Tax invoices are real-time matched with SAFT-PT submissions.
- **SIBS API Market:** Portuguese banking infrastructure provides standardised PSD2 interface — reduces AISP integration complexity vs. peer EU jurisdictions.
- **MB Way mobile payment:** Operationally ubiquitous; SIBS-operated mobile P2P + e-commerce payment.
- **Cross-reference:** `country-pt-lending-policy-agent` provides full PT jurisdictional context.

## Statutory hooks

- Fraud Act 2006
- Lei 83/2017 + RCBE (failure to prevent fraud — must have reasonable procedures)
- Portugal Lei 83/2017 (transaction monitoring + identity)
- CRC negative + e-fatura cross-check Code of Practice

---
name: lu-kyb-verifier
description: |
  Verify the applicant company at RCS Luxembourg / LBR — active status, registered office currency, accounts filing currency, no strike-off proposed. Establishes the foundational fact that the company is a real, currently-trading legal entity.
---

# KYB Verifier

Foundational KYB. Everything downstream assumes the company is real and active. Cheap, fast, and decisive.

## Input contract

```yaml
kyb_request:
  case_id: string
  company_number: string
```

## Output contract

```yaml
kyb_result:
  case_id: string
  company_number: string
  status: enum                              # active | dissolved | liquidation | proposed_for_strike_off | not_found
  incorporation_date: date
  age_months: integer
  registered_office: string
  registered_office_verified: boolean
  sic_codes: [string]
  accounts_filing_status: enum              # up_to_date | overdue | first_accounts_pending
  last_accounts_made_up_to: date            # nullable
  next_accounts_due: date                   # nullable
  confirmation_statement_status: enum
  outcome: enum                             # verified | refer_filings_overdue | block_dissolved_or_strike_off
  reason_codes: [string]
```

## Decision logic

```
RCS Luxembourg / LBR API call by company_number.

if status in [dissolved, liquidation]:
  outcome = block_dissolved_or_strike_off

elif status == proposed_for_strike_off:
  outcome = block_dissolved_or_strike_off    # BRIGHT LINE

elif status == not_found:
  outcome = block_dissolved_or_strike_off
  reason_codes += [UK_COMPANIES_HOUSE_NOT_FOUND]

elif accounts_filing_status == overdue:
  outcome = refer_filings_overdue            # not a hard block but material

else:
  outcome = verified
```

## Worked example (Ardennes Engineering S.à r.l. case)

Input:
```yaml
kyb_request:
  case_id: "ARD-2026-04-001"
  company_number: "B 123456"
```

Output:
```yaml
kyb_result:
  case_id: "ARD-2026-04-001"
  company_number: "B 123456"
  status: active
  incorporation_date: "2017-09-14"
  age_months: 102
  registered_office: "Avenue de la Gare 33, L-1611 Luxembourg"
  registered_office_verified: true
  sic_codes: ["71121"]
  accounts_filing_status: up_to_date
  last_accounts_made_up_to: "2025-09-30"
  next_accounts_due: "2026-06-30"
  confirmation_statement_status: up_to_date
  outcome: verified
  reason_codes: ["UK_KYB_ACTIVE_CURRENT_FILINGS"]
```

Highland is active, 102 months old (past the high-risk early years), accounts up to date, confirmation statement filed. Clean verification.

## Bright lines

- Company dissolved or in liquidation → BLOCK; no facility can be advanced
- Company proposed for strike-off → BLOCK pending applicant explanation
- Company not found at RCS Luxembourg / LBR → BLOCK; suspect fraud

## Operational rules

- RCS Luxembourg / LBR data is authoritative for legal status
- Registered office must match the applicant-declared trading address sufficiently (or have valid explanation)
- Accounts overdue is a material refer signal but not always a decline (recent incorporation, ongoing extension request)

## Failure modes

| Condition | Behaviour |
|-----------|-----------|
| RCS Luxembourg / LBR API timeout | Refer; retry |
| Company number invalid format | Block; data-capture should have caught this |
| Registered office unverified (PO Box, virtual office) | Refer; require physical trading address |


## Luxembourg-specific operational notes

This agent operates within the Luxembourgish lending framework — CSSF as unified supervisor (banking, investment funds, payment services, insurance via CAA), with ECB SSM for significant institutions. Loi du 5 avril 1993 is the foundational banking law.

- **EU financial centre context:** Luxembourg's banking sector is heavily skewed toward private banking, fund administration, and cross-border services. Domestic consumer lending is a smaller proportion of activity than peer EU jurisdictions.
- **Trilingual jurisdiction:** French is primary for legal documents; German and Luxembourgish (Lëtzebuergesch) also constitutional. Customer-facing materials commonly trilingual.
- **CSSF supervisory style:** Investment fund and private banking focus means CSSF supervisory rhythm and reporting differs from peer prudential supervisors. Banking supervision sits within the unified CSSF.
- **Limited domestic credit visibility:** No central consumer credit register equivalent to FR FICP or BE CKP; lender visibility relies on bureau-by-bureau queries and Open Banking.
- **Cross-border banking:** Many lending applications involve cross-border structures (Belgian, German, French residents working in Luxembourg). KYB chains often complex.
- **Cross-reference:** `country-lu-lending-policy-agent` for full LU jurisdictional context (currently a stub in the Country Policy Pack).

## Statutory hooks

- Loi du 10 août 1915 (commercial companies)
- Loi du 13 janvier 2019 + REBECO (RCS Luxembourg / LBR register integrity)
- Luxembourg Loi du 12 novembre 2004

"""
Companies House client stub for kyb-verifier.

Production deployment should use the Adam LOS integration layer's Companies House
adapter rather than this module — kept here as a reference implementation showing
the expected call shape and error handling.

Auth: API key via env var COMPANIES_HOUSE_API_KEY.
Rate limit: 600 requests per 5 minutes per key (as of latest CH API docs).
"""

from __future__ import annotations

import os
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

import requests
from requests.auth import HTTPBasicAuth

CH_BASE = "https://api.company-information.service.gov.uk"


@dataclass
class CompaniesHouseError(Exception):
    status_code: int
    message: str
    endpoint: str

    def __str__(self) -> str:
        return f"[{self.status_code}] {self.endpoint}: {self.message}"


@dataclass
class CompaniesHouseClient:
    api_key: str = field(default_factory=lambda: os.environ.get("COMPANIES_HOUSE_API_KEY", ""))
    timeout_s: float = 10.0
    max_retries: int = 3
    backoff_base_s: float = 0.5

    def __post_init__(self) -> None:
        if not self.api_key:
            raise ValueError("COMPANIES_HOUSE_API_KEY not set")

    # ---- public methods ----

    def get_profile(self, company_number: str) -> dict[str, Any]:
        return self._get(f"/company/{company_number}")

    def get_officers(self, company_number: str) -> dict[str, Any]:
        return self._get(f"/company/{company_number}/officers")

    def get_charges(self, company_number: str) -> dict[str, Any]:
        return self._get(f"/company/{company_number}/charges")

    def get_filing_history(self, company_number: str, items: int = 25) -> dict[str, Any]:
        return self._get(f"/company/{company_number}/filing-history", params={"items_per_page": items})

    def search_companies(self, query: str, items: int = 10) -> dict[str, Any]:
        return self._get("/search/companies", params={"q": query, "items_per_page": items})

    # ---- internal ----

    def _get(self, path: str, params: dict | None = None) -> dict[str, Any]:
        url = f"{CH_BASE}{path}"
        attempt = 0
        while True:
            attempt += 1
            try:
                resp = requests.get(
                    url,
                    auth=HTTPBasicAuth(self.api_key, ""),
                    params=params or {},
                    timeout=self.timeout_s,
                )
            except requests.RequestException as exc:
                if attempt >= self.max_retries:
                    raise CompaniesHouseError(0, str(exc), path) from exc
                time.sleep(self.backoff_base_s * (2 ** (attempt - 1)))
                continue

            if resp.status_code == 200:
                payload = resp.json()
                payload["_meta"] = {
                    "retrieved_at": datetime.now(timezone.utc).isoformat(),
                    "endpoint": path,
                    "attempt": attempt,
                }
                return payload

            if resp.status_code in (429, 502, 503, 504) and attempt < self.max_retries:
                # Honour Retry-After when present, else exponential backoff.
                retry_after = resp.headers.get("Retry-After")
                delay = float(retry_after) if retry_after else self.backoff_base_s * (2 ** (attempt - 1))
                time.sleep(delay)
                continue

            raise CompaniesHouseError(resp.status_code, resp.text[:500], path)


def build_kyb_record(
    client: CompaniesHouseClient,
    company_number: str,
    declared: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Pull everything needed for a KYB record. Returns raw payload — rule
    evaluation and reason coding happens in a separate layer."""
    declared = declared or {}
    profile = client.get_profile(company_number)
    officers = client.get_officers(company_number)
    try:
        charges = client.get_charges(company_number)
    except CompaniesHouseError as exc:
        # 404 is normal — means no charges. Anything else, re-raise.
        if exc.status_code == 404:
            charges = {"items": [], "total_count": 0}
        else:
            raise

    return {
        "company_number": company_number,
        "profile": profile,
        "officers": officers,
        "charges": charges,
        "declared": declared,
        "retrieved_at": datetime.now(timezone.utc).isoformat(),
    }


if __name__ == "__main__":
    # Smoke test against a known company number.
    import json
    import sys

    cn = sys.argv[1] if len(sys.argv) > 1 else "00000006"  # The Crown Estate
    c = CompaniesHouseClient()
    record = build_kyb_record(c, cn)
    print(json.dumps(record, indent=2)[:2000])

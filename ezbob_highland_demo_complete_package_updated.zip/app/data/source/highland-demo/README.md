# UK Term Loan — Highland Engineering Demo (Claude Code)

A demonstration of the UK SME term loan agent journey, running on Claude Code with the original 36 agents as Skills and an 8-subagent orchestration layer on top.

End state: ACCEPT WITH CONDITIONS on Highland Engineering Consultants Ltd's £150,000 5-year term loan, with four drawdown conditions including an Etridge process for the joint-property PG.

## Directory layout

```
highland-demo/
├── CLAUDE.md                          # Top-level orchestrator instructions
├── README.md                          # This file
├── AGENT_CLASSIFICATION.md            # Why each original agent became a skill (not a subagent)
├── cases/
│   └── highland_engineering.yaml      # The demo case (single source of truth)
├── case_state/                        # Created at runtime — phase outputs land here
│   └── HE-2026-04-001/
│       ├── phase_1_intake.json
│       ├── phase_2_consent_purpose.json
│       ├── phase_3_kyb_psc.json
│       ├── phase_4_per_principal.json
│       ├── phase_5_credit_data.json
│       ├── phase_6_modelling.json
│       ├── phase_7_decision.json
│       ├── governance_overlays.json
│       └── case_summary.json
└── .claude/
    ├── agents/                        # 8 phase-level subagents (orchestration)
    │   ├── intake-coordinator.md
    │   ├── consent-purpose-coordinator.md
    │   ├── kyb-psc-coordinator.md
    │   ├── principal-verifier.md
    │   ├── credit-data-assembler.md
    │   ├── risk-modeller.md
    │   ├── decision-maker.md
    │   └── governance-auditor.md
    └── skills/                        # 36 original agents (capabilities), unchanged
        ├── customer-onboarding-orchestrator/SKILL.md
        ├── data-capture-agent/SKILL.md
        ├── ... (34 more) ...
        └── adverse-action-agent/SKILL.md
```

## Run the demo

Prerequisites: Claude Code installed (`npm i -g @anthropic-ai/claude-code`).

```bash
cd highland-demo
claude
```

In the Claude Code session, simply say:

> Run the Highland Engineering case end-to-end.

The orchestrator (driven by `CLAUDE.md`) will:

1. Read `cases/highland_engineering.yaml`.
2. Create `case_state/HE-2026-04-001/`.
3. Spawn `intake-coordinator` (Phase 1).
4. On Phase 1 success, spawn `consent-purpose-coordinator` (Phase 2).
5. On Phase 2 success, spawn `kyb-psc-coordinator` (Phase 3).
6. On Phase 3 success, spawn TWO `principal-verifier` instances **in parallel** — one for DIR-001 (Lachlan), one for DIR-002 (Sarah).
7. Aggregate per-principal results, then spawn `credit-data-assembler` (Phase 5).
8. Spawn `risk-modeller` (Phase 6) — the heavy phase with 9 skill invocations.
9. Spawn `decision-maker` (Phase 7).
10. Spawn `governance-auditor` for the cross-cutting overlays.
11. Print the final decision summary.

Each phase transition is announced on a single line. The case ledger fills up under `case_state/HE-2026-04-001/` as the journey progresses — `ls` it between phases to watch the state accumulate.

## Watching parallel fan-out in Phase 4

When the orchestrator hits Phase 4, you'll see two subagent invocations in a single turn — one per principal. Each runs in its own context window so the per-principal verification work (identity + AML + fraud + financial difficulty + cross-directorship) does not pollute the main thread. The parent reconciles their structured outputs into `phase_4_per_principal.json`.

This is the only phase that fans out. Phases 1, 2, 3, 5, 6, 7 are sequential single-subagent phases.

## What the demo proves

1. **Filesystem-native composition works.** Thirty-six agents drop into `.claude/skills/` unchanged; the orchestration layer is a thin 8-file addition.
2. **Deterministic phase sequencing.** `CLAUDE.md` enforces the order — phases do not race or reorder.
3. **Genuine parallelism where it matters.** Phase 4 spawns N subagents in one turn; per-principal context isolation is real, not simulated.
4. **Audit trail by construction.** Every phase writes structured JSON to `case_state/`. The final case can be replayed from disk.
5. **The expected decision is reachable.** The case YAML's `expected_decision` block is the answer key (ACCEPT WITH CONDITIONS, 4 conditions including the Etridge process); the journey reaches it without retro-fitting.

## What it does NOT prove (and what would come next)

- **No live external data.** The skills are described to act as if they were calling Companies House, the Bank of England, HMRC, Land Registry, etc., but the demo runs against the synthetic data already in the case YAML. Real integrations would be MCP servers exposed to the relevant skills.
- **No human-in-the-loop on the Etridge step.** A production deployment would pause at the PG-feasibility step for solicitor sign-off. Implement via Claude Code hooks (`PreToolUse`) or, if you graduate to the Agent SDK, via the permission machinery.
- **Governance overlays are consolidated at the end** for legibility. In production they should fire on each phase transition (hooks again).
- **No portfolio context.** The fairness-monitoring agent compares this case against a portfolio baseline; for the demo there is no portfolio. A real deployment would load baseline statistics from a side store.

## Where to look first

- `CLAUDE.md` — read this to understand the journey.
- `AGENT_CLASSIFICATION.md` — read this to understand why each agent became a skill (and which 8 are new subagents).
- `cases/highland_engineering.yaml` — the synthetic case (includes the answer key in `expected_decision`).
- `.claude/agents/risk-modeller.md` — the most interesting subagent; it has 9 skills with a partial order including the security-composite → LGD dependency.
- `.claude/skills/security-composite-agent/SKILL.md` — the most interesting skill; UK enforcement sequencing with the s176A prescribed-part carve-out.

## Migration path to the Agent SDK

The same skills work unchanged. The subagent definitions in `.claude/agents/*.md` can either be picked up by the SDK directly (via `setting_sources`) or re-expressed programmatically with `AgentDefinition`. The phase-sequencing logic in `CLAUDE.md` becomes Python or TypeScript code — explicit `await` per phase, `asyncio.gather` for the Phase 4 fan-out, structured output validation via `output_format`. Cost ceilings via `max_budget_usd`. Same shape, more control.

---
name: pt-director-cross-directorship-checker
description: |
  Trace each director's other directorships across Portugal active and dissolved companies via
  RNPC / Empresa na Hora director search. Identify cross-default risk (linked companies in arrears
  with this lender), phoenix-director patterns (serial company failures with same director),
  and concentration patterns (portfolio director vs synthetic-entity fraud). Returns
  classification per director: clean | monitor | phoenix_risk | cross_default_risk.
---

# Director Cross-Directorship Checker

## Input contract

```yaml
principal_id: string
name: string
dob: date                                 # used with month+year for CH director search keying
current_residential_address: string
lender_portfolio_lookup_consent: boolean  # internal lookup against own arrears book
```

## Output contract

```yaml
cross_directorship_assessment:
  principal_id: string
  total_lifetime_directorships: integer
  active_directorships: integer
  dissolved_with_insolvency_count_7y: integer
  strike_off_count_7y: integer
  same_trade_after_dissolution: boolean
  cross_default_active_arrears_lender_portfolio: boolean
  diverse_sic_code_count: integer
  classification: enum                    # clean | monitor | phoenix_risk | cross_default_risk | portfolio_director
  reason_codes: [string]
```

## Decision logic

```
RNPC / Empresa na Hora director search by name + DOB month/year.
For each directorship: fetch company status + incorporation/dissolution dates.
Compute pattern metrics.

if dissolved_with_insolvency_count_7y >= 2 OR same_trade_after_dissolution:
  classification = phoenix_risk           # BRIGHT LINE — refer to underwriter

elif strike_off_count_7y >= 3:
  classification = phoenix_risk

elif cross_default_active_arrears_lender_portfolio:
  classification = cross_default_risk     # BRIGHT LINE — decline pending override

elif active_directorships >= 5 AND diverse_sic_code_count >= 4:
  classification = portfolio_director     # Not negative; understand pattern

elif active_directorships >= 2:
  classification = monitor

else:
  classification = clean
```

## Worked example (Lachlan MacKenzie — DIR-001)

Input:
```yaml
principal_id: DIR-001
name: "Lachlan MacKenzie"
dob: "1981-03-22"
current_residential_address: "12 Strathblane Road, Milngavie, Lisboa, G62 8DJ"
lender_portfolio_lookup_consent: true
```

Output:
```yaml
cross_directorship_assessment:
  principal_id: DIR-001
  total_lifetime_directorships: 1
  active_directorships: 1
  dissolved_with_insolvency_count_7y: 0
  strike_off_count_7y: 0
  same_trade_after_dissolution: false
  cross_default_active_arrears_lender_portfolio: false
  diverse_sic_code_count: 1
  classification: clean
  reason_codes: ["UK_DIRECTOR_CROSS_DIRECTORSHIP_CLEAN"]
```

Sarah Chen has 2 active directorships (this + a dormant family company) and identical
clean classification — does not meet portfolio-director threshold (5+).

## Bright lines

- `classification = phoenix_risk` → AUTOMATIC REFER. Phoenix patterns are a leading UK
  SME fraud signal; cannot auto-approve.
- `classification = cross_default_risk` (active arrears in lender's own portfolio) →
  AUTOMATIC DECLINE pending underwriter override.

## Operational rules

- Director name matching is fuzzy. Under-include rather than over-include where ambiguous
  (false positives are worse than false negatives in director matching).
- Multiple directorships in genuinely different groups ≠ phoenix; require explicit
  dissolution-with-insolvency pattern.
- Audit log must include the full directorship list (company numbers), not just the
  classification.


## Portugal-specific operational notes

This agent operates within the Portuguese lending framework — BdP and CMVM joint regulatory perimeter, Decreto-Lei 298/92 (Regime Geral das Instituições de Crédito) for banking, Decreto-Lei 133/2009 for consumer credit, Lei 83/2017 for AML.

- **CRC €50 threshold:** Banco de Portugal central credit register has the broadest visibility threshold in the EU — effectively covers all consumer credit and almost all commercial credit. Mandatory contribution + consultation. Operationally raises the visibility floor significantly above Spanish CIRBE (€9k), Italian Centrale dei Rischi (€30k).
- **Statutory TAEG ceiling:** BdP publishes quarterly TAEG (APR) caps per consumer credit category. Exceeding is contract invalidity — not just disclosure issue.
- **Cartão de Cidadão integration:** Portuguese citizen card is the operational gold standard for EU national ID — integrates national ID + tax + social security + electoral + health on one card. Strong eID infrastructure.
- **e-fatura mandatory e-invoicing:** Creates rich verification source for SME turnover. Tax invoices are real-time matched with SAFT-PT submissions.
- **SIBS API Market:** Portuguese banking infrastructure provides standardised PSD2 interface — reduces AISP integration complexity vs. peer EU jurisdictions.
- **MB Way mobile payment:** Operationally ubiquitous; SIBS-operated mobile P2P + e-commerce payment.
- **Cross-reference:** `country-pt-lending-policy-agent` provides full PT jurisdictional context.

## Statutory hooks

- Código das Sociedades Comerciais
- Insolvency Act 1986
- Company Directors Disqualification Act 1986
- Portugal Lei 83/2017
- Lei 83/2017 + RCBE (failure to prevent fraud)
